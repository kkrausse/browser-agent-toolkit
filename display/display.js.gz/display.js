var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined")
    return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// ../../packages/terminal/ghostty-web/src/official-abi.ts
var manifests = new WeakMap;
function check(result) {
  if (result !== 0)
    throw new Error(`Official libghostty-vt error ${result}`);
}

class OfficialABI {
  exports;
  types;
  cachedView;
  cachedBytes;
  get memory() {
    return this.exports.memory;
  }
  get view() {
    const buffer = this.memory.buffer;
    if (this.cachedView?.buffer !== buffer || this.cachedView.byteLength !== buffer.byteLength)
      this.cachedView = new DataView(buffer);
    return this.cachedView;
  }
  get bytes() {
    const buffer = this.memory.buffer;
    if (this.cachedBytes?.buffer !== buffer || this.cachedBytes.byteLength !== buffer.byteLength)
      this.cachedBytes = new Uint8Array(buffer);
    return this.cachedBytes;
  }
  constructor(exports) {
    this.exports = exports;
    const cached = manifests.get(exports);
    if (cached) {
      this.types = cached;
      return;
    }
    if (typeof this.exports.ghostty_type_json !== "function")
      throw new Error("Expected official libghostty-vt WASM with type manifest");
    const ptr = this.exports.ghostty_type_json();
    const bytes = this.bytes;
    const manifest = JSON.parse(new TextDecoder().decode(bytes.subarray(ptr, bytes.indexOf(0, ptr))));
    if (manifest.abi.pointer_size !== 4 || manifest.abi.endian !== "little")
      throw new Error("Unsupported Ghostty ABI");
    this.types = manifest.types;
    manifests.set(exports, this.types);
  }
  alloc(size) {
    const ptr = this.exports.ghostty_wasm_alloc(size);
    if (!ptr)
      throw new Error("Ghostty WASM allocation failed");
    this.bytes.fill(0, ptr, ptr + size);
    return ptr;
  }
  free(ptr, size) {
    this.exports.ghostty_wasm_free(ptr, size);
  }
  with(size, fn) {
    const ptr = this.alloc(size);
    try {
      return fn(ptr);
    } finally {
      this.free(ptr, size);
    }
  }
  create(name, ...args) {
    return this.with(4, (ptr) => {
      check(this.exports[name](0, ptr, ...args));
      return this.view.getUint32(ptr, true);
    });
  }
  sized(ptr, name) {
    this.view.setUint32(ptr, this.types[name].size, true);
  }
  field(name, field) {
    return this.types[name].fields[field].offset;
  }
}
var callbackModule = new WebAssembly.Module(new Uint8Array([
  0,
  97,
  115,
  109,
  1,
  0,
  0,
  0,
  1,
  8,
  1,
  96,
  4,
  127,
  127,
  127,
  127,
  0,
  2,
  7,
  1,
  1,
  101,
  1,
  102,
  0,
  0,
  7,
  5,
  1,
  1,
  102,
  0,
  0
]));
var freeSlots = new WeakMap;
function registerWriteCallback(abi, fn) {
  const table = abi.exports.__indirect_function_table;
  let slots = freeSlots.get(table);
  if (!slots)
    freeSlots.set(table, slots = []);
  const index = slots.pop() ?? table.grow(1);
  const instance = new WebAssembly.Instance(callbackModule, { e: { f: fn } });
  table.set(index, instance.exports.f);
  return { index, dispose() {
    table.set(index, null);
    slots.push(index);
  } };
}

// ../../packages/terminal/ghostty-web/src/official-terminal.ts
class GhosttyTerminal {
  a;
  handle = 0;
  state = 0;
  iterator = 0;
  rowCells = 0;
  scratch = 0;
  callback;
  responses = [];
  responseDecoder = new TextDecoder;
  changed = true;
  cells = [];
  dirtyRows = [];
  _cols;
  _rows;
  rawFields;
  flagFields;
  underlineOffset = 0;
  fgOffset = 0;
  bgOffset = 0;
  colorValueOffset = 0;
  palette = new Uint32Array(256);
  rowStyles = new Map;
  constructor(exports, _memory, cols = 80, rows = 24, config) {
    this.validateSize(cols, rows);
    if (config?.scrollbackLimit !== undefined && (!Number.isInteger(config.scrollbackLimit) || config.scrollbackLimit < 0 || config.scrollbackLimit > 4294967295)) {
      throw new RangeError("scrollbackLimit must be an unsigned 32-bit integer");
    }
    this.a = new OfficialABI(exports);
    const fields = this.a.types.GhosttyCell.bits;
    this.rawFields = {};
    for (const name of ["content_tag", "content", "style_id", "wide", "hyperlink"]) {
      const { lsb, width } = fields[name];
      const mask = 2 ** width - 1;
      this.rawFields[name] = lsb >= 32 ? (_lo, hi) => hi >>> lsb - 32 & mask : lsb + width <= 32 ? (lo, _hi) => lo >>> lsb & mask : (lo, hi) => (lo >>> lsb | hi << 32 - lsb) & mask;
    }
    this.flagFields = Object.entries({
      bold: 1 /* BOLD */,
      italic: 2 /* ITALIC */,
      faint: 128 /* FAINT */,
      blink: 64 /* BLINK */,
      inverse: 16 /* INVERSE */,
      invisible: 32 /* INVISIBLE */,
      strikethrough: 8 /* STRIKETHROUGH */
    }).map(([name, flag]) => [this.a.field("GhosttyStyle", name), flag]);
    this.underlineOffset = this.a.field("GhosttyStyle", "underline");
    this.fgOffset = this.a.field("GhosttyStyle", "fg_color");
    this.bgOffset = this.a.field("GhosttyStyle", "bg_color");
    this.colorValueOffset = this.a.field("GhosttyStyleColor", "value");
    this._cols = cols;
    this._rows = rows;
    const a = this.a, e = a.exports;
    try {
      this.scratch = a.alloc(2048);
      this.handle = a.create("ghostty_terminal_new", cols, rows);
      this.state = a.create("ghostty_render_state_new");
      this.iterator = a.create("ghostty_render_state_row_iterator_new");
      this.rowCells = a.create("ghostty_render_state_row_cells_new");
      this.callback = registerWriteCallback(a, (_terminal, _userdata, ptr, len) => {
        this.responses.push(a.bytes.slice(ptr, ptr + len));
      });
      check(e.ghostty_terminal_set(this.handle, 1, this.callback.index));
      a.view.setUint32(this.scratch, config?.scrollbackLimit ?? 1e4, true);
      check(e.ghostty_terminal_set(this.handle, 28, this.scratch));
      a.view.setUint16(this.scratch, 2027, true);
      a.view.setUint8(this.scratch + 2, 1);
      check(e.ghostty_terminal_set(this.handle, 33, this.scratch));
      for (const [option, color] of [[11, config?.fgColor], [12, config?.bgColor], [13, config?.cursorColor]]) {
        if (color !== undefined && color !== 0) {
          a.bytes.set([color >>> 16 & 255, color >>> 8 & 255, color & 255], this.scratch);
          check(e.ghostty_terminal_set(this.handle, option, this.scratch));
        }
      }
      if (config?.palette) {
        check(e.ghostty_terminal_get(this.handle, 21, this.scratch));
        for (let i = 0;i < Math.min(config.palette.length, 256); i++) {
          const color = config.palette[i];
          if (color === undefined || color === 0)
            continue;
          a.bytes.set([color >>> 16 & 255, color >>> 8 & 255, color & 255], this.scratch + i * 3);
        }
        check(e.ghostty_terminal_set(this.handle, 14, this.scratch));
      }
    } catch (error) {
      this.free();
      throw error;
    }
  }
  get cols() {
    return this._cols;
  }
  get rows() {
    return this._rows;
  }
  alive() {
    if (!this.handle)
      throw new Error("Terminal has been freed");
  }
  validateSize(cols, rows) {
    if (![cols, rows].every((n) => Number.isInteger(n) && n > 0 && n <= 65535))
      throw new RangeError("Terminal dimensions must be integers in 1..65535");
  }
  write(data) {
    this.alive();
    const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
    if (!bytes.length)
      return;
    this.a.with(bytes.length, (ptr) => {
      this.a.bytes.set(bytes, ptr);
      this.a.exports.ghostty_terminal_vt_write(this.handle, ptr, bytes.length);
    });
    this.changed = true;
    if (this.terminalNumber(33, 1))
      throw new Error("Official Ghostty reported a VT processing error");
  }
  resize(cols, rows) {
    this.alive();
    this.validateSize(cols, rows);
    if (cols === this.cols && rows === this.rows)
      return;
    check(this.a.exports.ghostty_terminal_resize(this.handle, cols, rows, 0, 0));
    this._cols = cols;
    this._rows = rows;
    this.changed = true;
  }
  free() {
    const e = this.a.exports;
    if (this.handle)
      e.ghostty_terminal_free(this.handle);
    if (this.state)
      e.ghostty_render_state_free(this.state);
    if (this.iterator)
      e.ghostty_render_state_row_iterator_free(this.iterator);
    if (this.rowCells)
      e.ghostty_render_state_row_cells_free(this.rowCells);
    if (this.scratch)
      this.a.free(this.scratch, 2048);
    this.callback?.dispose();
    this.callback = undefined;
    this.handle = this.state = this.iterator = this.rowCells = this.scratch = 0;
    this.cells = [];
    this.responses = [];
  }
  number(fn, handle, key, size = 4) {
    const a = this.a;
    check(a.exports[fn](handle, key, this.scratch));
    return size === 1 ? a.view.getUint8(this.scratch) : size === 2 ? a.view.getUint16(this.scratch, true) : a.view.getUint32(this.scratch, true);
  }
  terminalNumber(key, size = 4) {
    this.alive();
    return this.number("ghostty_terminal_get", this.handle, key, size);
  }
  renderNumber(key, size = 4) {
    return this.number("ghostty_render_state_get", this.state, key, size);
  }
  update() {
    this.alive();
    if (this.changed) {
      check(this.a.exports.ghostty_render_state_update(this.state, this.handle));
      this.changed = false;
      this.snapshot();
    }
    return this.renderNumber(3);
  }
  rgb(ptr) {
    const b = this.a.bytes;
    return { r: b[ptr], g: b[ptr + 1], b: b[ptr + 2] };
  }
  getColors() {
    this.update();
    return this.colors();
  }
  colors() {
    const e = this.a.exports, ptr = this.scratch;
    check(e.ghostty_render_state_get(this.state, 5, ptr));
    const background = this.rgb(ptr);
    check(e.ghostty_render_state_get(this.state, 6, ptr));
    const foreground = this.rgb(ptr);
    let cursor = null;
    if (this.renderNumber(8, 1)) {
      check(e.ghostty_render_state_get(this.state, 7, ptr));
      cursor = this.rgb(ptr);
    }
    return { background, foreground, cursor };
  }
  getCursor() {
    this.update();
    const hasViewport = !!this.renderNumber(14, 1);
    return {
      x: this.terminalNumber(3, 2),
      y: this.terminalNumber(4, 2),
      viewportX: hasViewport ? this.renderNumber(15, 2) : -1,
      viewportY: hasViewport ? this.renderNumber(16, 2) : -1,
      visible: hasViewport && !!this.renderNumber(11, 1),
      blinking: !!this.renderNumber(12, 1),
      style: ["bar", "block", "underline", "block"][this.renderNumber(10)] ?? "block"
    };
  }
  isRowDirty(y) {
    this.update();
    return this.renderNumber(3) === 2 /* FULL */ || !!this.dirtyRows[y];
  }
  markClean() {
    this.update();
    check(this.a.exports.ghostty_render_state_clean(this.state));
    this.dirtyRows.fill(false);
  }
  clearDirty() {
    this.markClean();
  }
  isDirty() {
    return this.update() !== 0 /* NONE */;
  }
  needsFullRedraw() {
    return this.update() === 2 /* FULL */;
  }
  getViewport() {
    this.update();
    return this.cells;
  }
  getLine(y) {
    if (!Number.isInteger(y) || y < 0 || y >= this.rows)
      return null;
    return this.getViewport().slice(y * this.cols, (y + 1) * this.cols).map((c) => ({ ...c }));
  }
  styleFlags(ptr) {
    const a = this.a;
    let flags = 0;
    const bytes = a.bytes;
    for (const [offset, flag] of this.flagFields) {
      if (bytes[ptr + offset])
        flags |= flag;
    }
    if (a.view.getInt32(ptr + this.underlineOffset, true))
      flags |= 4 /* UNDERLINE */;
    return flags;
  }
  packed(raw, name) {
    const field = this.a.types.GhosttyCell.bits[name];
    return Number(raw >> BigInt(field.lsb) & (1n << BigInt(field.width)) - 1n);
  }
  baseCell(raw, foreground, background, flags, count) {
    const tag = this.packed(raw, "content_tag");
    const wide = this.packed(raw, "wide");
    return {
      codepoint: tag < 2 ? this.packed(raw, "content") & 2097151 : 0,
      fg_r: foreground.r,
      fg_g: foreground.g,
      fg_b: foreground.b,
      bg_r: background.r,
      bg_g: background.g,
      bg_b: background.b,
      flags,
      width: wide === 0 ? 1 : wide === 1 ? 2 : 0,
      hyperlink_id: this.packed(raw, "hyperlink"),
      grapheme_len: Math.max(0, count - 1)
    };
  }
  snapshot() {
    const a = this.a, e = a.exports, ptr = this.scratch;
    const dirty = this.renderNumber(3);
    if (dirty === 0 /* NONE */ && this.cells.length === this.cols * this.rows)
      return;
    const defaults = this.colors();
    const defaultFg = defaults.foreground.r << 16 | defaults.foreground.g << 8 | defaults.foreground.b;
    const defaultBg = defaults.background.r << 16 | defaults.background.g << 8 | defaults.background.b;
    check(e.ghostty_render_state_get(this.state, 9, ptr));
    const paletteBytes = a.bytes;
    for (let i = 0;i < 256; i++)
      this.palette[i] = paletteBytes[ptr + i * 3] << 16 | paletteBytes[ptr + i * 3 + 1] << 8 | paletteBytes[ptr + i * 3 + 2];
    const color = (view, at, fallback) => {
      const tag = view.getUint32(at, true), value = at + this.colorValueOffset;
      return tag === 1 ? this.palette[view.getUint8(value)] : tag === 2 ? view.getUint8(value) << 16 | view.getUint8(value + 1) << 8 | view.getUint8(value + 2) : fallback;
    };
    const rawTag = this.rawFields.content_tag, rawContent = this.rawFields.content, rawStyle = this.rawFields.style_id;
    const rawWide = this.rawFields.wide, rawLink = this.rawFields.hyperlink;
    a.view.setUint32(ptr, this.iterator, true);
    check(e.ghostty_render_state_get(this.state, 4, ptr));
    let y = 0;
    while (e.ghostty_render_state_row_iterator_next(this.iterator)) {
      this.dirtyRows[y] = !!this.number("ghostty_render_state_row_get", this.iterator, 1, 1);
      if (dirty !== 2 /* FULL */ && !this.dirtyRows[y] && this.cells.length === this.cols * this.rows) {
        y++;
        continue;
      }
      a.view.setUint32(ptr, this.rowCells, true);
      check(e.ghostty_render_state_row_get(this.iterator, 3, ptr));
      check(e.ghostty_render_state_row_get(this.iterator, 5, ptr));
      let view = a.view;
      const rawPtr = view.getUint32(ptr, true), count = view.getUint32(ptr + 4, true);
      if (count !== this.cols)
        throw new Error("Unexpected official bulk row width");
      this.rowStyles.clear();
      for (let x = 0;x < count; x++) {
        const lo = view.getUint32(rawPtr + x * 8, true), hi = view.getUint32(rawPtr + x * 8 + 4, true);
        const tag = rawTag(lo, hi), content = rawContent(lo, hi), styleID = rawStyle(lo, hi), wide = rawWide(lo, hi);
        let fg = defaultFg, bg = defaultBg, flags = 0, graphemeLength = 0;
        let selected = false;
        if (styleID) {
          let style = this.rowStyles.get(styleID);
          if (!style) {
            check(e.ghostty_render_state_row_cells_select(this.rowCells, x));
            selected = true;
            a.sized(ptr, "GhosttyStyle");
            check(e.ghostty_render_state_row_cells_get(this.rowCells, 2, ptr));
            view = a.view;
            style = { fg: color(view, ptr + this.fgOffset, defaultFg), bg: color(view, ptr + this.bgOffset, defaultBg), flags: this.styleFlags(ptr) };
            this.rowStyles.set(styleID, style);
          }
          fg = style.fg;
          bg = style.bg;
          flags = style.flags;
        }
        if (tag === 2)
          bg = this.palette[content & 255];
        else if (tag === 3)
          bg = (content & 255) << 16 | content & 65280 | content >>> 16;
        else if (tag === 1) {
          if (!selected)
            check(e.ghostty_render_state_row_cells_select(this.rowCells, x));
          graphemeLength = Math.max(0, this.number("ghostty_render_state_row_cells_get", this.rowCells, 3) - 1);
          view = a.view;
        }
        const index = y * this.cols + x;
        let cell = this.cells[index];
        if (!cell)
          this.cells[index] = cell = { codepoint: 0, fg_r: 0, fg_g: 0, fg_b: 0, bg_r: 0, bg_g: 0, bg_b: 0, flags: 0, width: 1, hyperlink_id: 0, grapheme_len: 0 };
        cell.codepoint = tag < 2 ? content & 2097151 : 0;
        cell.fg_r = fg >>> 16;
        cell.fg_g = fg >>> 8 & 255;
        cell.fg_b = fg & 255;
        cell.bg_r = bg >>> 16;
        cell.bg_g = bg >>> 8 & 255;
        cell.bg_b = bg & 255;
        cell.flags = flags;
        cell.width = wide === 0 ? 1 : wide === 1 ? 2 : 0;
        cell.hyperlink_id = rawLink(lo, hi);
        cell.grapheme_len = graphemeLength;
      }
      y++;
    }
    this.cells.length = this.cols * this.rows;
    this.dirtyRows.length = this.rows;
  }
  isAlternateScreen() {
    return this.terminalNumber(6) !== 0;
  }
  hasBracketedPaste() {
    return this.getMode(2004);
  }
  hasFocusEvents() {
    return this.getMode(1004);
  }
  hasMouseTracking() {
    return this.terminalNumber(11, 1) !== 0;
  }
  getMode(mode, isAnsi = false) {
    this.alive();
    if (!Number.isInteger(mode) || mode < 0 || mode > 32767)
      throw new RangeError("Invalid mode number");
    this.a.view.setUint16(this.scratch, mode | (isAnsi ? 32768 : 0), true);
    const result = this.a.exports.ghostty_terminal_get(this.handle, 37, this.scratch);
    if (result === -2)
      return false;
    check(result);
    return !!this.a.view.getUint8(this.scratch + 2);
  }
  getDimensions() {
    return { cols: this.cols, rows: this.rows };
  }
  getScrollbackLength() {
    return this.terminalNumber(15);
  }
  syncKeyEncoder(encoder) {
    this.alive();
    encoder.syncFromTerminal(this.handle);
  }
  hasResponse() {
    this.alive();
    return this.responses.length > 0;
  }
  readResponse() {
    if (!this.hasResponse())
      return null;
    const response = this.responses.map((bytes) => this.responseDecoder.decode(bytes, { stream: true })).join("");
    this.responses = [];
    return response;
  }
  grid(row, col, history, fn) {
    this.alive();
    if (!Number.isInteger(row) || !Number.isInteger(col) || row < 0 || col < 0 || col >= this.cols || row >= (history ? this.getScrollbackLength() : this.rows))
      return null;
    const a = this.a;
    const pointSize = a.types.GhosttyPoint.size;
    return a.with(pointSize + a.types.GhosttyGridRef.size, (ptr) => {
      a.view.setUint32(ptr, history ? 3 : 0, true);
      a.view.setUint16(ptr + a.field("GhosttyPoint", "value"), col, true);
      a.view.setUint32(ptr + a.field("GhosttyPoint", "value") + a.field("GhosttyPointCoordinate", "y"), row, true);
      const ref = ptr + pointSize;
      a.sized(ref, "GhosttyGridRef");
      check(a.exports.ghostty_terminal_grid_ref(this.handle, ptr, ref));
      return fn(ref);
    });
  }
  variable(ref, name, unit) {
    const a = this.a, fn = a.exports[name];
    return a.with(4, (len) => {
      const result = fn(ref, 0, 0, len);
      if (result !== 0 && result !== -3)
        check(result);
      const count = a.view.getUint32(len, true);
      if (!count)
        return new Uint8Array;
      return a.with(count * unit, (ptr) => {
        check(fn(ref, ptr, count, len));
        return a.bytes.slice(ptr, ptr + a.view.getUint32(len, true) * unit);
      });
    });
  }
  grapheme(row, col, history) {
    return this.grid(row, col, history, (ref) => {
      const bytes = this.variable(ref, "ghostty_grid_ref_graphemes", 4);
      return Array.from(new Uint32Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 4));
    });
  }
  getGrapheme(row, col) {
    return this.grapheme(row, col, false);
  }
  getScrollbackGrapheme(row, col) {
    return this.grapheme(row, col, true);
  }
  getGraphemeString(row, col) {
    const g = this.getGrapheme(row, col);
    return g?.length ? g.map((c) => String.fromCodePoint(c)).join("") : " ";
  }
  getScrollbackGraphemeString(row, col) {
    const g = this.getScrollbackGrapheme(row, col);
    return g?.length ? g.map((c) => String.fromCodePoint(c)).join("") : " ";
  }
  getHyperlinkUri(row, col) {
    return this.grid(row, col, false, (ref) => new TextDecoder().decode(this.variable(ref, "ghostty_grid_ref_hyperlink_uri", 1))) || null;
  }
  getScrollbackHyperlinkUri(row, col) {
    return this.grid(row, col, true, (ref) => new TextDecoder().decode(this.variable(ref, "ghostty_grid_ref_hyperlink_uri", 1))) || null;
  }
  isRowWrapped(row) {
    return this.grid(row, 0, false, (ref) => {
      check(this.a.exports.ghostty_grid_ref_row(ref, this.scratch));
      const raw = this.a.view.getBigUint64(this.scratch, true);
      check(this.a.exports.ghostty_row_get(raw, 2, this.scratch));
      return !!this.a.view.getUint8(this.scratch);
    }) ?? false;
  }
  getScrollbackLine(row) {
    if (!Number.isInteger(row) || row < 0 || row >= this.getScrollbackLength())
      return null;
    this.update();
    const defaults = this.colors(), a = this.a, e = a.exports;
    check(e.ghostty_render_state_get(this.state, 9, this.scratch));
    const palette = a.bytes.slice(this.scratch, this.scratch + 768);
    const resolve = (ptr, fallback) => {
      const tag = a.view.getUint32(ptr, true), value = ptr + a.field("GhosttyStyleColor", "value");
      if (tag === 2)
        return this.rgb(value);
      if (tag === 1) {
        const i = a.bytes[value] * 3;
        return { r: palette[i], g: palette[i + 1], b: palette[i + 2] };
      }
      return fallback;
    };
    const result = [];
    for (let col = 0;col < this.cols; col++) {
      result.push(this.grid(row, col, true, (ref) => {
        const ptr = this.scratch;
        check(e.ghostty_grid_ref_cell(ref, ptr));
        const raw = a.view.getBigUint64(ptr, true);
        a.sized(ptr, "GhosttyStyle");
        check(e.ghostty_grid_ref_style(ref, ptr));
        const flags = this.styleFlags(ptr);
        const fg = resolve(ptr + a.field("GhosttyStyle", "fg_color"), defaults.foreground);
        let bg = resolve(ptr + a.field("GhosttyStyle", "bg_color"), defaults.background);
        const tag = this.packed(raw, "content_tag"), content = this.packed(raw, "content");
        if (tag === 2) {
          const i = (content & 255) * 3;
          bg = { r: palette[i], g: palette[i + 1], b: palette[i + 2] };
        }
        if (tag === 3)
          bg = { r: content & 255, g: content >>> 8 & 255, b: content >>> 16 & 255 };
        const count = this.variable(ref, "ghostty_grid_ref_graphemes", 4).length / 4;
        return this.baseCell(raw, fg, bg, flags, count);
      }));
    }
    return result;
  }
}

// ../../packages/terminal/ghostty-web/src/official-key.ts
class KeyEncoder {
  abi;
  handle;
  constructor(exports) {
    this.abi = new OfficialABI(exports);
    this.handle = this.abi.create("ghostty_key_encoder_new");
  }
  setOption(option, value) {
    this.alive();
    this.abi.with(4, (ptr) => {
      this.abi.view.setUint32(ptr, Number(value), true);
      this.abi.exports.ghostty_key_encoder_setopt(this.handle, option, ptr);
    });
  }
  setKittyFlags(flags) {
    this.setOption(5 /* KITTY_KEYBOARD_FLAGS */, flags);
  }
  setTerminal(terminal) {
    terminal.syncKeyEncoder(this);
  }
  syncFromTerminal(handle) {
    this.alive();
    this.abi.exports.ghostty_key_encoder_setopt_from_terminal(this.handle, handle);
  }
  encode(event) {
    this.alive();
    const a = this.abi, e = a.exports;
    const key = a.create("ghostty_key_event_new");
    const text = new TextEncoder().encode(event.utf8 ?? "");
    let ptr = 0;
    try {
      if (text.length)
        ptr = a.alloc(text.length);
      e.ghostty_key_event_set_action(key, event.action);
      e.ghostty_key_event_set_key(key, event.key >= 146 ? event.key + 1 : event.key);
      e.ghostty_key_event_set_mods(key, event.mods);
      e.ghostty_key_event_set_consumed_mods(key, event.consumedMods ?? 0);
      e.ghostty_key_event_set_composing(key, event.composing ? 1 : 0);
      e.ghostty_key_event_set_unshifted_codepoint(key, event.unshiftedCodepoint ?? 0);
      if (ptr) {
        a.bytes.set(text, ptr);
        e.ghostty_key_event_set_utf8(key, ptr, text.length);
      }
      return a.with(4, (written) => {
        const result = e.ghostty_key_encoder_encode(this.handle, key, 0, 0, written);
        if (result !== 0 && result !== -3)
          check(result);
        const size = a.view.getUint32(written, true);
        if (!size)
          return new Uint8Array;
        return a.with(size, (out) => {
          check(e.ghostty_key_encoder_encode(this.handle, key, out, size, written));
          return a.bytes.slice(out, out + a.view.getUint32(written, true));
        });
      });
    } finally {
      if (ptr)
        a.free(ptr, text.length);
      e.ghostty_key_event_free(key);
    }
  }
  alive() {
    if (!this.handle)
      throw new Error("Key encoder has been disposed");
  }
  dispose() {
    if (this.handle) {
      this.abi.exports.ghostty_key_encoder_free(this.handle);
      this.handle = 0;
    }
  }
}
// ../../packages/terminal/ghostty-web/src/ghostty.ts
class Ghostty {
  abi;
  constructor(instance) {
    this.abi = new OfficialABI(instance.exports);
  }
  createKeyEncoder() {
    return new KeyEncoder(this.abi.exports);
  }
  createTerminal(cols = 80, rows = 24, config) {
    return new GhosttyTerminal(this.abi.exports, this.abi.memory, cols, rows, config);
  }
  static async load(path) {
    const url = path ?? (typeof Bun !== "undefined" || typeof window === "undefined" ? new URL("../vendor/ghostty-vt.wasm", import.meta.url).href : "/ghostty-vt.wasm");
    let bytes;
    if (url.startsWith("file:") || !/^https?:/.test(url) && typeof window === "undefined") {
      const { readFile } = await import("node:fs/promises");
      const data = await readFile(url.startsWith("file:") ? new URL(url) : url);
      bytes = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
    } else {
      const response = await fetch(url);
      if (!response.ok)
        throw new Error(`Failed to fetch official Ghostty WASM: ${response.status}`);
      bytes = await response.arrayBuffer();
    }
    const { instance } = await WebAssembly.instantiate(bytes, {});
    return new Ghostty(instance);
  }
}

// ../../packages/terminal/ghostty-web/src/event-emitter.ts
class EventEmitter {
  listeners = [];
  fire(arg) {
    for (const listener of this.listeners) {
      listener(arg);
    }
  }
  event = (listener) => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        const index = this.listeners.indexOf(listener);
        if (index >= 0) {
          this.listeners.splice(index, 1);
        }
      }
    };
  };
  dispose() {
    this.listeners = [];
  }
}

// ../../packages/terminal/ghostty-web/src/buffer.ts
class BufferNamespace {
  terminal;
  bufferChangeEmitter = new EventEmitter;
  _normalBuffer;
  _alternateBuffer;
  constructor(terminal) {
    this.terminal = terminal;
  }
  get active() {
    const wasmTerm = this.terminal.wasmTerm;
    if (!wasmTerm) {
      return this.normal;
    }
    return wasmTerm.isAlternateScreen() ? this.alternate : this.normal;
  }
  get normal() {
    if (!this._normalBuffer) {
      this._normalBuffer = new Buffer(this.terminal, "normal");
    }
    return this._normalBuffer;
  }
  get alternate() {
    if (!this._alternateBuffer) {
      this._alternateBuffer = new Buffer(this.terminal, "alternate");
    }
    return this._alternateBuffer;
  }
  get onBufferChange() {
    return this.bufferChangeEmitter.event;
  }
  _fireBufferChange(buffer) {
    this.bufferChangeEmitter.fire(buffer);
  }
}

class Buffer {
  terminal;
  bufferType;
  nullCell;
  constructor(terminal, type) {
    this.terminal = terminal;
    this.bufferType = type;
    const nullCellData = {
      codepoint: 0,
      fg_r: 204,
      fg_g: 204,
      fg_b: 204,
      bg_r: 0,
      bg_g: 0,
      bg_b: 0,
      flags: 0,
      width: 1,
      hyperlink_id: 0,
      grapheme_len: 0
    };
    this.nullCell = new BufferCell(nullCellData, 0);
  }
  get type() {
    return this.bufferType;
  }
  get cursorX() {
    const wasmTerm = this.getWasmTerm();
    if (!wasmTerm)
      return 0;
    return wasmTerm.getCursor().x;
  }
  get cursorY() {
    const wasmTerm = this.getWasmTerm();
    if (!wasmTerm)
      return 0;
    return wasmTerm.getCursor().y;
  }
  get viewportY() {
    const base = this.baseY;
    return base - Math.max(0, Math.min(base, Math.floor(this.terminal.getViewportY())));
  }
  get baseY() {
    return this.bufferType === "normal" ? this.getWasmTerm()?.getScrollbackLength() ?? 0 : 0;
  }
  get length() {
    const wasmTerm = this.getWasmTerm();
    if (!wasmTerm)
      return 0;
    if (this.bufferType === "alternate") {
      return wasmTerm.rows;
    } else {
      const scrollback = wasmTerm.getScrollbackLength();
      return scrollback + wasmTerm.rows;
    }
  }
  getLine(y) {
    const wasmTerm = this.getWasmTerm();
    if (!wasmTerm)
      return;
    if (!Number.isInteger(y) || y < 0 || y >= this.length) {
      return;
    }
    const scrollbackLength = wasmTerm.getScrollbackLength();
    let cells;
    let lineNumber = y;
    let isWrapped;
    if (this.bufferType === "normal" && y < scrollbackLength) {
      const scrollbackOffset = y;
      cells = wasmTerm.getScrollbackLine(scrollbackOffset);
      isWrapped = false;
    } else {
      lineNumber = this.bufferType === "normal" ? y - scrollbackLength : y;
      cells = wasmTerm.getLine(lineNumber);
      isWrapped = wasmTerm.isRowWrapped(lineNumber);
    }
    if (!cells) {
      return;
    }
    const history = this.bufferType === "normal" && y < scrollbackLength;
    const graphemes = cells.map((cell, col) => cell.width !== 0 && cell.grapheme_len > 0 ? history ? wasmTerm.getScrollbackGraphemeString(y, col) : wasmTerm.getGraphemeString(lineNumber, col) : undefined);
    return new BufferLine(cells, isWrapped, wasmTerm.cols, graphemes);
  }
  getNullCell() {
    return this.nullCell;
  }
  getWasmTerm() {
    const wasmTerm = this.terminal.wasmTerm;
    if (!wasmTerm || wasmTerm.isAlternateScreen() !== (this.bufferType === "alternate")) {
      return;
    }
    return wasmTerm;
  }
}

class BufferLine {
  graphemes;
  cells;
  _isWrapped;
  _length;
  constructor(cells, isWrapped, length, graphemes = []) {
    this.graphemes = graphemes;
    this.cells = cells;
    this._isWrapped = isWrapped;
    this._length = length;
  }
  get length() {
    return this._length;
  }
  get isWrapped() {
    return this._isWrapped;
  }
  getCell(x) {
    if (!Number.isInteger(x) || x < 0 || x >= this._length) {
      return;
    }
    if (x >= this.cells.length) {
      return new BufferCell({
        codepoint: 0,
        fg_r: 204,
        fg_g: 204,
        fg_b: 204,
        bg_r: 0,
        bg_g: 0,
        bg_b: 0,
        flags: 0,
        width: 1,
        hyperlink_id: 0,
        grapheme_len: 0
      }, x);
    }
    return new BufferCell(this.cells[x], x, this.graphemes[x]);
  }
  translateToString(trimRight = false, startColumn = 0, endColumn = this._length) {
    const start = Math.max(0, Math.min(startColumn, this._length));
    const end = Math.max(start, Math.min(endColumn, this._length));
    let result = "";
    for (let x = start;x < end; x++) {
      const cell = this.getCell(x);
      if (cell) {
        const chars = cell.getChars();
        result += chars || (cell.getWidth() === 0 ? "" : " ");
      }
    }
    if (trimRight) {
      result = result.trimEnd();
    }
    return result;
  }
}

class BufferCell {
  grapheme;
  cell;
  x;
  constructor(cell, x, grapheme) {
    this.grapheme = grapheme;
    this.cell = cell;
    this.x = x;
  }
  getChars() {
    if (this.cell.width === 0)
      return "";
    if (this.grapheme !== undefined)
      return this.grapheme;
    const codepoint = this.cell.codepoint;
    if (codepoint === 0) {
      return "";
    }
    if (codepoint < 0 || codepoint > 1114111 || codepoint >= 55296 && codepoint <= 57343) {
      return "�";
    }
    return String.fromCodePoint(codepoint);
  }
  getCode() {
    return this.cell.codepoint;
  }
  getWidth() {
    return this.cell.width;
  }
  getFgColorMode() {
    return -1;
  }
  getBgColorMode() {
    return -1;
  }
  getFgColor() {
    return this.cell.fg_r << 16 | this.cell.fg_g << 8 | this.cell.fg_b;
  }
  getBgColor() {
    return this.cell.bg_r << 16 | this.cell.bg_g << 8 | this.cell.bg_b;
  }
  isBold() {
    return (this.cell.flags & 1 /* BOLD */) !== 0 ? 1 : 0;
  }
  isItalic() {
    return (this.cell.flags & 2 /* ITALIC */) !== 0 ? 1 : 0;
  }
  isUnderline() {
    return (this.cell.flags & 4 /* UNDERLINE */) !== 0 ? 1 : 0;
  }
  isStrikethrough() {
    return (this.cell.flags & 8 /* STRIKETHROUGH */) !== 0 ? 1 : 0;
  }
  isBlink() {
    return (this.cell.flags & 64 /* BLINK */) !== 0 ? 1 : 0;
  }
  isInverse() {
    return (this.cell.flags & 16 /* INVERSE */) !== 0 ? 1 : 0;
  }
  isInvisible() {
    return (this.cell.flags & 32 /* INVISIBLE */) !== 0 ? 1 : 0;
  }
  isFaint() {
    return (this.cell.flags & 128 /* FAINT */) !== 0 ? 1 : 0;
  }
  getHyperlinkId() {
    return this.cell.hyperlink_id;
  }
  getCodepoint() {
    return this.cell.codepoint;
  }
  isDim() {
    return (this.cell.flags & 128 /* FAINT */) !== 0;
  }
}

// ../../packages/terminal/ghostty-web/src/ime.ts
class ImeOverlay {
  textarea;
  sync;
  overlay;
  composing = false;
  start = () => {
    this.composing = true;
    this.sync();
  };
  update = (event) => {
    this.overlay.textContent = event.data;
    this.sync();
  };
  end = () => {
    this.composing = false;
    this.overlay.textContent = "";
    this.overlay.style.display = "none";
    this.textarea.value = "";
  };
  constructor(textarea, sync) {
    this.textarea = textarea;
    this.sync = sync;
    this.overlay = document.createElement("span");
    this.overlay.setAttribute("aria-hidden", "true");
    Object.assign(this.overlay.style, {
      position: "absolute",
      pointerEvents: "none",
      whiteSpace: "pre",
      textDecoration: "underline",
      display: "none",
      zIndex: "1"
    });
    textarea.parentElement.appendChild(this.overlay);
    textarea.addEventListener("compositionstart", this.start);
    textarea.addEventListener("compositionupdate", this.update);
    textarea.addEventListener("compositionend", this.end);
    textarea.addEventListener("blur", this.end);
  }
  position(options) {
    const { left, top, width, height, fontFamily, fontSize, foreground, background, visible } = options;
    const style = {
      left: `${left}px`,
      top: `${top}px`,
      height: `${height}px`,
      fontFamily,
      fontSize: `${fontSize}px`,
      lineHeight: `${height}px`
    };
    if (this.textarea.style.position !== "fixed") {
      Object.assign(this.textarea.style, style, {
        width: `${width}px`,
        fontSize: `${Math.max(16, fontSize)}px`
      });
    }
    Object.assign(this.overlay.style, style, {
      color: foreground,
      backgroundColor: background,
      display: this.composing && visible ? "block" : "none"
    });
  }
  dispose() {
    this.textarea.removeEventListener("compositionstart", this.start);
    this.textarea.removeEventListener("compositionupdate", this.update);
    this.textarea.removeEventListener("compositionend", this.end);
    this.textarea.removeEventListener("blur", this.end);
    this.overlay.remove();
  }
}

// ../../packages/terminal/ghostty-web/src/theme.ts
var DEFAULT_THEME = {
  foreground: "#d4d4d4",
  background: "#1e1e1e",
  cursor: "#ffffff",
  cursorAccent: "#1e1e1e",
  selectionBackground: "#d4d4d4",
  selectionForeground: "#1e1e1e",
  black: "#000000",
  red: "#cd3131",
  green: "#0dbc79",
  yellow: "#e5e510",
  blue: "#2472c8",
  magenta: "#bc3fbc",
  cyan: "#11a8cd",
  white: "#e5e5e5",
  brightBlack: "#666666",
  brightRed: "#f14c4c",
  brightGreen: "#23d18b",
  brightYellow: "#f5f543",
  brightBlue: "#3b8eea",
  brightMagenta: "#d670d6",
  brightCyan: "#29b8db",
  brightWhite: "#ffffff"
};

// ../../packages/terminal/ghostty-web/src/input-handler.ts
var KEY_MAP = {
  KeyA: 20 /* A */,
  KeyB: 21 /* B */,
  KeyC: 22 /* C */,
  KeyD: 23 /* D */,
  KeyE: 24 /* E */,
  KeyF: 25 /* F */,
  KeyG: 26 /* G */,
  KeyH: 27 /* H */,
  KeyI: 28 /* I */,
  KeyJ: 29 /* J */,
  KeyK: 30 /* K */,
  KeyL: 31 /* L */,
  KeyM: 32 /* M */,
  KeyN: 33 /* N */,
  KeyO: 34 /* O */,
  KeyP: 35 /* P */,
  KeyQ: 36 /* Q */,
  KeyR: 37 /* R */,
  KeyS: 38 /* S */,
  KeyT: 39 /* T */,
  KeyU: 40 /* U */,
  KeyV: 41 /* V */,
  KeyW: 42 /* W */,
  KeyX: 43 /* X */,
  KeyY: 44 /* Y */,
  KeyZ: 45 /* Z */,
  Digit1: 7 /* ONE */,
  Digit2: 8 /* TWO */,
  Digit3: 9 /* THREE */,
  Digit4: 10 /* FOUR */,
  Digit5: 11 /* FIVE */,
  Digit6: 12 /* SIX */,
  Digit7: 13 /* SEVEN */,
  Digit8: 14 /* EIGHT */,
  Digit9: 15 /* NINE */,
  Digit0: 6 /* ZERO */,
  Enter: 58 /* ENTER */,
  Escape: 120 /* ESCAPE */,
  Backspace: 53 /* BACKSPACE */,
  Tab: 64 /* TAB */,
  Space: 63 /* SPACE */,
  Minus: 46 /* MINUS */,
  Equal: 16 /* EQUAL */,
  BracketLeft: 3 /* BRACKET_LEFT */,
  BracketRight: 4 /* BRACKET_RIGHT */,
  Backslash: 2 /* BACKSLASH */,
  Semicolon: 49 /* SEMICOLON */,
  Quote: 48 /* QUOTE */,
  Backquote: 1 /* GRAVE */,
  Comma: 5 /* COMMA */,
  Period: 47 /* PERIOD */,
  Slash: 50 /* SLASH */,
  CapsLock: 54 /* CAPS_LOCK */,
  F1: 121 /* F1 */,
  F2: 122 /* F2 */,
  F3: 123 /* F3 */,
  F4: 124 /* F4 */,
  F5: 125 /* F5 */,
  F6: 126 /* F6 */,
  F7: 127 /* F7 */,
  F8: 128 /* F8 */,
  F9: 129 /* F9 */,
  F10: 130 /* F10 */,
  F11: 131 /* F11 */,
  F12: 132 /* F12 */,
  PrintScreen: 147 /* PRINT_SCREEN */,
  ScrollLock: 148 /* SCROLL_LOCK */,
  Pause: 149 /* PAUSE */,
  Insert: 72 /* INSERT */,
  Home: 71 /* HOME */,
  PageUp: 74 /* PAGE_UP */,
  Delete: 68 /* DELETE */,
  End: 69 /* END */,
  PageDown: 73 /* PAGE_DOWN */,
  ArrowRight: 77 /* RIGHT */,
  ArrowLeft: 76 /* LEFT */,
  ArrowDown: 75 /* DOWN */,
  ArrowUp: 78 /* UP */,
  NumLock: 79 /* NUM_LOCK */,
  NumpadDivide: 96 /* KP_DIVIDE */,
  NumpadMultiply: 104 /* KP_MULTIPLY */,
  NumpadSubtract: 107 /* KP_MINUS */,
  NumpadAdd: 90 /* KP_PLUS */,
  NumpadEnter: 97 /* KP_ENTER */,
  Numpad1: 81 /* KP_1 */,
  Numpad2: 82 /* KP_2 */,
  Numpad3: 83 /* KP_3 */,
  Numpad4: 84 /* KP_4 */,
  Numpad5: 85 /* KP_5 */,
  Numpad6: 86 /* KP_6 */,
  Numpad7: 87 /* KP_7 */,
  Numpad8: 88 /* KP_8 */,
  Numpad9: 89 /* KP_9 */,
  Numpad0: 80 /* KP_0 */,
  NumpadDecimal: 95 /* KP_PERIOD */,
  IntlBackslash: 17 /* INTL_BACKSLASH */,
  ContextMenu: 55 /* CONTEXT_MENU */,
  F13: 133 /* F13 */,
  F14: 134 /* F14 */,
  F15: 135 /* F15 */,
  F16: 136 /* F16 */,
  F17: 137 /* F17 */,
  F18: 138 /* F18 */,
  F19: 139 /* F19 */,
  F20: 140 /* F20 */,
  F21: 141 /* F21 */,
  F22: 142 /* F22 */,
  F23: 143 /* F23 */,
  F24: 144 /* F24 */
};

class InputHandler {
  syncEncoder;
  ctrlVPaste;
  encoder;
  container;
  inputElement;
  onDataCallback;
  onBellCallback;
  onKeyCallback;
  customKeyEventHandler;
  getModeCallback;
  onCopyCallback;
  mouseConfig;
  localSelectionGesture = false;
  keydownListener = null;
  keyupListener = null;
  pressedKeys = new Set;
  clearPressedKeys = () => {
    this.pressedKeys.clear();
    this.releaseHeldText();
  };
  suppressPressAndHold = typeof navigator !== "undefined" && /Mac/.test(navigator.platform ?? "") && !navigator.maxTouchPoints;
  heldText = new Set;
  keypressListener = null;
  pasteListener = null;
  beforeInputListener = null;
  compositionStartListener = null;
  compositionUpdateListener = null;
  compositionEndListener = null;
  mousedownListener = null;
  mouseupListener = null;
  mousemoveListener = null;
  wheelListener = null;
  isComposing = false;
  isDisposed = false;
  mouseButtonsPressed = 0;
  lastKeyDownData = null;
  lastKeyDownTime = 0;
  lastPasteData = null;
  lastPasteTime = 0;
  lastPasteSource = null;
  lastCompositionData = null;
  lastCompositionTime = 0;
  lastBeforeInputData = null;
  lastBeforeInputTime = 0;
  static BEFORE_INPUT_IGNORE_MS = 100;
  constructor(ghostty, container, onData, onBell, onKey, customKeyEventHandler, getMode, onCopy, inputElement, mouseConfig, syncEncoder, ctrlVPaste = () => true) {
    this.syncEncoder = syncEncoder;
    this.ctrlVPaste = ctrlVPaste;
    this.encoder = ghostty.createKeyEncoder();
    this.container = container;
    this.inputElement = inputElement;
    this.onDataCallback = onData;
    this.onBellCallback = onBell;
    this.onKeyCallback = onKey;
    this.customKeyEventHandler = customKeyEventHandler;
    this.getModeCallback = getMode;
    this.onCopyCallback = onCopy;
    this.mouseConfig = mouseConfig;
    this.attach();
  }
  setCustomKeyEventHandler(handler) {
    this.customKeyEventHandler = handler;
  }
  attach() {
    if (typeof this.container.hasAttribute === "function" && typeof this.container.setAttribute === "function") {
      if (!this.container.hasAttribute("tabindex")) {
        this.container.setAttribute("tabindex", "0");
      }
      if (this.container.style) {
        this.container.style.outline = "none";
      }
    }
    this.keydownListener = this.handleKeyDown.bind(this);
    this.container.addEventListener("keydown", this.keydownListener);
    this.keyupListener = (event) => {
      this.releaseHeldText(event.code);
      const accepted = this.pressedKeys.delete(event.code);
      if (!accepted || this.isDisposed || this.isComposing || event.isComposing || event.metaKey || this.isPasteShortcut(event))
        return;
      this.encodeKey(event, 0 /* RELEASE */);
    };
    this.container.addEventListener("keyup", this.keyupListener);
    this.container.addEventListener("blur", this.clearPressedKeys, true);
    this.pasteListener = this.handlePaste.bind(this);
    this.container.addEventListener("paste", this.pasteListener);
    if (this.inputElement && this.inputElement !== this.container) {
      this.inputElement.addEventListener("paste", this.pasteListener);
    }
    if (this.inputElement) {
      this.beforeInputListener = this.handleBeforeInput.bind(this);
      this.inputElement.addEventListener("beforeinput", this.beforeInputListener);
    }
    this.compositionStartListener = this.handleCompositionStart.bind(this);
    this.container.addEventListener("compositionstart", this.compositionStartListener);
    this.compositionUpdateListener = this.handleCompositionUpdate.bind(this);
    this.container.addEventListener("compositionupdate", this.compositionUpdateListener);
    this.compositionEndListener = this.handleCompositionEnd.bind(this);
    this.container.addEventListener("compositionend", this.compositionEndListener);
    this.mousedownListener = this.handleMouseDown.bind(this);
    this.container.addEventListener("mousedown", this.mousedownListener);
    this.mouseupListener = this.handleMouseUp.bind(this);
    this.container.addEventListener("mouseup", this.mouseupListener);
    this.mousemoveListener = this.handleMouseMove.bind(this);
    this.container.addEventListener("mousemove", this.mousemoveListener);
    this.wheelListener = this.handleWheel.bind(this);
    this.container.addEventListener("wheel", this.wheelListener, { passive: false });
  }
  mapKeyCode(code) {
    return KEY_MAP[code] ?? null;
  }
  extractModifiers(event) {
    let mods = 0 /* NONE */;
    if (event.shiftKey)
      mods |= 1 /* SHIFT */;
    if (event.ctrlKey)
      mods |= 2 /* CTRL */;
    if (event.altKey)
      mods |= 4 /* ALT */;
    if (event.metaKey)
      mods |= 8 /* SUPER */;
    return mods;
  }
  isPrintableCharacter(event) {
    if (event.ctrlKey && !event.altKey)
      return false;
    if (event.altKey && !event.ctrlKey)
      return false;
    if (event.metaKey)
      return false;
    return [...event.key].length === 1;
  }
  handleKeyDown(event) {
    if (this.isDisposed)
      return;
    this.pressedKeys.delete(event.code);
    if (this.isComposing || event.isComposing || event.keyCode === 229) {
      return;
    }
    this.holdText(event);
    if (this.onKeyCallback) {
      this.onKeyCallback({ key: event.key, domEvent: event });
    }
    if (this.customKeyEventHandler) {
      const handled = this.customKeyEventHandler(event);
      if (handled) {
        event.preventDefault();
        return;
      }
    }
    if (this.isPasteShortcut(event)) {
      return;
    }
    if (event.metaKey && event.code === "KeyC") {
      if (this.onCopyCallback && this.onCopyCallback()) {
        event.preventDefault();
      }
      return;
    }
    if (event.metaKey)
      return;
    if (this.mapKeyCode(event.code) === null && this.isPrintableCharacter(event)) {
      event.preventDefault();
      this.onDataCallback(event.key);
      this.recordKeyDownData(event.key);
      return;
    }
    this.encodeKey(event, event.repeat ? 2 /* REPEAT */ : 1 /* PRESS */);
  }
  isPasteShortcut(event) {
    if (event.code !== "KeyV")
      return false;
    if (event.metaKey)
      return true;
    return event.ctrlKey && (event.shiftKey || this.ctrlVPaste());
  }
  holdText(event) {
    if (!this.suppressPressAndHold || !(this.inputElement instanceof HTMLTextAreaElement))
      return;
    if (event.metaKey)
      return this.releaseHeldText();
    if (event.ctrlKey || event.altKey || !this.isPrintableCharacter(event))
      return;
    this.heldText.add(event.code);
    this.inputElement.readOnly = true;
  }
  releaseHeldText(code) {
    if (code === undefined)
      this.heldText.clear();
    else if (!this.heldText.delete(code))
      return;
    if (this.heldText.size === 0 && this.inputElement instanceof HTMLTextAreaElement) {
      this.inputElement.readOnly = false;
    }
  }
  encodeKey(event, action) {
    const key = this.mapKeyCode(event.code);
    if (key === null) {
      return;
    }
    const mods = this.extractModifiers(event);
    try {
      if (this.syncEncoder) {
        this.syncEncoder(this.encoder);
      } else if (this.getModeCallback) {
        const appCursorMode = this.getModeCallback(1);
        this.encoder.setOption(0 /* CURSOR_KEY_APPLICATION */, appCursorMode);
      }
      const utf8 = [...event.key].length === 1 ? event.key : undefined;
      const encoded = this.encoder.encode({
        action,
        key,
        mods: utf8 && event.ctrlKey && event.altKey ? mods & ~(2 /* CTRL */ | 4 /* ALT */) : mods,
        utf8,
        unshiftedCodepoint: utf8?.toLowerCase().codePointAt(0)
      });
      const decoder = new TextDecoder;
      const data = decoder.decode(encoded);
      if (action !== 0 /* RELEASE */ || data.length > 0) {
        event.preventDefault();
        event.stopPropagation();
      }
      if (action !== 0 /* RELEASE */)
        this.pressedKeys.add(event.code);
      if (data.length > 0) {
        this.onDataCallback(data);
        if (action !== 0 /* RELEASE */)
          this.recordKeyDownData(utf8 ?? data);
      }
    } catch (error) {
      console.warn("Failed to encode key:", event.code, error);
    }
  }
  handlePaste(event) {
    if (this.isDisposed)
      return;
    event.preventDefault();
    event.stopPropagation();
    const clipboardData = event.clipboardData;
    if (!clipboardData) {
      console.warn("No clipboard data available");
      return;
    }
    const text = clipboardData.getData("text/plain");
    if (!text) {
      console.warn("No text in clipboard");
      return;
    }
    if (this.shouldIgnorePasteEvent(text, "paste")) {
      return;
    }
    this.emitPasteData(text);
    this.recordPasteData(text, "paste");
  }
  handleBeforeInput(event) {
    if (this.isDisposed)
      return;
    if (this.isComposing || event.isComposing) {
      return;
    }
    const inputType = event.inputType;
    const data = event.data ?? "";
    let output = null;
    switch (inputType) {
      case "insertText":
      case "insertReplacementText":
        output = data.length > 0 ? data.replace(/\n/g, "\r") : null;
        break;
      case "insertLineBreak":
      case "insertParagraph":
        output = "\r";
        break;
      case "deleteContentBackward":
        output = "";
        break;
      case "deleteContentForward":
        output = "\x1B[3~";
        break;
      case "insertFromPaste":
        if (!data) {
          return;
        }
        if (this.shouldIgnorePasteEvent(data, "beforeinput")) {
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.emitPasteData(data);
        this.recordPasteData(data, "beforeinput");
        return;
      default:
        return;
    }
    if (!output) {
      return;
    }
    if (this.shouldIgnoreBeforeInput(output)) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    if (data && this.shouldIgnoreBeforeInputFromComposition(data)) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    this.onDataCallback(output);
    if (data) {
      this.recordBeforeInputData(data);
    }
  }
  handleCompositionStart(_event) {
    if (this.isDisposed)
      return;
    this.isComposing = true;
    this.clearPressedKeys();
  }
  handleCompositionUpdate(_event) {
    if (this.isDisposed)
      return;
  }
  handleCompositionEnd(event) {
    if (this.isDisposed)
      return;
    this.isComposing = false;
    const data = event.data;
    if (data && data.length > 0) {
      if (this.shouldIgnoreCompositionEnd(data)) {
        this.cleanupCompositionTextNodes();
        return;
      }
      this.onDataCallback(data);
      this.recordCompositionData(data);
    }
    this.cleanupCompositionTextNodes();
  }
  cleanupCompositionTextNodes() {
    if (this.container && this.container.childNodes) {
      for (let i = this.container.childNodes.length - 1;i >= 0; i--) {
        const node = this.container.childNodes[i];
        if (node.nodeType === 3) {
          this.container.removeChild(node);
        }
      }
    }
  }
  pixelToCell(event) {
    if (!this.mouseConfig)
      return null;
    const dims = this.mouseConfig.getCellDimensions();
    const offset = this.mouseConfig.getCanvasOffset();
    if (dims.width <= 0 || dims.height <= 0)
      return null;
    const x = event.clientX - offset.left;
    const y = event.clientY - offset.top;
    const col = Math.floor(x / dims.width) + 1;
    const row = Math.floor(y / dims.height) + 1;
    return {
      col: Math.max(1, col),
      row: Math.max(1, row)
    };
  }
  getMouseModifiers(event) {
    let mods = 0;
    if (event.shiftKey)
      mods |= 4;
    if (event.metaKey)
      mods |= 8;
    if (event.ctrlKey)
      mods |= 16;
    return mods;
  }
  encodeMouseSGR(button, col, row, isRelease, modifiers) {
    const btn = button + modifiers;
    const suffix = isRelease ? "m" : "M";
    return `\x1B[<${btn};${col};${row}${suffix}`;
  }
  encodeMouseX10(button, col, row, modifiers) {
    const btn = button + modifiers + 32;
    const colChar = String.fromCharCode(Math.min(col + 32, 255));
    const rowChar = String.fromCharCode(Math.min(row + 32, 255));
    return `\x1B[M${String.fromCharCode(btn)}${colChar}${rowChar}`;
  }
  sendMouseEvent(button, col, row, isRelease, event) {
    const modifiers = this.getMouseModifiers(event);
    const useSGR = this.mouseConfig?.hasSgrMouseMode?.() ?? true;
    let sequence;
    if (useSGR) {
      sequence = this.encodeMouseSGR(button, col, row, isRelease, modifiers);
    } else {
      const x10Button = isRelease ? 3 : button;
      sequence = this.encodeMouseX10(x10Button, col, row, modifiers);
    }
    this.onDataCallback(sequence);
  }
  handleMouseDown(event) {
    if (this.isDisposed)
      return;
    this.localSelectionGesture = event.button === 0 && (event.shiftKey || !!this.mouseConfig?.preferSelection?.() && !event.altKey);
    if (this.localSelectionGesture)
      return;
    if (!this.mouseConfig?.hasMouseTracking())
      return;
    const cell = this.pixelToCell(event);
    if (!cell)
      return;
    const button = event.button;
    this.mouseButtonsPressed |= 1 << button;
    this.sendMouseEvent(button, cell.col, cell.row, false, event);
  }
  handleMouseUp(event) {
    if (this.isDisposed)
      return;
    if (event.button === 0 && this.localSelectionGesture) {
      this.localSelectionGesture = false;
      return;
    }
    if (!this.mouseConfig?.hasMouseTracking())
      return;
    const cell = this.pixelToCell(event);
    if (!cell)
      return;
    const button = event.button;
    this.mouseButtonsPressed &= ~(1 << button);
    this.sendMouseEvent(button, cell.col, cell.row, true, event);
  }
  handleMouseMove(event) {
    if (this.isDisposed)
      return;
    if (this.localSelectionGesture || event.shiftKey || this.mouseConfig?.preferSelection?.() && !event.altKey && this.mouseButtonsPressed === 0)
      return;
    if (!this.mouseConfig?.hasMouseTracking())
      return;
    const hasButtonMotion = this.getModeCallback?.(1002) ?? false;
    const hasAnyMotion = this.getModeCallback?.(1003) ?? false;
    if (!hasButtonMotion && !hasAnyMotion)
      return;
    if (hasButtonMotion && !hasAnyMotion && this.mouseButtonsPressed === 0)
      return;
    const cell = this.pixelToCell(event);
    if (!cell)
      return;
    let button = 32;
    if (this.mouseButtonsPressed & 1)
      button += 0;
    else if (this.mouseButtonsPressed & 2)
      button += 1;
    else if (this.mouseButtonsPressed & 4)
      button += 2;
    else
      button += 3;
    this.sendMouseEvent(button, cell.col, cell.row, false, event);
  }
  handleWheel(event) {
    if (this.isDisposed)
      return;
    if (!this.mouseConfig?.hasMouseTracking())
      return;
    const cell = this.pixelToCell(event);
    if (!cell)
      return;
    const button = event.deltaY < 0 ? 64 : 65;
    this.sendMouseEvent(button, cell.col, cell.row, false, event);
    event.preventDefault();
  }
  emitPasteData(text) {
    const hasBracketedPaste = this.getModeCallback?.(2004) ?? false;
    if (hasBracketedPaste) {
      this.onDataCallback("\x1B[200~" + text + "\x1B[201~");
    } else {
      this.onDataCallback(text);
    }
  }
  recordKeyDownData(data) {
    this.lastKeyDownData = data;
    this.lastKeyDownTime = this.getNow();
  }
  recordPasteData(data, source) {
    this.lastPasteData = data;
    this.lastPasteTime = this.getNow();
    this.lastPasteSource = source;
  }
  shouldIgnoreBeforeInput(data) {
    if (!this.lastKeyDownData) {
      return false;
    }
    const now = this.getNow();
    const isDuplicate = now - this.lastKeyDownTime < InputHandler.BEFORE_INPUT_IGNORE_MS && this.lastKeyDownData === data;
    this.lastKeyDownData = null;
    return isDuplicate;
  }
  shouldIgnoreBeforeInputFromComposition(data) {
    if (!this.lastCompositionData) {
      return false;
    }
    const now = this.getNow();
    const isDuplicate = now - this.lastCompositionTime < InputHandler.BEFORE_INPUT_IGNORE_MS && this.lastCompositionData === data;
    if (isDuplicate) {
      this.lastCompositionData = null;
    }
    return isDuplicate;
  }
  shouldIgnoreCompositionEnd(data) {
    if (!this.lastBeforeInputData) {
      return false;
    }
    const now = this.getNow();
    const isDuplicate = now - this.lastBeforeInputTime < InputHandler.BEFORE_INPUT_IGNORE_MS && this.lastBeforeInputData === data;
    if (isDuplicate) {
      this.lastBeforeInputData = null;
    }
    return isDuplicate;
  }
  recordBeforeInputData(data) {
    this.lastBeforeInputData = data;
    this.lastBeforeInputTime = this.getNow();
  }
  recordCompositionData(data) {
    this.lastCompositionData = data;
    this.lastCompositionTime = this.getNow();
  }
  shouldIgnorePasteEvent(data, source) {
    if (!this.lastPasteData) {
      return false;
    }
    if (this.lastPasteSource === source) {
      return false;
    }
    const now = this.getNow();
    const isDuplicate = now - this.lastPasteTime < InputHandler.BEFORE_INPUT_IGNORE_MS && this.lastPasteData === data;
    if (isDuplicate) {
      this.lastPasteData = null;
      this.lastPasteSource = null;
    }
    return isDuplicate;
  }
  getNow() {
    return typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now();
  }
  dispose() {
    if (this.isDisposed)
      return;
    if (this.keydownListener) {
      this.container.removeEventListener("keydown", this.keydownListener);
      this.keydownListener = null;
    }
    if (this.keyupListener) {
      this.container.removeEventListener("keyup", this.keyupListener);
      this.keyupListener = null;
    }
    this.clearPressedKeys();
    this.container.removeEventListener("blur", this.clearPressedKeys, true);
    if (this.keypressListener) {
      this.container.removeEventListener("keypress", this.keypressListener);
      this.keypressListener = null;
    }
    if (this.pasteListener) {
      this.container.removeEventListener("paste", this.pasteListener);
      if (this.inputElement && this.inputElement !== this.container) {
        this.inputElement.removeEventListener("paste", this.pasteListener);
      }
      this.pasteListener = null;
    }
    if (this.beforeInputListener && this.inputElement) {
      this.inputElement.removeEventListener("beforeinput", this.beforeInputListener);
      this.beforeInputListener = null;
    }
    if (this.compositionStartListener) {
      this.container.removeEventListener("compositionstart", this.compositionStartListener);
      this.compositionStartListener = null;
    }
    if (this.compositionUpdateListener) {
      this.container.removeEventListener("compositionupdate", this.compositionUpdateListener);
      this.compositionUpdateListener = null;
    }
    if (this.compositionEndListener) {
      this.container.removeEventListener("compositionend", this.compositionEndListener);
      this.compositionEndListener = null;
    }
    if (this.mousedownListener) {
      this.container.removeEventListener("mousedown", this.mousedownListener);
      this.mousedownListener = null;
    }
    if (this.mouseupListener) {
      this.container.removeEventListener("mouseup", this.mouseupListener);
      this.mouseupListener = null;
    }
    if (this.mousemoveListener) {
      this.container.removeEventListener("mousemove", this.mousemoveListener);
      this.mousemoveListener = null;
    }
    if (this.wheelListener) {
      this.container.removeEventListener("wheel", this.wheelListener);
      this.wheelListener = null;
    }
    this.isDisposed = true;
    this.encoder.dispose();
  }
  isActive() {
    return !this.isDisposed;
  }
}

// ../../packages/terminal/ghostty-web/src/link-detector.ts
class LinkDetector {
  terminal;
  providers = [];
  linkCache = new Map;
  scannedRows = new Set;
  constructor(terminal) {
    this.terminal = terminal;
  }
  registerProvider(provider) {
    this.providers.push(provider);
    this.invalidateCache();
  }
  async getLinkAt(col, row) {
    const line = this.terminal.buffer.active.getLine(row);
    if (!line || col < 0 || col >= line.length) {
      return;
    }
    const cell = line.getCell(col);
    if (!cell) {
      return;
    }
    for (const link of this.linkCache.values()) {
      if (this.isPositionInLink(col, row, link)) {
        return link;
      }
    }
    if (!this.scannedRows.has(row)) {
      await this.scanRow(row);
    }
    for (const link of this.linkCache.values()) {
      if (this.isPositionInLink(col, row, link)) {
        return link;
      }
    }
    return;
  }
  async scanRow(row) {
    this.scannedRows.add(row);
    const allLinks = [];
    for (const provider of this.providers) {
      const links = await new Promise((resolve) => {
        provider.provideLinks(row, resolve);
      });
      if (links) {
        allLinks.push(...links);
      }
    }
    for (const link of allLinks) {
      this.cacheLink(link);
    }
  }
  cacheLink(link) {
    const { start: s, end: e } = link.range;
    const cacheKey = `r${s.y}:${s.x}-${e.x}`;
    if (!this.linkCache.has(cacheKey)) {
      this.linkCache.set(cacheKey, link);
    }
  }
  isPositionInLink(col, row, link) {
    const { start, end } = link.range;
    if (row < start.y || row > end.y) {
      return false;
    }
    if (start.y === end.y) {
      return col >= start.x && col <= end.x;
    }
    if (row === start.y) {
      return col >= start.x;
    } else if (row === end.y) {
      return col <= end.x;
    } else {
      return true;
    }
  }
  invalidateCache() {
    this.linkCache.clear();
    this.scannedRows.clear();
  }
  invalidateRows(startRow, endRow) {
    for (let row = startRow;row <= endRow; row++) {
      this.scannedRows.delete(row);
    }
    const toDelete = [];
    for (const [key, link] of this.linkCache.entries()) {
      const { start, end } = link.range;
      if (start.y >= startRow && start.y <= endRow || end.y >= startRow && end.y <= endRow || start.y < startRow && end.y > endRow) {
        toDelete.push(key);
      }
    }
    for (const key of toDelete) {
      this.linkCache.delete(key);
    }
  }
  dispose() {
    this.linkCache.clear();
    this.scannedRows.clear();
    for (const provider of this.providers) {
      provider.dispose?.();
    }
    this.providers = [];
  }
}

// ../../packages/terminal/ghostty-web/src/providers/osc8-link-provider.ts
class OSC8LinkProvider {
  terminal;
  constructor(terminal) {
    this.terminal = terminal;
  }
  provideLinks(y, callback) {
    const links = [];
    const visitedPositions = new Set;
    const line = this.terminal.buffer.active.getLine(y);
    if (!line) {
      callback(undefined);
      return;
    }
    for (let x = 0;x < line.length; x++) {
      if (visitedPositions.has(x))
        continue;
      const cell = line.getCell(x);
      if (!cell)
        continue;
      const hyperlinkId = cell.getHyperlinkId();
      if (hyperlinkId === 0) {
        continue;
      }
      if (!this.terminal.wasmTerm)
        continue;
      const scrollbackLength = this.terminal.wasmTerm.getScrollbackLength();
      const viewportRow = y - scrollbackLength;
      let uri;
      if (viewportRow < 0) {
        uri = this.terminal.wasmTerm.getScrollbackHyperlinkUri(y, x);
      } else {
        uri = this.terminal.wasmTerm.getHyperlinkUri(viewportRow, x);
      }
      if (uri) {
        let endX = x;
        for (let col = x + 1;col < line.length; col++) {
          const nextCell = line.getCell(col);
          if (!nextCell || nextCell.getHyperlinkId() === 0)
            break;
          const nextUri = viewportRow < 0 ? this.terminal.wasmTerm.getScrollbackHyperlinkUri(y, col) : this.terminal.wasmTerm.getHyperlinkUri(viewportRow, col);
          if (nextUri !== uri)
            break;
          endX = col;
        }
        for (let col = x;col <= endX; col++) {
          visitedPositions.add(col);
        }
        const range = {
          start: { x, y },
          end: { x: endX, y }
        };
        links.push({
          text: uri,
          range,
          activate: (event) => {
            if (event.ctrlKey || event.metaKey) {
              window.open(uri, "_blank", "noopener,noreferrer");
            }
          }
        });
      }
    }
    callback(links.length > 0 ? links : undefined);
  }
  findLinkRange(hyperlinkId, startY, startX) {
    const buffer = this.terminal.buffer.active;
    let minY = startY;
    let minX = startX;
    while (minX > 0) {
      const line = buffer.getLine(minY);
      if (!line)
        break;
      const cell = line.getCell(minX - 1);
      if (!cell || cell.getHyperlinkId() !== hyperlinkId)
        break;
      minX--;
    }
    if (minX === 0 && minY > 0) {
      let prevY = minY - 1;
      while (prevY >= 0) {
        const prevLine = buffer.getLine(prevY);
        if (!prevLine || prevLine.length === 0)
          break;
        const lastCell = prevLine.getCell(prevLine.length - 1);
        if (!lastCell || lastCell.getHyperlinkId() !== hyperlinkId)
          break;
        minY = prevY;
        minX = 0;
        for (let x = prevLine.length - 1;x >= 0; x--) {
          const cell = prevLine.getCell(x);
          if (!cell || cell.getHyperlinkId() !== hyperlinkId) {
            minX = x + 1;
            break;
          }
        }
        if (minX === 0) {
          prevY--;
        } else {
          break;
        }
      }
    }
    let maxY = startY;
    let maxX = startX;
    const currentLine = buffer.getLine(maxY);
    if (currentLine) {
      while (maxX < currentLine.length - 1) {
        const cell = currentLine.getCell(maxX + 1);
        if (!cell || cell.getHyperlinkId() !== hyperlinkId)
          break;
        maxX++;
      }
      if (maxX === currentLine.length - 1) {
        let nextY = maxY + 1;
        const maxBuffer = buffer.length;
        while (nextY < maxBuffer) {
          const nextLine = buffer.getLine(nextY);
          if (!nextLine || nextLine.length === 0)
            break;
          const firstCell = nextLine.getCell(0);
          if (!firstCell || firstCell.getHyperlinkId() !== hyperlinkId)
            break;
          maxY = nextY;
          maxX = 0;
          for (let x = 0;x < nextLine.length; x++) {
            const cell = nextLine.getCell(x);
            if (!cell)
              break;
            if (cell.getHyperlinkId() !== hyperlinkId) {
              maxX = x - 1;
              break;
            }
            maxX = x;
          }
          if (maxX === nextLine.length - 1) {
            nextY++;
          } else {
            break;
          }
        }
      }
    }
    return {
      start: { x: minX, y: minY },
      end: { x: maxX, y: maxY }
    };
  }
  dispose() {}
}

// ../../packages/terminal/ghostty-web/src/providers/url-regex-provider.ts
class UrlRegexProvider {
  terminal;
  static URL_REGEX = /(?:https?:\/\/|mailto:|ftp:\/\/|ssh:\/\/|git:\/\/|tel:|magnet:|gemini:\/\/|gopher:\/\/|news:)[\w\-.~:\/?#@!$&*+,;=%]+/gi;
  static TRAILING_PUNCTUATION = /[.,;!?)\]]+$/;
  constructor(terminal) {
    this.terminal = terminal;
  }
  provideLinks(y, callback) {
    const links = [];
    const line = this.terminal.buffer.active.getLine(y);
    if (!line) {
      callback(undefined);
      return;
    }
    let firstRow = y;
    while (firstRow > 0 && this.terminal.buffer.active.getLine(firstRow)?.isWrapped)
      firstRow--;
    let lastRow = y;
    while (this.terminal.buffer.active.getLine(lastRow + 1)?.isWrapped)
      lastRow++;
    let lineText = "";
    const positions = [];
    for (let row = firstRow;row <= lastRow; row++) {
      const current = this.terminal.buffer.active.getLine(row);
      for (let x = 0;x < current.length; x++) {
        const cell = current.getCell(x);
        if (cell?.getWidth?.() === 0)
          continue;
        const codepoint = cell?.getCodepoint() ?? 0;
        const text = codepoint < 32 ? " " : String.fromCodePoint(codepoint);
        lineText += text;
        for (let i = 0;i < text.length; i++)
          positions.push({ x, y: row });
      }
    }
    UrlRegexProvider.URL_REGEX.lastIndex = 0;
    let match = UrlRegexProvider.URL_REGEX.exec(lineText);
    while (match !== null) {
      let url = match[0];
      const stripped = url.replace(UrlRegexProvider.TRAILING_PUNCTUATION, "");
      if (stripped.length < url.length) {
        url = stripped;
      }
      const start = positions[match.index];
      const end = positions[match.index + url.length - 1];
      if (url.length > 8 && start.y <= y && end.y >= y) {
        links.push({
          text: url,
          range: {
            start,
            end
          },
          activate: (event) => {
            if (event.ctrlKey || event.metaKey) {
              window.open(url, "_blank", "noopener,noreferrer");
            }
          }
        });
      }
      match = UrlRegexProvider.URL_REGEX.exec(lineText);
    }
    callback(links.length > 0 ? links : undefined);
  }
  dispose() {}
}

// ../../packages/terminal/ghostty-web/src/font-metrics.ts
function measureFontMetrics(fontSize, fontFamily) {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    return {
      width: Math.ceil(fontSize * 0.6),
      height: Math.ceil(fontSize * 1.2) + 2,
      baseline: Math.ceil(fontSize * 0.8) + 1
    };
  }
  ctx.font = `${fontSize}px ${fontFamily}`;
  const widthMetrics = ctx.measureText("M");
  const width = Math.ceil(widthMetrics.width);
  const ascent = widthMetrics.actualBoundingBoxAscent || fontSize * 0.8;
  const descent = widthMetrics.actualBoundingBoxDescent || fontSize * 0.2;
  return {
    width,
    height: Math.ceil(ascent + descent) + 2,
    baseline: Math.ceil(ascent) + 1
  };
}

// ../../packages/terminal/ghostty-web/src/viewport-row.ts
function createViewportRowAccessor(buffer, cells, dims, viewportY, scrollbackLength, scrollbackProvider) {
  const offset = Math.max(0, Math.floor(viewportY));
  return (y) => {
    if (y < offset && scrollbackProvider) {
      const line2 = scrollbackProvider.getScrollbackLine(scrollbackLength - offset + y);
      return line2 ? { src: line2, base: 0, count: line2.length } : null;
    }
    const screenRow = y - offset;
    if (screenRow < 0 || screenRow >= dims.rows)
      return null;
    if (cells)
      return { src: cells, base: screenRow * dims.cols, count: dims.cols };
    const line = buffer.getLine(screenRow);
    return line ? { src: line, base: 0, count: line.length } : null;
  };
}

// ../../packages/terminal/ghostty-web/src/renderer.ts
class CanvasRenderer {
  canvas;
  ctx;
  fontSize;
  fontFamily;
  cursorStyle;
  cursorBlink;
  theme;
  devicePixelRatio;
  metrics;
  palette;
  cursorVisible = true;
  cursorBlinkInterval;
  lastCursorPosition = { x: 0, y: 0 };
  lastViewportY = 0;
  currentBuffer = null;
  currentCells = null;
  currentCols = 0;
  rowShadow = [];
  lastScrollbarOpacity = -1;
  lastScrollbarPainted = false;
  lastResizeCols = -1;
  lastResizeRows = -1;
  lastResizeCellW = -1;
  lastResizeCellH = -1;
  selectionManager;
  currentSelectionCoords = null;
  hoveredHyperlinkId = 0;
  previousHoveredHyperlinkId = 0;
  hoveredLinkRange = null;
  previousHoveredLinkRange = null;
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) {
      throw new Error("Failed to get 2D rendering context");
    }
    this.ctx = ctx;
    this.fontSize = options.fontSize ?? 15;
    this.fontFamily = options.fontFamily ?? "monospace";
    this.cursorStyle = options.cursorStyle ?? "block";
    this.cursorBlink = options.cursorBlink ?? false;
    this.theme = { ...DEFAULT_THEME, ...options.theme };
    this.devicePixelRatio = options.devicePixelRatio ?? window.devicePixelRatio ?? 1;
    this.palette = [
      this.theme.black,
      this.theme.red,
      this.theme.green,
      this.theme.yellow,
      this.theme.blue,
      this.theme.magenta,
      this.theme.cyan,
      this.theme.white,
      this.theme.brightBlack,
      this.theme.brightRed,
      this.theme.brightGreen,
      this.theme.brightYellow,
      this.theme.brightBlue,
      this.theme.brightMagenta,
      this.theme.brightCyan,
      this.theme.brightWhite
    ];
    this.metrics = this.measureFont();
    if (this.cursorBlink) {
      this.startCursorBlink();
    }
  }
  measureFont() {
    return measureFontMetrics(this.fontSize, this.fontFamily);
  }
  remeasureFont() {
    this.metrics = this.measureFont();
  }
  rgbToCSS(r, g, b) {
    return `rgb(${r}, ${g}, ${b})`;
  }
  resize(cols, rows) {
    this.rowShadow.length = 0;
    this.lastResizeCols = cols;
    this.lastResizeRows = rows;
    this.lastResizeCellW = this.metrics.width;
    this.lastResizeCellH = this.metrics.height;
    const cssWidth = cols * this.metrics.width;
    const cssHeight = rows * this.metrics.height;
    this.canvas.style.width = `${cssWidth}px`;
    this.canvas.style.height = `${cssHeight}px`;
    this.canvas.width = cssWidth * this.devicePixelRatio;
    this.canvas.height = cssHeight * this.devicePixelRatio;
    this.ctx.scale(this.devicePixelRatio, this.devicePixelRatio);
    this.ctx.textBaseline = "alphabetic";
    this.ctx.textAlign = "left";
    this.ctx.fillStyle = this.theme.background;
    this.ctx.fillRect(0, 0, cssWidth, cssHeight);
  }
  render(buffer, forceAll = false, viewportY = 0, scrollbackProvider, scrollbarOpacity = 1) {
    this.currentBuffer = buffer;
    const cursor = buffer.getCursor();
    const dims = buffer.getDimensions();
    const scrollbackLength = scrollbackProvider ? scrollbackProvider.getScrollbackLength() : 0;
    if (buffer.needsFullRedraw?.()) {
      forceAll = true;
    }
    if (typeof window !== "undefined" && window.devicePixelRatio && window.devicePixelRatio !== this.devicePixelRatio) {
      this.devicePixelRatio = window.devicePixelRatio;
      this.lastResizeCols = -1;
    }
    const needsResize = this.lastResizeCols !== dims.cols || this.lastResizeRows !== dims.rows || this.lastResizeCellW !== this.metrics.width || this.lastResizeCellH !== this.metrics.height;
    if (needsResize) {
      this.resize(dims.cols, dims.rows);
      forceAll = true;
    }
    if (viewportY !== this.lastViewportY) {
      forceAll = true;
      this.lastViewportY = viewportY;
    }
    const anyDirty = buffer.isDirty ? buffer.isDirty() : true;
    const scrollbarPainted = !!scrollbackProvider && scrollbarOpacity > 0 && scrollbackLength > 0;
    if (this.lastScrollbarPainted && !scrollbarPainted) {
      forceAll = true;
    }
    this.lastScrollbarPainted = scrollbarPainted;
    if (viewportY > 0 && anyDirty) {
      forceAll = true;
    }
    const cursorMoved = cursor.x !== this.lastCursorPosition.x || cursor.y !== this.lastCursorPosition.y;
    const hasSelection = this.selectionManager && this.selectionManager.hasSelection();
    const selectionRows = new Set;
    this.currentSelectionCoords = hasSelection ? this.selectionManager.getSelectionCoords() : null;
    if (this.currentSelectionCoords) {
      const coords = this.currentSelectionCoords;
      for (let row = coords.startRow;row <= coords.endRow; row++) {
        selectionRows.add(row);
      }
    }
    if (this.selectionManager) {
      const dirtyRows = this.selectionManager.getDirtySelectionRows();
      if (dirtyRows.size > 0) {
        for (const row of dirtyRows) {
          selectionRows.add(row);
        }
        this.selectionManager.clearDirtySelectionRows();
      }
    }
    const hyperlinkRows = new Set;
    const hyperlinkChanged = this.hoveredHyperlinkId !== this.previousHoveredHyperlinkId;
    const linkRangeChanged = JSON.stringify(this.hoveredLinkRange) !== JSON.stringify(this.previousHoveredLinkRange);
    if (!forceAll && !anyDirty && !cursorMoved && !this.cursorBlink && selectionRows.size === 0 && !hyperlinkChanged && !linkRangeChanged && scrollbarOpacity === this.lastScrollbarOpacity) {
      return;
    }
    const cells = buffer.getViewport ? buffer.getViewport() : null;
    this.currentCells = cells;
    this.currentCols = dims.cols;
    const rowAt = createViewportRowAccessor(buffer, cells, dims, viewportY, scrollbackLength, scrollbackProvider);
    const paintRow = (y) => {
      const row = rowAt(y);
      if (!row)
        return false;
      this.renderLine(row.src, y, dims.cols, row.base, row.count);
      return true;
    };
    if (hyperlinkChanged) {
      for (let y = 0;y < dims.rows; y++) {
        const row = rowAt(y);
        if (!row)
          continue;
        for (let i = 0;i < row.count; i++) {
          const cell = row.src[row.base + i];
          if (cell && (cell.hyperlink_id === this.hoveredHyperlinkId || cell.hyperlink_id === this.previousHoveredHyperlinkId)) {
            hyperlinkRows.add(y);
            break;
          }
        }
      }
      this.previousHoveredHyperlinkId = this.hoveredHyperlinkId;
    }
    if (linkRangeChanged) {
      if (this.previousHoveredLinkRange) {
        for (let y = this.previousHoveredLinkRange.startY;y <= this.previousHoveredLinkRange.endY; y++) {
          hyperlinkRows.add(y);
        }
      }
      if (this.hoveredLinkRange) {
        for (let y = this.hoveredLinkRange.startY;y <= this.hoveredLinkRange.endY; y++) {
          hyperlinkRows.add(y);
        }
      }
      this.previousHoveredLinkRange = this.hoveredLinkRange;
    }
    let anyLinesRendered = false;
    if (viewportY > 0) {
      this.rowShadow.length = 0;
    }
    const rowsToRender = new Set;
    for (let y = 0;y < dims.rows; y++) {
      let contentChanged = forceAll;
      if (viewportY === 0 && (forceAll || buffer.isRowDirty(y))) {
        if (cells) {
          const h = this.hashRow(cells, y * dims.cols, dims.cols);
          if (!forceAll)
            contentChanged = h !== this.rowShadow[y];
          this.rowShadow[y] = h;
        } else {
          contentChanged = true;
        }
      }
      const needsRender = viewportY > 0 ? forceAll || selectionRows.has(y) || hyperlinkRows.has(y) : forceAll || contentChanged || selectionRows.has(y) || hyperlinkRows.has(y);
      if (needsRender) {
        rowsToRender.add(y);
        if (y > 0)
          rowsToRender.add(y - 1);
        if (y < dims.rows - 1)
          rowsToRender.add(y + 1);
      }
    }
    if (viewportY === 0 && (cursorMoved || this.cursorBlink)) {
      rowsToRender.add(cursor.y);
      if (cursorMoved && this.lastCursorPosition.y !== cursor.y) {
        rowsToRender.add(this.lastCursorPosition.y);
      }
    }
    for (let y = 0;y < dims.rows; y++) {
      if (!rowsToRender.has(y)) {
        continue;
      }
      if (paintRow(y)) {
        anyLinesRendered = true;
      }
    }
    if (viewportY === 0 && cursor.visible && this.cursorVisible) {
      this.renderCursor(cursor.x, cursor.y);
    }
    if (scrollbackProvider && scrollbarOpacity > 0) {
      this.renderScrollbar(viewportY, scrollbackLength, dims.rows, scrollbarOpacity);
    }
    this.lastScrollbarOpacity = scrollbarOpacity;
    this.lastCursorPosition = { x: cursor.x, y: cursor.y };
    buffer.clearDirty();
  }
  hashRow(cells, base, count) {
    let h = 2166136261 | 0;
    for (let i = 0;i < count; i++) {
      const c = cells[base + i];
      if (!c)
        continue;
      h ^= c.codepoint;
      h = Math.imul(h, 16777619);
      h ^= c.fg_r << 16 | c.fg_g << 8 | c.fg_b;
      h = Math.imul(h, 16777619);
      h ^= c.bg_r << 16 | c.bg_g << 8 | c.bg_b;
      h = Math.imul(h, 16777619);
      h ^= c.flags << 24 | c.width << 16 | c.hyperlink_id;
      h = Math.imul(h, 16777619);
      h ^= c.grapheme_len;
      h = Math.imul(h, 16777619);
    }
    return h | 0;
  }
  renderLine(line, y, cols, base = 0, count = line.length - base) {
    const lineY = y * this.metrics.height;
    const lineWidth = cols * this.metrics.width;
    this.ctx.clearRect(0, lineY, lineWidth, this.metrics.height);
    this.ctx.fillStyle = this.theme.background;
    this.ctx.fillRect(0, lineY, lineWidth, this.metrics.height);
    for (let x = 0;x < count; x++) {
      const cell = line[base + x];
      if (!cell || cell.width === 0)
        continue;
      this.renderCellBackground(cell, x, y);
    }
    for (let x = 0;x < count; x++) {
      const cell = line[base + x];
      if (!cell || cell.width === 0)
        continue;
      this.renderCellText(cell, x, y);
    }
  }
  renderCellBackground(cell, x, y) {
    const cellX = x * this.metrics.width;
    const cellY = y * this.metrics.height;
    const cellWidth = this.metrics.width * cell.width;
    const isSelected = this.isInSelection(x, y);
    if (isSelected) {
      this.ctx.fillStyle = this.theme.selectionBackground;
      this.ctx.fillRect(cellX, cellY, cellWidth, this.metrics.height);
      return;
    }
    let { bg_r, bg_g, bg_b } = cell;
    if (cell.flags & 16 /* INVERSE */) {
      bg_r = cell.fg_r;
      bg_g = cell.fg_g;
      bg_b = cell.fg_b;
    }
    const isDefaultBg = bg_r === 0 && bg_g === 0 && bg_b === 0;
    if (!isDefaultBg) {
      this.ctx.fillStyle = this.rgbToCSS(bg_r, bg_g, bg_b);
      this.ctx.fillRect(cellX, cellY, cellWidth, this.metrics.height);
    }
  }
  renderCellText(cell, x, y, colorOverride) {
    const cellX = x * this.metrics.width;
    const cellY = y * this.metrics.height;
    const cellWidth = this.metrics.width * cell.width;
    if (cell.flags & 32 /* INVISIBLE */) {
      return;
    }
    const isSelected = this.isInSelection(x, y);
    let fontStyle = "";
    if (cell.flags & 2 /* ITALIC */)
      fontStyle += "italic ";
    if (cell.flags & 1 /* BOLD */)
      fontStyle += "bold ";
    this.ctx.font = `${fontStyle}${this.fontSize}px ${this.fontFamily}`;
    if (colorOverride) {
      this.ctx.fillStyle = colorOverride;
    } else if (isSelected) {
      this.ctx.fillStyle = this.theme.selectionForeground;
    } else {
      let { fg_r, fg_g, fg_b } = cell;
      if (cell.flags & 16 /* INVERSE */) {
        fg_r = cell.bg_r;
        fg_g = cell.bg_g;
        fg_b = cell.bg_b;
      }
      this.ctx.fillStyle = this.rgbToCSS(fg_r, fg_g, fg_b);
    }
    if (cell.flags & 128 /* FAINT */) {
      this.ctx.globalAlpha = 0.5;
    }
    const textX = cellX;
    const textY = cellY + this.metrics.baseline;
    let char;
    if (cell.grapheme_len > 0 && this.currentBuffer?.getGraphemeString) {
      char = this.currentBuffer.getGraphemeString(y, x);
    } else {
      char = String.fromCodePoint(cell.codepoint || 32);
    }
    this.ctx.fillText(char, textX, textY);
    if (cell.flags & 128 /* FAINT */) {
      this.ctx.globalAlpha = 1;
    }
    if (cell.flags & 4 /* UNDERLINE */) {
      const underlineY = cellY + this.metrics.baseline + 2;
      this.ctx.strokeStyle = this.ctx.fillStyle;
      this.ctx.lineWidth = 1;
      this.ctx.beginPath();
      this.ctx.moveTo(cellX, underlineY);
      this.ctx.lineTo(cellX + cellWidth, underlineY);
      this.ctx.stroke();
    }
    if (cell.flags & 8 /* STRIKETHROUGH */) {
      const strikeY = cellY + this.metrics.height / 2;
      this.ctx.strokeStyle = this.ctx.fillStyle;
      this.ctx.lineWidth = 1;
      this.ctx.beginPath();
      this.ctx.moveTo(cellX, strikeY);
      this.ctx.lineTo(cellX + cellWidth, strikeY);
      this.ctx.stroke();
    }
    if (cell.hyperlink_id > 0) {
      const isHovered = cell.hyperlink_id === this.hoveredHyperlinkId;
      if (isHovered) {
        const underlineY = cellY + this.metrics.baseline + 2;
        this.ctx.strokeStyle = "#4A90E2";
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(cellX, underlineY);
        this.ctx.lineTo(cellX + cellWidth, underlineY);
        this.ctx.stroke();
      }
    }
    if (this.hoveredLinkRange) {
      const range = this.hoveredLinkRange;
      const isInRange = y === range.startY && x >= range.startX && (y < range.endY || x <= range.endX) || y > range.startY && y < range.endY || y === range.endY && x <= range.endX && (y > range.startY || x >= range.startX);
      if (isInRange) {
        const underlineY = cellY + this.metrics.baseline + 2;
        this.ctx.strokeStyle = "#4A90E2";
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(cellX, underlineY);
        this.ctx.lineTo(cellX + cellWidth, underlineY);
        this.ctx.stroke();
      }
    }
  }
  renderCursor(x, y) {
    const cursorX = x * this.metrics.width;
    const cursorY = y * this.metrics.height;
    this.ctx.fillStyle = this.theme.cursor;
    switch (this.cursorStyle) {
      case "block":
        this.ctx.fillRect(cursorX, cursorY, this.metrics.width, this.metrics.height);
        {
          const cell = this.currentCells ? this.currentCells[y * this.currentCols + x] : this.currentBuffer?.getLine(y)?.[x];
          if (cell) {
            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.rect(cursorX, cursorY, this.metrics.width, this.metrics.height);
            this.ctx.clip();
            this.renderCellText(cell, x, y, this.theme.cursorAccent);
            this.ctx.restore();
          }
        }
        break;
      case "underline":
        const underlineHeight = Math.max(2, Math.floor(this.metrics.height * 0.15));
        this.ctx.fillRect(cursorX, cursorY + this.metrics.height - underlineHeight, this.metrics.width, underlineHeight);
        break;
      case "bar":
        const barWidth = Math.max(2, Math.floor(this.metrics.width * 0.15));
        this.ctx.fillRect(cursorX, cursorY, barWidth, this.metrics.height);
        break;
    }
  }
  startCursorBlink() {
    this.cursorBlinkInterval = window.setInterval(() => {
      this.cursorVisible = !this.cursorVisible;
    }, 530);
  }
  stopCursorBlink() {
    if (this.cursorBlinkInterval !== undefined) {
      clearInterval(this.cursorBlinkInterval);
      this.cursorBlinkInterval = undefined;
    }
    this.cursorVisible = true;
  }
  setTheme(theme) {
    this.rowShadow.length = 0;
    this.theme = { ...DEFAULT_THEME, ...theme };
    this.palette = [
      this.theme.black,
      this.theme.red,
      this.theme.green,
      this.theme.yellow,
      this.theme.blue,
      this.theme.magenta,
      this.theme.cyan,
      this.theme.white,
      this.theme.brightBlack,
      this.theme.brightRed,
      this.theme.brightGreen,
      this.theme.brightYellow,
      this.theme.brightBlue,
      this.theme.brightMagenta,
      this.theme.brightCyan,
      this.theme.brightWhite
    ];
  }
  setFontSize(size) {
    this.fontSize = size;
    this.metrics = this.measureFont();
  }
  setFontFamily(family) {
    this.fontFamily = family;
    this.metrics = this.measureFont();
  }
  setCursorStyle(style) {
    this.cursorStyle = style;
  }
  setCursorBlink(enabled) {
    if (enabled && !this.cursorBlink) {
      this.cursorBlink = true;
      this.startCursorBlink();
    } else if (!enabled && this.cursorBlink) {
      this.cursorBlink = false;
      this.stopCursorBlink();
    }
  }
  resetCursorBlink() {
    this.stopCursorBlink();
    if (this.cursorBlink)
      this.startCursorBlink();
  }
  renderScrollbar(viewportY, scrollbackLength, visibleRows, opacity = 1) {
    const ctx = this.ctx;
    const canvasHeight = this.canvas.height / this.devicePixelRatio;
    const canvasWidth = this.canvas.width / this.devicePixelRatio;
    const scrollbarWidth = 8;
    const scrollbarX = canvasWidth - scrollbarWidth - 4;
    const scrollbarPadding = 4;
    const scrollbarTrackHeight = canvasHeight - scrollbarPadding * 2;
    if (opacity <= 0 || scrollbackLength === 0)
      return;
    ctx.clearRect(scrollbarX - 2, 0, scrollbarWidth + 6, canvasHeight);
    ctx.fillStyle = this.theme.background;
    ctx.fillRect(scrollbarX - 2, 0, scrollbarWidth + 6, canvasHeight);
    const totalLines = scrollbackLength + visibleRows;
    const thumbHeight = Math.max(20, visibleRows / totalLines * scrollbarTrackHeight);
    const scrollPosition = viewportY / scrollbackLength;
    const thumbY = scrollbarPadding + (scrollbarTrackHeight - thumbHeight) * (1 - scrollPosition);
    ctx.fillStyle = `rgba(128, 128, 128, ${0.1 * opacity})`;
    ctx.fillRect(scrollbarX, scrollbarPadding, scrollbarWidth, scrollbarTrackHeight);
    const isScrolled = viewportY > 0;
    const baseOpacity = isScrolled ? 0.5 : 0.3;
    ctx.fillStyle = `rgba(128, 128, 128, ${baseOpacity * opacity})`;
    ctx.fillRect(scrollbarX, thumbY, scrollbarWidth, thumbHeight);
  }
  getMetrics() {
    return { ...this.metrics };
  }
  getCanvas() {
    return this.canvas;
  }
  setSelectionManager(manager) {
    this.selectionManager = manager;
  }
  isInSelection(x, y) {
    const sel = this.currentSelectionCoords;
    if (!sel)
      return false;
    const { startCol, startRow, endCol, endRow } = sel;
    if (startRow === endRow) {
      return y === startRow && x >= startCol && x <= endCol;
    }
    if (y === startRow) {
      return x >= startCol;
    } else if (y === endRow) {
      return x <= endCol;
    } else if (y > startRow && y < endRow) {
      return true;
    }
    return false;
  }
  setHoveredHyperlinkId(hyperlinkId) {
    this.hoveredHyperlinkId = hyperlinkId;
  }
  setHoveredLinkRange(range) {
    this.hoveredLinkRange = range;
  }
  get charWidth() {
    return this.metrics.width;
  }
  get charHeight() {
    return this.metrics.height;
  }
  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.fillStyle = this.theme.background;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }
  dispose() {
    this.stopCursorBlink();
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/color.ts
var HEX3 = /^#([0-9a-f])([0-9a-f])([0-9a-f])([0-9a-f])?$/i;
var HEX6 = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i;
var RGB_FN = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.%]+))?\s*\)$/i;
function parseColor(input, fallback) {
  if (!input)
    return fallback;
  const text = input.trim();
  const hex3 = HEX3.exec(text);
  if (hex3) {
    return {
      r: Number.parseInt(hex3[1] + hex3[1], 16) / 255,
      g: Number.parseInt(hex3[2] + hex3[2], 16) / 255,
      b: Number.parseInt(hex3[3] + hex3[3], 16) / 255,
      a: hex3[4] === undefined ? 1 : Number.parseInt(hex3[4] + hex3[4], 16) / 255
    };
  }
  const hex6 = HEX6.exec(text);
  if (hex6) {
    return {
      r: Number.parseInt(hex6[1], 16) / 255,
      g: Number.parseInt(hex6[2], 16) / 255,
      b: Number.parseInt(hex6[3], 16) / 255,
      a: hex6[4] === undefined ? 1 : Number.parseInt(hex6[4], 16) / 255
    };
  }
  const fn = RGB_FN.exec(text);
  if (fn) {
    const alpha = fn[4] === undefined ? 1 : parseAlpha(fn[4]);
    return {
      r: clamp01(Number.parseFloat(fn[1]) / 255),
      g: clamp01(Number.parseFloat(fn[2]) / 255),
      b: clamp01(Number.parseFloat(fn[3]) / 255),
      a: clamp01(alpha)
    };
  }
  return fallback;
}
function parseAlpha(text) {
  return text.endsWith("%") ? Number.parseFloat(text) / 100 : Number.parseFloat(text);
}
function clamp01(n) {
  return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0;
}

// ../../packages/terminal/ghostty-web/src/webgl/block-elements.ts
function blockElementRects(codepoint) {
  if (codepoint === 9600)
    return [[0, 0, 8, 4]];
  if (codepoint >= 9601 && codepoint <= 9608)
    return [[0, 8 - (codepoint - 9600), 8, 8]];
  if (codepoint >= 9609 && codepoint <= 9615)
    return [[0, 0, 9616 - codepoint, 8]];
  if (codepoint === 9616)
    return [[4, 0, 8, 8]];
  if (codepoint === 9620)
    return [[0, 0, 8, 1]];
  if (codepoint === 9621)
    return [[7, 0, 8, 8]];
  const mask = [4, 8, 1, 13, 9, 7, 11, 2, 6, 14][codepoint - 9622];
  if (mask === undefined)
    return null;
  return [0, 1, 2, 3].filter((bit) => mask & 1 << bit).map((bit) => {
    const x = bit % 2 * 4;
    const y = Math.floor(bit / 2) * 4;
    return [x, y, x + 4, y + 4];
  });
}

// ../../packages/terminal/ghostty-web/src/webgl/glyph-atlas.ts
var PAGE_SIZE = 1024;
var MAX_LAYERS = 4;
var INK_SLACK = 1;
var COLOR_SCAN_THRESHOLD = 169;

class GlyphAtlas {
  gl;
  options;
  texture;
  pageSize;
  scratch;
  scratchCtx;
  cache = new Map;
  asciiCache = [];
  shelfX = 0;
  shelfY = 0;
  shelfHeight = 0;
  layer = 0;
  generation = 0;
  constructor(gl, options) {
    this.gl = gl;
    this.options = options;
    this.pageSize = Math.min(PAGE_SIZE, gl.getParameter(gl.MAX_TEXTURE_SIZE));
    const texture = gl.createTexture();
    if (!texture)
      throw new Error("webgl: createTexture failed (glyph atlas)");
    this.texture = texture;
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, texture);
    gl.texStorage3D(gl.TEXTURE_2D_ARRAY, 1, gl.RGBA8, this.pageSize, this.pageSize, Math.min(MAX_LAYERS, gl.getParameter(gl.MAX_ARRAY_TEXTURE_LAYERS)));
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    this.scratch = document.createElement("canvas");
    const ctx = this.scratch.getContext("2d", { willReadFrequently: true });
    if (!ctx)
      throw new Error("webgl: no 2d context for glyph rasterization");
    this.scratchCtx = ctx;
    this.sizeScratch();
  }
  reconfigure(options) {
    this.options = options;
    this.sizeScratch();
    this.reset();
  }
  reset() {
    this.cache.clear();
    this.asciiCache.length = 0;
    this.shelfX = 0;
    this.shelfY = 0;
    this.shelfHeight = 0;
    this.layer = 0;
    this.generation++;
  }
  bind(unit) {
    this.gl.activeTexture(this.gl.TEXTURE0 + unit);
    this.gl.bindTexture(this.gl.TEXTURE_2D_ARRAY, this.texture);
  }
  dispose() {
    this.gl.deleteTexture(this.texture);
  }
  getAscii(codepoint, style) {
    const slot = (codepoint - 32) * 4 + style;
    const hit = this.asciiCache[slot];
    if (hit !== undefined)
      return hit;
    const entry = this.rasterize(String.fromCharCode(codepoint), style, false);
    this.asciiCache[slot] = entry;
    return entry;
  }
  get(chars, style) {
    const key = `${style}${chars}`;
    const hit = this.cache.get(key);
    if (hit !== undefined)
      return hit;
    const entry = this.rasterize(chars, style, true);
    this.cache.set(key, entry);
    return entry;
  }
  getBlock(codepoint, width, height, rects) {
    const key = `block:${codepoint}:${width}:${height}`;
    const hit = this.cache.get(key);
    if (hit !== undefined)
      return hit;
    if (width <= 0 || height <= 0 || width > this.scratch.width || height > this.scratch.height)
      return null;
    const ctx = this.scratchCtx;
    ctx.clearRect(0, 0, this.scratch.width, this.scratch.height);
    ctx.fillStyle = "#ffffff";
    for (const [left, top, right, bottom] of rects) {
      const x = Math.round(left * width / 8);
      const y = Math.round(top * height / 8);
      ctx.fillRect(x, y, Math.round(right * width / 8) - x, Math.round(bottom * height / 8) - y);
    }
    const rect = this.allocate(width, height);
    if (!rect)
      return null;
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, this.texture);
    gl.texSubImage3D(gl.TEXTURE_2D_ARRAY, 0, rect.x, rect.y, rect.layer, width, height, 1, gl.RGBA, gl.UNSIGNED_BYTE, this.scratch);
    const entry = {
      layer: rect.layer,
      u: rect.x / this.pageSize,
      v: rect.y / this.pageSize,
      uw: width / this.pageSize,
      vh: height / this.pageSize,
      w: width,
      h: height,
      offX: 0,
      offY: 0,
      colored: false
    };
    this.cache.set(key, entry);
    return entry;
  }
  sizeScratch() {
    const { cellWidth, cellHeight } = this.options;
    this.scratch.width = Math.ceil(cellWidth * 4 + 8);
    this.scratch.height = Math.ceil(cellHeight * 3 + 8);
  }
  rasterize(chars, style, maybeColor) {
    const gl = this.gl;
    const ctx = this.scratchCtx;
    const { fontSize, fontFamily, devicePixelRatio, baseline } = this.options;
    let fontStyle = "";
    if (style & 2 /* ITALIC */)
      fontStyle += "italic ";
    if (style & 1 /* BOLD */)
      fontStyle += "bold ";
    ctx.font = `${fontStyle}${fontSize * devicePixelRatio}px ${fontFamily}`;
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    const m = ctx.measureText(chars);
    const inkLeft = m.actualBoundingBoxLeft ?? 0;
    const inkRight = m.actualBoundingBoxRight ?? m.width;
    const inkAscent = m.actualBoundingBoxAscent ?? fontSize * devicePixelRatio;
    const inkDescent = m.actualBoundingBoxDescent ?? 0;
    const w = Math.ceil(inkLeft + inkRight) + INK_SLACK * 2;
    const h = Math.ceil(inkAscent + inkDescent) + INK_SLACK * 2;
    if (w <= INK_SLACK * 2 || h <= INK_SLACK * 2)
      return null;
    if (w > this.scratch.width || h > this.scratch.height)
      return null;
    const originX = Math.ceil(inkLeft) + INK_SLACK;
    const originY = Math.ceil(inkAscent) + INK_SLACK;
    ctx.clearRect(0, 0, this.scratch.width, this.scratch.height);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(chars, originX, originY);
    const colored = maybeColor && this.hasColor(chars, w, h);
    const rect = this.allocate(w, h);
    if (!rect)
      return null;
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, this.texture);
    gl.texSubImage3D(gl.TEXTURE_2D_ARRAY, 0, rect.x, rect.y, rect.layer, w, h, 1, gl.RGBA, gl.UNSIGNED_BYTE, this.scratch);
    return {
      layer: rect.layer,
      u: rect.x / this.pageSize,
      v: rect.y / this.pageSize,
      uw: w / this.pageSize,
      vh: h / this.pageSize,
      w,
      h,
      offX: -originX,
      offY: baseline - originY,
      colored
    };
  }
  hasColor(chars, w, h) {
    let scan = false;
    for (const ch of chars) {
      const codepoint = ch.codePointAt(0) ?? 0;
      const terminalDrawingGlyph = codepoint >= 9472 && codepoint <= 9631;
      if (codepoint >= COLOR_SCAN_THRESHOLD && !terminalDrawingGlyph) {
        scan = true;
        break;
      }
    }
    if (!scan)
      return false;
    const data = this.scratchCtx.getImageData(0, 0, w, h).data;
    for (let i = 0;i < data.length; i += 4) {
      if (data[i + 3] === 0)
        continue;
      if (data[i] !== data[i + 1] || data[i + 1] !== data[i + 2])
        return true;
    }
    return false;
  }
  allocate(w, h) {
    if (w > this.pageSize || h > this.pageSize)
      return null;
    if (this.shelfX + w > this.pageSize) {
      this.shelfX = 0;
      this.shelfY += this.shelfHeight;
      this.shelfHeight = 0;
    }
    if (this.shelfY + h > this.pageSize) {
      this.layer++;
      this.shelfX = 0;
      this.shelfY = 0;
      this.shelfHeight = 0;
    }
    if (this.layer >= MAX_LAYERS) {
      this.reset();
    }
    const rect = { x: this.shelfX, y: this.shelfY, layer: this.layer };
    this.shelfX += w;
    if (h > this.shelfHeight)
      this.shelfHeight = h;
    return rect;
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/gl-utils.ts
function compileProgram(gl, vertexSource, fragmentSource) {
  const vs = compileShader(gl, gl.VERTEX_SHADER, vertexSource);
  const fs = compileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
  const program = gl.createProgram();
  if (!program)
    throw new Error("webgl: createProgram failed");
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  gl.deleteShader(vs);
  gl.deleteShader(fs);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(program);
    gl.deleteProgram(program);
    throw new Error(`webgl: program link failed: ${log}`);
  }
  return program;
}
function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  if (!shader)
    throw new Error("webgl: createShader failed");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(`webgl: shader compile failed: ${log}
${source}`);
  }
  return shader;
}
function bindInstanceAttributes(gl, buffer, attrs, baseOffsetBytes = 0) {
  const stride = attrs.reduce((n, a) => n + a.size, 0) * 4;
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  let offset = baseOffsetBytes;
  for (const attr of attrs) {
    gl.enableVertexAttribArray(attr.location);
    gl.vertexAttribPointer(attr.location, attr.size, gl.FLOAT, false, stride, offset);
    gl.vertexAttribDivisor(attr.location, 1);
    offset += attr.size * 4;
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/instanced-buffer.ts
class InstancedBuffer {
  gl;
  stride;
  data;
  buffer;
  vao;
  attrs;
  capacity;
  dirtyMin = Number.POSITIVE_INFINITY;
  dirtyMax = -1;
  constructor(gl, attrs, capacity) {
    this.gl = gl;
    this.attrs = attrs;
    this.stride = attrs.reduce((n, a) => n + a.size, 0);
    this.capacity = Math.max(1, capacity);
    this.data = new Float32Array(this.capacity * this.stride);
    const buffer = gl.createBuffer();
    const vao = gl.createVertexArray();
    if (!buffer || !vao)
      throw new Error("webgl: buffer/VAO allocation failed");
    this.buffer = buffer;
    this.vao = vao;
    this.allocate();
  }
  get instanceCapacity() {
    return this.capacity;
  }
  resize(capacity) {
    const next = Math.max(1, capacity);
    if (next === this.capacity) {
      this.clearAll();
      return;
    }
    this.capacity = next;
    this.data = new Float32Array(this.capacity * this.stride);
    this.allocate();
  }
  clearInstance(index) {
    const base = index * this.stride;
    this.data.fill(0, base, base + this.stride);
    this.markDirty(index);
  }
  clearAll() {
    this.data.fill(0);
    this.dirtyMin = 0;
    this.dirtyMax = this.capacity - 1;
  }
  markDirty(index) {
    if (index < this.dirtyMin)
      this.dirtyMin = index;
    if (index > this.dirtyMax)
      this.dirtyMax = index;
  }
  markRangeDirty(from, to) {
    if (from < this.dirtyMin)
      this.dirtyMin = from;
    if (to > this.dirtyMax)
      this.dirtyMax = to;
  }
  flush() {
    if (this.dirtyMax < 0)
      return;
    const gl = this.gl;
    const from = Math.max(0, this.dirtyMin) * this.stride;
    const to = Math.min(this.capacity - 1, this.dirtyMax) * this.stride + this.stride;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, from * 4, this.data, from, to - from);
    this.dirtyMin = Number.POSITIVE_INFINITY;
    this.dirtyMax = -1;
  }
  draw(offset = 0, count = this.capacity) {
    if (count <= 0)
      return;
    const gl = this.gl;
    gl.bindVertexArray(this.vao);
    if (offset !== 0) {
      bindInstanceAttributes(gl, this.buffer, this.attrs, offset * this.stride * 4);
    }
    gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, count);
    if (offset !== 0) {
      bindInstanceAttributes(gl, this.buffer, this.attrs, 0);
    }
    gl.bindVertexArray(null);
  }
  dispose() {
    this.gl.deleteBuffer(this.buffer);
    this.gl.deleteVertexArray(this.vao);
  }
  allocate() {
    const gl = this.gl;
    gl.bindVertexArray(this.vao);
    bindInstanceAttributes(gl, this.buffer, this.attrs);
    gl.bufferData(gl.ARRAY_BUFFER, this.data.byteLength, gl.DYNAMIC_DRAW);
    gl.bindVertexArray(null);
    this.dirtyMin = Number.POSITIVE_INFINITY;
    this.dirtyMax = -1;
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/glyph-pass.ts
var VERTEX_SHADER = `#version 300 es
layout(location = 0) in vec4 a_rect;   // x, y, w, h in device pixels
layout(location = 1) in vec4 a_tex;    // u, v, uw, vh normalized
layout(location = 2) in vec2 a_meta;   // atlas layer, colored flag
layout(location = 3) in vec4 a_color;  // tint rgb + alpha (faint)
uniform vec2 u_resolution;
out vec2 v_uv;
out float v_layer;
out float v_colored;
out vec4 v_color;
void main() {
  vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));
  vec2 pixel = a_rect.xy + corner * a_rect.zw;
  vec2 clip = pixel / u_resolution * 2.0 - 1.0;
  gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
  v_uv = a_tex.xy + corner * a_tex.zw;
  v_layer = a_meta.x;
  v_colored = a_meta.y;
  v_color = a_color;
}`;
var FRAGMENT_SHADER = `#version 300 es
precision mediump float;
uniform mediump sampler2DArray u_atlas;
in vec2 v_uv;
in float v_layer;
in float v_colored;
in vec4 v_color;
out vec4 outColor;
void main() {
  vec4 texel = texture(u_atlas, vec3(v_uv, v_layer));
  if (v_colored > 0.5) {
    // Bitmap glyph: keep its own colors, honor the instance alpha (faint).
    float a = texel.a * v_color.a;
    outColor = vec4(texel.rgb * a, a);
  } else {
    // Coverage mask: tint it.
    float coverage = texel.a * v_color.a;
    outColor = vec4(v_color.rgb * coverage, coverage);
  }
}`;
function createGlyphProgram(gl) {
  const program = compileProgram(gl, VERTEX_SHADER, FRAGMENT_SHADER);
  const uResolution = gl.getUniformLocation(program, "u_resolution");
  const uAtlas = gl.getUniformLocation(program, "u_atlas");
  if (!uResolution || !uAtlas)
    throw new Error("webgl: glyph program missing uniforms");
  return { program, uResolution, uAtlas };
}
var STRIDE = 14;

class GlyphPass {
  gl;
  prog;
  buffer;
  constructor(gl, prog, capacity) {
    this.gl = gl;
    this.prog = prog;
    this.buffer = new InstancedBuffer(gl, [
      { location: 0, size: 4 },
      { location: 1, size: 4 },
      { location: 2, size: 2 },
      { location: 3, size: 4 }
    ], capacity);
  }
  resize(capacity) {
    this.buffer.resize(capacity);
  }
  set(index, entry, cellX, cellY, r, g, b, a) {
    const d = this.buffer.data;
    const o = index * STRIDE;
    d[o] = cellX + entry.offX;
    d[o + 1] = cellY + entry.offY;
    d[o + 2] = entry.w;
    d[o + 3] = entry.h;
    d[o + 4] = entry.u;
    d[o + 5] = entry.v;
    d[o + 6] = entry.uw;
    d[o + 7] = entry.vh;
    d[o + 8] = entry.layer;
    d[o + 9] = entry.colored ? 1 : 0;
    d[o + 10] = r;
    d[o + 11] = g;
    d[o + 12] = b;
    d[o + 13] = a;
    this.buffer.markDirty(index);
  }
  clear(index) {
    this.buffer.clearInstance(index);
  }
  clearAll() {
    this.buffer.clearAll();
  }
  draw(atlas, resolutionX, resolutionY, offset = 0, count) {
    const gl = this.gl;
    this.buffer.flush();
    gl.useProgram(this.prog.program);
    gl.uniform2f(this.prog.uResolution, resolutionX, resolutionY);
    atlas.bind(0);
    gl.uniform1i(this.prog.uAtlas, 0);
    this.buffer.draw(offset, count ?? this.buffer.instanceCapacity - offset);
  }
  dispose() {
    this.buffer.dispose();
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/image-pass.ts
var VERTEX_SHADER2 = `#version 300 es
uniform vec4 u_rect;        // x, y, w, h in device pixels
uniform vec4 u_tex;         // u, v, uw, vh normalized source rect
uniform vec2 u_resolution;
out vec2 v_uv;
void main() {
  vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));
  vec2 pixel = u_rect.xy + corner * u_rect.zw;
  vec2 clip = pixel / u_resolution * 2.0 - 1.0;
  gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
  v_uv = u_tex.xy + corner * u_tex.zw;
}`;
var FRAGMENT_SHADER2 = `#version 300 es
precision mediump float;
uniform sampler2D u_image;
uniform float u_opacity;
in vec2 v_uv;
out vec4 outColor;
void main() {
  vec4 texel = texture(u_image, v_uv);
  float a = texel.a * u_opacity;
  outColor = vec4(texel.rgb * a, a);
}`;

class ImagePass {
  gl;
  program;
  uRect;
  uTex;
  uResolution;
  uOpacity;
  uImage;
  vao;
  textures = new Map;
  constructor(gl) {
    this.gl = gl;
    this.program = compileProgram(gl, VERTEX_SHADER2, FRAGMENT_SHADER2);
    const uRect = gl.getUniformLocation(this.program, "u_rect");
    const uTex = gl.getUniformLocation(this.program, "u_tex");
    const uResolution = gl.getUniformLocation(this.program, "u_resolution");
    const uOpacity = gl.getUniformLocation(this.program, "u_opacity");
    const uImage = gl.getUniformLocation(this.program, "u_image");
    if (!uRect || !uTex || !uResolution || !uOpacity || !uImage) {
      throw new Error("webgl: image program missing uniforms");
    }
    this.uRect = uRect;
    this.uTex = uTex;
    this.uResolution = uResolution;
    this.uOpacity = uOpacity;
    this.uImage = uImage;
    const vao = gl.createVertexArray();
    if (!vao)
      throw new Error("webgl: createVertexArray failed (image pass)");
    this.vao = vao;
  }
  draw(placements, below, cellWidth, cellHeight, dpr, resolutionX, resolutionY) {
    const gl = this.gl;
    let bound = false;
    for (const placement of placements) {
      const isBelow = (placement.z ?? 0) < 0;
      if (isBelow !== below)
        continue;
      const cached = this.textureFor(placement.source);
      if (!cached)
        continue;
      if (!bound) {
        gl.useProgram(this.program);
        gl.bindVertexArray(this.vao);
        gl.uniform2f(this.uResolution, resolutionX, resolutionY);
        gl.uniform1i(this.uImage, 0);
        bound = true;
      }
      const src = placement.src ?? { x: 0, y: 0, w: cached.width, h: cached.height };
      gl.uniform4f(this.uRect, placement.col * cellWidth + (placement.offsetX ?? 0) * dpr, placement.row * cellHeight + (placement.offsetY ?? 0) * dpr, placement.cols * cellWidth, placement.rows * cellHeight);
      gl.uniform4f(this.uTex, src.x / cached.width, src.y / cached.height, src.w / cached.width, src.h / cached.height);
      gl.uniform1f(this.uOpacity, placement.opacity ?? 1);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, cached.texture);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    if (bound)
      gl.bindVertexArray(null);
  }
  retainOnly(placements) {
    if (this.textures.size === 0)
      return;
    const live = new Set;
    for (const p of placements)
      live.add(p.source);
    for (const [source, cached] of this.textures) {
      if (!live.has(source)) {
        this.gl.deleteTexture(cached.texture);
        this.textures.delete(source);
      }
    }
  }
  forgetTextures() {
    this.textures.clear();
  }
  dispose() {
    for (const cached of this.textures.values())
      this.gl.deleteTexture(cached.texture);
    this.textures.clear();
    this.gl.deleteVertexArray(this.vao);
    this.gl.deleteProgram(this.program);
  }
  textureFor(source) {
    const hit = this.textures.get(source);
    if (hit)
      return hit;
    const size = sourceSize(source);
    if (!size)
      return null;
    const gl = this.gl;
    const texture = gl.createTexture();
    if (!texture)
      return null;
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const cached = { texture, width: size.width, height: size.height };
    this.textures.set(source, cached);
    return cached;
  }
}
function sourceSize(source) {
  const candidate = source;
  const width = candidate.videoWidth ?? candidate.width;
  const height = source.videoHeight ?? candidate.height;
  if (!width || !height)
    return null;
  return { width, height };
}

// ../../packages/terminal/ghostty-web/src/webgl/rect-pass.ts
var VERTEX_SHADER3 = `#version 300 es
layout(location = 0) in vec4 a_rect;   // x, y, w, h in device pixels
layout(location = 1) in vec4 a_color;  // straight-alpha rgba, 0..1
uniform vec2 u_resolution;
out vec4 v_color;
void main() {
  // Unit-quad corner from the vertex index: TRIANGLE_STRIP over 4 vertices.
  vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));
  vec2 pixel = a_rect.xy + corner * a_rect.zw;
  vec2 clip = pixel / u_resolution * 2.0 - 1.0;
  gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
  v_color = a_color;
}`;
var FRAGMENT_SHADER3 = `#version 300 es
precision mediump float;
in vec4 v_color;
out vec4 outColor;
void main() {
  // Premultiplied output; the pass blends with (ONE, ONE_MINUS_SRC_ALPHA).
  outColor = vec4(v_color.rgb * v_color.a, v_color.a);
}`;
function createRectProgram(gl) {
  const program = compileProgram(gl, VERTEX_SHADER3, FRAGMENT_SHADER3);
  const uResolution = gl.getUniformLocation(program, "u_resolution");
  if (!uResolution)
    throw new Error("webgl: rect program missing u_resolution");
  return { program, uResolution };
}

class RectPass {
  gl;
  prog;
  buffer;
  constructor(gl, prog, capacity) {
    this.gl = gl;
    this.prog = prog;
    this.buffer = new InstancedBuffer(gl, [
      { location: 0, size: 4 },
      { location: 1, size: 4 }
    ], capacity);
  }
  get capacity() {
    return this.buffer.instanceCapacity;
  }
  resize(capacity) {
    this.buffer.resize(capacity);
  }
  set(index, x, y, w, h, r, g, b, a) {
    const d = this.buffer.data;
    const o = index * 8;
    d[o] = x;
    d[o + 1] = y;
    d[o + 2] = w;
    d[o + 3] = h;
    d[o + 4] = r;
    d[o + 5] = g;
    d[o + 6] = b;
    d[o + 7] = a;
    this.buffer.markDirty(index);
  }
  clear(index) {
    this.buffer.clearInstance(index);
  }
  clearAll() {
    this.buffer.clearAll();
  }
  draw(resolutionX, resolutionY, offset = 0, count) {
    const gl = this.gl;
    this.buffer.flush();
    gl.useProgram(this.prog.program);
    gl.uniform2f(this.prog.uResolution, resolutionX, resolutionY);
    this.buffer.draw(offset, count ?? this.buffer.instanceCapacity - offset);
  }
  dispose() {
    this.buffer.dispose();
  }
}

// ../../packages/terminal/ghostty-web/src/webgl/webgl-renderer.ts
var LINK_COLOR = { r: 74 / 255, g: 144 / 255, b: 226 / 255, a: 1 };
var OVERLAY_CURSOR = 0;
var OVERLAY_SCROLLBAR_TRACK = 1;
var OVERLAY_SCROLLBAR_THUMB = 2;
var OVERLAY_RECT_COUNT = 3;

class WebglRenderer {
  canvas;
  gl;
  contextLost = false;
  fontSize;
  fontFamily;
  cursorStyle;
  cursorBlink;
  theme;
  devicePixelRatio;
  metrics;
  bgColor = { r: 0, g: 0, b: 0, a: 1 };
  cursorColor = { r: 1, g: 1, b: 1, a: 1 };
  cursorAccentColor = { r: 0, g: 0, b: 0, a: 1 };
  selectionBgColor = { r: 1, g: 1, b: 1, a: 1 };
  selectionFgColor = { r: 0, g: 0, b: 0, a: 1 };
  atlas;
  atlasGeneration = 0;
  programs = [];
  bgRects;
  decoRects;
  glyphs;
  overlayRects;
  cursorGlyph;
  images;
  placements = [];
  placementsDirty = false;
  cols = 0;
  rows = 0;
  colX = new Int32Array(1);
  rowY = new Int32Array(1);
  cellWidthDevice = 1;
  cellHeightDevice = 1;
  cursorVisible = true;
  cursorClip = null;
  cursorBlinkInterval;
  lastCursorPosition = { x: 0, y: 0 };
  lastViewportY = 0;
  currentBuffer = null;
  currentCells = null;
  currentCols = 0;
  currentSelectionCoords = null;
  rowShadow = [];
  needsFullRebuild = true;
  lastResizeCols = -1;
  lastResizeRows = -1;
  lastResizeCellW = -1;
  lastResizeCellH = -1;
  lastScrollbarOpacity = -1;
  selectionManager;
  hoveredHyperlinkId = 0;
  previousHoveredHyperlinkId = 0;
  hoveredLinkRange = null;
  previousHoveredLinkRange = null;
  onContextLost = (event) => {
    event.preventDefault();
    this.contextLost = true;
  };
  onContextRestored = () => {
    this.contextLost = false;
    this.disposeGlResources();
    this.initGlResources();
    this.rowShadow.length = 0;
    this.needsFullRebuild = true;
    this.lastResizeCols = -1;
  };
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", {
      alpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      preserveDrawingBuffer: false,
      powerPreference: "high-performance"
    });
    if (!gl)
      throw new Error("webgl: WebGL2 is not available on this canvas");
    this.gl = gl;
    this.fontSize = options.fontSize ?? 15;
    this.fontFamily = options.fontFamily ?? "monospace";
    this.cursorStyle = options.cursorStyle ?? "block";
    this.cursorBlink = options.cursorBlink ?? false;
    this.theme = { ...DEFAULT_THEME, ...options.theme };
    this.devicePixelRatio = options.devicePixelRatio ?? (typeof window !== "undefined" ? window.devicePixelRatio : 1) ?? 1;
    this.metrics = measureFontMetrics(this.fontSize, this.fontFamily);
    this.parseThemeColors();
    canvas.addEventListener("webglcontextlost", this.onContextLost);
    canvas.addEventListener("webglcontextrestored", this.onContextRestored);
    this.atlas = undefined;
    this.bgRects = undefined;
    this.decoRects = undefined;
    this.glyphs = undefined;
    this.overlayRects = undefined;
    this.cursorGlyph = undefined;
    this.images = undefined;
    this.initGlResources();
    if (this.cursorBlink)
      this.startCursorBlink();
  }
  initGlResources() {
    const gl = this.gl;
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    const rectProgram = createRectProgram(gl);
    const glyphProgram = createGlyphProgram(gl);
    this.programs = [rectProgram.program, glyphProgram.program];
    this.atlas = new GlyphAtlas(gl, this.atlasOptions());
    this.atlasGeneration = this.atlas.generation;
    const cells = Math.max(1, this.cols * this.rows);
    this.bgRects = new RectPass(gl, rectProgram, cells);
    this.decoRects = new RectPass(gl, rectProgram, cells * 2);
    this.glyphs = new GlyphPass(gl, glyphProgram, cells);
    this.overlayRects = new RectPass(gl, rectProgram, OVERLAY_RECT_COUNT);
    this.cursorGlyph = new GlyphPass(gl, glyphProgram, 1);
    this.images = new ImagePass(gl);
  }
  disposeGlResources() {
    for (const program of this.programs)
      this.gl.deleteProgram(program);
    this.programs = [];
    this.atlas?.dispose();
    this.bgRects?.dispose();
    this.decoRects?.dispose();
    this.glyphs?.dispose();
    this.overlayRects?.dispose();
    this.cursorGlyph?.dispose();
    this.images?.dispose();
  }
  atlasOptions() {
    return {
      fontSize: this.fontSize,
      fontFamily: this.fontFamily,
      devicePixelRatio: this.devicePixelRatio,
      cellWidth: this.metrics.width * this.devicePixelRatio,
      cellHeight: this.metrics.height * this.devicePixelRatio,
      baseline: Math.round(this.metrics.baseline * this.devicePixelRatio)
    };
  }
  resize(cols, rows) {
    this.cols = cols;
    this.rows = rows;
    this.lastResizeCols = cols;
    this.lastResizeRows = rows;
    this.lastResizeCellW = this.metrics.width;
    this.lastResizeCellH = this.metrics.height;
    this.rowShadow.length = 0;
    this.needsFullRebuild = true;
    const cssWidth = cols * this.metrics.width;
    const cssHeight = rows * this.metrics.height;
    this.canvas.style.width = `${cssWidth}px`;
    this.canvas.style.height = `${cssHeight}px`;
    this.canvas.width = Math.max(1, Math.round(cssWidth * this.devicePixelRatio));
    this.canvas.height = Math.max(1, Math.round(cssHeight * this.devicePixelRatio));
    this.colX = new Int32Array(cols + 1);
    for (let x = 0;x <= cols; x++) {
      this.colX[x] = Math.round(x * this.metrics.width * this.devicePixelRatio);
    }
    this.rowY = new Int32Array(rows + 1);
    for (let y = 0;y <= rows; y++) {
      this.rowY[y] = Math.round(y * this.metrics.height * this.devicePixelRatio);
    }
    this.cellWidthDevice = this.metrics.width * this.devicePixelRatio;
    this.cellHeightDevice = this.metrics.height * this.devicePixelRatio;
    const cells = Math.max(1, cols * rows);
    this.bgRects.resize(cells);
    this.decoRects.resize(cells * 2);
    this.glyphs.resize(cells);
    this.atlas.reconfigure(this.atlasOptions());
    this.atlasGeneration = this.atlas.generation;
    this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
  }
  remeasureFont() {
    this.metrics = measureFontMetrics(this.fontSize, this.fontFamily);
  }
  render(buffer, forceAll = false, viewportY = 0, scrollbackProvider, scrollbarOpacity = 1) {
    if (this.contextLost)
      return;
    this.currentBuffer = buffer;
    const cursor = buffer.getCursor();
    const dims = buffer.getDimensions();
    const scrollbackLength = scrollbackProvider ? scrollbackProvider.getScrollbackLength() : 0;
    if (buffer.needsFullRedraw?.())
      forceAll = true;
    if (typeof window !== "undefined" && window.devicePixelRatio && window.devicePixelRatio !== this.devicePixelRatio) {
      this.devicePixelRatio = window.devicePixelRatio;
      this.lastResizeCols = -1;
    }
    const needsResize = this.lastResizeCols !== dims.cols || this.lastResizeRows !== dims.rows || this.lastResizeCellW !== this.metrics.width || this.lastResizeCellH !== this.metrics.height;
    if (needsResize) {
      this.resize(dims.cols, dims.rows);
      forceAll = true;
    }
    if (viewportY !== this.lastViewportY) {
      forceAll = true;
      this.lastViewportY = viewportY;
    }
    if (this.needsFullRebuild)
      forceAll = true;
    const anyDirty = buffer.isDirty ? buffer.isDirty() : true;
    if (viewportY > 0 && anyDirty)
      forceAll = true;
    const cursorMoved = cursor.x !== this.lastCursorPosition.x || cursor.y !== this.lastCursorPosition.y;
    const hasSelection = this.selectionManager && this.selectionManager.hasSelection();
    this.currentSelectionCoords = hasSelection ? this.selectionManager.getSelectionCoords() : null;
    const selectionRows = new Set;
    if (this.currentSelectionCoords) {
      const coords = this.currentSelectionCoords;
      for (let row = coords.startRow;row <= coords.endRow; row++)
        selectionRows.add(row);
    }
    if (this.selectionManager) {
      const dirtyRows = this.selectionManager.getDirtySelectionRows();
      if (dirtyRows.size > 0) {
        for (const row of dirtyRows)
          selectionRows.add(row);
        this.selectionManager.clearDirtySelectionRows();
      }
    }
    const hyperlinkChanged = this.hoveredHyperlinkId !== this.previousHoveredHyperlinkId;
    const linkRangeChanged = JSON.stringify(this.hoveredLinkRange) !== JSON.stringify(this.previousHoveredLinkRange);
    if (!forceAll && !anyDirty && !cursorMoved && !this.cursorBlink && !this.placementsDirty && selectionRows.size === 0 && !hyperlinkChanged && !linkRangeChanged && scrollbarOpacity === this.lastScrollbarOpacity) {
      return;
    }
    const cells = buffer.getViewport ? buffer.getViewport() : null;
    this.currentCells = cells;
    this.currentCols = dims.cols;
    const rowAt = createViewportRowAccessor(buffer, cells, dims, viewportY, scrollbackLength, scrollbackProvider);
    const hyperlinkRows = new Set;
    if (hyperlinkChanged) {
      for (let y = 0;y < dims.rows; y++) {
        const row = rowAt(y);
        if (!row)
          continue;
        for (let i = 0;i < row.count; i++) {
          const cell = row.src[row.base + i];
          if (cell && (cell.hyperlink_id === this.hoveredHyperlinkId || cell.hyperlink_id === this.previousHoveredHyperlinkId)) {
            hyperlinkRows.add(y);
            break;
          }
        }
      }
      this.previousHoveredHyperlinkId = this.hoveredHyperlinkId;
    }
    if (linkRangeChanged) {
      if (this.previousHoveredLinkRange) {
        for (let y = this.previousHoveredLinkRange.startY;y <= this.previousHoveredLinkRange.endY; y++) {
          hyperlinkRows.add(y);
        }
      }
      if (this.hoveredLinkRange) {
        for (let y = this.hoveredLinkRange.startY;y <= this.hoveredLinkRange.endY; y++) {
          hyperlinkRows.add(y);
        }
      }
      this.previousHoveredLinkRange = this.hoveredLinkRange;
    }
    if (viewportY > 0)
      this.rowShadow.length = 0;
    for (let y = 0;y < dims.rows; y++) {
      let contentChanged = forceAll;
      if (viewportY === 0 && (forceAll || buffer.isRowDirty(y))) {
        if (cells) {
          const h = hashRow(cells, y * dims.cols, dims.cols);
          if (!forceAll)
            contentChanged = h !== this.rowShadow[y];
          this.rowShadow[y] = h;
        } else {
          contentChanged = true;
        }
      }
      const needsRebuild = viewportY > 0 ? forceAll || selectionRows.has(y) || hyperlinkRows.has(y) : forceAll || contentChanged || selectionRows.has(y) || hyperlinkRows.has(y);
      if (!needsRebuild)
        continue;
      const row = rowAt(y);
      if (row) {
        this.buildRow(y, row.src, row.base, row.count, dims.cols);
      } else {
        this.clearRow(y, dims.cols);
      }
    }
    this.needsFullRebuild = this.atlas.generation !== this.atlasGeneration;
    this.atlasGeneration = this.atlas.generation;
    this.buildOverlay(cursor, viewportY, scrollbackLength, dims.rows, scrollbarOpacity);
    this.drawFrame(scrollbackLength, scrollbarOpacity);
    this.lastScrollbarOpacity = scrollbarOpacity;
    this.lastCursorPosition = { x: cursor.x, y: cursor.y };
    this.placementsDirty = false;
    buffer.clearDirty();
  }
  clearRow(y, cols) {
    for (let x = 0;x < cols; x++) {
      const idx = y * cols + x;
      this.bgRects.clear(idx);
      this.glyphs.clear(idx);
      this.decoRects.clear(idx * 2);
      this.decoRects.clear(idx * 2 + 1);
    }
  }
  buildRow(y, line, base, count, cols) {
    const y0 = this.rowY[y];
    const y1 = this.rowY[y + 1];
    const cellHeight = y1 - y0;
    const dpr = this.devicePixelRatio;
    const underlineY = y0 + Math.round((this.metrics.baseline + 2) * dpr);
    const strikeY = y0 + Math.round(cellHeight / 2);
    const lineThickness = Math.max(1, Math.round(dpr));
    for (let x = 0;x < cols; x++) {
      const idx = y * cols + x;
      const cell = x < count ? line[base + x] : undefined;
      if (!cell || cell.width === 0) {
        this.bgRects.clear(idx);
        this.glyphs.clear(idx);
        this.decoRects.clear(idx * 2);
        this.decoRects.clear(idx * 2 + 1);
        continue;
      }
      const x0 = this.colX[x];
      const span = Math.min(cols, x + Math.max(1, cell.width));
      const x1 = this.colX[span];
      const width = x1 - x0;
      const selected = this.isInSelection(x, y);
      const inverse = (cell.flags & 16 /* INVERSE */) !== 0;
      if (selected) {
        const c = this.selectionBgColor;
        this.bgRects.set(idx, x0, y0, width, cellHeight, c.r, c.g, c.b, c.a);
      } else {
        const r = inverse ? cell.fg_r : cell.bg_r;
        const g = inverse ? cell.fg_g : cell.bg_g;
        const b = inverse ? cell.fg_b : cell.bg_b;
        if (r === 0 && g === 0 && b === 0) {
          this.bgRects.clear(idx);
        } else {
          this.bgRects.set(idx, x0, y0, width, cellHeight, r / 255, g / 255, b / 255, 1);
        }
      }
      let fr;
      let fg;
      let fb;
      if (selected) {
        fr = this.selectionFgColor.r;
        fg = this.selectionFgColor.g;
        fb = this.selectionFgColor.b;
      } else if (inverse) {
        fr = cell.bg_r / 255;
        fg = cell.bg_g / 255;
        fb = cell.bg_b / 255;
      } else {
        fr = cell.fg_r / 255;
        fg = cell.fg_g / 255;
        fb = cell.fg_b / 255;
      }
      const alpha = cell.flags & 128 /* FAINT */ ? 0.5 : 1;
      if (cell.flags & 32 /* INVISIBLE */) {
        this.glyphs.clear(idx);
      } else {
        const entry = this.glyphFor(cell, y, x);
        if (entry) {
          this.glyphs.set(idx, entry, x0, y0, fr, fg, fb, alpha);
        } else {
          this.glyphs.clear(idx);
        }
      }
      const linkHovered = cell.hyperlink_id > 0 && cell.hyperlink_id === this.hoveredHyperlinkId || this.isInHoveredLinkRange(x, y);
      if (cell.flags & 4 /* UNDERLINE */ || linkHovered) {
        const c = linkHovered ? LINK_COLOR : null;
        this.decoRects.set(idx * 2, x0, underlineY, width, lineThickness, c ? c.r : fr, c ? c.g : fg, c ? c.b : fb, 1);
      } else {
        this.decoRects.clear(idx * 2);
      }
      if (cell.flags & 8 /* STRIKETHROUGH */) {
        this.decoRects.set(idx * 2 + 1, x0, strikeY, width, lineThickness, fr, fg, fb, 1);
      } else {
        this.decoRects.clear(idx * 2 + 1);
      }
    }
  }
  glyphFor(cell, y, x) {
    const chars = cell.codepoint >= 9600 && cell.codepoint <= 9631 ? cell.grapheme_len > 0 && this.currentBuffer?.getGraphemeString ? this.currentBuffer.getGraphemeString(y, x) : String.fromCodePoint(cell.codepoint) : null;
    const rects = chars && chars.length === 1 ? blockElementRects(chars.charCodeAt(0)) : null;
    if (rects && chars) {
      const span = Math.min(this.cols, x + Math.max(1, cell.width));
      return this.atlas.getBlock(chars.charCodeAt(0), this.colX[span] - this.colX[x], this.rowY[y + 1] - this.rowY[y], rects);
    }
    let style = 0 /* NONE */;
    if (cell.flags & 1 /* BOLD */)
      style |= 1 /* BOLD */;
    if (cell.flags & 2 /* ITALIC */)
      style |= 2 /* ITALIC */;
    if (cell.grapheme_len > 0 && this.currentBuffer?.getGraphemeString) {
      const chars2 = this.currentBuffer.getGraphemeString(y, x);
      return chars2 ? this.atlas.get(chars2, style) : null;
    }
    const codepoint = cell.codepoint;
    if (!codepoint || codepoint === 32)
      return null;
    if (codepoint >= 33 && codepoint <= 126)
      return this.atlas.getAscii(codepoint, style);
    return this.atlas.get(String.fromCodePoint(codepoint), style);
  }
  buildOverlay(cursor, viewportY, scrollbackLength, visibleRows, scrollbarOpacity) {
    const showCursor = viewportY === 0 && cursor.visible && this.cursorVisible;
    this.cursorGlyph.clear(0);
    this.cursorClip = null;
    if (!showCursor || cursor.x >= this.cols || cursor.y >= this.rows) {
      this.overlayRects.clear(OVERLAY_CURSOR);
    } else {
      const x0 = this.colX[cursor.x];
      const y0 = this.rowY[cursor.y];
      const w = this.colX[cursor.x + 1] - x0;
      const h = this.rowY[cursor.y + 1] - y0;
      const c = this.cursorColor;
      if (this.cursorStyle === "block") {
        this.overlayRects.set(OVERLAY_CURSOR, x0, y0, w, h, c.r, c.g, c.b, c.a);
        const cell = this.currentCells ? this.currentCells[cursor.y * this.currentCols + cursor.x] : this.currentBuffer?.getLine(cursor.y)?.[cursor.x];
        if (cell) {
          const entry = this.glyphFor(cell, cursor.y, cursor.x);
          if (entry) {
            const accent = this.cursorAccentColor;
            this.cursorGlyph.set(0, entry, x0, y0, accent.r, accent.g, accent.b, accent.a);
            this.cursorClip = { x: x0, y: y0, w, h };
          }
        }
      } else if (this.cursorStyle === "underline") {
        const thickness = Math.max(2, Math.floor(this.metrics.height * 0.15)) * this.devicePixelRatio;
        this.overlayRects.set(OVERLAY_CURSOR, x0, y0 + h - thickness, w, thickness, c.r, c.g, c.b, c.a);
      } else {
        const barWidth = Math.max(2, Math.floor(this.metrics.width * 0.15)) * this.devicePixelRatio;
        this.overlayRects.set(OVERLAY_CURSOR, x0, y0, barWidth, h, c.r, c.g, c.b, c.a);
      }
    }
    if (scrollbarOpacity <= 0 || scrollbackLength === 0) {
      this.overlayRects.clear(OVERLAY_SCROLLBAR_TRACK);
      this.overlayRects.clear(OVERLAY_SCROLLBAR_THUMB);
      return;
    }
    const dpr = this.devicePixelRatio;
    const canvasWidth = this.canvas.width;
    const canvasHeight = this.canvas.height;
    const scrollbarWidth = 8 * dpr;
    const scrollbarX = canvasWidth - scrollbarWidth - 4 * dpr;
    const padding = 4 * dpr;
    const trackHeight = canvasHeight - padding * 2;
    const totalLines = scrollbackLength + visibleRows;
    const thumbHeight = Math.max(20 * dpr, visibleRows / totalLines * trackHeight);
    const thumbY = padding + (trackHeight - thumbHeight) * (1 - viewportY / scrollbackLength);
    this.overlayRects.set(OVERLAY_SCROLLBAR_TRACK, scrollbarX, padding, scrollbarWidth, trackHeight, 0.5, 0.5, 0.5, 0.1 * scrollbarOpacity);
    this.overlayRects.set(OVERLAY_SCROLLBAR_THUMB, scrollbarX, thumbY, scrollbarWidth, thumbHeight, 0.5, 0.5, 0.5, (viewportY > 0 ? 0.5 : 0.3) * scrollbarOpacity);
  }
  drawFrame(scrollbackLength, scrollbarOpacity) {
    const gl = this.gl;
    const w = this.canvas.width;
    const h = this.canvas.height;
    gl.viewport(0, 0, w, h);
    const bg = this.bgColor;
    gl.clearColor(bg.r * bg.a, bg.g * bg.a, bg.b * bg.a, bg.a);
    gl.clear(gl.COLOR_BUFFER_BIT);
    this.bgRects.draw(w, h);
    const hasImages = this.placements.length > 0;
    if (hasImages) {
      this.images.draw(this.placements, true, this.cellWidthDevice, this.cellHeightDevice, this.devicePixelRatio, w, h);
    }
    this.glyphs.draw(this.atlas, w, h);
    this.decoRects.draw(w, h);
    if (hasImages) {
      this.images.draw(this.placements, false, this.cellWidthDevice, this.cellHeightDevice, this.devicePixelRatio, w, h);
    }
    this.overlayRects.draw(w, h, OVERLAY_CURSOR, 1);
    const clip = this.cursorClip;
    if (clip) {
      gl.enable(gl.SCISSOR_TEST);
      gl.scissor(clip.x, h - (clip.y + clip.h), clip.w, clip.h);
      this.cursorGlyph.draw(this.atlas, w, h);
      gl.disable(gl.SCISSOR_TEST);
    }
    if (scrollbarOpacity > 0 && scrollbackLength > 0) {
      this.overlayRects.draw(w, h, OVERLAY_SCROLLBAR_TRACK, 2);
    }
  }
  setImagePlacements(placements) {
    this.placements = [...placements].sort((a, b) => (a.z ?? 0) - (b.z ?? 0));
    this.images.retainOnly(this.placements);
    this.placementsDirty = true;
  }
  getImagePlacements() {
    return this.placements;
  }
  setTheme(theme) {
    this.theme = { ...DEFAULT_THEME, ...theme };
    this.parseThemeColors();
    this.rowShadow.length = 0;
    this.needsFullRebuild = true;
  }
  setFontSize(size) {
    this.fontSize = size;
    this.metrics = measureFontMetrics(this.fontSize, this.fontFamily);
  }
  setFontFamily(family) {
    this.fontFamily = family;
    this.metrics = measureFontMetrics(this.fontSize, this.fontFamily);
  }
  setCursorStyle(style) {
    this.cursorStyle = style;
  }
  setCursorBlink(enabled) {
    if (enabled && !this.cursorBlink) {
      this.cursorBlink = true;
      this.startCursorBlink();
    } else if (!enabled && this.cursorBlink) {
      this.cursorBlink = false;
      this.stopCursorBlink();
    }
  }
  resetCursorBlink() {
    this.stopCursorBlink();
    if (this.cursorBlink)
      this.startCursorBlink();
  }
  setSelectionManager(manager) {
    this.selectionManager = manager;
  }
  setHoveredHyperlinkId(hyperlinkId) {
    this.hoveredHyperlinkId = hyperlinkId;
  }
  setHoveredLinkRange(range) {
    this.hoveredLinkRange = range;
  }
  getMetrics() {
    return { ...this.metrics };
  }
  getCanvas() {
    return this.canvas;
  }
  get charWidth() {
    return this.metrics.width;
  }
  get charHeight() {
    return this.metrics.height;
  }
  clear() {
    this.bgRects.clearAll();
    this.decoRects.clearAll();
    this.glyphs.clearAll();
    this.overlayRects.clearAll();
    this.cursorGlyph.clearAll();
    this.rowShadow.length = 0;
    this.needsFullRebuild = true;
    if (this.contextLost)
      return;
    const gl = this.gl;
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    const bg = this.bgColor;
    gl.clearColor(bg.r * bg.a, bg.g * bg.a, bg.b * bg.a, bg.a);
    gl.clear(gl.COLOR_BUFFER_BIT);
  }
  dispose() {
    this.stopCursorBlink();
    this.canvas.removeEventListener("webglcontextlost", this.onContextLost);
    this.canvas.removeEventListener("webglcontextrestored", this.onContextRestored);
    this.disposeGlResources();
  }
  parseThemeColors() {
    this.bgColor = parseColor(this.theme.background, { r: 0, g: 0, b: 0, a: 1 });
    this.cursorColor = parseColor(this.theme.cursor, { r: 1, g: 1, b: 1, a: 1 });
    this.cursorAccentColor = parseColor(this.theme.cursorAccent, { r: 0, g: 0, b: 0, a: 1 });
    this.selectionBgColor = parseColor(this.theme.selectionBackground, {
      r: 1,
      g: 1,
      b: 1,
      a: 1
    });
    this.selectionFgColor = parseColor(this.theme.selectionForeground, { r: 0, g: 0, b: 0, a: 1 });
  }
  startCursorBlink() {
    this.cursorBlinkInterval = window.setInterval(() => {
      this.cursorVisible = !this.cursorVisible;
    }, 530);
  }
  stopCursorBlink() {
    if (this.cursorBlinkInterval !== undefined) {
      clearInterval(this.cursorBlinkInterval);
      this.cursorBlinkInterval = undefined;
    }
    this.cursorVisible = true;
  }
  isInSelection(x, y) {
    const sel = this.currentSelectionCoords;
    if (!sel)
      return false;
    const { startCol, startRow, endCol, endRow } = sel;
    if (startRow === endRow)
      return y === startRow && x >= startCol && x <= endCol;
    if (y === startRow)
      return x >= startCol;
    if (y === endRow)
      return x <= endCol;
    return y > startRow && y < endRow;
  }
  isInHoveredLinkRange(x, y) {
    const range = this.hoveredLinkRange;
    if (!range)
      return false;
    return y === range.startY && x >= range.startX && (y < range.endY || x <= range.endX) || y > range.startY && y < range.endY || y === range.endY && x <= range.endX && (y > range.startY || x >= range.startX);
  }
}
function hashRow(cells, base, count) {
  let h = 2166136261 | 0;
  for (let i = 0;i < count; i++) {
    const c = cells[base + i];
    if (!c)
      continue;
    h ^= c.codepoint;
    h = Math.imul(h, 16777619);
    h ^= c.fg_r << 16 | c.fg_g << 8 | c.fg_b;
    h = Math.imul(h, 16777619);
    h ^= c.bg_r << 16 | c.bg_g << 8 | c.bg_b;
    h = Math.imul(h, 16777619);
    h ^= c.flags << 24 | c.width << 16 | c.hyperlink_id;
    h = Math.imul(h, 16777619);
    h ^= c.grapheme_len;
    h = Math.imul(h, 16777619);
  }
  return h | 0;
}

// ../../packages/terminal/ghostty-web/src/renderer-factory.ts
function createRenderer(canvas, options, type = "canvas") {
  if (type === "webgl" && supportsWebgl2()) {
    try {
      return new WebglRenderer(canvas, options);
    } catch (error) {
      console.warn("ghostty-web: WebGL renderer failed to initialize.", error);
      throw error;
    }
  }
  if (type === "webgl") {
    console.warn("ghostty-web: WebGL2 unavailable, falling back to the canvas renderer.");
  }
  return new CanvasRenderer(canvas, options);
}
function supportsWebgl2() {
  try {
    return !!document.createElement("canvas").getContext("webgl2");
  } catch {
    return false;
  }
}

// ../../packages/terminal/ghostty-web/src/selection-manager.ts
class SelectionManager {
  terminal;
  renderer;
  wasmTerm;
  textarea;
  selectionStart = null;
  selectionEnd = null;
  isSelecting = false;
  mouseDownX = 0;
  mouseDownY = 0;
  dragThresholdMet = false;
  mouseDownTarget = null;
  dirtySelectionRows = new Set;
  selectionChangedEmitter = new EventEmitter;
  boundMouseUpHandler = null;
  boundContextMenuHandler = null;
  boundClickHandler = null;
  boundDocumentMouseMoveHandler = null;
  restoreContextMenu = null;
  contextMenuTimer = null;
  autoScrollInterval = null;
  autoScrollDirection = 0;
  static AUTO_SCROLL_EDGE_SIZE = 30;
  shouldSelect(event) {
    return event.shiftKey || this.terminal.options.selectOnDrag && !event.altKey || !this.terminal.hasMouseTracking();
  }
  getViewportY() {
    const rawViewportY = typeof this.terminal.getViewportY === "function" ? this.terminal.getViewportY() : this.terminal.viewportY || 0;
    return Math.max(0, Math.floor(rawViewportY));
  }
  viewportRowToAbsolute(viewportRow) {
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    const viewportY = this.getViewportY();
    return scrollbackLength + viewportRow - viewportY;
  }
  absoluteRowToViewport(absoluteRow) {
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    const viewportY = this.getViewportY();
    return absoluteRow - scrollbackLength + viewportY;
  }
  static AUTO_SCROLL_SPEED = 3;
  static AUTO_SCROLL_INTERVAL = 50;
  constructor(terminal, renderer, wasmTerm, textarea) {
    this.terminal = terminal;
    this.renderer = renderer;
    this.wasmTerm = wasmTerm;
    this.textarea = textarea;
    this.attachEventListeners();
  }
  getSelection() {
    if (!this.selectionStart || !this.selectionEnd)
      return "";
    let { col: startCol, absoluteRow: startAbsRow } = this.selectionStart;
    let { col: endCol, absoluteRow: endAbsRow } = this.selectionEnd;
    if (startAbsRow > endAbsRow || startAbsRow === endAbsRow && startCol > endCol) {
      [startCol, endCol] = [endCol, startCol];
      [startAbsRow, endAbsRow] = [endAbsRow, startAbsRow];
    }
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    let text = "";
    for (let absRow = startAbsRow;absRow <= endAbsRow; absRow++) {
      let line = null;
      if (absRow < scrollbackLength) {
        line = this.wasmTerm.getScrollbackLine(absRow);
      } else {
        const screenRow = absRow - scrollbackLength;
        line = this.wasmTerm.getLine(screenRow);
      }
      if (!line)
        continue;
      let lastNonEmpty = -1;
      const colStart = absRow === startAbsRow ? startCol : 0;
      const colEnd = absRow === endAbsRow ? endCol : line.length - 1;
      let lineText = "";
      for (let col = colStart;col <= colEnd; col++) {
        const cell = line[col];
        if (cell && cell.codepoint !== 0) {
          let char;
          if (cell.grapheme_len > 0) {
            if (absRow < scrollbackLength) {
              char = this.wasmTerm.getScrollbackGraphemeString(absRow, col);
            } else {
              const screenRow = absRow - scrollbackLength;
              char = this.wasmTerm.getGraphemeString(screenRow, col);
            }
          } else {
            char = String.fromCodePoint(cell.codepoint);
          }
          lineText += char;
          if (char.trim()) {
            lastNonEmpty = lineText.length;
          }
        } else {
          lineText += " ";
        }
      }
      if (lastNonEmpty >= 0) {
        lineText = lineText.substring(0, lastNonEmpty);
      } else {
        lineText = "";
      }
      text += lineText;
      if (absRow < endAbsRow) {
        text += `
`;
      }
    }
    return text;
  }
  hasSelection() {
    if (!this.selectionStart || !this.selectionEnd)
      return false;
    if (this.isSelecting && !this.dragThresholdMet)
      return false;
    return true;
  }
  copySelection() {
    if (!this.hasSelection())
      return false;
    const text = this.getSelection();
    if (text) {
      this.copyToClipboard(text);
      return true;
    }
    return false;
  }
  clearSelection() {
    if (!this.hasSelection())
      return;
    const coords = this.normalizeSelection();
    if (coords) {
      for (let row = coords.startRow;row <= coords.endRow; row++) {
        this.dirtySelectionRows.add(row);
      }
    }
    this.selectionStart = null;
    this.selectionEnd = null;
    this.isSelecting = false;
    this.requestRender();
  }
  selectAll() {
    const dims = this.wasmTerm.getDimensions();
    const viewportY = this.getViewportY();
    this.selectionStart = { col: 0, absoluteRow: viewportY };
    this.selectionEnd = { col: dims.cols - 1, absoluteRow: viewportY + dims.rows - 1 };
    this.requestRender();
    this.selectionChangedEmitter.fire();
  }
  select(column, row, length) {
    const dims = this.wasmTerm.getDimensions();
    row = Math.max(0, Math.min(row, dims.rows - 1));
    column = Math.max(0, Math.min(column, dims.cols - 1));
    let endRow = row;
    let endCol = column + length - 1;
    while (endCol >= dims.cols) {
      endCol -= dims.cols;
      endRow++;
    }
    endRow = Math.min(endRow, dims.rows - 1);
    const viewportY = this.getViewportY();
    this.selectionStart = { col: column, absoluteRow: viewportY + row };
    this.selectionEnd = { col: endCol, absoluteRow: viewportY + endRow };
    this.requestRender();
    this.selectionChangedEmitter.fire();
  }
  selectLines(start, end) {
    const dims = this.wasmTerm.getDimensions();
    start = Math.max(0, Math.min(start, dims.rows - 1));
    end = Math.max(0, Math.min(end, dims.rows - 1));
    if (start > end) {
      [start, end] = [end, start];
    }
    this.selectionStart = { col: 0, absoluteRow: this.viewportRowToAbsolute(start) };
    this.selectionEnd = { col: dims.cols - 1, absoluteRow: this.viewportRowToAbsolute(end) };
    this.requestRender();
    this.selectionChangedEmitter.fire();
  }
  getSelectionPosition() {
    const coords = this.normalizeSelection();
    if (!coords)
      return;
    return {
      start: { x: coords.startCol, y: coords.startRow },
      end: { x: coords.endCol, y: coords.endRow }
    };
  }
  deselect() {
    this.clearSelection();
    this.selectionChangedEmitter.fire();
  }
  focus() {
    const canvas = this.renderer.getCanvas();
    if (canvas.parentElement) {
      canvas.parentElement.focus();
    }
  }
  getSelectionCoords() {
    return this.normalizeSelection();
  }
  getDirtySelectionRows() {
    return this.dirtySelectionRows;
  }
  clearDirtySelectionRows() {
    this.dirtySelectionRows.clear();
  }
  get onSelectionChange() {
    return this.selectionChangedEmitter.event;
  }
  dispose() {
    this.restoreContextMenu?.();
    this.selectionChangedEmitter.dispose();
    this.stopAutoScroll();
    if (this.boundMouseUpHandler) {
      document.removeEventListener("mouseup", this.boundMouseUpHandler);
      this.boundMouseUpHandler = null;
    }
    if (this.boundDocumentMouseMoveHandler) {
      document.removeEventListener("mousemove", this.boundDocumentMouseMoveHandler);
      this.boundDocumentMouseMoveHandler = null;
    }
    if (this.boundContextMenuHandler) {
      const canvas = this.renderer.getCanvas();
      canvas.removeEventListener("contextmenu", this.boundContextMenuHandler);
      this.boundContextMenuHandler = null;
    }
    if (this.boundClickHandler) {
      document.removeEventListener("click", this.boundClickHandler);
      this.boundClickHandler = null;
    }
  }
  attachEventListeners() {
    const canvas = this.renderer.getCanvas();
    canvas.addEventListener("mousedown", (e) => {
      if (!this.shouldSelect(e))
        return;
      if (e.button === 0) {
        if (canvas.parentElement) {
          canvas.parentElement.focus();
        }
        const cell = this.pixelToCell(e.offsetX, e.offsetY);
        const hadSelection = this.hasSelection();
        if (hadSelection) {
          this.clearSelection();
        }
        const absoluteRow = this.viewportRowToAbsolute(cell.row);
        this.selectionStart = { col: cell.col, absoluteRow };
        this.selectionEnd = { col: cell.col, absoluteRow };
        this.isSelecting = true;
        this.mouseDownX = e.offsetX;
        this.mouseDownY = e.offsetY;
        this.dragThresholdMet = false;
      }
    });
    canvas.addEventListener("mousemove", (e) => {
      if (this.isSelecting) {
        if (!this.dragThresholdMet) {
          const dx = e.offsetX - this.mouseDownX;
          const dy = e.offsetY - this.mouseDownY;
          const threshold = this.renderer.getMetrics().width * 0.5;
          if (dx * dx + dy * dy < threshold * threshold) {
            return;
          }
          this.dragThresholdMet = true;
        }
        this.markCurrentSelectionDirty();
        this.selectionEnd = this.pixelToSelectionEnd(e.offsetX, e.offsetY);
        this.requestRender();
        this.updateAutoScroll(e.offsetY, canvas.clientHeight);
      }
    });
    canvas.addEventListener("mouseleave", (e) => {
      if (this.isSelecting) {
        const rect = canvas.getBoundingClientRect();
        if (e.clientY < rect.top) {
          this.startAutoScroll(-1);
        } else if (e.clientY > rect.bottom) {
          this.startAutoScroll(1);
        }
      }
    });
    canvas.addEventListener("mouseenter", () => {
      if (this.isSelecting) {
        this.stopAutoScroll();
      }
    });
    this.boundDocumentMouseMoveHandler = (e) => {
      if (this.isSelecting) {
        if (!this.dragThresholdMet) {
          const dx = e.clientX - (canvas.getBoundingClientRect().left + this.mouseDownX);
          const dy = e.clientY - (canvas.getBoundingClientRect().top + this.mouseDownY);
          const threshold = this.renderer.getMetrics().width * 0.5;
          if (dx * dx + dy * dy < threshold * threshold) {
            return;
          }
          this.dragThresholdMet = true;
        }
        const rect = canvas.getBoundingClientRect();
        const clampedX = Math.max(rect.left, Math.min(e.clientX, rect.right));
        const clampedY = Math.max(rect.top, Math.min(e.clientY, rect.bottom));
        const offsetX = clampedX - rect.left;
        const offsetY = clampedY - rect.top;
        if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) {
          if (e.clientY < rect.top) {
            this.startAutoScroll(-1);
          } else if (e.clientY > rect.bottom) {
            this.startAutoScroll(1);
          } else {
            this.stopAutoScroll();
          }
          if (this.autoScrollDirection === 0) {
            this.markCurrentSelectionDirty();
            this.selectionEnd = this.pixelToSelectionEnd(offsetX, offsetY);
            this.requestRender();
          }
        }
      }
    };
    document.addEventListener("mousemove", this.boundDocumentMouseMoveHandler);
    document.addEventListener("mousedown", (e) => {
      this.mouseDownTarget = e.target;
    });
    this.boundMouseUpHandler = (e) => {
      if (this.isSelecting) {
        this.isSelecting = false;
        this.stopAutoScroll();
        if (!this.dragThresholdMet) {
          this.clearSelection();
          return;
        }
        if (this.hasSelection()) {
          const text = this.getSelection();
          if (text) {
            if (this.terminal.options.copyOnSelect)
              this.copyToClipboard(text);
            this.selectionChangedEmitter.fire();
          }
        }
      }
    };
    document.addEventListener("mouseup", this.boundMouseUpHandler);
    canvas.addEventListener("click", (e) => {
      if (!this.shouldSelect(e))
        return;
      if (e.detail === 2) {
        const cell = this.pixelToCell(e.offsetX, e.offsetY);
        const word = this.getWordAtCell(cell.col, cell.row);
        if (word) {
          const absoluteRow = this.viewportRowToAbsolute(cell.row);
          this.selectionStart = { col: word.startCol, absoluteRow };
          this.selectionEnd = { col: word.endCol, absoluteRow };
          this.requestRender();
          const text = this.getSelection();
          if (text) {
            if (this.terminal.options.copyOnSelect)
              this.copyToClipboard(text);
            this.selectionChangedEmitter.fire();
          }
        }
      } else if (e.detail >= 3) {
        const cell = this.pixelToCell(e.offsetX, e.offsetY);
        const absoluteRow = this.viewportRowToAbsolute(cell.row);
        const scrollbackLength = this.wasmTerm.getScrollbackLength();
        let line = null;
        if (absoluteRow < scrollbackLength) {
          line = this.wasmTerm.getScrollbackLine(absoluteRow);
        } else {
          const screenRow = absoluteRow - scrollbackLength;
          line = this.wasmTerm.getLine(screenRow);
        }
        let endCol = -1;
        if (line) {
          for (let i = line.length - 1;i >= 0; i--) {
            if (line[i] && line[i].codepoint !== 0 && line[i].codepoint !== 32) {
              endCol = i;
              break;
            }
          }
        }
        if (endCol >= 0) {
          this.selectionStart = { col: 0, absoluteRow };
          this.selectionEnd = { col: endCol, absoluteRow };
          this.requestRender();
          const text = this.getSelection();
          if (text) {
            if (this.terminal.options.copyOnSelect)
              this.copyToClipboard(text);
            this.selectionChangedEmitter.fire();
          }
        }
      }
    });
    this.boundContextMenuHandler = (e) => {
      this.restoreContextMenu?.();
      const previousStyle = this.textarea.style.cssText;
      this.textarea.style.position = "fixed";
      this.textarea.style.left = `${e.clientX}px`;
      this.textarea.style.top = `${e.clientY}px`;
      this.textarea.style.width = "1px";
      this.textarea.style.height = "1px";
      this.textarea.style.zIndex = "1000";
      this.textarea.style.opacity = "0";
      this.textarea.style.pointerEvents = "auto";
      if (this.hasSelection()) {
        const text = this.getSelection();
        this.textarea.value = text;
        this.textarea.select();
        this.textarea.setSelectionRange(0, text.length);
      } else {
        this.textarea.value = "";
      }
      this.textarea.focus();
      const resetTextarea = () => {
        if (this.contextMenuTimer !== null)
          clearTimeout(this.contextMenuTimer);
        this.contextMenuTimer = null;
        this.textarea.style.cssText = previousStyle;
        this.textarea.value = "";
        document.removeEventListener("click", resetTextarea);
        document.removeEventListener("contextmenu", resetTextarea);
        this.textarea.removeEventListener("blur", resetTextarea);
        this.restoreContextMenu = null;
      };
      this.restoreContextMenu = resetTextarea;
      this.contextMenuTimer = setTimeout(() => {
        this.contextMenuTimer = null;
        document.addEventListener("click", resetTextarea, { once: true });
        document.addEventListener("contextmenu", resetTextarea, { once: true });
        this.textarea.addEventListener("blur", resetTextarea, { once: true });
      }, 10);
    };
    canvas.addEventListener("contextmenu", this.boundContextMenuHandler);
    this.boundClickHandler = (e) => {
      if (this.isSelecting) {
        return;
      }
      const mouseDownWasInCanvas = this.mouseDownTarget && canvas.contains(this.mouseDownTarget);
      if (mouseDownWasInCanvas) {
        return;
      }
      const target = e.target;
      if (!canvas.contains(target)) {
        if (this.hasSelection()) {
          this.clearSelection();
        }
      }
    };
    document.addEventListener("click", this.boundClickHandler);
  }
  markCurrentSelectionDirty() {
    const coords = this.normalizeSelection();
    if (coords) {
      for (let row = coords.startRow;row <= coords.endRow; row++) {
        this.dirtySelectionRows.add(row);
      }
    }
  }
  updateAutoScroll(offsetY, canvasHeight) {
    const edgeSize = SelectionManager.AUTO_SCROLL_EDGE_SIZE;
    if (offsetY < edgeSize) {
      this.startAutoScroll(-1);
    } else if (offsetY > canvasHeight - edgeSize) {
      this.startAutoScroll(1);
    } else {
      this.stopAutoScroll();
    }
  }
  startAutoScroll(direction) {
    if (this.autoScrollInterval !== null && this.autoScrollDirection === direction) {
      return;
    }
    this.stopAutoScroll();
    this.autoScrollDirection = direction;
    this.autoScrollInterval = setInterval(() => {
      if (!this.isSelecting) {
        this.stopAutoScroll();
        return;
      }
      const scrollAmount = SelectionManager.AUTO_SCROLL_SPEED * this.autoScrollDirection;
      this.terminal.scrollLines(scrollAmount);
      if (this.selectionEnd) {
        const dims = this.wasmTerm.getDimensions();
        if (this.autoScrollDirection < 0) {
          const topAbsoluteRow = this.viewportRowToAbsolute(0);
          if (topAbsoluteRow < this.selectionEnd.absoluteRow) {
            this.selectionEnd = { col: 0, absoluteRow: topAbsoluteRow };
          }
        } else {
          const bottomAbsoluteRow = this.viewportRowToAbsolute(dims.rows - 1);
          if (bottomAbsoluteRow > this.selectionEnd.absoluteRow) {
            this.selectionEnd = { col: dims.cols - 1, absoluteRow: bottomAbsoluteRow };
          }
        }
      }
      this.requestRender();
    }, SelectionManager.AUTO_SCROLL_INTERVAL);
  }
  stopAutoScroll() {
    if (this.autoScrollInterval !== null) {
      clearInterval(this.autoScrollInterval);
      this.autoScrollInterval = null;
    }
    this.autoScrollDirection = 0;
  }
  pixelToCell(x, y) {
    const metrics = this.renderer.getMetrics();
    const col = Math.floor(x / metrics.width);
    const row = Math.floor(y / metrics.height);
    return {
      col: Math.max(0, Math.min(col, this.terminal.cols - 1)),
      row: Math.max(0, Math.min(row, this.terminal.rows - 1))
    };
  }
  pixelToSelectionEnd(x, y) {
    const metrics = this.renderer.getMetrics();
    const cols = this.terminal.cols;
    const row = Math.max(0, Math.min(Math.floor(y / metrics.height), this.terminal.rows - 1));
    const absoluteRow = this.viewportRowToAbsolute(row);
    const boundaryCol = Math.max(0, Math.min(Math.floor(x / metrics.width + 0.5), cols));
    const boundary = absoluteRow * cols + boundaryCol;
    const anchor = this.selectionStart.absoluteRow * cols + this.selectionStart.col;
    const end = boundary > anchor ? boundary - 1 : boundary;
    return { col: (end % cols + cols) % cols, absoluteRow: Math.floor(end / cols) };
  }
  normalizeSelection() {
    if (!this.selectionStart || !this.selectionEnd)
      return null;
    let { col: startCol, absoluteRow: startAbsRow } = this.selectionStart;
    let { col: endCol, absoluteRow: endAbsRow } = this.selectionEnd;
    if (startAbsRow > endAbsRow || startAbsRow === endAbsRow && startCol > endCol) {
      [startCol, endCol] = [endCol, startCol];
      [startAbsRow, endAbsRow] = [endAbsRow, startAbsRow];
    }
    let startRow = this.absoluteRowToViewport(startAbsRow);
    let endRow = this.absoluteRowToViewport(endAbsRow);
    const dims = this.wasmTerm.getDimensions();
    const maxRow = dims.rows - 1;
    if (endRow < 0 || startRow > maxRow) {
      return null;
    }
    if (startRow < 0) {
      startRow = 0;
      startCol = 0;
    }
    if (endRow > maxRow) {
      endRow = maxRow;
      endCol = dims.cols - 1;
    }
    return { startCol, startRow, endCol, endRow };
  }
  getWordAtCell(col, row) {
    const absoluteRow = this.viewportRowToAbsolute(row);
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    let line;
    if (absoluteRow < scrollbackLength) {
      line = this.wasmTerm.getScrollbackLine(absoluteRow);
    } else {
      const screenRow = absoluteRow - scrollbackLength;
      line = this.wasmTerm.getLine(screenRow);
    }
    if (!line)
      return null;
    const isWordChar = (cell) => {
      if (!cell || cell.codepoint === 0)
        return false;
      const char = String.fromCodePoint(cell.codepoint);
      return /[\w\-./~@+]/.test(char);
    };
    if (!isWordChar(line[col]))
      return null;
    let startCol = col;
    while (startCol > 0 && isWordChar(line[startCol - 1])) {
      startCol--;
    }
    let endCol = col;
    while (endCol < line.length - 1 && isWordChar(line[endCol + 1])) {
      endCol++;
    }
    return { startCol, endCol };
  }
  copyToClipboard(text) {
    if (navigator.clipboard && typeof ClipboardItem !== "undefined") {
      try {
        const blob = new Blob([text], { type: "text/plain" });
        const clipboardItem = new ClipboardItem({
          "text/plain": blob
        });
        navigator.clipboard.write([clipboardItem]).then(() => {
          this.terminal.options.onClipboardWrite(true);
        }, (err) => {
          console.warn("ClipboardItem write failed, trying writeText:", err);
          this.copyWithWriteText(text);
        });
        return;
      } catch (err) {}
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        this.terminal.options.onClipboardWrite(true);
      }, (err) => {
        console.warn("Clipboard writeText failed, trying execCommand:", err);
        this.copyWithExecCommand(text);
      });
      return;
    }
    this.copyWithExecCommand(text);
  }
  copyWithWriteText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        this.terminal.options.onClipboardWrite(true);
      }, (err) => {
        console.warn("Clipboard writeText failed, trying execCommand:", err);
        this.copyWithExecCommand(text);
      });
    } else {
      this.copyWithExecCommand(text);
    }
  }
  copyWithExecCommand(text) {
    const previouslyFocused = document.activeElement;
    const previousStyle = this.textarea.style.cssText;
    const previousValue = this.textarea.value;
    try {
      const textarea = this.textarea;
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";
      textarea.style.top = "0";
      textarea.style.width = "1px";
      textarea.style.height = "1px";
      textarea.style.opacity = "0";
      textarea.focus();
      textarea.select();
      textarea.setSelectionRange(0, text.length);
      const success = document.execCommand("copy");
      if (previouslyFocused) {
        previouslyFocused.focus();
      }
      if (!success) {
        console.warn("execCommand copy failed");
      }
      this.terminal.options.onClipboardWrite(success);
    } catch (err) {
      console.warn("execCommand copy threw:", err);
      this.terminal.options.onClipboardWrite(false);
      if (previouslyFocused) {
        previouslyFocused.focus();
      }
    } finally {
      this.textarea.style.cssText = previousStyle;
      this.textarea.value = previousValue;
    }
  }
  requestRender() {}
}

// ../../packages/terminal/ghostty-web/src/terminal.ts
class Terminal {
  cols;
  rows;
  element;
  textarea;
  imeOverlay;
  originalPosition;
  forwardFocus = () => this.textarea?.focus({ preventScroll: true });
  hasFocus = false;
  setFocus(focused) {
    if (focused === this.hasFocus)
      return;
    this.hasFocus = focused;
    if (this.isDisposed || !this.wasmTerm?.hasFocusEvents())
      return;
    this.dataEmitter.fire(focused ? "\x1B[I" : "\x1B[O");
  }
  ownsActiveElement() {
    return !!this.element && this.element.contains(document.activeElement);
  }
  handleFocusIn = () => {
    if (document.hasFocus?.() === false)
      return;
    this.setFocus(true);
  };
  handleFocusOut = (event) => {
    const next = event.relatedTarget;
    if (next && this.element?.contains(next))
      return;
    this.setFocus(false);
  };
  handleWindowBlur = () => this.setFocus(false);
  handleWindowFocus = () => this.setFocus(this.ownsActiveElement());
  buffer;
  unicode = {
    get activeVersion() {
      return "15.1";
    }
  };
  options;
  ghostty;
  wasmTerm;
  renderer;
  inputHandler;
  selectionManager;
  canvas;
  linkDetector;
  currentHoveredLink;
  mouseMoveThrottleTimeout;
  pendingMouseMove;
  dataEmitter = new EventEmitter;
  resizeEmitter = new EventEmitter;
  bellEmitter = new EventEmitter;
  selectionChangeEmitter = new EventEmitter;
  keyEmitter = new EventEmitter;
  titleChangeEmitter = new EventEmitter;
  scrollEmitter = new EventEmitter;
  renderEmitter = new EventEmitter;
  cursorMoveEmitter = new EventEmitter;
  onData = this.dataEmitter.event;
  onResize = this.resizeEmitter.event;
  onBell = this.bellEmitter.event;
  onSelectionChange = this.selectionChangeEmitter.event;
  onKey = this.keyEmitter.event;
  onTitleChange = this.titleChangeEmitter.event;
  onScroll = this.scrollEmitter.event;
  onRender = this.renderEmitter.event;
  onCursorMove = this.cursorMoveEmitter.event;
  isOpen = false;
  isDisposed = false;
  animationFrameId;
  writeQueue = [];
  awaitingEcho = false;
  addons = [];
  customKeyEventHandler;
  currentTitle = "";
  viewportY = 0;
  targetViewportY = 0;
  scrollAnimationStartTime;
  scrollAnimationStartY;
  scrollAnimationFrame;
  customWheelEventHandler;
  lastCursorY = 0;
  isDraggingScrollbar = false;
  scrollbarDragStart = null;
  scrollbarDragStartViewportY = 0;
  scrollbarVisible = false;
  scrollbarOpacity = 0;
  scrollbarHideTimeout;
  SCROLLBAR_HIDE_DELAY_MS = 1500;
  SCROLLBAR_FADE_DURATION_MS = 200;
  constructor(options = {}) {
    this.ghostty = options.ghostty ?? getGhostty();
    const baseOptions = {
      cols: options.cols ?? 80,
      rows: options.rows ?? 24,
      cursorBlink: options.cursorBlink ?? false,
      cursorStyle: options.cursorStyle ?? "block",
      theme: options.theme ?? {},
      scrollback: options.scrollback ?? 1e4,
      fontSize: options.fontSize ?? 15,
      fontFamily: options.fontFamily ?? "monospace",
      allowTransparency: options.allowTransparency ?? false,
      convertEol: options.convertEol ?? false,
      disableStdin: options.disableStdin ?? false,
      selectOnDrag: options.selectOnDrag ?? false,
      copyOnSelect: options.copyOnSelect ?? true,
      ctrlVPaste: options.ctrlVPaste ?? true,
      onClipboardWrite: options.onClipboardWrite ?? (() => {}),
      smoothScrollDuration: options.smoothScrollDuration ?? 100,
      rendererType: options.rendererType ?? "canvas"
    };
    this.options = new Proxy(baseOptions, {
      set: (target, prop, value) => {
        const oldValue = target[prop];
        target[prop] = value;
        if (this.isOpen) {
          this.handleOptionChange(prop, value, oldValue);
        }
        return true;
      }
    });
    this.cols = this.options.cols;
    this.rows = this.options.rows;
    this.buffer = new BufferNamespace(this);
  }
  handleOptionChange(key, newValue, oldValue) {
    if (newValue === oldValue)
      return;
    switch (key) {
      case "disableStdin":
        break;
      case "cursorBlink":
      case "cursorStyle":
        if (this.renderer) {
          this.renderer.setCursorStyle(this.options.cursorStyle);
          this.renderer.setCursorBlink(this.options.cursorBlink);
        }
        break;
      case "theme":
        if (this.renderer) {
          console.warn("ghostty-web: theme changes after open() are not yet fully supported");
        }
        break;
      case "fontSize":
        if (this.renderer) {
          this.renderer.setFontSize(this.options.fontSize);
          this.handleFontChange();
        }
        break;
      case "fontFamily":
        if (this.renderer) {
          this.renderer.setFontFamily(this.options.fontFamily);
          this.handleFontChange();
        }
        break;
      case "cols":
      case "rows":
        this.resize(this.options.cols, this.options.rows);
        break;
    }
  }
  handleFontChange() {
    if (!this.renderer || !this.wasmTerm || !this.canvas)
      return;
    if (this.selectionManager) {
      this.selectionManager.clearSelection();
    }
    this.renderer.resize(this.cols, this.rows);
    this.renderer.render(this.wasmTerm, true, this.viewportY, this);
  }
  parseColorToHex(color) {
    if (!color)
      return 0;
    if (color.startsWith("#")) {
      let hex = color.slice(1);
      if (hex.length === 3) {
        hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      }
      const value = Number.parseInt(hex, 16);
      return Number.isNaN(value) ? 0 : value;
    }
    const match = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (match) {
      const r = Number.parseInt(match[1], 10);
      const g = Number.parseInt(match[2], 10);
      const b = Number.parseInt(match[3], 10);
      return r << 16 | g << 8 | b;
    }
    return 0;
  }
  buildWasmConfig() {
    const theme = this.options.theme;
    const scrollback = this.options.scrollback;
    if (!theme && scrollback === 1e4) {
      return;
    }
    const palette = [
      this.parseColorToHex(theme?.black),
      this.parseColorToHex(theme?.red),
      this.parseColorToHex(theme?.green),
      this.parseColorToHex(theme?.yellow),
      this.parseColorToHex(theme?.blue),
      this.parseColorToHex(theme?.magenta),
      this.parseColorToHex(theme?.cyan),
      this.parseColorToHex(theme?.white),
      this.parseColorToHex(theme?.brightBlack),
      this.parseColorToHex(theme?.brightRed),
      this.parseColorToHex(theme?.brightGreen),
      this.parseColorToHex(theme?.brightYellow),
      this.parseColorToHex(theme?.brightBlue),
      this.parseColorToHex(theme?.brightMagenta),
      this.parseColorToHex(theme?.brightCyan),
      this.parseColorToHex(theme?.brightWhite)
    ];
    return {
      scrollbackLimit: scrollback,
      fgColor: this.parseColorToHex(theme?.foreground),
      bgColor: this.parseColorToHex(theme?.background),
      cursorColor: this.parseColorToHex(theme?.cursor),
      palette
    };
  }
  open(parent) {
    if (this.isOpen) {
      throw new Error("Terminal is already open");
    }
    if (this.isDisposed) {
      throw new Error("Terminal has been disposed");
    }
    this.element = parent;
    this.isOpen = true;
    try {
      if (!parent.hasAttribute("tabindex")) {
        parent.setAttribute("tabindex", "0");
      }
      parent.setAttribute("contenteditable", "true");
      if (getComputedStyle(parent).position === "static" || !getComputedStyle(parent).position) {
        this.originalPosition = parent.style.position;
        parent.style.position = "relative";
      }
      parent.addEventListener("focus", this.forwardFocus);
      parent.addEventListener("focusin", this.handleFocusIn);
      parent.addEventListener("focusout", this.handleFocusOut);
      window.addEventListener("blur", this.handleWindowBlur);
      window.addEventListener("focus", this.handleWindowFocus);
      this.hasFocus = document.hasFocus?.() !== false && this.ownsActiveElement();
      parent.addEventListener("beforeinput", (e) => {
        if (e.target === parent) {
          e.preventDefault();
        }
      });
      parent.setAttribute("role", "textbox");
      parent.setAttribute("aria-label", "Terminal input");
      parent.setAttribute("aria-multiline", "true");
      const config = this.buildWasmConfig();
      this.wasmTerm = this.ghostty.createTerminal(this.cols, this.rows, config);
      this.canvas = document.createElement("canvas");
      this.canvas.style.display = "block";
      this.canvas.style.cursor = "text";
      parent.appendChild(this.canvas);
      this.textarea = document.createElement("textarea");
      this.textarea.setAttribute("autocorrect", "off");
      this.textarea.setAttribute("autocapitalize", "off");
      this.textarea.setAttribute("spellcheck", "false");
      this.textarea.setAttribute("tabindex", "0");
      this.textarea.setAttribute("aria-label", "Terminal input");
      this.textarea.style.position = "absolute";
      this.textarea.style.left = "0";
      this.textarea.style.top = "0";
      this.textarea.style.width = "1px";
      this.textarea.style.height = "1px";
      this.textarea.style.padding = "0";
      this.textarea.style.border = "none";
      this.textarea.style.margin = "0";
      this.textarea.style.color = "transparent";
      this.textarea.style.caretColor = "transparent";
      this.textarea.style.background = "transparent";
      this.textarea.style.outline = "none";
      this.textarea.style.pointerEvents = "none";
      this.textarea.style.overflow = "hidden";
      this.textarea.style.whiteSpace = "nowrap";
      this.textarea.style.resize = "none";
      parent.appendChild(this.textarea);
      const textarea = this.textarea;
      this.canvas.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        textarea.focus();
      });
      this.canvas.addEventListener("touchend", (ev) => {
        ev.preventDefault();
        textarea.focus();
      });
      this.renderer = createRenderer(this.canvas, {
        fontSize: this.options.fontSize,
        fontFamily: this.options.fontFamily,
        cursorStyle: this.options.cursorStyle,
        cursorBlink: this.options.cursorBlink,
        theme: this.options.theme
      }, this.options.rendererType);
      this.renderer.resize(this.cols, this.rows);
      this.imeOverlay = new ImeOverlay(this.textarea, () => this.updateImePosition());
      this.updateImePosition();
      const canvas = this.canvas;
      const renderer = this.renderer;
      const wasmTerm = this.wasmTerm;
      const mouseConfig = {
        preferSelection: () => this.options.selectOnDrag,
        hasMouseTracking: () => wasmTerm?.hasMouseTracking() ?? false,
        hasSgrMouseMode: () => wasmTerm?.getMode(1006, false) ?? true,
        getCellDimensions: () => ({
          width: renderer.charWidth,
          height: renderer.charHeight
        }),
        getCanvasOffset: () => {
          const rect = canvas.getBoundingClientRect();
          return { left: rect.left, top: rect.top };
        }
      };
      this.inputHandler = new InputHandler(this.ghostty, parent, (data) => {
        if (this.options.disableStdin) {
          return;
        }
        this.selectionManager?.clearSelection();
        this.scrollToBottom();
        this.renderer?.resetCursorBlink();
        this.awaitingEcho = true;
        this.dataEmitter.fire(data);
      }, () => {
        this.bellEmitter.fire();
      }, (keyEvent) => {
        this.keyEmitter.fire(keyEvent);
      }, this.customKeyEventHandler, (mode) => {
        return this.wasmTerm?.getMode(mode, false) ?? false;
      }, () => {
        return this.copySelection();
      }, this.textarea, mouseConfig, (encoder) => this.wasmTerm?.syncKeyEncoder(encoder), () => this.options.ctrlVPaste);
      this.selectionManager = new SelectionManager(this, this.renderer, this.wasmTerm, this.textarea);
      this.renderer.setSelectionManager(this.selectionManager);
      this.selectionManager.onSelectionChange(() => {
        this.selectionChangeEmitter.fire();
      });
      this.linkDetector = new LinkDetector(this);
      this.linkDetector.registerProvider(new OSC8LinkProvider(this));
      this.linkDetector.registerProvider(new UrlRegexProvider(this));
      parent.addEventListener("mousedown", this.handleMouseDown, { capture: true });
      parent.addEventListener("mousemove", this.handleMouseMove);
      parent.addEventListener("mouseleave", this.handleMouseLeave);
      parent.addEventListener("click", this.handleClick);
      document.addEventListener("mouseup", this.handleMouseUp);
      parent.addEventListener("wheel", this.handleWheel, { passive: false });
      this.renderer.render(this.wasmTerm, true, this.viewportY, this, this.scrollbarOpacity);
      this.startRenderLoop();
      this.focus();
    } catch (error) {
      this.isOpen = false;
      this.cleanupComponents();
      throw new Error(`Failed to open terminal: ${error}`);
    }
  }
  write(data, callback) {
    this.assertOpen();
    if (this.options.convertEol && typeof data === "string") {
      data = data.replace(/\n/g, `\r
`);
    }
    this.writeInternal(data, callback);
  }
  writeInternal(data, callback) {
    const wasScrolled = this.viewportY > 0;
    const previousScrollbackLength = wasScrolled ? this.getScrollbackLength() : 0;
    this.wasmTerm.write(data);
    this.processTerminalResponses();
    if (typeof data === "string" && data.includes("\x07")) {
      this.bellEmitter.fire();
    } else if (data instanceof Uint8Array && data.includes(7)) {
      this.bellEmitter.fire();
    }
    this.linkDetector?.invalidateCache();
    if (wasScrolled) {
      const scrollbackLength = this.getScrollbackLength();
      const growth = Math.max(0, scrollbackLength - previousScrollbackLength);
      if (growth > 0) {
        this.viewportY = Math.min(scrollbackLength, this.viewportY + growth);
        this.targetViewportY = this.viewportY;
        this.scrollEmitter.fire(this.viewportY);
      }
    }
    if (typeof data === "string" && data.includes("\x1B]")) {
      this.checkForTitleChange(data);
    }
    if (callback) {
      requestAnimationFrame(callback);
    }
    if (this.awaitingEcho) {
      this.awaitingEcho = false;
      if (this.renderer && this.wasmTerm) {
        this.renderer.render(this.wasmTerm, false, this.viewportY, this, this.scrollbarOpacity);
      }
    }
  }
  writeln(data, callback) {
    if (typeof data === "string") {
      this.write(data + `\r
`, callback);
    } else {
      const newData = new Uint8Array(data.length + 2);
      newData.set(data);
      newData[data.length] = 13;
      newData[data.length + 1] = 10;
      this.write(newData, callback);
    }
  }
  paste(data) {
    this.assertOpen();
    if (this.options.disableStdin) {
      return;
    }
    this.awaitingEcho = true;
    if (this.wasmTerm.hasBracketedPaste()) {
      this.dataEmitter.fire("\x1B[200~" + data + "\x1B[201~");
    } else {
      this.dataEmitter.fire(data);
    }
  }
  input(data, wasUserInput = false) {
    this.assertOpen();
    if (this.options.disableStdin) {
      return;
    }
    if (wasUserInput) {
      this.awaitingEcho = true;
      this.dataEmitter.fire(data);
    } else {
      this.write(data);
    }
  }
  resize(cols, rows) {
    this.assertOpen();
    if (cols === this.cols && rows === this.rows) {
      return;
    }
    this.cancelRenderLoop();
    try {
      this.cols = cols;
      this.rows = rows;
      this.wasmTerm.resize(cols, rows);
      this.renderer.resize(cols, rows);
      this.resizeEmitter.fire({ cols, rows });
      this.renderer.render(this.wasmTerm, true, this.viewportY, this);
    } catch (e) {
      console.error("Terminal resize failed:", e);
    }
    this.flushWriteQueue();
    this.startRenderLoop();
  }
  clear() {
    this.assertOpen();
    this.wasmTerm.write("\x1B[2J\x1B[H");
  }
  reset() {
    this.assertOpen();
    if (this.wasmTerm) {
      this.wasmTerm.free();
    }
    const config = this.buildWasmConfig();
    this.wasmTerm = this.ghostty.createTerminal(this.cols, this.rows, config);
    this.renderer.clear();
    this.currentTitle = "";
  }
  updateImePosition() {
    if (!this.wasmTerm || !this.renderer || !this.canvas)
      return;
    const cursor = this.wasmTerm.getCursor();
    this.imeOverlay?.position({
      left: this.canvas.offsetLeft + cursor.x * this.renderer.charWidth,
      top: this.canvas.offsetTop + cursor.y * this.renderer.charHeight,
      width: this.renderer.charWidth,
      height: this.renderer.charHeight,
      fontFamily: this.options.fontFamily,
      fontSize: this.options.fontSize,
      foreground: this.options.theme?.foreground ?? DEFAULT_THEME.foreground,
      background: this.options.theme?.background ?? DEFAULT_THEME.background,
      visible: this.viewportY === 0 && cursor.visible
    });
  }
  focus() {
    if (this.isOpen)
      this.forwardFocus();
  }
  blur() {
    if (this.isOpen && this.element) {
      this.textarea?.blur();
      this.element.blur();
    }
  }
  loadAddon(addon) {
    addon.activate(this);
    this.addons.push(addon);
  }
  getSelection() {
    return this.selectionManager?.getSelection() || "";
  }
  hasSelection() {
    return this.selectionManager?.hasSelection() || false;
  }
  clearSelection() {
    this.selectionManager?.clearSelection();
  }
  copySelection() {
    return this.selectionManager?.copySelection() || false;
  }
  selectAll() {
    this.selectionManager?.selectAll();
  }
  select(column, row, length) {
    this.selectionManager?.select(column, row, length);
  }
  selectLines(start, end) {
    this.selectionManager?.selectLines(start, end);
  }
  getViewportY() {
    return this.viewportY;
  }
  getSelectionPosition() {
    return this.selectionManager?.getSelectionPosition();
  }
  attachCustomKeyEventHandler(customKeyEventHandler) {
    this.customKeyEventHandler = customKeyEventHandler;
    if (this.inputHandler) {
      this.inputHandler.setCustomKeyEventHandler(customKeyEventHandler);
    }
  }
  attachCustomWheelEventHandler(customWheelEventHandler) {
    this.customWheelEventHandler = customWheelEventHandler;
  }
  registerLinkProvider(provider) {
    if (!this.linkDetector) {
      throw new Error("Terminal must be opened before registering link providers");
    }
    this.linkDetector.registerProvider(provider);
  }
  scrollLines(amount) {
    if (!this.wasmTerm) {
      throw new Error("Terminal not open");
    }
    const scrollbackLength = this.getScrollbackLength();
    const maxScroll = scrollbackLength;
    const newViewportY = Math.max(0, Math.min(maxScroll, this.viewportY - amount));
    if (newViewportY !== this.viewportY) {
      this.viewportY = newViewportY;
      this.scrollEmitter.fire(this.viewportY);
      if (scrollbackLength > 0) {
        this.showScrollbar();
      }
    }
  }
  scrollPages(amount) {
    this.scrollLines(amount * this.rows);
  }
  scrollToTop() {
    const scrollbackLength = this.getScrollbackLength();
    if (scrollbackLength > 0 && this.viewportY !== scrollbackLength) {
      this.viewportY = scrollbackLength;
      this.scrollEmitter.fire(this.viewportY);
      this.showScrollbar();
    }
  }
  scrollToBottom() {
    if (this.viewportY !== 0) {
      this.viewportY = 0;
      this.scrollEmitter.fire(this.viewportY);
      if (this.getScrollbackLength() > 0) {
        this.showScrollbar();
      }
    }
  }
  scrollToLine(line) {
    const scrollbackLength = this.getScrollbackLength();
    const newViewportY = Math.max(0, Math.min(scrollbackLength, line));
    if (newViewportY !== this.viewportY) {
      this.viewportY = newViewportY;
      this.scrollEmitter.fire(this.viewportY);
      if (scrollbackLength > 0) {
        this.showScrollbar();
      }
    }
  }
  smoothScrollTo(targetY) {
    if (!this.wasmTerm)
      return;
    const scrollbackLength = this.getScrollbackLength();
    const maxScroll = scrollbackLength;
    const newTarget = Math.max(0, Math.min(maxScroll, targetY));
    const duration = this.options.smoothScrollDuration ?? 100;
    if (duration === 0) {
      this.viewportY = newTarget;
      this.targetViewportY = newTarget;
      this.scrollEmitter.fire(Math.floor(this.viewportY));
      if (scrollbackLength > 0) {
        this.showScrollbar();
      }
      return;
    }
    this.targetViewportY = newTarget;
    if (this.scrollAnimationFrame) {
      return;
    }
    this.scrollAnimationStartTime = Date.now();
    this.scrollAnimationStartY = this.viewportY;
    this.animateScroll();
  }
  animateScroll = () => {
    if (!this.wasmTerm || this.scrollAnimationStartTime === undefined) {
      return;
    }
    const duration = this.options.smoothScrollDuration ?? 100;
    const distance = this.targetViewportY - this.viewportY;
    const absDistance = Math.abs(distance);
    if (absDistance < 0.01) {
      this.viewportY = this.targetViewportY;
      this.scrollEmitter.fire(Math.floor(this.viewportY));
      const scrollbackLength2 = this.getScrollbackLength();
      if (scrollbackLength2 > 0) {
        this.showScrollbar();
      }
      this.scrollAnimationFrame = undefined;
      this.scrollAnimationStartTime = undefined;
      this.scrollAnimationStartY = undefined;
      return;
    }
    const framesForDuration = duration / 1000 * 60;
    const moveRatio = 1 - (1 / framesForDuration) ** 2;
    this.viewportY += distance * moveRatio;
    const intViewportY = Math.floor(this.viewportY);
    this.scrollEmitter.fire(intViewportY);
    const scrollbackLength = this.getScrollbackLength();
    if (scrollbackLength > 0) {
      this.showScrollbar();
    }
    this.scrollAnimationFrame = requestAnimationFrame(this.animateScroll);
  };
  dispose() {
    if (this.isDisposed) {
      return;
    }
    this.isDisposed = true;
    this.isOpen = false;
    this.cancelRenderLoop();
    this.writeQueue.length = 0;
    if (this.scrollAnimationFrame) {
      cancelAnimationFrame(this.scrollAnimationFrame);
      this.scrollAnimationFrame = undefined;
    }
    if (this.mouseMoveThrottleTimeout) {
      clearTimeout(this.mouseMoveThrottleTimeout);
      this.mouseMoveThrottleTimeout = undefined;
    }
    this.pendingMouseMove = undefined;
    for (const addon of this.addons) {
      addon.dispose();
    }
    this.addons = [];
    this.cleanupComponents();
    this.dataEmitter.dispose();
    this.resizeEmitter.dispose();
    this.bellEmitter.dispose();
    this.selectionChangeEmitter.dispose();
    this.keyEmitter.dispose();
    this.titleChangeEmitter.dispose();
    this.scrollEmitter.dispose();
    this.renderEmitter.dispose();
    this.cursorMoveEmitter.dispose();
  }
  cancelRenderLoop() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = undefined;
    }
  }
  flushWriteQueue() {
    while (this.writeQueue.length > 0) {
      const data = this.writeQueue.shift();
      this.wasmTerm.write(data);
    }
  }
  startRenderLoop() {
    if (this.animationFrameId)
      return;
    const loop = () => {
      if (!this.isDisposed && this.isOpen) {
        this.renderer.render(this.wasmTerm, false, this.viewportY, this, this.scrollbarOpacity);
        const cursor = this.wasmTerm.getCursor();
        this.updateImePosition();
        if (cursor.y !== this.lastCursorY) {
          this.lastCursorY = cursor.y;
          this.cursorMoveEmitter.fire();
        }
        this.animationFrameId = requestAnimationFrame(loop);
      }
    };
    loop();
  }
  getScrollbackLine(offset) {
    if (!this.wasmTerm)
      return null;
    return this.wasmTerm.getScrollbackLine(offset);
  }
  getScrollbackLength() {
    if (!this.wasmTerm)
      return 0;
    return this.wasmTerm.getScrollbackLength();
  }
  cleanupComponents() {
    if (this.selectionManager) {
      this.selectionManager.dispose();
      this.selectionManager = undefined;
    }
    if (this.inputHandler) {
      this.inputHandler.dispose();
      this.inputHandler = undefined;
    }
    if (this.renderer) {
      this.renderer.dispose();
      this.renderer = undefined;
    }
    if (this.canvas && this.canvas.parentNode) {
      this.canvas.parentNode.removeChild(this.canvas);
      this.canvas = undefined;
    }
    this.imeOverlay?.dispose();
    this.imeOverlay = undefined;
    if (this.element) {
      this.element.removeEventListener("focus", this.forwardFocus);
      this.element.removeEventListener("focusin", this.handleFocusIn);
      this.element.removeEventListener("focusout", this.handleFocusOut);
      window.removeEventListener("blur", this.handleWindowBlur);
      window.removeEventListener("focus", this.handleWindowFocus);
      if (this.originalPosition !== undefined) {
        this.element.style.position = this.originalPosition;
        this.originalPosition = undefined;
      }
    }
    if (this.textarea && this.textarea.parentNode) {
      this.textarea.parentNode.removeChild(this.textarea);
      this.textarea = undefined;
    }
    if (this.element) {
      this.element.removeEventListener("wheel", this.handleWheel);
      this.element.removeEventListener("mousedown", this.handleMouseDown, { capture: true });
      this.element.removeEventListener("mousemove", this.handleMouseMove);
      this.element.removeEventListener("mouseleave", this.handleMouseLeave);
      this.element.removeEventListener("click", this.handleClick);
      this.element.removeAttribute("contenteditable");
      this.element.removeAttribute("role");
      this.element.removeAttribute("aria-label");
      this.element.removeAttribute("aria-multiline");
    }
    if (this.isOpen && typeof document !== "undefined") {
      document.removeEventListener("mouseup", this.handleMouseUp);
    }
    if (this.scrollbarHideTimeout) {
      window.clearTimeout(this.scrollbarHideTimeout);
      this.scrollbarHideTimeout = undefined;
    }
    if (this.linkDetector) {
      this.linkDetector.dispose();
      this.linkDetector = undefined;
    }
    if (this.wasmTerm) {
      this.wasmTerm.free();
      this.wasmTerm = undefined;
    }
    this.ghostty = undefined;
    this.element = undefined;
    this.textarea = undefined;
  }
  assertOpen() {
    if (this.isDisposed) {
      throw new Error("Terminal has been disposed");
    }
    if (!this.isOpen) {
      throw new Error("Terminal must be opened before use. Call terminal.open(parent) first.");
    }
  }
  handleMouseMove = (e) => {
    if (!this.canvas || !this.renderer || !this.wasmTerm)
      return;
    if (this.isDraggingScrollbar) {
      this.processScrollbarDrag(e);
      return;
    }
    if (!this.linkDetector)
      return;
    if (this.mouseMoveThrottleTimeout) {
      this.pendingMouseMove = e;
      return;
    }
    this.processMouseMove(e);
    this.mouseMoveThrottleTimeout = window.setTimeout(() => {
      this.mouseMoveThrottleTimeout = undefined;
      if (this.pendingMouseMove) {
        const pending = this.pendingMouseMove;
        this.pendingMouseMove = undefined;
        this.processMouseMove(pending);
      }
    }, 16);
  };
  processMouseMove(e) {
    if (!this.canvas || !this.renderer || !this.linkDetector || !this.wasmTerm)
      return;
    const rect = this.canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / this.renderer.charWidth);
    const y = Math.floor((e.clientY - rect.top) / this.renderer.charHeight);
    const viewportRow = y;
    let hyperlinkId = 0;
    let line = null;
    const rawViewportY = this.getViewportY();
    const viewportY = Math.max(0, Math.floor(rawViewportY));
    if (viewportY > 0) {
      const scrollbackLength2 = this.wasmTerm.getScrollbackLength();
      if (viewportRow < viewportY) {
        const scrollbackOffset = scrollbackLength2 - viewportY + viewportRow;
        line = this.wasmTerm.getScrollbackLine(scrollbackOffset);
      } else {
        const screenRow = viewportRow - viewportY;
        line = this.wasmTerm.getLine(screenRow);
      }
    } else {
      line = this.wasmTerm.getLine(viewportRow);
    }
    if (line && x >= 0 && x < line.length) {
      hyperlinkId = line[x].hyperlink_id;
    }
    const previousHyperlinkId = this.renderer.hoveredHyperlinkId || 0;
    if (hyperlinkId !== previousHyperlinkId) {
      this.renderer.setHoveredHyperlinkId(hyperlinkId);
    }
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    let bufferRow;
    const rawViewportYForBuffer = this.getViewportY();
    const viewportYForBuffer = Math.max(0, Math.floor(rawViewportYForBuffer));
    if (viewportYForBuffer > 0) {
      if (viewportRow < viewportYForBuffer) {
        bufferRow = scrollbackLength - viewportYForBuffer + viewportRow;
      } else {
        const screenRow = viewportRow - viewportYForBuffer;
        bufferRow = scrollbackLength + screenRow;
      }
    } else {
      bufferRow = scrollbackLength + viewportRow;
    }
    this.linkDetector.getLinkAt(x, bufferRow).then((link) => {
      if (link !== this.currentHoveredLink) {
        this.currentHoveredLink?.hover?.(false);
        this.currentHoveredLink = link;
        link?.hover?.(true);
        const cursorStyle = link ? "pointer" : "text";
        if (this.element) {
          this.element.style.cursor = cursorStyle;
        }
        if (this.canvas) {
          this.canvas.style.cursor = cursorStyle;
        }
        if (this.renderer) {
          if (link) {
            const scrollbackLength2 = this.wasmTerm?.getScrollbackLength() || 0;
            const rawViewportYForLinks = this.getViewportY();
            const viewportYForLinks = Math.max(0, Math.floor(rawViewportYForLinks));
            const startViewportY = link.range.start.y - scrollbackLength2 + viewportYForLinks;
            const endViewportY = link.range.end.y - scrollbackLength2 + viewportYForLinks;
            if (startViewportY < this.rows && endViewportY >= 0) {
              this.renderer.setHoveredLinkRange({
                startX: link.range.start.x,
                startY: Math.max(0, startViewportY),
                endX: link.range.end.x,
                endY: Math.min(this.rows - 1, endViewportY)
              });
            } else {
              this.renderer.setHoveredLinkRange(null);
            }
          } else {
            this.renderer.setHoveredLinkRange(null);
          }
        }
      }
    }).catch((err) => {
      console.warn("Link detection error:", err);
    });
  }
  handleMouseLeave = () => {
    if (this.renderer && this.wasmTerm) {
      const previousHyperlinkId = this.renderer.hoveredHyperlinkId || 0;
      if (previousHyperlinkId > 0) {
        this.renderer.setHoveredHyperlinkId(0);
      }
      this.renderer.setHoveredLinkRange(null);
    }
    if (this.currentHoveredLink) {
      this.currentHoveredLink.hover?.(false);
      this.currentHoveredLink = undefined;
      if (this.element) {
        this.element.style.cursor = "text";
        if (this.canvas) {
          this.canvas.style.cursor = "text";
        }
      }
    }
  };
  handleClick = async (e) => {
    if (!this.canvas || !this.renderer || !this.linkDetector || !this.wasmTerm)
      return;
    const rect = this.canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / this.renderer.charWidth);
    const y = Math.floor((e.clientY - rect.top) / this.renderer.charHeight);
    const viewportRow = y;
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    let bufferRow;
    const rawViewportYForClick = this.getViewportY();
    const viewportYForClick = Math.max(0, Math.floor(rawViewportYForClick));
    if (viewportYForClick > 0) {
      if (viewportRow < viewportYForClick) {
        bufferRow = scrollbackLength - viewportYForClick + viewportRow;
      } else {
        const screenRow = viewportRow - viewportYForClick;
        bufferRow = scrollbackLength + screenRow;
      }
    } else {
      bufferRow = scrollbackLength + viewportRow;
    }
    const link = await this.linkDetector.getLinkAt(x, bufferRow);
    if (link) {
      link.activate(e);
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
      }
    }
  };
  handleWheel = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (this.customWheelEventHandler && this.customWheelEventHandler(e)) {
      return;
    }
    if (this.wasmTerm?.hasMouseTracking())
      return;
    const isAltScreen = this.wasmTerm?.isAlternateScreen() ?? false;
    if (isAltScreen) {
      const direction = e.deltaY > 0 ? "down" : "up";
      const count = Math.min(Math.max(1, Math.abs(Math.round(e.deltaY / 33))), 5);
      for (let i = 0;i < count; i++) {
        if (direction === "up") {
          this.dataEmitter.fire("\x1B[A");
        } else {
          this.dataEmitter.fire("\x1B[B");
        }
      }
    } else {
      let deltaLines;
      if (e.deltaMode === WheelEvent.DOM_DELTA_PIXEL) {
        const lineHeight = this.renderer?.getMetrics()?.height ?? 20;
        deltaLines = e.deltaY / lineHeight;
      } else if (e.deltaMode === WheelEvent.DOM_DELTA_LINE) {
        deltaLines = e.deltaY;
      } else if (e.deltaMode === WheelEvent.DOM_DELTA_PAGE) {
        deltaLines = e.deltaY * this.rows;
      } else {
        deltaLines = e.deltaY / 33;
      }
      if (deltaLines !== 0) {
        const targetY = this.viewportY - deltaLines;
        this.smoothScrollTo(targetY);
      }
    }
  };
  handleMouseDown = (e) => {
    if (!this.canvas || !this.renderer || !this.wasmTerm)
      return;
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    if (scrollbackLength === 0)
      return;
    const rect = this.canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const canvasWidth = rect.width;
    const canvasHeight = rect.height;
    const scrollbarWidth = 8;
    const scrollbarX = canvasWidth - scrollbarWidth - 4;
    const scrollbarPadding = 4;
    if (mouseX >= scrollbarX && mouseX <= scrollbarX + scrollbarWidth) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      const scrollbarTrackHeight = canvasHeight - scrollbarPadding * 2;
      const visibleRows = this.rows;
      const totalLines = scrollbackLength + visibleRows;
      const thumbHeight = Math.max(20, visibleRows / totalLines * scrollbarTrackHeight);
      const scrollPosition = this.viewportY / scrollbackLength;
      const thumbY = scrollbarPadding + (scrollbarTrackHeight - thumbHeight) * (1 - scrollPosition);
      if (mouseY >= thumbY && mouseY <= thumbY + thumbHeight) {
        this.isDraggingScrollbar = true;
        this.scrollbarDragStart = mouseY;
        this.scrollbarDragStartViewportY = this.viewportY;
        if (this.canvas) {
          this.canvas.style.userSelect = "none";
          this.canvas.style.webkitUserSelect = "none";
        }
      } else {
        const relativeY = mouseY - scrollbarPadding;
        const scrollFraction = 1 - relativeY / scrollbarTrackHeight;
        const targetViewportY = Math.round(scrollFraction * scrollbackLength);
        this.scrollToLine(Math.max(0, Math.min(scrollbackLength, targetViewportY)));
      }
    }
  };
  handleMouseUp = () => {
    if (this.isDraggingScrollbar) {
      this.isDraggingScrollbar = false;
      this.scrollbarDragStart = null;
      if (this.canvas) {
        this.canvas.style.userSelect = "";
        this.canvas.style.webkitUserSelect = "";
      }
      if (this.scrollbarVisible && this.getScrollbackLength() > 0) {
        this.showScrollbar();
      }
    }
  };
  processScrollbarDrag(e) {
    if (!this.canvas || !this.renderer || !this.wasmTerm || this.scrollbarDragStart === null)
      return;
    const scrollbackLength = this.wasmTerm.getScrollbackLength();
    if (scrollbackLength === 0)
      return;
    const rect = this.canvas.getBoundingClientRect();
    const mouseY = e.clientY - rect.top;
    const deltaY = mouseY - this.scrollbarDragStart;
    const canvasHeight = rect.height;
    const scrollbarPadding = 4;
    const scrollbarTrackHeight = canvasHeight - scrollbarPadding * 2;
    const visibleRows = this.rows;
    const totalLines = scrollbackLength + visibleRows;
    const thumbHeight = Math.max(20, visibleRows / totalLines * scrollbarTrackHeight);
    const scrollFraction = -deltaY / (scrollbarTrackHeight - thumbHeight);
    const viewportDelta = Math.round(scrollFraction * scrollbackLength);
    const newViewportY = this.scrollbarDragStartViewportY + viewportDelta;
    this.scrollToLine(Math.max(0, Math.min(scrollbackLength, newViewportY)));
  }
  showScrollbar() {
    if (this.scrollbarHideTimeout) {
      window.clearTimeout(this.scrollbarHideTimeout);
      this.scrollbarHideTimeout = undefined;
    }
    if (!this.scrollbarVisible) {
      this.scrollbarVisible = true;
      this.scrollbarOpacity = 0;
      this.fadeInScrollbar();
    } else {
      this.scrollbarOpacity = 1;
    }
    if (!this.isDraggingScrollbar) {
      this.scrollbarHideTimeout = window.setTimeout(() => {
        this.hideScrollbar();
      }, this.SCROLLBAR_HIDE_DELAY_MS);
    }
  }
  hideScrollbar() {
    if (this.scrollbarHideTimeout) {
      window.clearTimeout(this.scrollbarHideTimeout);
      this.scrollbarHideTimeout = undefined;
    }
    if (this.scrollbarVisible) {
      this.fadeOutScrollbar();
    }
  }
  fadeInScrollbar() {
    const startTime = Date.now();
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / this.SCROLLBAR_FADE_DURATION_MS, 1);
      this.scrollbarOpacity = progress;
      if (this.renderer && this.wasmTerm) {
        this.renderer.render(this.wasmTerm, false, this.viewportY, this, this.scrollbarOpacity);
      }
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    animate();
  }
  fadeOutScrollbar() {
    const startTime = Date.now();
    const startOpacity = this.scrollbarOpacity;
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / this.SCROLLBAR_FADE_DURATION_MS, 1);
      this.scrollbarOpacity = startOpacity * (1 - progress);
      if (this.renderer && this.wasmTerm) {
        this.renderer.render(this.wasmTerm, false, this.viewportY, this, this.scrollbarOpacity);
      }
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        this.scrollbarVisible = false;
        this.scrollbarOpacity = 0;
        if (this.renderer && this.wasmTerm) {
          this.renderer.render(this.wasmTerm, false, this.viewportY, this, 0);
        }
      }
    };
    animate();
  }
  processTerminalResponses() {
    if (!this.wasmTerm)
      return;
    while (true) {
      const response = this.wasmTerm.readResponse();
      if (response === null)
        break;
      this.dataEmitter.fire(response);
    }
  }
  checkForTitleChange(data) {
    const oscRegex = /\x1b\]([012]);([^\x07\x1b]*?)(?:\x07|\x1b\\)/g;
    let match = null;
    while ((match = oscRegex.exec(data)) !== null) {
      const ps = match[1];
      const pt = match[2];
      if (ps === "0" || ps === "2") {
        if (pt !== this.currentTitle) {
          this.currentTitle = pt;
          this.titleChangeEmitter.fire(pt);
        }
      }
    }
  }
  getMode(mode, isAnsi = false) {
    this.assertOpen();
    return this.wasmTerm.getMode(mode, isAnsi);
  }
  hasBracketedPaste() {
    this.assertOpen();
    return this.wasmTerm.hasBracketedPaste();
  }
  hasFocusEvents() {
    this.assertOpen();
    return this.wasmTerm.hasFocusEvents();
  }
  hasMouseTracking() {
    this.assertOpen();
    return this.wasmTerm.hasMouseTracking();
  }
}

// ../../packages/terminal/ghostty-web/src/index.ts
var ghosttyInstance = null;
var initialization = null;
function init(options = {}) {
  if (ghosttyInstance) {
    return Promise.resolve();
  }
  if (!initialization) {
    const wasmUrl = typeof options === "string" ? options : options.wasmUrl;
    initialization = Ghostty.load(wasmUrl).then((instance) => {
      ghosttyInstance = instance;
    }, (error) => {
      initialization = null;
      throw error;
    });
  }
  return initialization;
}
function getGhostty() {
  if (!ghosttyInstance) {
    throw new Error(`ghostty-web not initialized. Call init() before creating Terminal instances.
` + `Example:
` + `  import { init, Terminal } from "@random/ghostty-web";
` + `  await init();
` + `  const term = new Terminal();

` + `For tests, pass a Ghostty instance directly:
` + `  import { Ghostty, Terminal } from "@random/ghostty-web";
` + `  const ghostty = await Ghostty.load();
` + "  const term = new Terminal({ ghostty });");
  }
  return ghosttyInstance;
}

// ../../packages/terminal/osc52.ts
var intro = [27, 93, 53, 50, 59];
var limit = 8 << 20;
function clipboardWrites(onText) {
  let matched = 0;
  let body;
  let escape = false;
  function finish() {
    const bytes = body;
    body = undefined;
    escape = false;
    matched = 0;
    const semicolon = bytes.indexOf(59);
    if (semicolon < 0)
      return;
    const payload = new TextDecoder("latin1").decode(Uint8Array.from(bytes.slice(semicolon + 1)));
    if (!payload || payload === "?")
      return;
    let text;
    try {
      text = new TextDecoder().decode(Uint8Array.from(atob(payload), (char) => char.charCodeAt(0)));
    } catch {
      return;
    }
    if (text)
      onText(text);
  }
  return (data) => {
    for (const byte of data) {
      if (body) {
        if (escape) {
          if (byte === 92)
            finish();
          else {
            body = undefined;
            escape = false;
            matched = byte === intro[0] ? 1 : 0;
          }
        } else if (byte === 7)
          finish();
        else if (byte === 27)
          escape = true;
        else if (body.length >= limit) {
          body = undefined;
          matched = 0;
        } else
          body.push(byte);
      } else if (byte === intro[matched]) {
        if (++matched === intro.length)
          body = [];
      } else
        matched = byte === intro[0] ? 1 : 0;
    }
  };
}

// ../../packages/terminal/display.ts
function rendererChoice() {
  try {
    const gl = document.createElement("canvas").getContext("webgl2");
    const info = gl?.getExtension("WEBGL_debug_renderer_info");
    const name = String((info && gl?.getParameter(info.UNMASKED_RENDERER_WEBGL)) ?? "");
    gl?.getExtension("WEBGL_lose_context")?.loseContext();
    if (/swiftshader|llvmpipe|softpipe|software/i.test(name))
      return "canvas";
  } catch {}
  return "webgl";
}
async function mountDisplay(options) {
  const { container } = options;
  await init({ wasmUrl: new URL(options.wasmUrl, location.href).href });
  const terminal = new Terminal({
    rendererType: options.renderer ?? rendererChoice(),
    ctrlVPaste: options.ctrlVPaste ?? false,
    cursorBlink: true,
    copyOnSelect: false,
    scrollback: 5000,
    smoothScrollDuration: 0,
    fontSize: options.fontSize ?? 14,
    theme: options.theme ?? { background: "#16161d", foreground: "#dcd7ba" }
  });
  await terminal.open(container);
  const cell = () => {
    const metrics = terminal.renderer?.getMetrics();
    return { width: metrics?.width ?? 0, height: metrics?.height ?? 0 };
  };
  const size = () => {
    const { width, height } = cell();
    return { cols: terminal.cols, rows: terminal.rows, xpixel: Math.round(width * terminal.cols), ypixel: Math.round(height * terminal.rows) };
  };
  function fit() {
    const { width, height } = cell();
    if (!width || !height || !container.clientWidth || !container.clientHeight)
      return;
    const cols = Math.max(2, Math.min(500, Math.floor((container.clientWidth + 1) / width)));
    const rows = Math.max(1, Math.min(300, Math.floor(container.clientHeight / height)));
    if (cols !== terminal.cols || rows !== terminal.rows)
      terminal.resize(cols, rows);
  }
  fit();
  terminal.onData((data) => options.onInput(data));
  terminal.onResize(() => options.onResize(size()));
  let layoutTimer;
  const observer = new ResizeObserver(() => {
    clearTimeout(layoutTimer);
    layoutTimer = setTimeout(fit, 50);
  });
  observer.observe(container);
  terminal.focus();
  const copied = clipboardWrites(options.onClipboard ?? ((text) => {
    navigator.clipboard.writeText(text).catch((error) => console.warn("terminal display: the clipboard was not written:", error));
  }));
  return {
    terminal,
    write(data) {
      if (typeof data !== "string")
        copied(data);
      terminal.write(data);
    },
    size,
    screen() {
      const buffer = terminal.buffer.active;
      const lines = [];
      for (let row = 0;row < terminal.rows; row++)
        lines.push(buffer.getLine(buffer.viewportY + row)?.translateToString(true) ?? "");
      return lines;
    },
    focus: () => terminal.focus(),
    dispose() {
      observer.disconnect();
      clearTimeout(layoutTimer);
      terminal.dispose();
    }
  };
}
export {
  mountDisplay,
  rendererChoice
};
