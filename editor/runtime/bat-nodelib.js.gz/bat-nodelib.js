(() => {
  // third_party/node/primordials.js
  var uncurryThis = Function.prototype.call.bind.bind(Function.prototype.call);
  var lowerFirst = (s) => s.length ? s[0].toLowerCase() + s.slice(1) : s;
  var TypedArray = Object.getPrototypeOf(Uint8Array);
  var NAMESPACES = {
    TypedArray,
    ...typeof SharedArrayBuffer !== "undefined" ? { SharedArrayBuffer } : {},
    ArrayBuffer,
    Uint8ClampedArray,
    BigInt64Array,
    BigUint64Array,
    Float32Array,
    Float64Array,
    Uint16Array,
    Uint32Array,
    Int16Array,
    Int32Array,
    Uint8Array,
    Int8Array,
    WeakMap,
    WeakSet,
    Array,
    Object,
    Function,
    Boolean,
    Number,
    BigInt,
    Math,
    JSON,
    Reflect,
    String,
    Symbol,
    RegExp,
    Date,
    Error,
    TypeError,
    RangeError,
    SyntaxError,
    Promise,
    Map,
    Set,
    Proxy,
    DataView
  };
  var NS_NAMES = Object.keys(NAMESPACES).sort((a, b) => b.length - a.length);
  var BIND_STATICS = new Set(["Promise"]);
  var GLOBALS = {
    globalThis,
    ...NAMESPACES,
    Infinity: Infinity,
    NaN: NaN,
    undefined: undefined,
    decodeURIComponent,
    encodeURIComponent,
    decodeURI,
    encodeURI
  };
  function findDescriptor(obj, prop) {
    let cur = obj;
    while (cur) {
      const d = Object.getOwnPropertyDescriptor(cur, prop);
      if (d)
        return d;
      cur = Object.getPrototypeOf(cur);
    }
    return;
  }
  function resolvePrototypeMember(proto, methodPart) {
    if (methodPart.startsWith("Symbol")) {
      const sym = Symbol[lowerFirst(methodPart.slice(6))];
      if (sym && typeof proto[sym] === "function")
        return uncurryThis(proto[sym]);
      return;
    }
    const direct = findDescriptor(proto, lowerFirst(methodPart));
    if (direct) {
      if (typeof direct.value === "function")
        return uncurryThis(direct.value);
      if (direct.get)
        return uncurryThis(direct.get);
    }
    if (methodPart.startsWith("Get")) {
      const d = findDescriptor(proto, lowerFirst(methodPart.slice(3)));
      if (d && d.get)
        return uncurryThis(d.get);
    }
    if (methodPart.startsWith("Set")) {
      const d = findDescriptor(proto, lowerFirst(methodPart.slice(3)));
      if (d && d.set)
        return uncurryThis(d.set);
    }
    return;
  }
  var AsyncIteratorPrototype = Object.getPrototypeOf(Object.getPrototypeOf(async function* () {}).prototype);
  var RegExpPrototypeExec = uncurryThis(RegExp.prototype.exec);
  var ArrayPrototypeMap = uncurryThis(Array.prototype.map);
  var SafeStringPrototypeSearch = (str, regexp) => {
    regexp.lastIndex = 0;
    const match = RegExpPrototypeExec(regexp, str);
    return match ? match.index : -1;
  };
  var SafePromiseAll = (promises, mapFn) => Promise.all(mapFn ? ArrayPrototypeMap(promises, mapFn) : promises);
  var SPECIALS = {
    uncurryThis,
    SafeMap: Map,
    SafeSet: Set,
    SafeWeakMap: WeakMap,
    SafeWeakSet: WeakSet,
    SafePromiseAll,
    SafeStringPrototypeSearch,
    AsyncIteratorPrototype,
    SymbolDispose: Symbol.dispose ?? Symbol("nodejs.dispose"),
    SymbolAsyncDispose: Symbol.asyncDispose ?? Symbol("nodejs.asyncDispose")
  };
  function resolve(name) {
    if (Object.prototype.hasOwnProperty.call(SPECIALS, name))
      return SPECIALS[name];
    if (Object.prototype.hasOwnProperty.call(GLOBALS, name))
      return GLOBALS[name];
    for (const ns of NS_NAMES) {
      if (name.length <= ns.length || !name.startsWith(ns))
        continue;
      const base = NAMESPACES[ns];
      const rest = name.slice(ns.length);
      if (rest === "Prototype")
        return base.prototype;
      if (rest.startsWith("Prototype")) {
        const hit = resolvePrototypeMember(base.prototype, rest.slice("Prototype".length));
        if (hit !== undefined)
          return hit;
        continue;
      }
      const lf = lowerFirst(rest);
      const key = lf in base ? lf : (rest in base) ? rest : undefined;
      if (key !== undefined) {
        const value = base[key];
        return typeof value === "function" && BIND_STATICS.has(ns) ? value.bind(base) : value;
      }
    }
    return;
  }
  var cache = { __proto__: null };
  var primordials = new Proxy({ __proto__: null }, {
    get(_target, prop) {
      if (typeof prop !== "string")
        return;
      if (prop in cache)
        return cache[prop];
      const value = resolve(prop);
      if (value === undefined && !["undefined", "NaN"].includes(prop)) {
        throw new Error(`Vivari: primordials.${prop} is not resolvable \u2014 add it to node/primordials.js`);
      }
      cache[prop] = value;
      return value;
    },
    has(_target, prop) {
      return typeof prop === "string" && resolve(prop) !== undefined;
    }
  });

  // third_party/node/bindings/buffer.js
  var encoder = new TextEncoder;
  var utf8Decoder = new TextDecoder("utf-8");
  var utf8Strict = new TextDecoder("utf-8", { fatal: true });
  var hasSAB = typeof SharedArrayBuffer !== "undefined";
  var unshare = (view) => hasSAB && view.buffer instanceof SharedArrayBuffer ? new Uint8Array(view) : view;
  function asBytes(input) {
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    if (ArrayBuffer.isView(input)) {
      return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
    }
    return input;
  }
  var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var B64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  var B64REV = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < 64; i++)
      t[B64.charCodeAt(i)] = i;
    t[45] = 62;
    t[95] = 63;
    return t;
  })();
  function encodeBase64(buf, start, end, url) {
    const alpha = url ? B64URL : B64;
    let out = "";
    let i = start;
    for (;i + 2 < end; i += 3) {
      const n = buf[i] << 16 | buf[i + 1] << 8 | buf[i + 2];
      out += alpha[n >> 18 & 63] + alpha[n >> 12 & 63] + alpha[n >> 6 & 63] + alpha[n & 63];
    }
    const rem = end - i;
    if (rem === 1) {
      const n = buf[i] << 16;
      out += alpha[n >> 18 & 63] + alpha[n >> 12 & 63];
      if (!url)
        out += "==";
    } else if (rem === 2) {
      const n = buf[i] << 16 | buf[i + 1] << 8;
      out += alpha[n >> 18 & 63] + alpha[n >> 12 & 63] + alpha[n >> 6 & 63];
      if (!url)
        out += "=";
    }
    return out;
  }
  function decodeBase64(str) {
    const bytes = [];
    let acc = 0;
    let nbits = 0;
    for (let i = 0;i < str.length; i++) {
      const v = B64REV[str.charCodeAt(i) & 255];
      if (v < 0)
        continue;
      acc = acc << 6 | v;
      nbits += 6;
      if (nbits >= 8) {
        nbits -= 8;
        bytes.push(acc >> nbits & 255);
      }
    }
    return Uint8Array.from(bytes);
  }
  var utf8Slice = (buf, start, end) => utf8Decoder.decode(unshare(buf.subarray(start, end)));
  function latin1Slice(buf, start, end) {
    let s = "";
    for (let i = start;i < end; i++)
      s += String.fromCharCode(buf[i]);
    return s;
  }
  function asciiSlice(buf, start, end) {
    let s = "";
    for (let i = start;i < end; i++)
      s += String.fromCharCode(buf[i] & 127);
    return s;
  }
  function hexSlice(buf, start, end) {
    let s = "";
    for (let i = start;i < end; i++)
      s += buf[i].toString(16).padStart(2, "0");
    return s;
  }
  function ucs2Slice(buf, start, end) {
    let s = "";
    for (let i = start;i + 1 < end; i += 2) {
      s += String.fromCharCode(buf[i] | buf[i + 1] << 8);
    }
    return s;
  }
  var base64Slice = (buf, start, end) => encodeBase64(buf, start, end, false);
  var base64urlSlice = (buf, start, end) => encodeBase64(buf, start, end, true);
  function utf8WriteStatic(buf, string, offset, length) {
    const { written } = encoder.encodeInto(string, buf.subarray(offset, offset + length));
    return written;
  }
  function asciiWriteStatic(buf, string, offset, length) {
    const n = Math.min(string.length, length);
    for (let i = 0;i < n; i++)
      buf[offset + i] = string.charCodeAt(i) & 127;
    return n;
  }
  function latin1WriteStatic(buf, string, offset, length) {
    const n = Math.min(string.length, length);
    for (let i = 0;i < n; i++)
      buf[offset + i] = string.charCodeAt(i) & 255;
    return n;
  }
  function ucs2Write(buf, string, offset, length) {
    const units = Math.min(string.length, length >> 1);
    let p = offset;
    for (let i = 0;i < units; i++) {
      const c = string.charCodeAt(i);
      buf[p++] = c & 255;
      buf[p++] = c >> 8 & 255;
    }
    return units * 2;
  }
  function hexWrite(buf, string, offset, length) {
    const max = Math.min(length, string.length >> 1);
    let i = 0;
    for (;i < max; i++) {
      const byte = parseInt(string.substr(i * 2, 2), 16);
      if (Number.isNaN(byte))
        break;
      buf[offset + i] = byte;
    }
    return i;
  }
  function base64Write(buf, string, offset, length) {
    const bytes = decodeBase64(string);
    const n = Math.min(length, bytes.length);
    buf.set(bytes.subarray(0, n), offset);
    return n;
  }
  var base64urlWrite = base64Write;
  function compareRange(a, aStart, aEnd, b, bStart, bEnd) {
    const aLen = aEnd - aStart;
    const bLen = bEnd - bStart;
    const len = Math.min(aLen, bLen);
    for (let i = 0;i < len; i++) {
      const x = a[aStart + i];
      const y = b[bStart + i];
      if (x < y)
        return -1;
      if (x > y)
        return 1;
    }
    if (aLen < bLen)
      return -1;
    if (aLen > bLen)
      return 1;
    return 0;
  }
  var compare = (a, b) => compareRange(a, 0, a.length, b, 0, b.length);
  var compareOffset = (source, target, targetStart, sourceStart, targetEnd, sourceEnd) => compareRange(source, sourceStart, sourceEnd, target, targetStart, targetEnd);
  function copy(source, target, targetStart, sourceStart, nb) {
    target.set(source.subarray(sourceStart, sourceStart + nb), targetStart);
    return nb;
  }
  function bindingFill(buf, value, offset, end, encoding) {
    let bytes;
    if (typeof value === "string") {
      const enc = normalizeForFill(encoding);
      bytes = encodeString(value, enc);
    } else {
      bytes = asBytes(value);
    }
    if (!bytes || bytes.length === 0)
      return -1;
    for (let i = offset, j = 0;i < end; i++, j++)
      buf[i] = bytes[j % bytes.length];
    return end - offset;
  }
  function normalizeForFill(encoding) {
    if (!encoding)
      return "utf8";
    const e = String(encoding).toLowerCase();
    return e === "utf-8" ? "utf8" : e;
  }
  function encodeString(str, enc) {
    switch (enc) {
      case "utf8":
      case "utf-8":
        return encoder.encode(str);
      case "ascii": {
        const b = new Uint8Array(str.length);
        for (let i = 0;i < str.length; i++)
          b[i] = str.charCodeAt(i) & 127;
        return b;
      }
      case "latin1":
      case "binary": {
        const b = new Uint8Array(str.length);
        for (let i = 0;i < str.length; i++)
          b[i] = str.charCodeAt(i) & 255;
        return b;
      }
      case "utf16le":
      case "ucs2":
      case "ucs-2":
      case "utf-16le": {
        const b = new Uint8Array(str.length * 2);
        for (let i = 0;i < str.length; i++) {
          const c = str.charCodeAt(i);
          b[i * 2] = c & 255;
          b[i * 2 + 1] = c >> 8 & 255;
        }
        return b;
      }
      case "hex": {
        const n = str.length >> 1;
        const b = new Uint8Array(n);
        for (let i = 0;i < n; i++)
          b[i] = parseInt(str.substr(i * 2, 2), 16) || 0;
        return b;
      }
      case "base64":
      case "base64url":
        return decodeBase64(str);
      default:
        return encoder.encode(str);
    }
  }
  function byteSearch(haystack, needle, byteOffset, dir) {
    const len = haystack.length;
    const nlen = needle.length;
    if (nlen === 0)
      return dir ? Math.max(0, Math.min(byteOffset, len)) : len;
    if (nlen > len)
      return -1;
    if (dir) {
      let start2 = byteOffset < 0 ? Math.max(len + byteOffset, 0) : byteOffset;
      for (let i = start2;i <= len - nlen; i++) {
        let m = true;
        for (let j = 0;j < nlen; j++) {
          if (haystack[i + j] !== needle[j]) {
            m = false;
            break;
          }
        }
        if (m)
          return i;
      }
      return -1;
    }
    let start = byteOffset < 0 ? len + byteOffset : byteOffset;
    if (start > len - nlen)
      start = len - nlen;
    for (let i = start;i >= 0; i--) {
      let m = true;
      for (let j = 0;j < nlen; j++) {
        if (haystack[i + j] !== needle[j]) {
          m = false;
          break;
        }
      }
      if (m)
        return i;
    }
    return -1;
  }
  var indexOfBuffer = (buf, val, byteOffset, _encoding, dir) => byteSearch(buf, asBytes(val), byteOffset, dir);
  function indexOfNumber(buf, val, byteOffset, dir) {
    const len = buf.length;
    const target = val & 255;
    if (dir) {
      for (let i = byteOffset < 0 ? Math.max(len + byteOffset, 0) : byteOffset;i < len; i++) {
        if (buf[i] === target)
          return i;
      }
    } else {
      let start = byteOffset < 0 ? len + byteOffset : byteOffset;
      if (start >= len)
        start = len - 1;
      for (let i = start;i >= 0; i--)
        if (buf[i] === target)
          return i;
    }
    return -1;
  }
  var indexOfString = (buf, val, byteOffset, encoding, dir) => byteSearch(buf, encodeString(val, normalizeForFill(encoding)), byteOffset, dir);
  function swap16(buf) {
    for (let i = 0;i < buf.length; i += 2) {
      const t = buf[i];
      buf[i] = buf[i + 1];
      buf[i + 1] = t;
    }
    return buf;
  }
  function swap32(buf) {
    for (let i = 0;i < buf.length; i += 4) {
      let t = buf[i];
      buf[i] = buf[i + 3];
      buf[i + 3] = t;
      t = buf[i + 1];
      buf[i + 1] = buf[i + 2];
      buf[i + 2] = t;
    }
    return buf;
  }
  function swap64(buf) {
    for (let i = 0;i < buf.length; i += 8) {
      for (let j = 0;j < 4; j++) {
        const t = buf[i + j];
        buf[i + j] = buf[i + 7 - j];
        buf[i + 7 - j] = t;
      }
    }
    return buf;
  }
  function btoa(str) {
    const b = new Uint8Array(str.length);
    for (let i = 0;i < str.length; i++) {
      const c = str.charCodeAt(i);
      if (c > 255)
        return -1;
      b[i] = c;
    }
    return encodeBase64(b, 0, b.length, false);
  }
  function atob(str) {
    let clean = "";
    for (let i = 0;i < str.length; i++) {
      const c = str[i];
      if (c === " " || c === "\t" || c === `
` || c === "\r" || c === "\f")
        continue;
      clean += c;
    }
    for (let i = 0;i < clean.length; i++) {
      const ch = clean.charCodeAt(i);
      if (B64REV[ch & 255] < 0 && clean[i] !== "=")
        return -2;
    }
    const bytes = decodeBase64(clean);
    let out = "";
    for (let i = 0;i < bytes.length; i++)
      out += String.fromCharCode(bytes[i]);
    return out;
  }
  function createBufferBinding() {
    return {
      kMaxLength: 4294967295,
      kStringMaxLength: 536870888,
      byteLengthUtf8: (str) => encoder.encode(str).length,
      compare,
      compareOffset,
      copy,
      fill: bindingFill,
      isAscii: (input) => {
        const b = asBytes(input);
        for (let i = 0;i < b.length; i++)
          if (b[i] > 127)
            return false;
        return true;
      },
      isUtf8: (input) => {
        try {
          utf8Strict.decode(unshare(asBytes(input)));
          return true;
        } catch {
          return false;
        }
      },
      indexOfBuffer,
      indexOfNumber,
      indexOfString,
      swap16,
      swap32,
      swap64,
      atob,
      btoa,
      asciiSlice,
      base64Slice,
      base64urlSlice,
      latin1Slice,
      hexSlice,
      ucs2Slice,
      utf8Slice,
      asciiWriteStatic,
      latin1WriteStatic,
      utf8WriteStatic,
      base64Write,
      base64urlWrite,
      hexWrite,
      ucs2Write,
      createUnsafeArrayBuffer: (size) => new ArrayBuffer(size),
      setDetachKey: () => {}
    };
  }

  // third_party/node/bindings/uv-errors.js
  var UV_MESSAGES = {
    [-4095]: ["EOF", "end of file"],
    [-1]: ["EPERM", "operation not permitted"],
    [-2]: ["ENOENT", "no such file or directory"],
    [-5]: ["EIO", "i/o error"],
    [-9]: ["EBADF", "bad file descriptor"],
    [-11]: ["EAGAIN", "resource temporarily unavailable"],
    [-12]: ["ENOMEM", "not enough memory"],
    [-13]: ["EACCES", "permission denied"],
    [-16]: ["EBUSY", "resource busy or locked"],
    [-17]: ["EEXIST", "file already exists"],
    [-18]: ["EXDEV", "cross-device link not permitted"],
    [-20]: ["ENOTDIR", "not a directory"],
    [-21]: ["EISDIR", "illegal operation on a directory"],
    [-22]: ["EINVAL", "invalid argument"],
    [-23]: ["ENFILE", "file table overflow"],
    [-24]: ["EMFILE", "too many open files"],
    [-27]: ["EFBIG", "file too large"],
    [-28]: ["ENOSPC", "no space left on device"],
    [-29]: ["ESPIPE", "invalid seek"],
    [-30]: ["EROFS", "read-only file system"],
    [-31]: ["EMLINK", "too many links"],
    [-32]: ["EPIPE", "broken pipe"],
    [-36]: ["ENAMETOOLONG", "name too long"],
    [-38]: ["ENOSYS", "function not implemented"],
    [-39]: ["ENOTEMPTY", "directory not empty"],
    [-40]: ["ELOOP", "too many symbolic links encountered"],
    [-75]: ["EOVERFLOW", "value too large for defined data type"],
    [-98]: ["EADDRINUSE", "address already in use"],
    [-99]: ["EADDRNOTAVAIL", "address not available"],
    [-103]: ["ECONNABORTED", "software caused connection abort"],
    [-104]: ["ECONNRESET", "connection reset by peer"],
    [-107]: ["ENOTCONN", "socket is not connected"],
    [-110]: ["ETIMEDOUT", "connection timed out"],
    [-111]: ["ECONNREFUSED", "connection refused"],
    [-113]: ["EHOSTUNREACH", "host is unreachable"],
    [-125]: ["ECANCELED", "operation canceled"],
    [-3008]: ["ENOTFOUND", "name not resolved"]
  };
  var UV_CODES = (() => {
    const out = {};
    for (const errno of Object.keys(UV_MESSAGES)) {
      out["UV_" + UV_MESSAGES[errno][0]] = Number(errno);
    }
    return out;
  })();
  var ERRNO_BY_NAME = (() => {
    const out = {};
    for (const errno of Object.keys(UV_MESSAGES))
      out[UV_MESSAGES[errno][0]] = Number(errno);
    return out;
  })();
  var errname = (errno) => UV_MESSAGES[errno] ? UV_MESSAGES[errno][0] : `Unknown system error ${errno}`;
  var getErrorMap = () => {
    const m = new Map;
    for (const errno of Object.keys(UV_MESSAGES)) {
      const [name, msg] = UV_MESSAGES[errno];
      m.set(Number(errno), [name, msg]);
    }
    return m;
  };

  // third_party/node/bindings/constants.js
  var OS_SIGNALS = {
    SIGHUP: 1,
    SIGINT: 2,
    SIGQUIT: 3,
    SIGILL: 4,
    SIGTRAP: 5,
    SIGABRT: 6,
    SIGIOT: 6,
    SIGBUS: 7,
    SIGFPE: 8,
    SIGKILL: 9,
    SIGUSR1: 10,
    SIGSEGV: 11,
    SIGUSR2: 12,
    SIGPIPE: 13,
    SIGALRM: 14,
    SIGTERM: 15,
    SIGCHLD: 17,
    SIGSTKFLT: 16,
    SIGCONT: 18,
    SIGSTOP: 19,
    SIGTSTP: 20,
    SIGTTIN: 21,
    SIGTTOU: 22,
    SIGURG: 23,
    SIGXCPU: 24,
    SIGXFSZ: 25,
    SIGVTALRM: 26,
    SIGPROF: 27,
    SIGWINCH: 28,
    SIGIO: 29,
    SIGPOLL: 29,
    SIGPWR: 30,
    SIGSYS: 31
  };
  var OS_PRIORITY = {
    PRIORITY_LOW: 19,
    PRIORITY_BELOW_NORMAL: 10,
    PRIORITY_NORMAL: 0,
    PRIORITY_ABOVE_NORMAL: -7,
    PRIORITY_HIGH: -14,
    PRIORITY_HIGHEST: -20
  };
  var OS_DLOPEN = {
    RTLD_LAZY: 1,
    RTLD_NOW: 2,
    RTLD_GLOBAL: 256,
    RTLD_LOCAL: 0,
    RTLD_DEEPBIND: 8
  };
  var UV_UDP_REUSEADDR = 4;
  var CRYPTO_CONSTANTS = {
    RSA_PKCS1_PADDING: 1,
    RSA_NO_PADDING: 3,
    RSA_PKCS1_OAEP_PADDING: 4,
    RSA_PKCS1_PSS_PADDING: 6,
    RSA_PSS_SALTLEN_DIGEST: -1,
    RSA_PSS_SALTLEN_AUTO: -2,
    RSA_PSS_SALTLEN_MAX_SIGN: -2,
    OPENSSL_VERSION_NUMBER: 810549360,
    SSL_OP_ALL: 2147485776,
    SSL_OP_ALLOW_NO_DHE_KEX: 1024,
    SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION: 262144,
    SSL_OP_CIPHER_SERVER_PREFERENCE: 4194304,
    SSL_OP_CISCO_ANYCONNECT: 32768,
    SSL_OP_COOKIE_EXCHANGE: 8192,
    SSL_OP_CRYPTOPRO_TLSEXT_BUG: 2147483648,
    SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS: 2048,
    SSL_OP_LEGACY_SERVER_CONNECT: 4,
    SSL_OP_NO_COMPRESSION: 131072,
    SSL_OP_NO_ENCRYPT_THEN_MAC: 524288,
    SSL_OP_NO_QUERY_MTU: 4096,
    SSL_OP_NO_RENEGOTIATION: 1073741824,
    SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION: 65536,
    SSL_OP_NO_SSLv2: 0,
    SSL_OP_NO_SSLv3: 33554432,
    SSL_OP_NO_TICKET: 16384,
    SSL_OP_NO_TLSv1: 67108864,
    SSL_OP_NO_TLSv1_1: 268435456,
    SSL_OP_NO_TLSv1_2: 134217728,
    SSL_OP_NO_TLSv1_3: 536870912,
    SSL_OP_PRIORITIZE_CHACHA: 2097152,
    SSL_OP_TLS_ROLLBACK_BUG: 8388608,
    ENGINE_METHOD_RSA: 1,
    ENGINE_METHOD_DSA: 2,
    ENGINE_METHOD_DH: 4,
    ENGINE_METHOD_RAND: 8,
    ENGINE_METHOD_EC: 2048,
    ENGINE_METHOD_CIPHERS: 64,
    ENGINE_METHOD_DIGESTS: 128,
    ENGINE_METHOD_PKEY_METHS: 512,
    ENGINE_METHOD_PKEY_ASN1_METHS: 1024,
    ENGINE_METHOD_ALL: 65535,
    ENGINE_METHOD_NONE: 0,
    DH_CHECK_P_NOT_SAFE_PRIME: 2,
    DH_CHECK_P_NOT_PRIME: 1,
    DH_UNABLE_TO_CHECK_GENERATOR: 4,
    DH_NOT_SUITABLE_GENERATOR: 8,
    RSA_X931_PADDING: 5,
    TLS1_VERSION: 769,
    TLS1_1_VERSION: 770,
    TLS1_2_VERSION: 771,
    TLS1_3_VERSION: 772,
    POINT_CONVERSION_COMPRESSED: 2,
    POINT_CONVERSION_UNCOMPRESSED: 4,
    POINT_CONVERSION_HYBRID: 6,
    defaultCoreCipherList: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA"
  };
  var OS_ERRNO = {
    E2BIG: 7,
    EACCES: 13,
    EADDRINUSE: 98,
    EADDRNOTAVAIL: 99,
    EAFNOSUPPORT: 97,
    EAGAIN: 11,
    EALREADY: 114,
    EBADF: 9,
    EBADMSG: 74,
    EBUSY: 16,
    ECANCELED: 125,
    ECHILD: 10,
    ECONNABORTED: 103,
    ECONNREFUSED: 111,
    ECONNRESET: 104,
    EDEADLK: 35,
    EDESTADDRREQ: 89,
    EDOM: 33,
    EDQUOT: 122,
    EEXIST: 17,
    EFAULT: 14,
    EFBIG: 27,
    EHOSTUNREACH: 113,
    EIDRM: 43,
    EILSEQ: 84,
    EINPROGRESS: 115,
    EINTR: 4,
    EINVAL: 22,
    EIO: 5,
    EISCONN: 106,
    EISDIR: 21,
    ELOOP: 40,
    EMFILE: 24,
    EMLINK: 31,
    EMSGSIZE: 90,
    EMULTIHOP: 72,
    ENAMETOOLONG: 36,
    ENETDOWN: 100,
    ENETRESET: 102,
    ENETUNREACH: 101,
    ENFILE: 23,
    ENOBUFS: 105,
    ENODATA: 61,
    ENODEV: 19,
    ENOENT: 2,
    ENOEXEC: 8,
    ENOLCK: 37,
    ENOLINK: 67,
    ENOMEM: 12,
    ENOMSG: 42,
    ENOPROTOOPT: 92,
    ENOSPC: 28,
    ENOSR: 63,
    ENOSTR: 60,
    ENOSYS: 38,
    ENOTCONN: 107,
    ENOTDIR: 20,
    ENOTEMPTY: 39,
    ENOTSOCK: 88,
    ENOTSUP: 95,
    ENOTTY: 25,
    ENXIO: 6,
    EOPNOTSUPP: 95,
    EOVERFLOW: 75,
    EPERM: 1,
    EPIPE: 32,
    EPROTO: 71,
    EPROTONOSUPPORT: 93,
    EPROTOTYPE: 91,
    ERANGE: 34,
    EROFS: 30,
    ESPIPE: 29,
    ESRCH: 3,
    ESTALE: 116,
    ETIME: 62,
    ETIMEDOUT: 110,
    ETXTBSY: 26,
    EWOULDBLOCK: 11,
    EXDEV: 18
  };
  var FS_CONSTANTS = {
    O_RDONLY: 0,
    O_WRONLY: 1,
    O_RDWR: 2,
    O_CREAT: 64,
    O_EXCL: 128,
    O_NOCTTY: 256,
    O_TRUNC: 512,
    O_APPEND: 1024,
    O_DIRECTORY: 65536,
    O_NOFOLLOW: 131072,
    O_SYNC: 1052672,
    O_DSYNC: 4096,
    O_DIRECT: 16384,
    O_NONBLOCK: 2048,
    S_IFMT: 61440,
    S_IFREG: 32768,
    S_IFDIR: 16384,
    S_IFCHR: 8192,
    S_IFBLK: 24576,
    S_IFIFO: 4096,
    S_IFLNK: 40960,
    S_IFSOCK: 49152,
    S_IRWXU: 448,
    S_IRUSR: 256,
    S_IWUSR: 128,
    S_IXUSR: 64,
    S_IRWXG: 56,
    S_IRGRP: 32,
    S_IWGRP: 16,
    S_IXGRP: 8,
    S_IRWXO: 7,
    S_IROTH: 4,
    S_IWOTH: 2,
    S_IXOTH: 1,
    O_NOATIME: 262144,
    F_OK: 0,
    R_OK: 4,
    W_OK: 2,
    X_OK: 1,
    COPYFILE_EXCL: 1,
    COPYFILE_FICLONE: 2,
    COPYFILE_FICLONE_FORCE: 4,
    UV_FS_COPYFILE_EXCL: 1,
    UV_FS_COPYFILE_FICLONE: 2,
    UV_FS_COPYFILE_FICLONE_FORCE: 4,
    UV_FS_O_FILEMAP: 0,
    UV_FS_SYMLINK_DIR: 1,
    UV_FS_SYMLINK_JUNCTION: 2,
    UV_DIRENT_UNKNOWN: 0,
    UV_DIRENT_FILE: 1,
    UV_DIRENT_DIR: 2,
    UV_DIRENT_LINK: 3,
    UV_DIRENT_FIFO: 4,
    UV_DIRENT_SOCKET: 5,
    UV_DIRENT_CHAR: 6,
    UV_DIRENT_BLOCK: 7
  };

  // third_party/node/lib/assert.js
  function assert_default(exports, require2, module, process, internalBinding, primordials2) {
    const { isDeepStrictEqual } = require2("internal/util/comparisons");
    const inspect = (v) => {
      try {
        return require2("util").inspect(v, { depth: 2, breakLength: Infinity });
      } catch {
        return String(v);
      }
    };

    class AssertionError extends Error {
      constructor(options = {}) {
        const { actual, expected, operator, stackStartFn } = options;
        const message = options.message != null ? String(options.message) : `${inspect(actual)} ${operator} ${inspect(expected)}`;
        super(message);
        this.name = "AssertionError";
        this.code = "ERR_ASSERTION";
        this.actual = actual;
        this.expected = expected;
        this.operator = operator;
        this.generatedMessage = options.message == null;
        if (Error.captureStackTrace)
          Error.captureStackTrace(this, stackStartFn || AssertionError);
      }
    }
    function fail(actual, expected, message, operator, stackStartFn) {
      const argsLen = arguments.length;
      if (argsLen === 0) {
        throw new AssertionError({ message: "Failed", operator: "fail", stackStartFn: fail });
      }
      if (argsLen === 1) {
        if (actual instanceof Error)
          throw actual;
        throw new AssertionError({ message: actual == null ? "Failed" : actual, operator: "fail", stackStartFn: fail });
      }
      if (message instanceof Error)
        throw message;
      throw new AssertionError({
        actual,
        expected,
        message,
        operator: operator || "fail",
        stackStartFn: stackStartFn || fail
      });
    }
    function raise(fn, actual, expected, message, operator) {
      if (message instanceof Error)
        throw message;
      throw new AssertionError({ actual, expected, message, operator, stackStartFn: fn });
    }
    function ok(value, message) {
      if (!value)
        raise(ok, value, true, message, "==");
    }
    function equal(actual, expected, message) {
      if (actual != expected)
        raise(equal, actual, expected, message, "==");
    }
    function notEqual(actual, expected, message) {
      if (actual == expected)
        raise(notEqual, actual, expected, message, "!=");
    }
    function strictEqual(actual, expected, message) {
      if (!Object.is(actual, expected))
        raise(strictEqual, actual, expected, message, "strictEqual");
    }
    function notStrictEqual(actual, expected, message) {
      if (Object.is(actual, expected))
        raise(notStrictEqual, actual, expected, message, "notStrictEqual");
    }
    function deepEqual(actual, expected, message) {
      if (!isDeepStrictEqual(actual, expected))
        raise(deepEqual, actual, expected, message, "deepEqual");
    }
    function notDeepEqual(actual, expected, message) {
      if (isDeepStrictEqual(actual, expected))
        raise(notDeepEqual, actual, expected, message, "notDeepEqual");
    }
    function deepStrictEqual(actual, expected, message) {
      if (!isDeepStrictEqual(actual, expected))
        raise(deepStrictEqual, actual, expected, message, "deepStrictEqual");
    }
    function notDeepStrictEqual(actual, expected, message) {
      if (isDeepStrictEqual(actual, expected))
        raise(notDeepStrictEqual, actual, expected, message, "notDeepStrictEqual");
    }
    function ifError(value) {
      if (value !== null && value !== undefined) {
        let message = "ifError got unwanted exception: ";
        if (value instanceof Error)
          message += value.message;
        else
          message += inspect(value);
        throw new AssertionError({ actual: value, expected: null, message, operator: "ifError", stackStartFn: ifError });
      }
    }
    function match(str, regexp, message) {
      if (!(regexp instanceof RegExp)) {
        throw new TypeError('The "regexp" argument must be an instance of RegExp.');
      }
      if (!regexp.test(String(str)))
        raise(match, str, regexp, message, "match");
    }
    function doesNotMatch(str, regexp, message) {
      if (!(regexp instanceof RegExp)) {
        throw new TypeError('The "regexp" argument must be an instance of RegExp.');
      }
      if (regexp.test(String(str)))
        raise(doesNotMatch, str, regexp, message, "doesNotMatch");
    }
    function errorMatches(actual, expected) {
      if (expected == null)
        return true;
      if (expected instanceof RegExp)
        return expected.test(String(actual));
      if (typeof expected === "function") {
        if (expected.prototype !== undefined && actual instanceof expected)
          return true;
        if (Error.isPrototypeOf(expected) || expected === Error)
          return false;
        return expected.call({}, actual) === true;
      }
      if (typeof expected === "object") {
        for (const key of Object.keys(expected)) {
          const a = actual == null ? undefined : actual[key];
          if (!(isDeepStrictEqual(a, expected[key]) || a === expected[key]))
            return false;
        }
        return true;
      }
      return false;
    }
    function throws(fn, error, message) {
      let threw = false;
      let caught;
      try {
        fn();
      } catch (e) {
        threw = true;
        caught = e;
      }
      if (!threw) {
        const msg = (typeof error === "string" ? error : message) || "Missing expected exception.";
        throw new AssertionError({ message: msg, operator: "throws", stackStartFn: throws });
      }
      if (typeof error === "string") {
        return;
      }
      if (error && !errorMatches(caught, error))
        throw caught;
    }
    function doesNotThrow(fn, error, message) {
      let caught;
      try {
        fn();
      } catch (e) {
        caught = e;
      }
      if (caught === undefined)
        return;
      if (error && typeof error !== "string" && !errorMatches(caught, error))
        throw caught;
      const detail = typeof error === "string" ? error : message;
      throw new AssertionError({
        message: `Got unwanted exception.${detail ? " " + detail : ""}`,
        operator: "doesNotThrow",
        stackStartFn: doesNotThrow
      });
    }
    async function rejects(promiseFn, error, message) {
      let threw = false;
      let caught;
      try {
        await (typeof promiseFn === "function" ? promiseFn() : promiseFn);
      } catch (e) {
        threw = true;
        caught = e;
      }
      if (!threw) {
        const msg = (typeof error === "string" ? error : message) || "Missing expected rejection.";
        throw new AssertionError({ message: msg, operator: "rejects", stackStartFn: rejects });
      }
      if (typeof error === "string")
        return;
      if (error && !errorMatches(caught, error))
        throw caught;
    }
    async function doesNotReject(promiseFn, error, message) {
      let caught;
      try {
        await (typeof promiseFn === "function" ? promiseFn() : promiseFn);
      } catch (e) {
        caught = e;
      }
      if (caught === undefined)
        return;
      if (error && typeof error !== "string" && !errorMatches(caught, error))
        throw caught;
      const detail = typeof error === "string" ? error : message;
      throw new AssertionError({
        message: `Got unwanted rejection.${detail ? " " + detail : ""}`,
        operator: "doesNotReject",
        stackStartFn: doesNotReject
      });
    }
    const assert = function assert2(value, message) {
      ok(value, message);
    };
    Object.assign(assert, {
      AssertionError,
      ok,
      equal,
      notEqual,
      strictEqual,
      notStrictEqual,
      deepEqual,
      notDeepEqual,
      deepStrictEqual,
      notDeepStrictEqual,
      ifError,
      match,
      doesNotMatch,
      throws,
      doesNotThrow,
      rejects,
      doesNotReject,
      fail
    });
    const strict = function strict2(value, message) {
      ok(value, message);
    };
    Object.assign(strict, assert, {
      equal: strictEqual,
      notEqual: notStrictEqual,
      deepEqual: deepStrictEqual,
      notDeepEqual: notDeepStrictEqual
    });
    strict.strict = strict;
    assert.strict = strict;
    module.exports = assert;
  }

  // third_party/node/lib/buffer.js
  function buffer_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Array: Array2,
      ArrayBufferIsView,
      ArrayIsArray,
      ArrayPrototypeForEach,
      MathFloor,
      MathMin,
      MathTrunc,
      NumberIsInteger,
      NumberIsNaN,
      NumberMAX_SAFE_INTEGER,
      NumberMIN_SAFE_INTEGER,
      ObjectDefineProperties,
      ObjectDefineProperty,
      ObjectPrototypeHasOwnProperty,
      ObjectSetPrototypeOf,
      RegExpPrototypeSymbolReplace,
      StringPrototypeCharCodeAt,
      StringPrototypeSlice,
      StringPrototypeToLowerCase,
      StringPrototypeTrim,
      SymbolSpecies,
      SymbolToPrimitive,
      TypedArrayPrototypeFill,
      TypedArrayPrototypeGetBuffer,
      TypedArrayPrototypeGetByteLength,
      TypedArrayPrototypeGetByteOffset,
      TypedArrayPrototypeGetLength,
      TypedArrayPrototypeSet,
      TypedArrayPrototypeSubarray,
      Uint8Array: Uint8Array2,
      Uint8ArrayPrototype
    } = primordials2;
    const {
      byteLengthUtf8,
      compare: _compare,
      compareOffset: compareOffset2,
      copy: _copy,
      fill: bindingFill2,
      isAscii: bindingIsAscii,
      isUtf8: bindingIsUtf8,
      indexOfBuffer: indexOfBuffer2,
      indexOfNumber: indexOfNumber2,
      indexOfString: indexOfString2,
      swap16: _swap16,
      swap32: _swap32,
      swap64: _swap64,
      kMaxLength,
      kStringMaxLength,
      atob: _atob,
      btoa: _btoa,
      asciiSlice: asciiSlice2,
      base64Slice: base64Slice2,
      base64urlSlice: base64urlSlice2,
      latin1Slice: latin1Slice2,
      hexSlice: hexSlice2,
      ucs2Slice: ucs2Slice2,
      utf8Slice: utf8Slice2,
      base64Write: base64Write2,
      base64urlWrite: base64urlWrite2,
      hexWrite: hexWrite2,
      ucs2Write: ucs2Write2
    } = internalBinding("buffer");
    const {
      constants: {
        ALL_PROPERTIES,
        ONLY_ENUMERABLE
      },
      getOwnNonIndexProperties,
      isInsideNodeModules
    } = internalBinding("util");
    const {
      customInspectSymbol,
      lazyDOMException,
      normalizeEncoding,
      kIsEncodingSymbol,
      defineLazyProperties,
      encodingsMap,
      deprecate
    } = require2("internal/util");
    const {
      isAnyArrayBuffer,
      isArrayBufferView,
      isUint8Array,
      isTypedArray
    } = require2("internal/util/types");
    const {
      inspect: utilInspect
    } = require2("internal/util/inspect");
    const {
      codes: {
        ERR_BUFFER_OUT_OF_BOUNDS,
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_ARG_VALUE,
        ERR_INVALID_BUFFER_SIZE,
        ERR_MISSING_ARGS,
        ERR_OUT_OF_RANGE,
        ERR_UNKNOWN_ENCODING
      },
      genericNodeError
    } = require2("internal/errors");
    const {
      validateArray,
      validateBuffer,
      validateInteger,
      validateNumber,
      validateString
    } = require2("internal/validators");
    const validateOffset = (value, name, min = 0, max = kMaxLength) => validateInteger(value, name, min, max);
    const {
      FastBuffer,
      markAsUntransferable,
      addBufferPrototypeMethods,
      createUnsafeBuffer,
      asciiWrite,
      latin1Write,
      utf8Write
    } = require2("internal/buffer");
    const {
      namespace: {
        addDeserializeCallback,
        isBuildingSnapshot
      }
    } = require2("internal/v8/startup_snapshot");
    FastBuffer.prototype.constructor = Buffer;
    Buffer.prototype = FastBuffer.prototype;
    addBufferPrototypeMethods(Buffer.prototype);
    const constants = ObjectDefineProperties({}, {
      MAX_LENGTH: {
        __proto__: null,
        value: kMaxLength,
        writable: false,
        enumerable: true
      },
      MAX_STRING_LENGTH: {
        __proto__: null,
        value: kStringMaxLength,
        writable: false,
        enumerable: true
      }
    });
    Buffer.poolSize = 64 * 1024;
    let poolSize, poolOffset, allocPool, allocBuffer;
    function createPool() {
      poolSize = Buffer.poolSize;
      allocBuffer = createUnsafeBuffer(poolSize);
      allocPool = allocBuffer.buffer;
      markAsUntransferable(allocPool);
      const hostMark = globalThis.__ocHostMarkUntransferable;
      if (typeof hostMark === "function") {
        try {
          hostMark(allocPool);
        } catch {}
      }
      poolOffset = 0;
    }
    function poolExhaustedOrDetached(need) {
      return need > poolSize - poolOffset || allocBuffer.byteLength === 0;
    }
    createPool();
    if (isBuildingSnapshot()) {
      addDeserializeCallback(() => {
        createPool();
      });
    }
    function alignPool() {
      if (poolOffset & 7) {
        poolOffset |= 7;
        poolOffset++;
      }
    }
    let bufferWarningAlreadyEmitted = false;
    let nodeModulesCheckCounter = 0;
    const bufferWarning = "Buffer() is deprecated due to security and usability " + "issues. Please use the Buffer.alloc(), " + "Buffer.allocUnsafe(), or Buffer.from() methods instead.";
    function showFlaggedDeprecation() {
      if (bufferWarningAlreadyEmitted || ++nodeModulesCheckCounter > 1e4 || !require2("internal/options").getOptionValue("--pending-deprecation") && isInsideNodeModules(3)) {
        return;
      }
      process.emitWarning(bufferWarning, "DeprecationWarning", "DEP0005");
      bufferWarningAlreadyEmitted = true;
    }
    function toInteger(n, defaultVal) {
      n = +n;
      if (!NumberIsNaN(n) && n >= NumberMIN_SAFE_INTEGER && n <= NumberMAX_SAFE_INTEGER) {
        return n % 1 === 0 ? n : MathFloor(n);
      }
      return defaultVal;
    }
    function copyImpl(source, target, targetStart, sourceStart, sourceEnd) {
      if (!ArrayBufferIsView(source))
        throw new ERR_INVALID_ARG_TYPE("source", ["Buffer", "Uint8Array"], source);
      if (!ArrayBufferIsView(target))
        throw new ERR_INVALID_ARG_TYPE("target", ["Buffer", "Uint8Array"], target);
      if (targetStart === undefined) {
        targetStart = 0;
      } else {
        targetStart = NumberIsInteger(targetStart) ? targetStart : toInteger(targetStart, 0);
        if (targetStart < 0)
          throw new ERR_OUT_OF_RANGE("targetStart", ">= 0", targetStart);
      }
      if (sourceStart === undefined) {
        sourceStart = 0;
      } else {
        sourceStart = NumberIsInteger(sourceStart) ? sourceStart : toInteger(sourceStart, 0);
        if (sourceStart < 0 || sourceStart > source.byteLength)
          throw new ERR_OUT_OF_RANGE("sourceStart", `>= 0 && <= ${source.byteLength}`, sourceStart);
      }
      if (sourceEnd === undefined) {
        sourceEnd = source.byteLength;
      } else {
        sourceEnd = NumberIsInteger(sourceEnd) ? sourceEnd : toInteger(sourceEnd, 0);
        if (sourceEnd < 0)
          throw new ERR_OUT_OF_RANGE("sourceEnd", ">= 0", sourceEnd);
      }
      if (targetStart >= target.byteLength || sourceStart >= sourceEnd)
        return 0;
      return _copyActual(source, target, targetStart, sourceStart, sourceEnd);
    }
    function _copyActual(source, target, targetStart, sourceStart, sourceEnd, isUint8Copy = false) {
      if (sourceEnd - sourceStart > target.byteLength - targetStart)
        sourceEnd = sourceStart + target.byteLength - targetStart;
      let nb = sourceEnd - sourceStart;
      const sourceLen = source.byteLength - sourceStart;
      if (nb > sourceLen)
        nb = sourceLen;
      if (nb <= 0)
        return 0;
      if (sourceStart === 0 && nb === sourceLen && (isUint8Copy || isUint8Array(target))) {
        TypedArrayPrototypeSet(target, source, targetStart);
      } else {
        _copy(source, target, targetStart, sourceStart, nb);
      }
      return nb;
    }
    function Buffer(arg, encodingOrOffset, length) {
      showFlaggedDeprecation();
      if (typeof arg === "number") {
        if (typeof encodingOrOffset === "string") {
          throw new ERR_INVALID_ARG_TYPE("string", "string", arg);
        }
        return Buffer.alloc(arg);
      }
      return Buffer.from(arg, encodingOrOffset, length);
    }
    ObjectDefineProperty(Buffer, SymbolSpecies, {
      __proto__: null,
      enumerable: false,
      configurable: true,
      get() {
        return FastBuffer;
      }
    });
    Buffer.from = function from(value, encodingOrOffset, length) {
      if (typeof value === "string")
        return fromString(value, encodingOrOffset);
      if (typeof value === "object" && value !== null) {
        if (isAnyArrayBuffer(value))
          return fromArrayBuffer(value, encodingOrOffset, length);
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value && (typeof valueOf === "string" || typeof valueOf === "object")) {
          return from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b)
          return b;
        if (typeof value[SymbolToPrimitive] === "function") {
          const primitive = value[SymbolToPrimitive]("string");
          if (typeof primitive === "string") {
            return fromString(primitive, encodingOrOffset);
          }
        }
      }
      throw new ERR_INVALID_ARG_TYPE("first argument", ["string", "Buffer", "ArrayBuffer", "Array", "Array-like Object"], value);
    };
    Buffer.copyBytesFrom = function copyBytesFrom(view, offset, length) {
      if (!isTypedArray(view)) {
        throw new ERR_INVALID_ARG_TYPE("view", ["TypedArray"], view);
      }
      const viewLength = TypedArrayPrototypeGetLength(view);
      if (viewLength === 0) {
        return new FastBuffer;
      }
      let start = 0;
      let end = viewLength;
      if (offset !== undefined) {
        validateInteger(offset, "offset", 0);
        if (offset >= viewLength)
          return new FastBuffer;
        start = offset;
      }
      if (length !== undefined) {
        validateInteger(length, "length", 0);
        end = MathMin(start + length, viewLength);
      }
      if (end <= start)
        return new FastBuffer;
      const viewByteLength = TypedArrayPrototypeGetByteLength(view);
      const elementSize = viewByteLength / viewLength;
      const srcByteOffset = TypedArrayPrototypeGetByteOffset(view) + start * elementSize;
      const srcByteLength = (end - start) * elementSize;
      return fromArrayLike(new Uint8Array2(TypedArrayPrototypeGetBuffer(view), srcByteOffset, srcByteLength));
    };
    const of = (...items) => {
      const len = items.length;
      const newObj = new FastBuffer(len);
      for (let k = 0;k < len; k++)
        newObj[k] = items[k];
      return newObj;
    };
    Buffer.of = of;
    ObjectSetPrototypeOf(Buffer, Uint8Array2);
    Buffer.alloc = function alloc(size, fill, encoding) {
      validateNumber(size, "size", 0, kMaxLength);
      if (fill !== undefined && fill !== 0 && size > 0) {
        const buf = createUnsafeBuffer(size);
        return _fill(buf, fill, 0, buf.length, encoding);
      }
      return new FastBuffer(size);
    };
    Buffer.allocUnsafe = function allocUnsafe(size) {
      validateNumber(size, "size", 0, kMaxLength);
      return allocate(size);
    };
    Buffer.allocUnsafeSlow = function allocUnsafeSlow(size) {
      validateNumber(size, "size", 0, kMaxLength);
      return createUnsafeBuffer(size);
    };
    function SlowBuffer(size) {
      validateNumber(size, "size", 0, kMaxLength);
      return createUnsafeBuffer(size);
    }
    ObjectSetPrototypeOf(SlowBuffer.prototype, Uint8ArrayPrototype);
    ObjectSetPrototypeOf(SlowBuffer, Uint8Array2);
    function allocate(size) {
      if (size <= 0) {
        return new FastBuffer;
      }
      if (size < Buffer.poolSize >>> 1) {
        if (poolExhaustedOrDetached(size))
          createPool();
        const b = new FastBuffer(allocPool, poolOffset, size);
        poolOffset += size;
        alignPool();
        return b;
      }
      return createUnsafeBuffer(size);
    }
    function fromStringFast(string, ops) {
      const maxLength = Buffer.poolSize >>> 1;
      let length = string.length;
      if (length >= maxLength)
        return createFromString(string, ops);
      length *= 4;
      if (length >= maxLength)
        length = ops.byteLength(string);
      if (length >= maxLength)
        return createFromString(string, ops, length);
      if (poolExhaustedOrDetached(length))
        createPool();
      const actual = ops.write(allocBuffer, string, poolOffset, length);
      const b = new FastBuffer(allocPool, poolOffset, actual);
      poolOffset += actual;
      alignPool();
      return b;
    }
    function createFromString(string, ops, length = ops.byteLength(string)) {
      const buf = Buffer.allocUnsafeSlow(length);
      const actual = ops.write(buf, string, 0, length);
      return actual < length ? new FastBuffer(buf.buffer, 0, actual) : buf;
    }
    function fromString(string, encoding) {
      let ops;
      if (!encoding || encoding === "utf8" || typeof encoding !== "string") {
        ops = encodingOps.utf8;
      } else {
        ops = getEncodingOps(encoding);
        if (ops === undefined)
          throw new ERR_UNKNOWN_ENCODING(encoding);
      }
      return string.length === 0 ? new FastBuffer : fromStringFast(string, ops);
    }
    function fromArrayBuffer(obj, byteOffset, length) {
      if (byteOffset === undefined) {
        byteOffset = 0;
      } else {
        byteOffset = +byteOffset;
        if (NumberIsNaN(byteOffset))
          byteOffset = 0;
      }
      const maxLength = obj.byteLength - byteOffset;
      if (maxLength < 0)
        throw new ERR_BUFFER_OUT_OF_BOUNDS("offset");
      if (length !== undefined) {
        length = +length;
        if (length > 0) {
          if (length > maxLength)
            throw new ERR_BUFFER_OUT_OF_BOUNDS("length");
        } else {
          length = 0;
        }
      }
      return new FastBuffer(obj, byteOffset, length);
    }
    function fromArrayLike(obj) {
      const { length } = obj;
      if (length <= 0)
        return new FastBuffer;
      if (length < Buffer.poolSize >>> 1) {
        if (poolExhaustedOrDetached(length))
          createPool();
        const b = new FastBuffer(allocPool, poolOffset, length);
        TypedArrayPrototypeSet(b, obj, 0);
        poolOffset += length;
        alignPool();
        return b;
      }
      return new FastBuffer(obj);
    }
    function fromObject(obj) {
      if (obj.length !== undefined || isAnyArrayBuffer(obj.buffer)) {
        if (typeof obj.length !== "number") {
          return new FastBuffer;
        }
        return fromArrayLike(obj);
      }
      if (obj.type === "Buffer" && ArrayIsArray(obj.data)) {
        return fromArrayLike(obj.data);
      }
    }
    Buffer.isBuffer = function isBuffer(b) {
      return b instanceof Buffer;
    };
    Buffer.compare = function compare2(buf1, buf2) {
      if (!isUint8Array(buf1)) {
        throw new ERR_INVALID_ARG_TYPE("buf1", ["Buffer", "Uint8Array"], buf1);
      }
      if (!isUint8Array(buf2)) {
        throw new ERR_INVALID_ARG_TYPE("buf2", ["Buffer", "Uint8Array"], buf2);
      }
      if (buf1 === buf2) {
        return 0;
      }
      return _compare(buf1, buf2);
    };
    Buffer.isEncoding = function isEncoding(encoding) {
      return typeof encoding === "string" && encoding.length !== 0 && normalizeEncoding(encoding) !== undefined;
    };
    Buffer[kIsEncodingSymbol] = Buffer.isEncoding;
    Buffer.concat = function concat(list, length) {
      validateArray(list, "list");
      if (list.length === 0)
        return new FastBuffer;
      if (length === undefined) {
        length = 0;
        for (let i = 0;i < list.length; i++) {
          const buf = list[i];
          if (!isUint8Array(buf)) {
            throw new ERR_INVALID_ARG_TYPE(`list[${i}]`, ["Buffer", "Uint8Array"], buf);
          }
          length += TypedArrayPrototypeGetByteLength(buf);
        }
        const buffer2 = allocate(length);
        let pos2 = 0;
        for (let i = 0;i < list.length; i++) {
          const buf = list[i];
          const bufLength = TypedArrayPrototypeGetByteLength(buf);
          TypedArrayPrototypeSet(buffer2, buf, pos2);
          pos2 += bufLength;
        }
        if (pos2 < length) {
          TypedArrayPrototypeFill(buffer2, 0, pos2, length);
        }
        return buffer2;
      }
      validateOffset(length, "length");
      for (let i = 0;i < list.length; i++) {
        if (!isUint8Array(list[i])) {
          throw new ERR_INVALID_ARG_TYPE(`list[${i}]`, ["Buffer", "Uint8Array"], list[i]);
        }
      }
      const buffer = allocate(length);
      let pos = 0;
      for (let i = 0;i < list.length; i++) {
        const buf = list[i];
        const bufLength = TypedArrayPrototypeGetByteLength(buf);
        if (pos + bufLength > length) {
          TypedArrayPrototypeSet(buffer, TypedArrayPrototypeSubarray(buf, 0, length - pos), pos);
          pos = length;
          break;
        }
        TypedArrayPrototypeSet(buffer, buf, pos);
        pos += bufLength;
      }
      if (pos < length) {
        TypedArrayPrototypeFill(buffer, 0, pos, length);
      }
      return buffer;
    };
    function base64ByteLength(str, bytes) {
      if (StringPrototypeCharCodeAt(str, bytes - 1) === 61)
        bytes--;
      if (bytes > 1 && StringPrototypeCharCodeAt(str, bytes - 1) === 61)
        bytes--;
      return bytes * 3 >>> 2;
    }
    const encodingOps = {
      utf8: {
        encoding: "utf8",
        encodingVal: encodingsMap.utf8,
        byteLength: byteLengthUtf8,
        write: utf8Write,
        slice: utf8Slice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfString2(buf, val, byteOffset, encodingsMap.utf8, dir)
      },
      ucs2: {
        encoding: "ucs2",
        encodingVal: encodingsMap.utf16le,
        byteLength: (string) => string.length * 2,
        write: ucs2Write2,
        slice: ucs2Slice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfString2(buf, val, byteOffset, encodingsMap.utf16le, dir)
      },
      utf16le: {
        encoding: "utf16le",
        encodingVal: encodingsMap.utf16le,
        byteLength: (string) => string.length * 2,
        write: ucs2Write2,
        slice: ucs2Slice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfString2(buf, val, byteOffset, encodingsMap.utf16le, dir)
      },
      latin1: {
        encoding: "latin1",
        encodingVal: encodingsMap.latin1,
        byteLength: (string) => string.length,
        write: latin1Write,
        slice: latin1Slice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfString2(buf, val, byteOffset, encodingsMap.latin1, dir)
      },
      ascii: {
        encoding: "ascii",
        encodingVal: encodingsMap.ascii,
        byteLength: (string) => string.length,
        write: asciiWrite,
        slice: asciiSlice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfString2(buf, val, byteOffset, encodingsMap.ascii, dir)
      },
      base64: {
        encoding: "base64",
        encodingVal: encodingsMap.base64,
        byteLength: (string) => base64ByteLength(string, string.length),
        write: base64Write2,
        slice: base64Slice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfBuffer2(buf, fromStringFast(val, encodingOps.base64), byteOffset, encodingsMap.base64, dir)
      },
      base64url: {
        encoding: "base64url",
        encodingVal: encodingsMap.base64url,
        byteLength: (string) => base64ByteLength(string, string.length),
        write: base64urlWrite2,
        slice: base64urlSlice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfBuffer2(buf, fromStringFast(val, encodingOps.base64url), byteOffset, encodingsMap.base64url, dir)
      },
      hex: {
        encoding: "hex",
        encodingVal: encodingsMap.hex,
        byteLength: (string) => string.length >>> 1,
        write: hexWrite2,
        slice: hexSlice2,
        indexOf: (buf, val, byteOffset, dir) => indexOfBuffer2(buf, fromStringFast(val, encodingOps.hex), byteOffset, encodingsMap.hex, dir)
      }
    };
    function getEncodingOps(encoding) {
      encoding += "";
      switch (encoding.length) {
        case 4:
          if (encoding === "utf8")
            return encodingOps.utf8;
          if (encoding === "ucs2")
            return encodingOps.ucs2;
          encoding = StringPrototypeToLowerCase(encoding);
          if (encoding === "utf8")
            return encodingOps.utf8;
          if (encoding === "ucs2")
            return encodingOps.ucs2;
          break;
        case 5:
          if (encoding === "utf-8")
            return encodingOps.utf8;
          if (encoding === "ascii")
            return encodingOps.ascii;
          if (encoding === "ucs-2")
            return encodingOps.ucs2;
          encoding = StringPrototypeToLowerCase(encoding);
          if (encoding === "utf-8")
            return encodingOps.utf8;
          if (encoding === "ascii")
            return encodingOps.ascii;
          if (encoding === "ucs-2")
            return encodingOps.ucs2;
          break;
        case 7:
          if (encoding === "utf16le" || StringPrototypeToLowerCase(encoding) === "utf16le")
            return encodingOps.utf16le;
          break;
        case 8:
          if (encoding === "utf-16le" || StringPrototypeToLowerCase(encoding) === "utf-16le")
            return encodingOps.utf16le;
          break;
        case 6:
          if (encoding === "latin1" || encoding === "binary")
            return encodingOps.latin1;
          if (encoding === "base64")
            return encodingOps.base64;
          encoding = StringPrototypeToLowerCase(encoding);
          if (encoding === "latin1" || encoding === "binary")
            return encodingOps.latin1;
          if (encoding === "base64")
            return encodingOps.base64;
          break;
        case 3:
          if (encoding === "hex" || StringPrototypeToLowerCase(encoding) === "hex")
            return encodingOps.hex;
          break;
        case 9:
          if (encoding === "base64url" || StringPrototypeToLowerCase(encoding) === "base64url")
            return encodingOps.base64url;
          break;
      }
    }
    function byteLength(string, encoding) {
      if (typeof string !== "string") {
        if (isArrayBufferView(string) || isAnyArrayBuffer(string)) {
          return string.byteLength;
        }
        throw new ERR_INVALID_ARG_TYPE("string", ["string", "Buffer", "ArrayBuffer"], string);
      }
      const len = string.length;
      if (len === 0)
        return 0;
      if (!encoding || encoding === "utf8") {
        return byteLengthUtf8(string);
      }
      if (encoding === "ascii") {
        return len;
      }
      const ops = getEncodingOps(encoding);
      if (ops === undefined) {
        return byteLengthUtf8(string);
      }
      return ops.byteLength(string);
    }
    Buffer.byteLength = byteLength;
    ObjectDefineProperty(Buffer.prototype, "parent", {
      __proto__: null,
      enumerable: true,
      get() {
        if (!(this instanceof Buffer))
          return;
        return this.buffer;
      }
    });
    ObjectDefineProperty(Buffer.prototype, "offset", {
      __proto__: null,
      enumerable: true,
      get() {
        if (!(this instanceof Buffer))
          return;
        return this.byteOffset;
      }
    });
    Buffer.prototype.copy = function copy2(target, targetStart, sourceStart, sourceEnd) {
      return copyImpl(this, target, targetStart, sourceStart, sourceEnd);
    };
    Buffer.prototype.toString = function toString(encoding, start, end) {
      if (arguments.length === 0) {
        return utf8Slice2(this, 0, this.length);
      }
      const bufferLength = TypedArrayPrototypeGetLength(this);
      if (start <= 0)
        start = 0;
      else if (start >= bufferLength)
        return "";
      else
        start = MathTrunc(start) || 0;
      if (end === undefined || end > bufferLength)
        end = bufferLength;
      else
        end = MathTrunc(end) || 0;
      if (end <= start)
        return "";
      if (encoding === undefined)
        return utf8Slice2(this, start, end);
      const ops = getEncodingOps(encoding);
      if (ops === undefined)
        throw new ERR_UNKNOWN_ENCODING(encoding);
      return ops.slice(this, start, end);
    };
    Buffer.prototype.equals = function equals(otherBuffer) {
      if (!isUint8Array(otherBuffer)) {
        throw new ERR_INVALID_ARG_TYPE("otherBuffer", ["Buffer", "Uint8Array"], otherBuffer);
      }
      if (this === otherBuffer)
        return true;
      const len = TypedArrayPrototypeGetByteLength(this);
      if (len !== TypedArrayPrototypeGetByteLength(otherBuffer))
        return false;
      return len === 0 || _compare(this, otherBuffer) === 0;
    };
    let INSPECT_MAX_BYTES = 50;
    Buffer.prototype[customInspectSymbol] = function inspect(recurseTimes, ctx) {
      const max = INSPECT_MAX_BYTES;
      const actualMax = MathMin(max, this.length);
      const remaining = this.length - max;
      let str = StringPrototypeTrim(RegExpPrototypeSymbolReplace(/(.{2})/g, hexSlice2(this, 0, actualMax), "$1 "));
      if (remaining > 0)
        str += ` ... ${remaining} more byte${remaining > 1 ? "s" : ""}`;
      if (ctx) {
        let extras = false;
        const filter = ctx.showHidden ? ALL_PROPERTIES : ONLY_ENUMERABLE;
        const obj = { __proto__: null };
        ArrayPrototypeForEach(getOwnNonIndexProperties(this, filter), (key) => {
          extras = true;
          obj[key] = this[key];
        });
        if (extras) {
          if (this.length !== 0)
            str += ", ";
          str += StringPrototypeSlice(utilInspect(obj, {
            ...ctx,
            breakLength: Infinity,
            compact: true
          }), 27, -2);
        }
      }
      let constructorName = "Buffer";
      try {
        const { constructor } = this;
        if (typeof constructor === "function" && ObjectPrototypeHasOwnProperty(constructor, "name")) {
          constructorName = constructor.name;
        }
      } catch {}
      return `<${constructorName} ${str}>`;
    };
    Buffer.prototype.inspect = Buffer.prototype[customInspectSymbol];
    Buffer.prototype.compare = function compare2(target, targetStart, targetEnd, sourceStart, sourceEnd) {
      if (!isUint8Array(target)) {
        throw new ERR_INVALID_ARG_TYPE("target", ["Buffer", "Uint8Array"], target);
      }
      if (arguments.length === 1)
        return _compare(this, target);
      if (targetStart === undefined)
        targetStart = 0;
      else
        validateOffset(targetStart, "targetStart");
      if (targetEnd === undefined)
        targetEnd = target.length;
      else
        validateOffset(targetEnd, "targetEnd", 0, target.length);
      if (sourceStart === undefined)
        sourceStart = 0;
      else
        validateOffset(sourceStart, "sourceStart");
      if (sourceEnd === undefined)
        sourceEnd = this.length;
      else
        validateOffset(sourceEnd, "sourceEnd", 0, this.length);
      if (sourceStart >= sourceEnd)
        return targetStart >= targetEnd ? 0 : -1;
      if (targetStart >= targetEnd)
        return 1;
      return compareOffset2(this, target, targetStart, sourceStart, targetEnd, sourceEnd);
    };
    function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
      validateBuffer(buffer);
      if (typeof byteOffset === "string") {
        encoding = byteOffset;
        byteOffset = undefined;
      } else if (byteOffset > 2147483647) {
        byteOffset = 2147483647;
      } else if (byteOffset < -2147483648) {
        byteOffset = -2147483648;
      }
      byteOffset = +byteOffset;
      if (NumberIsNaN(byteOffset)) {
        byteOffset = dir ? 0 : buffer.length || buffer.byteLength;
      }
      dir = !!dir;
      if (typeof val === "number")
        return indexOfNumber2(buffer, val >>> 0, byteOffset, dir);
      let ops;
      if (encoding === undefined)
        ops = encodingOps.utf8;
      else
        ops = getEncodingOps(encoding);
      if (typeof val === "string") {
        if (ops === undefined)
          throw new ERR_UNKNOWN_ENCODING(encoding);
        return ops.indexOf(buffer, val, byteOffset, dir);
      }
      if (isUint8Array(val)) {
        const encodingVal = ops === undefined ? encodingsMap.utf8 : ops.encodingVal;
        return indexOfBuffer2(buffer, val, byteOffset, encodingVal, dir);
      }
      throw new ERR_INVALID_ARG_TYPE("value", ["number", "string", "Buffer", "Uint8Array"], val);
    }
    Buffer.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
      return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
    };
    Buffer.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
      return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
    };
    Buffer.prototype.includes = function includes(val, byteOffset, encoding) {
      return bidirectionalIndexOf(this, val, byteOffset, encoding, true) !== -1;
    };
    Buffer.prototype.fill = function fill(value, offset, end, encoding) {
      return _fill(this, value, offset, end, encoding);
    };
    function _fill(buf, value, offset, end, encoding) {
      if (typeof value === "string") {
        if (offset === undefined || typeof offset === "string") {
          encoding = offset;
          offset = 0;
          end = buf.length;
        } else if (typeof end === "string") {
          encoding = end;
          end = buf.length;
        }
        const normalizedEncoding = normalizeEncoding(encoding);
        if (normalizedEncoding === undefined) {
          validateString(encoding, "encoding");
          throw new ERR_UNKNOWN_ENCODING(encoding);
        }
        if (value.length === 0) {
          value = 0;
        } else if (value.length === 1) {
          if (normalizedEncoding === "utf8" || normalizedEncoding === "ascii") {
            const code = StringPrototypeCharCodeAt(value, 0);
            if (code < 128) {
              value = code;
            }
          } else if (normalizedEncoding === "latin1") {
            value = StringPrototypeCharCodeAt(value, 0);
          }
        }
      } else {
        encoding = undefined;
      }
      if (offset === undefined) {
        offset = 0;
        end = buf.length;
      } else {
        validateOffset(offset, "offset");
        if (end === undefined) {
          end = buf.length;
        } else {
          validateOffset(end, "end", 0, buf.length);
        }
        if (offset >= end)
          return buf;
      }
      if (typeof value === "number") {
        const byteLen = TypedArrayPrototypeGetByteLength(buf);
        const fillLength = end - offset;
        if (offset > end || fillLength + offset > byteLen)
          throw new ERR_BUFFER_OUT_OF_BOUNDS;
        TypedArrayPrototypeFill(buf, value, offset, end);
      } else {
        const res = bindingFill2(buf, value, offset, end, encoding);
        if (res < 0) {
          if (res === -1)
            throw new ERR_INVALID_ARG_VALUE("value", value);
          throw new ERR_BUFFER_OUT_OF_BOUNDS;
        }
      }
      return buf;
    }
    Buffer.prototype.write = function write(string, offset, length, encoding) {
      const bufferLength = TypedArrayPrototypeGetLength(this);
      if (offset === undefined) {
        return utf8Write(this, string, 0, bufferLength);
      }
      if (length === undefined && typeof offset === "string") {
        encoding = offset;
        length = bufferLength;
        offset = 0;
      } else {
        validateOffset(offset, "offset", 0, bufferLength);
        const remaining = bufferLength - offset;
        if (length === undefined) {
          length = remaining;
        } else if (typeof length === "string") {
          encoding = length;
          length = remaining;
        } else {
          validateOffset(length, "length", 0, bufferLength);
          if (length > remaining)
            length = remaining;
        }
      }
      if (!encoding || encoding === "utf8")
        return utf8Write(this, string, offset, length);
      if (encoding === "ascii")
        return asciiWrite(this, string, offset, length);
      const ops = getEncodingOps(encoding);
      if (ops === undefined)
        throw new ERR_UNKNOWN_ENCODING(encoding);
      return ops.write(this, string, offset, length);
    };
    Buffer.prototype.toJSON = function toJSON() {
      const bufferLength = TypedArrayPrototypeGetLength(this);
      if (bufferLength > 0) {
        const data = new Array2(bufferLength);
        for (let i = 0;i < bufferLength; ++i)
          data[i] = this[i];
        return { type: "Buffer", data };
      }
      return { type: "Buffer", data: [] };
    };
    function adjustOffset(offset, length) {
      offset = MathTrunc(offset);
      if (offset === 0) {
        return 0;
      }
      if (offset < 0) {
        offset += length;
        return offset > 0 ? offset : 0;
      }
      if (offset < length) {
        return offset;
      }
      return NumberIsNaN(offset) ? 0 : length;
    }
    Buffer.prototype.subarray = function subarray(start, end) {
      const srcLength = TypedArrayPrototypeGetLength(this);
      start = adjustOffset(start, srcLength);
      end = end !== undefined ? adjustOffset(end, srcLength) : srcLength;
      const newLength = end > start ? end - start : 0;
      return new FastBuffer(this.buffer, this.byteOffset + start, newLength);
    };
    Buffer.prototype.slice = function slice(start, end) {
      return this.subarray(start, end);
    };
    function swap(b, n, m) {
      const i = b[n];
      b[n] = b[m];
      b[m] = i;
    }
    Buffer.prototype.swap16 = function swap162() {
      const len = TypedArrayPrototypeGetLength(this);
      if (len % 2 !== 0)
        throw new ERR_INVALID_BUFFER_SIZE("16-bits");
      if (len <= 32) {
        for (let i = 0;i < len; i += 2)
          swap(this, i, i + 1);
        return this;
      }
      _swap16(this);
      return this;
    };
    Buffer.prototype.swap32 = function swap322() {
      const len = TypedArrayPrototypeGetLength(this);
      if (len % 4 !== 0)
        throw new ERR_INVALID_BUFFER_SIZE("32-bits");
      if (len <= 32) {
        for (let i = 0;i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      }
      _swap32(this);
      return this;
    };
    Buffer.prototype.swap64 = function swap642() {
      const len = TypedArrayPrototypeGetLength(this);
      if (len % 8 !== 0)
        throw new ERR_INVALID_BUFFER_SIZE("64-bits");
      if (len < 48) {
        for (let i = 0;i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      }
      _swap64(this);
      return this;
    };
    Buffer.prototype.toLocaleString = Buffer.prototype.toString;
    let transcode;
    if (internalBinding("config").hasIntl) {
      const {
        icuErrName,
        transcode: _transcode
      } = internalBinding("icu");
      transcode = function transcode2(source, fromEncoding, toEncoding) {
        if (!isUint8Array(source)) {
          throw new ERR_INVALID_ARG_TYPE("source", ["Buffer", "Uint8Array"], source);
        }
        if (source.length === 0)
          return new FastBuffer;
        fromEncoding = normalizeEncoding(fromEncoding) || fromEncoding;
        toEncoding = normalizeEncoding(toEncoding) || toEncoding;
        const result = _transcode(source, fromEncoding, toEncoding);
        if (typeof result !== "number")
          return result;
        const code = icuErrName(result);
        const err = genericNodeError(`Unable to transcode Buffer [${code}]`, { code, errno: result });
        throw err;
      };
    }
    function btoa2(input) {
      if (arguments.length === 0) {
        throw new ERR_MISSING_ARGS("input");
      }
      const result = _btoa(`${input}`);
      if (result === -1) {
        throw lazyDOMException("Invalid character", "InvalidCharacterError");
      }
      return result;
    }
    function atob2(input) {
      if (arguments.length === 0) {
        throw new ERR_MISSING_ARGS("input");
      }
      const result = _atob(`${input}`);
      switch (result) {
        case -2:
          throw lazyDOMException("Invalid character", "InvalidCharacterError");
        case -1:
          throw lazyDOMException("The string to be decoded is not correctly encoded.", "InvalidCharacterError");
        case -3:
          throw lazyDOMException("The input causes overflow.", "InvalidCharacterError");
        default:
          return result;
      }
    }
    function isUtf8(input) {
      if (isTypedArray(input) || isAnyArrayBuffer(input)) {
        return bindingIsUtf8(input);
      }
      throw new ERR_INVALID_ARG_TYPE("input", ["ArrayBuffer", "Buffer", "TypedArray"], input);
    }
    function isAscii(input) {
      if (isTypedArray(input) || isAnyArrayBuffer(input)) {
        return bindingIsAscii(input);
      }
      throw new ERR_INVALID_ARG_TYPE("input", ["ArrayBuffer", "Buffer", "TypedArray"], input);
    }
    module.exports = {
      Buffer,
      SlowBuffer: deprecate(SlowBuffer, "SlowBuffer() is deprecated. Please use Buffer.allocUnsafeSlow()", "DEP0030"),
      transcode,
      isUtf8,
      isAscii,
      kMaxLength,
      kStringMaxLength,
      btoa: btoa2,
      atob: atob2
    };
    ObjectDefineProperties(module.exports, {
      constants: {
        __proto__: null,
        configurable: false,
        enumerable: true,
        value: constants
      },
      INSPECT_MAX_BYTES: {
        __proto__: null,
        configurable: true,
        enumerable: true,
        get() {
          return INSPECT_MAX_BYTES;
        },
        set(val) {
          validateNumber(val, "INSPECT_MAX_BYTES", 0);
          INSPECT_MAX_BYTES = val;
        }
      }
    });
    defineLazyProperties(module.exports, "internal/blob", ["Blob", "resolveObjectURL"]);
    defineLazyProperties(module.exports, "internal/file", ["File"]);
  }

  // third_party/node/lib/diagnostics_channel.js
  function diagnostics_channel_default(exports, require2, module, process, internalBinding, primordials2) {
    class Channel {
      constructor(name) {
        this.name = name;
      }
      get hasSubscribers() {
        return false;
      }
      publish() {}
      subscribe() {}
      unsubscribe() {
        return false;
      }
      bindStore() {}
      unbindStore() {}
      runStores(ctx, fn, thisArg, ...args) {
        return fn.apply(thisArg, args);
      }
    }
    const channels = new Map;
    const channel = (name) => {
      let c = channels.get(name);
      if (!c) {
        c = new Channel(name);
        channels.set(name, c);
      }
      return c;
    };
    const tracingChannel = (nameOrChannels) => {
      const run = (ctx, fn, thisArg, ...args) => fn.apply(thisArg, args);
      return {
        subscribe() {},
        unsubscribe() {
          return false;
        },
        hasSubscribers: false,
        start: channel("start"),
        end: channel("end"),
        asyncStart: channel("asyncStart"),
        asyncEnd: channel("asyncEnd"),
        error: channel("error"),
        traceSync(fn, ctx, thisArg, ...args) {
          return fn.apply(thisArg, args);
        },
        traceCallback(fn, position, ctx, thisArg, ...args) {
          return fn.apply(thisArg, args);
        },
        tracePromise(fn, ctx, thisArg, ...args) {
          return fn.apply(thisArg, args);
        }
      };
    };
    module.exports = {
      Channel,
      channel,
      hasSubscribers: () => false,
      subscribe: () => {},
      unsubscribe: () => false,
      tracingChannel
    };
  }

  // third_party/node/lib/events.js
  function events_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypeJoin,
      ArrayPrototypePop,
      ArrayPrototypePush,
      ArrayPrototypeSlice,
      ArrayPrototypeSplice,
      ArrayPrototypeUnshift,
      AsyncIteratorPrototype: AsyncIteratorPrototype2,
      Boolean: Boolean2,
      Error: Error2,
      ErrorCaptureStackTrace,
      FunctionPrototypeBind,
      NumberMAX_SAFE_INTEGER,
      ObjectDefineProperties,
      ObjectDefineProperty,
      ObjectGetPrototypeOf,
      ObjectSetPrototypeOf,
      Promise: Promise2,
      PromiseReject,
      PromiseResolve,
      ReflectApply,
      ReflectOwnKeys,
      String: String2,
      StringPrototypeSplit,
      Symbol: Symbol2,
      SymbolAsyncIterator,
      SymbolDispose,
      SymbolFor
    } = primordials2;
    const kRejection = SymbolFor("nodejs.rejection");
    const { kEmptyObject, spliceOne } = require2("internal/util");
    const {
      inspect,
      identicalSequenceRange
    } = require2("internal/util/inspect");
    let FixedQueue;
    let kFirstEventParam;
    let kResistStopPropagation;
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_UNHANDLED_ERROR
      },
      genericNodeError,
      kEnhanceStackBeforeInspector
    } = require2("internal/errors");
    const {
      validateInteger,
      validateAbortSignal,
      validateBoolean,
      validateFunction,
      validateNumber,
      validateObject,
      validateString
    } = require2("internal/validators");
    const { addAbortListener } = require2("internal/events/abort_listener");
    const kCapture = Symbol2("kCapture");
    const kErrorMonitor = Symbol2("events.errorMonitor");
    const kShapeMode = Symbol2("shapeMode");
    const kEmitting = Symbol2("events.emitting");
    const kMaxEventTargetListeners = Symbol2("events.maxEventTargetListeners");
    const kMaxEventTargetListenersWarned = Symbol2("events.maxEventTargetListenersWarned");
    const kWatermarkData = SymbolFor("nodejs.watermarkData");
    let EventEmitterAsyncResource;
    function lazyEventEmitterAsyncResource() {
      if (EventEmitterAsyncResource === undefined) {
        const {
          AsyncResource
        } = require2("async_hooks");

        class EventEmitterReferencingAsyncResource extends AsyncResource {
          #eventEmitter;
          constructor(ee, type, options) {
            super(type, options);
            this.#eventEmitter = ee;
          }
          get eventEmitter() {
            return this.#eventEmitter;
          }
        }
        EventEmitterAsyncResource = class EventEmitterAsyncResource2 extends EventEmitter {
          #asyncResource;
          constructor(options = undefined) {
            let name;
            if (typeof options === "string") {
              name = options;
              options = undefined;
            } else {
              if (new.target === EventEmitterAsyncResource2) {
                validateString(options?.name, "options.name");
              }
              name = options?.name || new.target.name;
            }
            super(options);
            this.#asyncResource = new EventEmitterReferencingAsyncResource(this, name, options);
          }
          emit(event, ...args) {
            const asyncResource = this.#asyncResource;
            ArrayPrototypeUnshift(args, super.emit, this, event);
            return ReflectApply(asyncResource.runInAsyncScope, asyncResource, args);
          }
          emitDestroy() {
            this.#asyncResource.emitDestroy();
          }
          get asyncId() {
            return this.#asyncResource.asyncId();
          }
          get triggerAsyncId() {
            return this.#asyncResource.triggerAsyncId();
          }
          get asyncResource() {
            return this.#asyncResource;
          }
        };
      }
      return EventEmitterAsyncResource;
    }
    function EventEmitter(opts) {
      EventEmitter.init.call(this, opts);
    }
    module.exports = EventEmitter;
    module.exports.addAbortListener = addAbortListener;
    module.exports.once = once;
    module.exports.on = on;
    module.exports.getEventListeners = getEventListeners;
    module.exports.getMaxListeners = getMaxListeners;
    module.exports.listenerCount = listenerCount;
    EventEmitter.EventEmitter = EventEmitter;
    EventEmitter.usingDomains = false;
    EventEmitter.captureRejectionSymbol = kRejection;
    ObjectDefineProperty(EventEmitter, "captureRejections", {
      __proto__: null,
      get() {
        return EventEmitter.prototype[kCapture];
      },
      set(value) {
        validateBoolean(value, "EventEmitter.captureRejections");
        EventEmitter.prototype[kCapture] = value;
      },
      enumerable: true
    });
    ObjectDefineProperty(EventEmitter, "EventEmitterAsyncResource", {
      __proto__: null,
      enumerable: true,
      get: lazyEventEmitterAsyncResource,
      set: undefined,
      configurable: true
    });
    EventEmitter.errorMonitor = kErrorMonitor;
    ObjectDefineProperty(EventEmitter.prototype, kCapture, {
      __proto__: null,
      value: false,
      writable: true,
      enumerable: false
    });
    EventEmitter.prototype._events = undefined;
    EventEmitter.prototype._eventsCount = 0;
    EventEmitter.prototype._maxListeners = undefined;
    let defaultMaxListeners = 10;
    let isEventTarget;
    function checkListener(listener) {
      validateFunction(listener, "listener");
    }
    ObjectDefineProperty(EventEmitter, "defaultMaxListeners", {
      __proto__: null,
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        validateNumber(arg, "defaultMaxListeners", 0);
        defaultMaxListeners = arg;
      }
    });
    ObjectDefineProperties(EventEmitter, {
      kMaxEventTargetListeners: {
        __proto__: null,
        value: kMaxEventTargetListeners,
        enumerable: false,
        configurable: false,
        writable: false
      },
      kMaxEventTargetListenersWarned: {
        __proto__: null,
        value: kMaxEventTargetListenersWarned,
        enumerable: false,
        configurable: false,
        writable: false
      }
    });
    EventEmitter.setMaxListeners = function(n = defaultMaxListeners, ...eventTargets) {
      validateNumber(n, "setMaxListeners", 0);
      if (eventTargets.length === 0) {
        defaultMaxListeners = n;
      } else {
        if (isEventTarget === undefined)
          isEventTarget = require2("internal/event_target").isEventTarget;
        for (let i = 0;i < eventTargets.length; i++) {
          const target = eventTargets[i];
          if (isEventTarget(target)) {
            target[kMaxEventTargetListeners] = n;
            target[kMaxEventTargetListenersWarned] = false;
          } else if (typeof target.setMaxListeners === "function") {
            target.setMaxListeners(n);
          } else {
            throw new ERR_INVALID_ARG_TYPE("eventTargets", ["EventEmitter", "EventTarget"], target);
          }
        }
      }
    };
    EventEmitter.init = function(opts) {
      if (this._events === undefined || this._events === ObjectGetPrototypeOf(this)._events) {
        this._events = { __proto__: null };
        this._eventsCount = 0;
        this[kShapeMode] = false;
      } else {
        this[kShapeMode] = true;
      }
      this._maxListeners ||= undefined;
      if (opts?.captureRejections) {
        validateBoolean(opts.captureRejections, "options.captureRejections");
        this[kCapture] = Boolean2(opts.captureRejections);
      } else {
        this[kCapture] = EventEmitter.prototype[kCapture];
      }
    };
    function addCatch(that, promise, type, args) {
      if (!that[kCapture]) {
        return;
      }
      try {
        const then = promise.then;
        if (typeof then === "function") {
          then.call(promise, undefined, function(err) {
            process.nextTick(emitUnhandledRejectionOrErr, that, err, type, args);
          });
        }
      } catch (err) {
        that.emit("error", err);
      }
    }
    function emitUnhandledRejectionOrErr(ee, err, type, args) {
      if (typeof ee[kRejection] === "function") {
        ee[kRejection](err, type, ...args);
      } else {
        const prev = ee[kCapture];
        try {
          ee[kCapture] = false;
          ee.emit("error", err);
        } finally {
          ee[kCapture] = prev;
        }
      }
    }
    EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
      validateNumber(n, "setMaxListeners", 0);
      this._maxListeners = n;
      return this;
    };
    function _getMaxListeners(that) {
      if (that._maxListeners === undefined)
        return EventEmitter.defaultMaxListeners;
      return that._maxListeners;
    }
    EventEmitter.prototype.getMaxListeners = function getMaxListeners2() {
      return _getMaxListeners(this);
    };
    function enhanceStackTrace(err, own) {
      let ctorInfo = "";
      try {
        const { name } = this.constructor;
        if (name !== "EventEmitter")
          ctorInfo = ` on ${name} instance`;
      } catch {}
      const sep = `
Emitted 'error' event${ctorInfo} at:
`;
      const errStack = ArrayPrototypeSlice(StringPrototypeSplit(err.stack, `
`), 1);
      const ownStack = ArrayPrototypeSlice(StringPrototypeSplit(own.stack, `
`), 1);
      const { len, offset } = identicalSequenceRange(ownStack, errStack);
      if (len > 0) {
        ArrayPrototypeSplice(ownStack, offset + 1, len - 2, "    [... lines matching original stack trace ...]");
      }
      return err.stack + sep + ArrayPrototypeJoin(ownStack, `
`);
    }
    EventEmitter.prototype.emit = function emit(type, ...args) {
      let doError = type === "error";
      const events = this._events;
      if (events !== undefined) {
        if (doError && events[kErrorMonitor] !== undefined)
          this.emit(kErrorMonitor, ...args);
        doError &&= events.error === undefined;
      } else if (!doError)
        return false;
      if (doError) {
        let er;
        if (args.length > 0)
          er = args[0];
        if (er instanceof Error2) {
          try {
            const capture = {};
            ErrorCaptureStackTrace(capture, EventEmitter.prototype.emit);
            ObjectDefineProperty(er, kEnhanceStackBeforeInspector, {
              __proto__: null,
              value: FunctionPrototypeBind(enhanceStackTrace, this, er, capture),
              configurable: true
            });
          } catch {}
          throw er;
        }
        let stringifiedEr;
        try {
          stringifiedEr = inspect(er);
        } catch {
          stringifiedEr = er;
        }
        const err = new ERR_UNHANDLED_ERROR(stringifiedEr);
        err.context = er;
        throw err;
      }
      const handler = events[type];
      if (handler === undefined)
        return false;
      if (typeof handler === "function") {
        const result = handler.apply(this, args);
        if (result !== undefined && result !== null) {
          addCatch(this, result, type, args);
        }
      } else {
        handler[kEmitting]++;
        try {
          for (let i = 0;i < handler.length; ++i) {
            const result = ReflectApply(handler[i], this, args);
            if (result !== undefined && result !== null) {
              addCatch(this, result, type, args);
            }
          }
        } finally {
          handler[kEmitting]--;
        }
      }
      return true;
    };
    function _addListener(target, type, listener, prepend) {
      let m;
      let events;
      let existing;
      checkListener(listener);
      events = target._events;
      if (events === undefined) {
        events = target._events = { __proto__: null };
        target._eventsCount = 0;
      } else {
        if (events.newListener !== undefined) {
          target.emit("newListener", type, listener.listener ?? listener);
          events = target._events;
        }
        existing = events[type];
      }
      if (existing === undefined) {
        events[type] = listener;
        ++target._eventsCount;
      } else {
        if (typeof existing === "function") {
          existing = prepend ? [listener, existing] : [existing, listener];
          existing[kEmitting] = 0;
          events[type] = existing;
        } else {
          existing = ensureMutableListenerArray(events, type, existing);
          if (prepend) {
            existing.unshift(listener);
          } else {
            existing.push(listener);
          }
        }
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
          existing.warned = true;
          const w = genericNodeError(`Possible EventEmitter memory leak detected. ${existing.length} ${String2(type)} listeners ` + `added to ${inspect(target, { depth: -1 })}. MaxListeners is ${m}. Use emitter.setMaxListeners() to increase limit`, { name: "MaxListenersExceededWarning", emitter: target, type, count: existing.length });
          process.emitWarning(w);
        }
      }
      return target;
    }
    EventEmitter.prototype.addListener = function addListener(type, listener) {
      return _addListener(this, type, listener, false);
    };
    EventEmitter.prototype.on = EventEmitter.prototype.addListener;
    EventEmitter.prototype.prependListener = function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };
    function onceWrapper() {
      if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0)
          return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
      }
    }
    function _onceWrap(target, type, listener) {
      const state = { fired: false, wrapFn: undefined, target, type, listener };
      const wrapped = onceWrapper.bind(state);
      wrapped.listener = listener;
      state.wrapFn = wrapped;
      return wrapped;
    }
    EventEmitter.prototype.once = function once2(type, listener) {
      checkListener(listener);
      this.on(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.removeListener = function removeListener(type, listener) {
      checkListener(listener);
      const events = this._events;
      if (events === undefined)
        return this;
      let list = events[type];
      if (list === undefined)
        return this;
      if (list === listener || list.listener === listener) {
        this._eventsCount -= 1;
        if (this[kShapeMode]) {
          events[type] = undefined;
        } else if (this._eventsCount === 0) {
          this._events = { __proto__: null };
        } else {
          delete events[type];
        }
        if (events.removeListener !== undefined)
          this.emit("removeListener", type, list.listener || listener);
      } else if (typeof list !== "function") {
        list = ensureMutableListenerArray(events, type, list);
        let position = -1;
        for (let i = list.length - 1;i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            position = i;
            break;
          }
        }
        if (position < 0)
          return this;
        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }
        if (list.length === 1)
          events[type] = list[0];
        if (events.removeListener !== undefined)
          this.emit("removeListener", type, listener);
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
      const events = this._events;
      if (events === undefined)
        return this;
      if (events.removeListener === undefined) {
        if (arguments.length === 0) {
          this._events = { __proto__: null };
          this._eventsCount = 0;
        } else if (events[type] !== undefined) {
          if (--this._eventsCount === 0)
            this._events = { __proto__: null };
          else
            delete events[type];
        }
        this[kShapeMode] = false;
        return this;
      }
      if (arguments.length === 0) {
        for (const key of ReflectOwnKeys(events)) {
          if (key === "removeListener")
            continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = { __proto__: null };
        this._eventsCount = 0;
        this[kShapeMode] = false;
        return this;
      }
      const listeners = events[type];
      if (typeof listeners === "function") {
        this.removeListener(type, listeners);
      } else if (listeners !== undefined) {
        for (let i = listeners.length - 1;i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }
      return this;
    };
    function _listeners(target, type, unwrap) {
      const events = target._events;
      if (events === undefined)
        return [];
      const evlistener = events[type];
      if (evlistener === undefined)
        return [];
      if (typeof evlistener === "function")
        return unwrap ? [evlistener.listener || evlistener] : [evlistener];
      return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener);
    }
    EventEmitter.prototype.listeners = function listeners(type) {
      return _listeners(this, type, true);
    };
    EventEmitter.prototype.rawListeners = function rawListeners(type) {
      return _listeners(this, type, false);
    };
    EventEmitter.prototype.listenerCount = function listenerCount2(type, listener) {
      const events = this._events;
      if (events !== undefined) {
        const evlistener = events[type];
        if (typeof evlistener === "function") {
          if (listener != null) {
            return listener === evlistener || listener === evlistener.listener ? 1 : 0;
          }
          return 1;
        } else if (evlistener !== undefined) {
          if (listener != null) {
            let matching = 0;
            for (let i = 0, l = evlistener.length;i < l; i++) {
              if (evlistener[i] === listener || evlistener[i].listener === listener) {
                matching++;
              }
            }
            return matching;
          }
          return evlistener.length;
        }
      }
      return 0;
    };
    EventEmitter.prototype.eventNames = function eventNames() {
      return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
    };
    function arrayClone(arr) {
      switch (arr.length) {
        case 2:
          return [arr[0], arr[1]];
        case 3:
          return [arr[0], arr[1], arr[2]];
        case 4:
          return [arr[0], arr[1], arr[2], arr[3]];
        case 5:
          return [arr[0], arr[1], arr[2], arr[3], arr[4]];
        case 6:
          return [arr[0], arr[1], arr[2], arr[3], arr[4], arr[5]];
      }
      return ArrayPrototypeSlice(arr);
    }
    function cloneEventListenerArray(arr) {
      const copy2 = arrayClone(arr);
      copy2[kEmitting] = 0;
      if (arr.warned) {
        copy2.warned = true;
      }
      return copy2;
    }
    function ensureMutableListenerArray(events, type, handler) {
      if (handler[kEmitting] > 0) {
        const copy2 = cloneEventListenerArray(handler);
        events[type] = copy2;
        return copy2;
      }
      return handler;
    }
    function unwrapListeners(arr) {
      const ret = arrayClone(arr);
      for (let i = 0;i < ret.length; ++i) {
        const orig = ret[i].listener;
        if (typeof orig === "function")
          ret[i] = orig;
      }
      return ret;
    }
    function getEventListeners(emitterOrTarget, type) {
      if (typeof emitterOrTarget.listeners === "function") {
        return emitterOrTarget.listeners(type);
      }
      const { isEventTarget: isEventTarget2, kEvents } = require2("internal/event_target");
      if (isEventTarget2(emitterOrTarget)) {
        const root = emitterOrTarget[kEvents].get(type);
        const listeners = [];
        let handler = root?.next;
        while (handler?.listener !== undefined) {
          const listener = handler.listener?.deref ? handler.listener.deref() : handler.listener;
          listeners.push(listener);
          handler = handler.next;
        }
        return listeners;
      }
      throw new ERR_INVALID_ARG_TYPE("emitter", ["EventEmitter", "EventTarget"], emitterOrTarget);
    }
    function getMaxListeners(emitterOrTarget) {
      if (typeof emitterOrTarget?.getMaxListeners === "function") {
        return _getMaxListeners(emitterOrTarget);
      } else if (typeof emitterOrTarget?.[kMaxEventTargetListeners] === "number") {
        return emitterOrTarget[kMaxEventTargetListeners];
      }
      throw new ERR_INVALID_ARG_TYPE("emitter", ["EventEmitter", "EventTarget"], emitterOrTarget);
    }
    function listenerCount(emitterOrTarget, type) {
      if (typeof emitterOrTarget.listenerCount === "function") {
        return emitterOrTarget.listenerCount(type);
      }
      const { isEventTarget: isEventTarget2, kEvents } = require2("internal/event_target");
      if (isEventTarget2(emitterOrTarget)) {
        return emitterOrTarget[kEvents].get(type)?.size ?? 0;
      }
      throw new ERR_INVALID_ARG_TYPE("emitter", ["EventEmitter", "EventTarget"], emitterOrTarget);
    }
    async function once(emitter, name, options = kEmptyObject) {
      validateObject(options, "options");
      const { signal } = options;
      validateAbortSignal(signal, "options.signal");
      if (signal?.aborted)
        throw new AbortError(undefined, { cause: signal.reason });
      return new Promise2((resolve2, reject) => {
        const errorListener = (err) => {
          emitter.removeListener(name, resolver);
          if (signal != null) {
            eventTargetAgnosticRemoveListener(signal, "abort", abortListener);
          }
          reject(err);
        };
        const resolver = (...args) => {
          if (typeof emitter.removeListener === "function") {
            emitter.removeListener("error", errorListener);
          }
          if (signal != null) {
            eventTargetAgnosticRemoveListener(signal, "abort", abortListener);
          }
          resolve2(args);
        };
        kResistStopPropagation ??= require2("internal/event_target").kResistStopPropagation;
        const opts = { __proto__: null, once: true, [kResistStopPropagation]: true };
        eventTargetAgnosticAddListener(emitter, name, resolver, opts);
        if (name !== "error" && typeof emitter.once === "function") {
          emitter.once("error", errorListener);
        }
        function abortListener() {
          eventTargetAgnosticRemoveListener(emitter, name, resolver);
          eventTargetAgnosticRemoveListener(emitter, "error", errorListener);
          reject(new AbortError(undefined, { cause: signal?.reason }));
        }
        if (signal != null) {
          eventTargetAgnosticAddListener(signal, "abort", abortListener, { __proto__: null, once: true, [kResistStopPropagation]: true });
        }
      });
    }
    function createIterResult(value, done) {
      return { value, done };
    }
    function eventTargetAgnosticRemoveListener(emitter, name, listener, flags) {
      if (typeof emitter.removeListener === "function") {
        emitter.removeListener(name, listener);
      } else if (typeof emitter.removeEventListener === "function") {
        emitter.removeEventListener(name, listener, flags);
      } else {
        throw new ERR_INVALID_ARG_TYPE("emitter", "EventEmitter", emitter);
      }
    }
    function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
      if (typeof emitter.on === "function") {
        if (flags?.once) {
          emitter.once(name, listener);
        } else {
          emitter.on(name, listener);
        }
      } else if (typeof emitter.addEventListener === "function") {
        emitter.addEventListener(name, listener, flags);
      } else {
        throw new ERR_INVALID_ARG_TYPE("emitter", "EventEmitter", emitter);
      }
    }
    function on(emitter, event, options = kEmptyObject) {
      validateObject(options, "options");
      const signal = options.signal;
      validateAbortSignal(signal, "options.signal");
      if (signal?.aborted)
        throw new AbortError(undefined, { cause: signal.reason });
      const highWatermark = options.highWaterMark ?? options.highWatermark ?? NumberMAX_SAFE_INTEGER;
      validateInteger(highWatermark, "options.highWaterMark", 1);
      const lowWatermark = options.lowWaterMark ?? options.lowWatermark ?? 1;
      validateInteger(lowWatermark, "options.lowWaterMark", 1);
      FixedQueue ??= require2("internal/fixed_queue");
      const unconsumedEvents = new FixedQueue;
      const unconsumedPromises = new FixedQueue;
      let paused = false;
      let error = null;
      let finished = false;
      let size = 0;
      const iterator = ObjectSetPrototypeOf({
        next() {
          if (size) {
            const value = unconsumedEvents.shift();
            size--;
            if (paused && size < lowWatermark) {
              emitter.resume();
              paused = false;
            }
            return PromiseResolve(createIterResult(value, false));
          }
          if (error) {
            const p = PromiseReject(error);
            error = null;
            return p;
          }
          if (finished)
            return closeHandler();
          return new Promise2(function(resolve2, reject) {
            unconsumedPromises.push({ resolve: resolve2, reject });
          });
        },
        return() {
          return closeHandler();
        },
        throw(err) {
          if (!err || !(err instanceof Error2)) {
            throw new ERR_INVALID_ARG_TYPE("EventEmitter.AsyncIterator", "Error", err);
          }
          errorHandler(err);
        },
        [SymbolAsyncIterator]() {
          return this;
        },
        [kWatermarkData]: {
          get size() {
            return size;
          },
          get low() {
            return lowWatermark;
          },
          get high() {
            return highWatermark;
          },
          get isPaused() {
            return paused;
          }
        }
      }, AsyncIteratorPrototype2);
      const { addEventListener, removeAll } = listenersController();
      kFirstEventParam ??= require2("internal/events/symbols").kFirstEventParam;
      addEventListener(emitter, event, options[kFirstEventParam] ? eventHandler : function(...args) {
        return eventHandler(args);
      });
      if (event !== "error" && typeof emitter.on === "function") {
        addEventListener(emitter, "error", errorHandler);
      }
      const closeEvents = options?.close;
      if (closeEvents?.length) {
        for (let i = 0;i < closeEvents.length; i++) {
          addEventListener(emitter, closeEvents[i], closeHandler);
        }
      }
      const abortListenerDisposable = signal ? addAbortListener(signal, abortListener) : null;
      return iterator;
      function abortListener() {
        errorHandler(new AbortError(undefined, { cause: signal?.reason }));
      }
      function eventHandler(value) {
        if (unconsumedPromises.isEmpty()) {
          size++;
          if (!paused && size > highWatermark) {
            paused = true;
            emitter.pause();
          }
          unconsumedEvents.push(value);
        } else
          unconsumedPromises.shift().resolve(createIterResult(value, false));
      }
      function errorHandler(err) {
        if (unconsumedPromises.isEmpty())
          error = err;
        else
          unconsumedPromises.shift().reject(err);
        closeHandler();
      }
      function closeHandler() {
        abortListenerDisposable?.[SymbolDispose]();
        removeAll();
        finished = true;
        paused = false;
        const doneResult = createIterResult(undefined, true);
        while (!unconsumedPromises.isEmpty()) {
          unconsumedPromises.shift().resolve(doneResult);
        }
        return PromiseResolve(doneResult);
      }
    }
    function listenersController() {
      const listeners = [];
      return {
        addEventListener(emitter, event, handler, flags) {
          eventTargetAgnosticAddListener(emitter, event, handler, flags);
          ArrayPrototypePush(listeners, [emitter, event, handler, flags]);
        },
        removeAll() {
          while (listeners.length > 0) {
            ReflectApply(eventTargetAgnosticRemoveListener, undefined, ArrayPrototypePop(listeners));
          }
        }
      };
    }
  }

  // third_party/node/lib/path.js
  function path_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypeIncludes,
      ArrayPrototypeJoin,
      ArrayPrototypePush,
      ArrayPrototypeSlice,
      FunctionPrototypeBind,
      StringPrototypeCharCodeAt,
      StringPrototypeIncludes,
      StringPrototypeIndexOf,
      StringPrototypeLastIndexOf,
      StringPrototypeRepeat,
      StringPrototypeReplace,
      StringPrototypeSlice,
      StringPrototypeSplit,
      StringPrototypeToLowerCase,
      StringPrototypeToUpperCase
    } = primordials2;
    const {
      CHAR_UPPERCASE_A,
      CHAR_LOWERCASE_A,
      CHAR_UPPERCASE_Z,
      CHAR_LOWERCASE_Z,
      CHAR_DOT,
      CHAR_FORWARD_SLASH,
      CHAR_BACKWARD_SLASH,
      CHAR_COLON,
      CHAR_QUESTION_MARK
    } = require2("internal/constants");
    const {
      validateObject,
      validateString
    } = require2("internal/validators");
    const {
      isWindows,
      getLazy
    } = require2("internal/util");
    const lazyMatchGlobPattern = getLazy(() => require2("internal/fs/glob").matchGlobPattern);
    function isPathSeparator(code) {
      return code === CHAR_FORWARD_SLASH || code === CHAR_BACKWARD_SLASH;
    }
    function isPosixPathSeparator(code) {
      return code === CHAR_FORWARD_SLASH;
    }
    const WINDOWS_RESERVED_NAMES = [
      "CON",
      "PRN",
      "AUX",
      "NUL",
      "COM1",
      "COM2",
      "COM3",
      "COM4",
      "COM5",
      "COM6",
      "COM7",
      "COM8",
      "COM9",
      "LPT1",
      "LPT2",
      "LPT3",
      "LPT4",
      "LPT5",
      "LPT6",
      "LPT7",
      "LPT8",
      "LPT9",
      "COM¹",
      "COM²",
      "COM³",
      "LPT¹",
      "LPT²",
      "LPT³"
    ];
    function isWindowsReservedName(path, colonIndex) {
      const devicePart = StringPrototypeToUpperCase(StringPrototypeSlice(path, 0, colonIndex));
      return ArrayPrototypeIncludes(WINDOWS_RESERVED_NAMES, devicePart);
    }
    function isWindowsDeviceRoot(code) {
      return code >= CHAR_UPPERCASE_A && code <= CHAR_UPPERCASE_Z || code >= CHAR_LOWERCASE_A && code <= CHAR_LOWERCASE_Z;
    }
    function normalizeString(path, allowAboveRoot, separator, isPathSeparator2) {
      let res = "";
      let lastSegmentLength = 0;
      let lastSlash = -1;
      let dots = 0;
      let code = 0;
      for (let i = 0;i <= path.length; ++i) {
        if (i < path.length)
          code = StringPrototypeCharCodeAt(path, i);
        else if (isPathSeparator2(code))
          break;
        else
          code = CHAR_FORWARD_SLASH;
        if (isPathSeparator2(code)) {
          if (lastSlash === i - 1 || dots === 1) {} else if (dots === 2) {
            if (res.length < 2 || lastSegmentLength !== 2 || StringPrototypeCharCodeAt(res, res.length - 1) !== CHAR_DOT || StringPrototypeCharCodeAt(res, res.length - 2) !== CHAR_DOT) {
              if (res.length > 2) {
                const lastSlashIndex = res.length - lastSegmentLength - 1;
                if (lastSlashIndex === -1) {
                  res = "";
                  lastSegmentLength = 0;
                } else {
                  res = StringPrototypeSlice(res, 0, lastSlashIndex);
                  lastSegmentLength = res.length - 1 - StringPrototypeLastIndexOf(res, separator);
                }
                lastSlash = i;
                dots = 0;
                continue;
              } else if (res.length !== 0) {
                res = "";
                lastSegmentLength = 0;
                lastSlash = i;
                dots = 0;
                continue;
              }
            }
            if (allowAboveRoot) {
              res += res.length > 0 ? `${separator}..` : "..";
              lastSegmentLength = 2;
            }
          } else {
            if (res.length > 0)
              res += `${separator}${StringPrototypeSlice(path, lastSlash + 1, i)}`;
            else
              res = StringPrototypeSlice(path, lastSlash + 1, i);
            lastSegmentLength = i - lastSlash - 1;
          }
          lastSlash = i;
          dots = 0;
        } else if (code === CHAR_DOT && dots !== -1) {
          ++dots;
        } else {
          dots = -1;
        }
      }
      return res;
    }
    function formatExt(ext) {
      return ext ? `${ext[0] === "." ? "" : "."}${ext}` : "";
    }
    function _format(sep, pathObject) {
      validateObject(pathObject, "pathObject");
      const dir = pathObject.dir || pathObject.root;
      const base = pathObject.base || `${pathObject.name || ""}${formatExt(pathObject.ext)}`;
      if (!dir) {
        return base;
      }
      return dir === pathObject.root ? `${dir}${base}` : `${dir}${sep}${base}`;
    }
    const forwardSlashRegExp = /\//g;
    const win32 = {
      resolve(...args) {
        let resolvedDevice = "";
        let resolvedTail = "";
        let resolvedAbsolute = false;
        for (let i = args.length - 1;i >= -1; i--) {
          let path;
          if (i >= 0) {
            path = args[i];
            validateString(path, `paths[${i}]`);
            if (path.length === 0) {
              continue;
            }
          } else if (resolvedDevice.length === 0) {
            path = process.cwd();
            if (args.length === 0 || args.length === 1 && (args[0] === "" || args[0] === ".") && isPathSeparator(StringPrototypeCharCodeAt(path, 0))) {
              if (!isWindows) {
                path = StringPrototypeReplace(path, forwardSlashRegExp, "\\");
              }
              return path;
            }
          } else {
            path = process.env[`=${resolvedDevice}`] || process.cwd();
            if (path === undefined || StringPrototypeToLowerCase(StringPrototypeSlice(path, 0, 2)) !== StringPrototypeToLowerCase(resolvedDevice) && StringPrototypeCharCodeAt(path, 2) === CHAR_BACKWARD_SLASH) {
              path = `${resolvedDevice}\\`;
            }
          }
          const len = path.length;
          let rootEnd = 0;
          let device = "";
          let isAbsolute = false;
          const code = StringPrototypeCharCodeAt(path, 0);
          if (len === 1) {
            if (isPathSeparator(code)) {
              rootEnd = 1;
              isAbsolute = true;
            }
          } else if (isPathSeparator(code)) {
            isAbsolute = true;
            if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
              let j = 2;
              let last = j;
              while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                j++;
              }
              if (j < len && j !== last) {
                const firstPart = StringPrototypeSlice(path, last, j);
                last = j;
                while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                  j++;
                }
                if (j < len && j !== last) {
                  last = j;
                  while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                    j++;
                  }
                  if (j === len || j !== last) {
                    if (firstPart !== "." && firstPart !== "?") {
                      device = `\\\\${firstPart}\\${StringPrototypeSlice(path, last, j)}`;
                      rootEnd = j;
                    } else {
                      device = `\\\\${firstPart}`;
                      rootEnd = 4;
                    }
                  }
                }
              }
            } else {
              rootEnd = 1;
            }
          } else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
            device = StringPrototypeSlice(path, 0, 2);
            rootEnd = 2;
            if (len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
              isAbsolute = true;
              rootEnd = 3;
            }
          }
          if (device.length > 0) {
            if (resolvedDevice.length > 0) {
              if (StringPrototypeToLowerCase(device) !== StringPrototypeToLowerCase(resolvedDevice))
                continue;
            } else {
              resolvedDevice = device;
            }
          }
          if (resolvedAbsolute) {
            if (resolvedDevice.length > 0)
              break;
          } else {
            resolvedTail = `${StringPrototypeSlice(path, rootEnd)}\\${resolvedTail}`;
            resolvedAbsolute = isAbsolute;
            if (isAbsolute && resolvedDevice.length > 0) {
              break;
            }
          }
        }
        resolvedTail = normalizeString(resolvedTail, !resolvedAbsolute, "\\", isPathSeparator);
        return resolvedAbsolute ? `${resolvedDevice}\\${resolvedTail}` : `${resolvedDevice}${resolvedTail}` || ".";
      },
      normalize(path) {
        validateString(path, "path");
        const len = path.length;
        if (len === 0)
          return ".";
        let rootEnd = 0;
        let device;
        let isAbsolute = false;
        const code = StringPrototypeCharCodeAt(path, 0);
        if (len === 1) {
          return isPosixPathSeparator(code) ? "\\" : path;
        }
        if (isPathSeparator(code)) {
          isAbsolute = true;
          if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
            let j = 2;
            let last = j;
            while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
              j++;
            }
            if (j < len && j !== last) {
              const firstPart = StringPrototypeSlice(path, last, j);
              last = j;
              while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                j++;
              }
              if (j < len && j !== last) {
                last = j;
                while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                  j++;
                }
                if (j === len || j !== last) {
                  if (firstPart === "." || firstPart === "?") {
                    device = `\\\\${firstPart}`;
                    rootEnd = 4;
                    const colonIndex2 = StringPrototypeIndexOf(path, ":");
                    const possibleDevice = StringPrototypeSlice(path, 4, colonIndex2 + 1);
                    if (isWindowsReservedName(possibleDevice, possibleDevice.length - 1)) {
                      device = `\\\\?\\${possibleDevice}`;
                      rootEnd = 4 + possibleDevice.length;
                    }
                  } else if (j === len) {
                    return `\\\\${firstPart}\\${StringPrototypeSlice(path, last)}\\`;
                  } else {
                    device = `\\\\${firstPart}\\${StringPrototypeSlice(path, last, j)}`;
                    rootEnd = j;
                  }
                }
              }
            }
          } else {
            rootEnd = 1;
          }
        } else {
          const colonIndex2 = StringPrototypeIndexOf(path, ":");
          if (colonIndex2 > 0) {
            if (isWindowsDeviceRoot(code) && colonIndex2 === 1) {
              device = StringPrototypeSlice(path, 0, 2);
              rootEnd = 2;
              if (len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
                isAbsolute = true;
                rootEnd = 3;
              }
            } else if (isWindowsReservedName(path, colonIndex2)) {
              device = StringPrototypeSlice(path, 0, colonIndex2 + 1);
              rootEnd = colonIndex2 + 1;
            }
          }
        }
        let tail = rootEnd < len ? normalizeString(StringPrototypeSlice(path, rootEnd), !isAbsolute, "\\", isPathSeparator) : "";
        if (tail.length === 0 && !isAbsolute)
          tail = ".";
        if (tail.length > 0 && isPathSeparator(StringPrototypeCharCodeAt(path, len - 1)))
          tail += "\\";
        if (!isAbsolute && device === undefined && StringPrototypeIncludes(path, ":")) {
          if (tail.length >= 2 && isWindowsDeviceRoot(StringPrototypeCharCodeAt(tail, 0)) && StringPrototypeCharCodeAt(tail, 1) === CHAR_COLON) {
            return `.\\${tail}`;
          }
          let index = StringPrototypeIndexOf(path, ":");
          do {
            if (index === len - 1 || isPathSeparator(StringPrototypeCharCodeAt(path, index + 1))) {
              return `.\\${tail}`;
            }
          } while ((index = StringPrototypeIndexOf(path, ":", index + 1)) !== -1);
        }
        const colonIndex = StringPrototypeIndexOf(path, ":");
        if (isWindowsReservedName(path, colonIndex)) {
          return `.\\${device ?? ""}${tail}`;
        }
        if (device === undefined) {
          return isAbsolute ? `\\${tail}` : tail;
        }
        return isAbsolute ? `${device}\\${tail}` : `${device}${tail}`;
      },
      isAbsolute(path) {
        validateString(path, "path");
        const len = path.length;
        if (len === 0)
          return false;
        const code = StringPrototypeCharCodeAt(path, 0);
        return isPathSeparator(code) || len > 2 && isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON && isPathSeparator(StringPrototypeCharCodeAt(path, 2));
      },
      join(...args) {
        if (args.length === 0)
          return ".";
        const path = [];
        for (let i = 0;i < args.length; ++i) {
          const arg = args[i];
          validateString(arg, "path");
          if (arg.length > 0) {
            ArrayPrototypePush(path, arg);
          }
        }
        if (path.length === 0)
          return ".";
        const firstPart = path[0];
        let joined = ArrayPrototypeJoin(path, "\\");
        let needsReplace = true;
        let slashCount = 0;
        if (isPathSeparator(StringPrototypeCharCodeAt(firstPart, 0))) {
          ++slashCount;
          const firstLen = firstPart.length;
          if (firstLen > 1 && isPathSeparator(StringPrototypeCharCodeAt(firstPart, 1))) {
            ++slashCount;
            if (firstLen > 2) {
              if (isPathSeparator(StringPrototypeCharCodeAt(firstPart, 2)))
                ++slashCount;
              else {
                needsReplace = false;
              }
            }
          }
        }
        if (needsReplace) {
          while (slashCount < joined.length && isPathSeparator(StringPrototypeCharCodeAt(joined, slashCount))) {
            slashCount++;
          }
          if (slashCount >= 2)
            joined = `\\${StringPrototypeSlice(joined, slashCount)}`;
        }
        const parts = [];
        let part = "";
        for (let i = 0;i < joined.length; i++) {
          if (joined[i] === "\\") {
            if (part)
              parts.push(part);
            part = "";
            while (i + 1 < joined.length && joined[i + 1] === "\\")
              i++;
          } else {
            part += joined[i];
          }
        }
        if (part)
          parts.push(part);
        if (parts.some((p) => {
          const colonIndex = StringPrototypeIndexOf(p, ":");
          return colonIndex !== -1 && isWindowsReservedName(p, colonIndex);
        })) {
          let result = "";
          for (let i = 0;i < joined.length; i++) {
            result += joined[i] === "/" ? "\\" : joined[i];
          }
          return result;
        }
        return win32.normalize(joined);
      },
      relative(from, to) {
        validateString(from, "from");
        validateString(to, "to");
        if (from === to)
          return "";
        const fromOrig = win32.resolve(from);
        const toOrig = win32.resolve(to);
        if (fromOrig === toOrig)
          return "";
        from = StringPrototypeToLowerCase(fromOrig);
        to = StringPrototypeToLowerCase(toOrig);
        if (from === to)
          return "";
        if (fromOrig.length !== from.length || toOrig.length !== to.length) {
          const fromSplit = StringPrototypeSplit(fromOrig, "\\");
          const toSplit = StringPrototypeSplit(toOrig, "\\");
          if (fromSplit[fromSplit.length - 1] === "") {
            fromSplit.pop();
          }
          if (toSplit[toSplit.length - 1] === "") {
            toSplit.pop();
          }
          const fromLen2 = fromSplit.length;
          const toLen2 = toSplit.length;
          const length2 = fromLen2 < toLen2 ? fromLen2 : toLen2;
          let i2;
          for (i2 = 0;i2 < length2; i2++) {
            if (StringPrototypeToLowerCase(fromSplit[i2]) !== StringPrototypeToLowerCase(toSplit[i2])) {
              break;
            }
          }
          if (i2 === 0) {
            return toOrig;
          } else if (i2 === length2) {
            if (toLen2 > length2) {
              return ArrayPrototypeJoin(ArrayPrototypeSlice(toSplit, i2), "\\");
            }
            if (fromLen2 > length2) {
              return StringPrototypeRepeat("..\\", fromLen2 - 1 - i2) + "..";
            }
            return "";
          }
          return StringPrototypeRepeat("..\\", fromLen2 - i2) + ArrayPrototypeJoin(ArrayPrototypeSlice(toSplit, i2), "\\");
        }
        let fromStart = 0;
        while (fromStart < from.length && StringPrototypeCharCodeAt(from, fromStart) === CHAR_BACKWARD_SLASH) {
          fromStart++;
        }
        let fromEnd = from.length;
        while (fromEnd - 1 > fromStart && StringPrototypeCharCodeAt(from, fromEnd - 1) === CHAR_BACKWARD_SLASH) {
          fromEnd--;
        }
        const fromLen = fromEnd - fromStart;
        let toStart = 0;
        while (toStart < to.length && StringPrototypeCharCodeAt(to, toStart) === CHAR_BACKWARD_SLASH) {
          toStart++;
        }
        let toEnd = to.length;
        while (toEnd - 1 > toStart && StringPrototypeCharCodeAt(to, toEnd - 1) === CHAR_BACKWARD_SLASH) {
          toEnd--;
        }
        const toLen = toEnd - toStart;
        const length = fromLen < toLen ? fromLen : toLen;
        let lastCommonSep = -1;
        let i = 0;
        for (;i < length; i++) {
          const fromCode = StringPrototypeCharCodeAt(from, fromStart + i);
          if (fromCode !== StringPrototypeCharCodeAt(to, toStart + i))
            break;
          else if (fromCode === CHAR_BACKWARD_SLASH)
            lastCommonSep = i;
        }
        if (i !== length) {
          if (lastCommonSep === -1)
            return toOrig;
        } else {
          if (toLen > length) {
            if (StringPrototypeCharCodeAt(to, toStart + i) === CHAR_BACKWARD_SLASH) {
              return StringPrototypeSlice(toOrig, toStart + i + 1);
            }
            if (i === 2) {
              return StringPrototypeSlice(toOrig, toStart + i);
            }
          }
          if (fromLen > length) {
            if (StringPrototypeCharCodeAt(from, fromStart + i) === CHAR_BACKWARD_SLASH) {
              lastCommonSep = i;
            } else if (i === 2) {
              lastCommonSep = 3;
            }
          }
          if (lastCommonSep === -1)
            lastCommonSep = 0;
        }
        let out = "";
        for (i = fromStart + lastCommonSep + 1;i <= fromEnd; ++i) {
          if (i === fromEnd || StringPrototypeCharCodeAt(from, i) === CHAR_BACKWARD_SLASH) {
            out += out.length === 0 ? ".." : "\\..";
          }
        }
        toStart += lastCommonSep;
        if (out.length > 0)
          return `${out}${StringPrototypeSlice(toOrig, toStart, toEnd)}`;
        if (StringPrototypeCharCodeAt(toOrig, toStart) === CHAR_BACKWARD_SLASH)
          ++toStart;
        return StringPrototypeSlice(toOrig, toStart, toEnd);
      },
      toNamespacedPath(path) {
        if (typeof path !== "string" || path.length === 0)
          return path;
        const resolvedPath = win32.resolve(path);
        if (resolvedPath.length <= 2)
          return path;
        if (StringPrototypeCharCodeAt(resolvedPath, 0) === CHAR_BACKWARD_SLASH) {
          if (StringPrototypeCharCodeAt(resolvedPath, 1) === CHAR_BACKWARD_SLASH) {
            const code = StringPrototypeCharCodeAt(resolvedPath, 2);
            if (code !== CHAR_QUESTION_MARK && code !== CHAR_DOT) {
              return `\\\\?\\UNC\\${StringPrototypeSlice(resolvedPath, 2)}`;
            }
          }
        } else if (isWindowsDeviceRoot(StringPrototypeCharCodeAt(resolvedPath, 0)) && StringPrototypeCharCodeAt(resolvedPath, 1) === CHAR_COLON && StringPrototypeCharCodeAt(resolvedPath, 2) === CHAR_BACKWARD_SLASH) {
          return `\\\\?\\${resolvedPath}`;
        }
        return resolvedPath;
      },
      dirname(path) {
        validateString(path, "path");
        const len = path.length;
        if (len === 0)
          return ".";
        let rootEnd = -1;
        let offset = 0;
        const code = StringPrototypeCharCodeAt(path, 0);
        if (len === 1) {
          return isPathSeparator(code) ? path : ".";
        }
        if (isPathSeparator(code)) {
          rootEnd = offset = 1;
          if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
            let j = 2;
            let last = j;
            while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
              j++;
            }
            if (j < len && j !== last) {
              last = j;
              while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                j++;
              }
              if (j < len && j !== last) {
                last = j;
                while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                  j++;
                }
                if (j === len) {
                  return path;
                }
                if (j !== last) {
                  rootEnd = offset = j + 1;
                }
              }
            }
          }
        } else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
          rootEnd = len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2)) ? 3 : 2;
          offset = rootEnd;
        }
        let end = -1;
        let matchedSlash = true;
        for (let i = len - 1;i >= offset; --i) {
          if (isPathSeparator(StringPrototypeCharCodeAt(path, i))) {
            if (!matchedSlash) {
              end = i;
              break;
            }
          } else {
            matchedSlash = false;
          }
        }
        if (end === -1) {
          if (rootEnd === -1)
            return ".";
          end = rootEnd;
        }
        return StringPrototypeSlice(path, 0, end);
      },
      basename(path, suffix) {
        if (suffix !== undefined)
          validateString(suffix, "suffix");
        validateString(path, "path");
        let start = 0;
        let end = -1;
        let matchedSlash = true;
        if (path.length >= 2 && isWindowsDeviceRoot(StringPrototypeCharCodeAt(path, 0)) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
          start = 2;
        }
        if (suffix !== undefined && suffix.length > 0 && suffix.length <= path.length) {
          if (suffix === path)
            return "";
          let extIdx = suffix.length - 1;
          let firstNonSlashEnd = -1;
          for (let i = path.length - 1;i >= start; --i) {
            const code = StringPrototypeCharCodeAt(path, i);
            if (isPathSeparator(code)) {
              if (!matchedSlash) {
                start = i + 1;
                break;
              }
            } else {
              if (firstNonSlashEnd === -1) {
                matchedSlash = false;
                firstNonSlashEnd = i + 1;
              }
              if (extIdx >= 0) {
                if (code === StringPrototypeCharCodeAt(suffix, extIdx)) {
                  if (--extIdx === -1) {
                    end = i;
                  }
                } else {
                  extIdx = -1;
                  end = firstNonSlashEnd;
                }
              }
            }
          }
          if (start === end)
            end = firstNonSlashEnd;
          else if (end === -1)
            end = path.length;
          return StringPrototypeSlice(path, start, end);
        }
        for (let i = path.length - 1;i >= start; --i) {
          if (isPathSeparator(StringPrototypeCharCodeAt(path, i))) {
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
        }
        if (end === -1)
          return "";
        return StringPrototypeSlice(path, start, end);
      },
      extname(path) {
        validateString(path, "path");
        let start = 0;
        let startDot = -1;
        let startPart = 0;
        let end = -1;
        let matchedSlash = true;
        let preDotState = 0;
        if (path.length >= 2 && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON && isWindowsDeviceRoot(StringPrototypeCharCodeAt(path, 0))) {
          start = startPart = 2;
        }
        for (let i = path.length - 1;i >= start; --i) {
          const code = StringPrototypeCharCodeAt(path, i);
          if (isPathSeparator(code)) {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (code === CHAR_DOT) {
            if (startDot === -1)
              startDot = i;
            else if (preDotState !== 1)
              preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
          return "";
        }
        return StringPrototypeSlice(path, startDot, end);
      },
      format: FunctionPrototypeBind(_format, null, "\\"),
      parse(path) {
        validateString(path, "path");
        const ret = { root: "", dir: "", base: "", ext: "", name: "" };
        if (path.length === 0)
          return ret;
        const len = path.length;
        let rootEnd = 0;
        let code = StringPrototypeCharCodeAt(path, 0);
        if (len === 1) {
          if (isPathSeparator(code)) {
            ret.root = ret.dir = path;
            return ret;
          }
          ret.base = ret.name = path;
          return ret;
        }
        if (isPathSeparator(code)) {
          rootEnd = 1;
          if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
            let j = 2;
            let last = j;
            while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
              j++;
            }
            if (j < len && j !== last) {
              last = j;
              while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                j++;
              }
              if (j < len && j !== last) {
                last = j;
                while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) {
                  j++;
                }
                if (j === len) {
                  rootEnd = j;
                } else if (j !== last) {
                  rootEnd = j + 1;
                }
              }
            }
          }
        } else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
          if (len <= 2) {
            ret.root = ret.dir = path;
            return ret;
          }
          rootEnd = 2;
          if (isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
            if (len === 3) {
              ret.root = ret.dir = path;
              return ret;
            }
            rootEnd = 3;
          }
        }
        if (rootEnd > 0)
          ret.root = StringPrototypeSlice(path, 0, rootEnd);
        let startDot = -1;
        let startPart = rootEnd;
        let end = -1;
        let matchedSlash = true;
        let i = path.length - 1;
        let preDotState = 0;
        for (;i >= rootEnd; --i) {
          code = StringPrototypeCharCodeAt(path, i);
          if (isPathSeparator(code)) {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (code === CHAR_DOT) {
            if (startDot === -1)
              startDot = i;
            else if (preDotState !== 1)
              preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (end !== -1) {
          if (startDot === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
            ret.base = ret.name = StringPrototypeSlice(path, startPart, end);
          } else {
            ret.name = StringPrototypeSlice(path, startPart, startDot);
            ret.base = StringPrototypeSlice(path, startPart, end);
            ret.ext = StringPrototypeSlice(path, startDot, end);
          }
        }
        if (startPart > 0 && startPart !== rootEnd)
          ret.dir = StringPrototypeSlice(path, 0, startPart - 1);
        else
          ret.dir = ret.root;
        return ret;
      },
      matchesGlob(path, pattern) {
        return lazyMatchGlobPattern()(path, pattern, true);
      },
      sep: "\\",
      delimiter: ";",
      win32: null,
      posix: null
    };
    const posixCwd = (() => {
      if (isWindows) {
        const regexp = /\\/g;
        return () => {
          const cwd = StringPrototypeReplace(process.cwd(), regexp, "/");
          return StringPrototypeSlice(cwd, StringPrototypeIndexOf(cwd, "/"));
        };
      }
      return () => process.cwd();
    })();
    const posix = {
      resolve(...args) {
        if (args.length === 0 || args.length === 1 && (args[0] === "" || args[0] === ".")) {
          const cwd = posixCwd();
          if (StringPrototypeCharCodeAt(cwd, 0) === CHAR_FORWARD_SLASH) {
            return cwd;
          }
        }
        let resolvedPath = "";
        let resolvedAbsolute = false;
        for (let i = args.length - 1;i >= 0 && !resolvedAbsolute; i--) {
          const path = args[i];
          validateString(path, `paths[${i}]`);
          if (path.length === 0) {
            continue;
          }
          resolvedPath = `${path}/${resolvedPath}`;
          resolvedAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
        }
        if (!resolvedAbsolute) {
          const cwd = posixCwd();
          resolvedPath = `${cwd}/${resolvedPath}`;
          resolvedAbsolute = StringPrototypeCharCodeAt(cwd, 0) === CHAR_FORWARD_SLASH;
        }
        resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute, "/", isPosixPathSeparator);
        if (resolvedAbsolute) {
          return `/${resolvedPath}`;
        }
        return resolvedPath.length > 0 ? resolvedPath : ".";
      },
      normalize(path) {
        validateString(path, "path");
        if (path.length === 0)
          return ".";
        const isAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
        const trailingSeparator = StringPrototypeCharCodeAt(path, path.length - 1) === CHAR_FORWARD_SLASH;
        path = normalizeString(path, !isAbsolute, "/", isPosixPathSeparator);
        if (path.length === 0) {
          if (isAbsolute)
            return "/";
          return trailingSeparator ? "./" : ".";
        }
        if (trailingSeparator)
          path += "/";
        return isAbsolute ? `/${path}` : path;
      },
      isAbsolute(path) {
        validateString(path, "path");
        return path.length > 0 && StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
      },
      join(...args) {
        if (args.length === 0)
          return ".";
        const path = [];
        for (let i = 0;i < args.length; ++i) {
          const arg = args[i];
          validateString(arg, "path");
          if (arg.length > 0) {
            path.push(arg);
          }
        }
        if (path.length === 0)
          return ".";
        return posix.normalize(ArrayPrototypeJoin(path, "/"));
      },
      relative(from, to) {
        validateString(from, "from");
        validateString(to, "to");
        if (from === to)
          return "";
        from = posix.resolve(from);
        to = posix.resolve(to);
        if (from === to)
          return "";
        const fromStart = 1;
        const fromEnd = from.length;
        const fromLen = fromEnd - fromStart;
        const toStart = 1;
        const toLen = to.length - toStart;
        const length = fromLen < toLen ? fromLen : toLen;
        let lastCommonSep = -1;
        let i = 0;
        for (;i < length; i++) {
          const fromCode = StringPrototypeCharCodeAt(from, fromStart + i);
          if (fromCode !== StringPrototypeCharCodeAt(to, toStart + i))
            break;
          else if (fromCode === CHAR_FORWARD_SLASH)
            lastCommonSep = i;
        }
        if (i === length) {
          if (toLen > length) {
            if (StringPrototypeCharCodeAt(to, toStart + i) === CHAR_FORWARD_SLASH) {
              return StringPrototypeSlice(to, toStart + i + 1);
            }
            if (i === 0) {
              return StringPrototypeSlice(to, toStart + i);
            }
          } else if (fromLen > length) {
            if (StringPrototypeCharCodeAt(from, fromStart + i) === CHAR_FORWARD_SLASH) {
              lastCommonSep = i;
            } else if (i === 0) {
              lastCommonSep = 0;
            }
          }
        }
        let out = "";
        for (i = fromStart + lastCommonSep + 1;i <= fromEnd; ++i) {
          if (i === fromEnd || StringPrototypeCharCodeAt(from, i) === CHAR_FORWARD_SLASH) {
            out += out.length === 0 ? ".." : "/..";
          }
        }
        return `${out}${StringPrototypeSlice(to, toStart + lastCommonSep)}`;
      },
      toNamespacedPath(path) {
        return path;
      },
      dirname(path) {
        validateString(path, "path");
        if (path.length === 0)
          return ".";
        const hasRoot = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
        let end = -1;
        let matchedSlash = true;
        for (let i = path.length - 1;i >= 1; --i) {
          if (StringPrototypeCharCodeAt(path, i) === CHAR_FORWARD_SLASH) {
            if (!matchedSlash) {
              end = i;
              break;
            }
          } else {
            matchedSlash = false;
          }
        }
        if (end === -1)
          return hasRoot ? "/" : ".";
        if (hasRoot && end === 1)
          return "//";
        return StringPrototypeSlice(path, 0, end);
      },
      basename(path, suffix) {
        if (suffix !== undefined)
          validateString(suffix, "suffix");
        validateString(path, "path");
        let start = 0;
        let end = -1;
        let matchedSlash = true;
        if (suffix !== undefined && suffix.length > 0 && suffix.length <= path.length) {
          if (suffix === path)
            return "";
          let extIdx = suffix.length - 1;
          let firstNonSlashEnd = -1;
          for (let i = path.length - 1;i >= 0; --i) {
            const code = StringPrototypeCharCodeAt(path, i);
            if (code === CHAR_FORWARD_SLASH) {
              if (!matchedSlash) {
                start = i + 1;
                break;
              }
            } else {
              if (firstNonSlashEnd === -1) {
                matchedSlash = false;
                firstNonSlashEnd = i + 1;
              }
              if (extIdx >= 0) {
                if (code === StringPrototypeCharCodeAt(suffix, extIdx)) {
                  if (--extIdx === -1) {
                    end = i;
                  }
                } else {
                  extIdx = -1;
                  end = firstNonSlashEnd;
                }
              }
            }
          }
          if (start === end)
            end = firstNonSlashEnd;
          else if (end === -1)
            end = path.length;
          return StringPrototypeSlice(path, start, end);
        }
        for (let i = path.length - 1;i >= 0; --i) {
          if (StringPrototypeCharCodeAt(path, i) === CHAR_FORWARD_SLASH) {
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
        }
        if (end === -1)
          return "";
        return StringPrototypeSlice(path, start, end);
      },
      extname(path) {
        validateString(path, "path");
        let startDot = -1;
        let startPart = 0;
        let end = -1;
        let matchedSlash = true;
        let preDotState = 0;
        for (let i = path.length - 1;i >= 0; --i) {
          const char = path[i];
          if (char === "/") {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (char === ".") {
            if (startDot === -1)
              startDot = i;
            else if (preDotState !== 1)
              preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
          return "";
        }
        return StringPrototypeSlice(path, startDot, end);
      },
      format: FunctionPrototypeBind(_format, null, "/"),
      parse(path) {
        validateString(path, "path");
        const ret = { root: "", dir: "", base: "", ext: "", name: "" };
        if (path.length === 0)
          return ret;
        const isAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
        let start;
        if (isAbsolute) {
          ret.root = "/";
          start = 1;
        } else {
          start = 0;
        }
        let startDot = -1;
        let startPart = 0;
        let end = -1;
        let matchedSlash = true;
        let i = path.length - 1;
        let preDotState = 0;
        for (;i >= start; --i) {
          const code = StringPrototypeCharCodeAt(path, i);
          if (code === CHAR_FORWARD_SLASH) {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (code === CHAR_DOT) {
            if (startDot === -1)
              startDot = i;
            else if (preDotState !== 1)
              preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (end !== -1) {
          const start2 = startPart === 0 && isAbsolute ? 1 : startPart;
          if (startDot === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
            ret.base = ret.name = StringPrototypeSlice(path, start2, end);
          } else {
            ret.name = StringPrototypeSlice(path, start2, startDot);
            ret.base = StringPrototypeSlice(path, start2, end);
            ret.ext = StringPrototypeSlice(path, startDot, end);
          }
        }
        if (startPart > 0)
          ret.dir = StringPrototypeSlice(path, 0, startPart - 1);
        else if (isAbsolute)
          ret.dir = "/";
        return ret;
      },
      matchesGlob(path, pattern) {
        return lazyMatchGlobPattern()(path, pattern, false);
      },
      sep: "/",
      delimiter: ":",
      win32: null,
      posix: null
    };
    posix.win32 = win32.win32 = win32;
    posix.posix = win32.posix = posix;
    win32._makeLong = win32.toNamespacedPath;
    posix._makeLong = posix.toNamespacedPath;
    module.exports = isWindows ? win32 : posix;
  }

  // third_party/node/lib/punycode.js
  function punycode_default(exports, require2, module, process, internalBinding, primordials2) {
    const maxInt = 2147483647;
    const base = 36;
    const tMin = 1;
    const tMax = 26;
    const skew = 38;
    const damp = 700;
    const initialBias = 72;
    const initialN = 128;
    const delimiter = "-";
    const regexPunycode = /^xn--/;
    const regexNonASCII = /[^\0-\x7F]/;
    const regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g;
    const errors = {
      overflow: "Overflow: input needs wider integers to process",
      "not-basic": "Illegal input >= 0x80 (not a basic code point)",
      "invalid-input": "Invalid input"
    };
    const baseMinusTMin = base - tMin;
    const floor = Math.floor;
    const stringFromCharCode = String.fromCharCode;
    function error(type) {
      throw new RangeError(errors[type]);
    }
    function map(array, callback) {
      const result = [];
      let length = array.length;
      while (length--) {
        result[length] = callback(array[length]);
      }
      return result;
    }
    function mapDomain(domain, callback) {
      const parts = domain.split("@");
      let result = "";
      if (parts.length > 1) {
        result = parts[0] + "@";
        domain = parts[1];
      }
      domain = domain.replace(regexSeparators, ".");
      const labels = domain.split(".");
      const encoded = map(labels, callback).join(".");
      return result + encoded;
    }
    function ucs2decode(string) {
      const output = [];
      let counter = 0;
      const length = string.length;
      while (counter < length) {
        const value = string.charCodeAt(counter++);
        if (value >= 55296 && value <= 56319 && counter < length) {
          const extra = string.charCodeAt(counter++);
          if ((extra & 64512) == 56320) {
            output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
          } else {
            output.push(value);
            counter--;
          }
        } else {
          output.push(value);
        }
      }
      return output;
    }
    const ucs2encode = (codePoints) => String.fromCodePoint(...codePoints);
    const basicToDigit = function(codePoint) {
      if (codePoint >= 48 && codePoint < 58) {
        return 26 + (codePoint - 48);
      }
      if (codePoint >= 65 && codePoint < 91) {
        return codePoint - 65;
      }
      if (codePoint >= 97 && codePoint < 123) {
        return codePoint - 97;
      }
      return base;
    };
    const digitToBasic = function(digit, flag) {
      return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
    };
    const adapt = function(delta, numPoints, firstTime) {
      let k = 0;
      delta = firstTime ? floor(delta / damp) : delta >> 1;
      delta += floor(delta / numPoints);
      for (;delta > baseMinusTMin * tMax >> 1; k += base) {
        delta = floor(delta / baseMinusTMin);
      }
      return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
    };
    const decode = function(input) {
      const output = [];
      const inputLength = input.length;
      let i = 0;
      let n = initialN;
      let bias = initialBias;
      let basic = input.lastIndexOf(delimiter);
      if (basic < 0) {
        basic = 0;
      }
      for (let j = 0;j < basic; ++j) {
        if (input.charCodeAt(j) >= 128) {
          error("not-basic");
        }
        output.push(input.charCodeAt(j));
      }
      for (let index = basic > 0 ? basic + 1 : 0;index < inputLength; ) {
        const oldi = i;
        for (let w = 1, k = base;; k += base) {
          if (index >= inputLength) {
            error("invalid-input");
          }
          const digit = basicToDigit(input.charCodeAt(index++));
          if (digit >= base) {
            error("invalid-input");
          }
          if (digit > floor((maxInt - i) / w)) {
            error("overflow");
          }
          i += digit * w;
          const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
          if (digit < t) {
            break;
          }
          const baseMinusT = base - t;
          if (w > floor(maxInt / baseMinusT)) {
            error("overflow");
          }
          w *= baseMinusT;
        }
        const out = output.length + 1;
        bias = adapt(i - oldi, out, oldi == 0);
        if (floor(i / out) > maxInt - n) {
          error("overflow");
        }
        n += floor(i / out);
        i %= out;
        output.splice(i++, 0, n);
      }
      return String.fromCodePoint(...output);
    };
    const encode = function(input) {
      const output = [];
      input = ucs2decode(input);
      const inputLength = input.length;
      let n = initialN;
      let delta = 0;
      let bias = initialBias;
      for (const currentValue of input) {
        if (currentValue < 128) {
          output.push(stringFromCharCode(currentValue));
        }
      }
      const basicLength = output.length;
      let handledCPCount = basicLength;
      if (basicLength) {
        output.push(delimiter);
      }
      while (handledCPCount < inputLength) {
        let m = maxInt;
        for (const currentValue of input) {
          if (currentValue >= n && currentValue < m) {
            m = currentValue;
          }
        }
        const handledCPCountPlusOne = handledCPCount + 1;
        if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
          error("overflow");
        }
        delta += (m - n) * handledCPCountPlusOne;
        n = m;
        for (const currentValue of input) {
          if (currentValue < n && ++delta > maxInt) {
            error("overflow");
          }
          if (currentValue === n) {
            let q = delta;
            for (let k = base;; k += base) {
              const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
              if (q < t) {
                break;
              }
              const qMinusT = q - t;
              const baseMinusT = base - t;
              output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
              q = floor(qMinusT / baseMinusT);
            }
            output.push(stringFromCharCode(digitToBasic(q, 0)));
            bias = adapt(delta, handledCPCountPlusOne, handledCPCount === basicLength);
            delta = 0;
            ++handledCPCount;
          }
        }
        ++delta;
        ++n;
      }
      return output.join("");
    };
    const toUnicode = function(input) {
      return mapDomain(input, function(string) {
        return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
      });
    };
    const toASCII = function(input) {
      return mapDomain(input, function(string) {
        return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
      });
    };
    const punycode = {
      version: "2.3.1",
      ucs2: {
        decode: ucs2decode,
        encode: ucs2encode
      },
      decode,
      encode,
      toASCII,
      toUnicode
    };
    module.exports = punycode;
  }

  // third_party/node/lib/querystring.js
  function querystring_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Array: Array2,
      ArrayIsArray,
      Int8Array: Int8Array2,
      MathAbs,
      NumberIsFinite,
      ObjectKeys,
      String: String2,
      StringPrototypeCharCodeAt,
      StringPrototypeSlice,
      decodeURIComponent: decodeURIComponent2
    } = primordials2;
    const { Buffer } = require2("buffer");
    const {
      encodeStr,
      hexTable,
      isHexTable
    } = require2("internal/querystring");
    const QueryString = module.exports = {
      unescapeBuffer,
      unescape: qsUnescape,
      escape: qsEscape,
      stringify,
      encode: stringify,
      parse,
      decode: parse
    };
    const unhexTable = new Int8Array2([
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      10,
      11,
      12,
      13,
      14,
      15,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      10,
      11,
      12,
      13,
      14,
      15,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1
    ]);
    function unescapeBuffer(s, decodeSpaces) {
      const out = Buffer.allocUnsafe(s.length);
      let index = 0;
      let outIndex = 0;
      let currentChar;
      let nextChar;
      let hexHigh;
      let hexLow;
      const maxLength = s.length - 2;
      let hasHex = false;
      while (index < s.length) {
        currentChar = StringPrototypeCharCodeAt(s, index);
        if (currentChar === 43 && decodeSpaces) {
          out[outIndex++] = 32;
          index++;
          continue;
        }
        if (currentChar === 37 && index < maxLength) {
          currentChar = StringPrototypeCharCodeAt(s, ++index);
          hexHigh = unhexTable[currentChar];
          if (!(hexHigh >= 0)) {
            out[outIndex++] = 37;
            continue;
          } else {
            nextChar = StringPrototypeCharCodeAt(s, ++index);
            hexLow = unhexTable[nextChar];
            if (!(hexLow >= 0)) {
              out[outIndex++] = 37;
              index--;
            } else {
              hasHex = true;
              currentChar = hexHigh * 16 + hexLow;
            }
          }
        }
        out[outIndex++] = currentChar;
        index++;
      }
      return hasHex ? out.slice(0, outIndex) : out;
    }
    function qsUnescape(s, decodeSpaces) {
      try {
        return decodeURIComponent2(s);
      } catch {
        return QueryString.unescapeBuffer(s, decodeSpaces).toString();
      }
    }
    const noEscape = new Int8Array2([
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      0
    ]);
    function qsEscape(str) {
      if (typeof str !== "string") {
        if (typeof str === "object")
          str = String2(str);
        else
          str += "";
      }
      return encodeStr(str, noEscape, hexTable);
    }
    function stringifyPrimitive(v) {
      if (typeof v === "string")
        return v;
      if (typeof v === "number" && NumberIsFinite(v))
        return "" + v;
      if (typeof v === "bigint")
        return "" + v;
      if (typeof v === "boolean")
        return v ? "true" : "false";
      return "";
    }
    function encodeStringified(v, encode) {
      if (typeof v === "string")
        return v.length ? encode(v) : "";
      if (typeof v === "number" && NumberIsFinite(v)) {
        return MathAbs(v) < 1000000000000000000000 ? "" + v : encode("" + v);
      }
      if (typeof v === "bigint")
        return "" + v;
      if (typeof v === "boolean")
        return v ? "true" : "false";
      return "";
    }
    function encodeStringifiedCustom(v, encode) {
      return encode(stringifyPrimitive(v));
    }
    function stringify(obj, sep, eq, options) {
      sep ||= "&";
      eq ||= "=";
      let encode = QueryString.escape;
      if (options && typeof options.encodeURIComponent === "function") {
        encode = options.encodeURIComponent;
      }
      const convert = encode === qsEscape ? encodeStringified : encodeStringifiedCustom;
      if (obj !== null && typeof obj === "object") {
        const keys = ObjectKeys(obj);
        const len = keys.length;
        let fields = "";
        for (let i = 0;i < len; ++i) {
          const k = keys[i];
          const v = obj[k];
          let ks = convert(k, encode);
          ks += eq;
          if (ArrayIsArray(v)) {
            const vlen = v.length;
            if (vlen === 0)
              continue;
            if (fields)
              fields += sep;
            for (let j = 0;j < vlen; ++j) {
              if (j)
                fields += sep;
              fields += ks;
              fields += convert(v[j], encode);
            }
          } else {
            if (fields)
              fields += sep;
            fields += ks;
            fields += convert(v, encode);
          }
        }
        return fields;
      }
      return "";
    }
    function charCodes(str) {
      if (str.length === 0)
        return [];
      if (str.length === 1)
        return [StringPrototypeCharCodeAt(str, 0)];
      const ret = new Array2(str.length);
      for (let i = 0;i < str.length; ++i)
        ret[i] = StringPrototypeCharCodeAt(str, i);
      return ret;
    }
    const defSepCodes = [38];
    const defEqCodes = [61];
    function addKeyVal(obj, key, value, keyEncoded, valEncoded, decode) {
      if (key.length > 0 && keyEncoded)
        key = decodeStr(key, decode);
      if (value.length > 0 && valEncoded)
        value = decodeStr(value, decode);
      if (obj[key] === undefined) {
        obj[key] = value;
      } else {
        const curValue = obj[key];
        if (curValue.pop)
          curValue[curValue.length] = value;
        else
          obj[key] = [curValue, value];
      }
    }
    function parse(qs, sep, eq, options) {
      const obj = { __proto__: null };
      if (typeof qs !== "string" || qs.length === 0) {
        return obj;
      }
      const sepCodes = !sep ? defSepCodes : charCodes(String2(sep));
      const eqCodes = !eq ? defEqCodes : charCodes(String2(eq));
      const sepLen = sepCodes.length;
      const eqLen = eqCodes.length;
      let pairs = 1000;
      if (options && typeof options.maxKeys === "number") {
        pairs = options.maxKeys > 0 ? options.maxKeys : -1;
      }
      let decode = QueryString.unescape;
      if (options && typeof options.decodeURIComponent === "function") {
        decode = options.decodeURIComponent;
      }
      const customDecode = decode !== qsUnescape;
      let lastPos = 0;
      let sepIdx = 0;
      let eqIdx = 0;
      let key = "";
      let value = "";
      let keyEncoded = customDecode;
      let valEncoded = customDecode;
      const plusChar = customDecode ? "%20" : " ";
      let encodeCheck = 0;
      for (let i = 0;i < qs.length; ++i) {
        const code = StringPrototypeCharCodeAt(qs, i);
        if (code === sepCodes[sepIdx]) {
          if (++sepIdx === sepLen) {
            const end = i - sepIdx + 1;
            if (eqIdx < eqLen) {
              if (lastPos < end) {
                key += StringPrototypeSlice(qs, lastPos, end);
              } else if (key.length === 0) {
                if (--pairs === 0)
                  return obj;
                lastPos = i + 1;
                sepIdx = eqIdx = 0;
                continue;
              }
            } else if (lastPos < end) {
              value += StringPrototypeSlice(qs, lastPos, end);
            }
            addKeyVal(obj, key, value, keyEncoded, valEncoded, decode);
            if (--pairs === 0)
              return obj;
            keyEncoded = valEncoded = customDecode;
            key = value = "";
            encodeCheck = 0;
            lastPos = i + 1;
            sepIdx = eqIdx = 0;
          }
        } else {
          sepIdx = 0;
          if (eqIdx < eqLen) {
            if (code === eqCodes[eqIdx]) {
              if (++eqIdx === eqLen) {
                const end = i - eqIdx + 1;
                if (lastPos < end)
                  key += StringPrototypeSlice(qs, lastPos, end);
                encodeCheck = 0;
                lastPos = i + 1;
              }
              continue;
            } else {
              eqIdx = 0;
              if (!keyEncoded) {
                if (code === 37) {
                  encodeCheck = 1;
                  continue;
                } else if (encodeCheck > 0) {
                  if (isHexTable[code] === 1) {
                    if (++encodeCheck === 3)
                      keyEncoded = true;
                    continue;
                  } else {
                    encodeCheck = 0;
                  }
                }
              }
            }
            if (code === 43) {
              if (lastPos < i)
                key += StringPrototypeSlice(qs, lastPos, i);
              key += plusChar;
              lastPos = i + 1;
              continue;
            }
          }
          if (code === 43) {
            if (lastPos < i)
              value += StringPrototypeSlice(qs, lastPos, i);
            value += plusChar;
            lastPos = i + 1;
          } else if (!valEncoded) {
            if (code === 37) {
              encodeCheck = 1;
            } else if (encodeCheck > 0) {
              if (isHexTable[code] === 1) {
                if (++encodeCheck === 3)
                  valEncoded = true;
              } else {
                encodeCheck = 0;
              }
            }
          }
        }
      }
      if (lastPos < qs.length) {
        if (eqIdx < eqLen)
          key += StringPrototypeSlice(qs, lastPos);
        else if (sepIdx < sepLen)
          value += StringPrototypeSlice(qs, lastPos);
      } else if (eqIdx === 0 && key.length === 0) {
        return obj;
      }
      addKeyVal(obj, key, value, keyEncoded, valEncoded, decode);
      return obj;
    }
    function decodeStr(s, decoder) {
      try {
        return decoder(s);
      } catch {
        return QueryString.unescape(s, true);
      }
    }
  }

  // third_party/node/lib/stream/consumers.js
  function consumers_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      JSONParse,
      Uint8Array: Uint8Array2
    } = primordials2;
    const {
      TextDecoder: TextDecoder2
    } = require2("internal/encoding");
    const {
      Blob
    } = require2("internal/blob");
    const {
      Buffer
    } = require2("buffer");
    async function blob(stream) {
      const chunks = [];
      for await (const chunk of stream)
        chunks.push(chunk);
      return new Blob(chunks);
    }
    async function arrayBuffer(stream) {
      const ret = await blob(stream);
      return ret.arrayBuffer();
    }
    async function buffer(stream) {
      return Buffer.from(await arrayBuffer(stream));
    }
    async function bytes(stream) {
      return new Uint8Array2(await arrayBuffer(stream));
    }
    async function text(stream) {
      const dec = new TextDecoder2;
      let str = "";
      for await (const chunk of stream) {
        if (typeof chunk === "string")
          str += chunk;
        else
          str += dec.decode(chunk, { stream: true });
      }
      str += dec.decode(undefined, { stream: false });
      return str;
    }
    async function json(stream) {
      const str = await text(stream);
      return JSONParse(str);
    }
    module.exports = {
      arrayBuffer,
      blob,
      buffer,
      bytes,
      text,
      json
    };
  }

  // third_party/node/lib/stream/promises.js
  function promises_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypePop,
      Promise: Promise2
    } = primordials2;
    const {
      isIterable,
      isNodeStream,
      isWebStream
    } = require2("internal/streams/utils");
    const { pipelineImpl: pl } = require2("internal/streams/pipeline");
    const { finished } = require2("internal/streams/end-of-stream");
    require2("stream");
    function pipeline(...streams) {
      return new Promise2((resolve2, reject) => {
        let signal;
        let end;
        const lastArg = streams[streams.length - 1];
        if (lastArg && typeof lastArg === "object" && !isNodeStream(lastArg) && !isIterable(lastArg) && !isWebStream(lastArg)) {
          const options = ArrayPrototypePop(streams);
          signal = options.signal;
          end = options.end;
        }
        pl(streams, (err, value) => {
          if (err) {
            reject(err);
          } else {
            resolve2(value);
          }
        }, { signal, end });
      });
    }
    module.exports = {
      finished,
      pipeline
    };
  }

  // third_party/node/lib/stream.js
  function stream_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ObjectDefineProperty,
      ObjectKeys,
      ReflectApply
    } = primordials2;
    const {
      promisify: { custom: customPromisify }
    } = require2("internal/util");
    const {
      streamReturningOperators,
      promiseReturningOperators
    } = require2("internal/streams/operators");
    const {
      codes: {
        ERR_ILLEGAL_CONSTRUCTOR
      }
    } = require2("internal/errors");
    const compose = require2("internal/streams/compose");
    const { setDefaultHighWaterMark, getDefaultHighWaterMark } = require2("internal/streams/state");
    const { pipeline } = require2("internal/streams/pipeline");
    const { destroyer } = require2("internal/streams/destroy");
    const { eos } = require2("internal/streams/end-of-stream");
    const internalBuffer = require2("internal/buffer");
    const promises = require2("stream/promises");
    const utils = require2("internal/streams/utils");
    const { isArrayBufferView, isUint8Array } = require2("internal/util/types");
    const Stream = module.exports = require2("internal/streams/legacy").Stream;
    Stream.isDestroyed = utils.isDestroyed;
    Stream.isDisturbed = utils.isDisturbed;
    Stream.isErrored = utils.isErrored;
    Stream.isReadable = utils.isReadable;
    Stream.isWritable = utils.isWritable;
    Stream.Readable = require2("internal/streams/readable");
    const streamKeys = ObjectKeys(streamReturningOperators);
    for (let i = 0;i < streamKeys.length; i++) {
      let fn = function(...args) {
        if (new.target) {
          throw new ERR_ILLEGAL_CONSTRUCTOR;
        }
        return Stream.Readable.from(ReflectApply(op, this, args));
      };
      const key = streamKeys[i];
      const op = streamReturningOperators[key];
      ObjectDefineProperty(fn, "name", { __proto__: null, value: op.name });
      ObjectDefineProperty(fn, "length", { __proto__: null, value: op.length });
      ObjectDefineProperty(Stream.Readable.prototype, key, {
        __proto__: null,
        value: fn,
        enumerable: false,
        configurable: true,
        writable: true
      });
    }
    const promiseKeys = ObjectKeys(promiseReturningOperators);
    for (let i = 0;i < promiseKeys.length; i++) {
      let fn = function(...args) {
        if (new.target) {
          throw new ERR_ILLEGAL_CONSTRUCTOR;
        }
        return ReflectApply(op, this, args);
      };
      const key = promiseKeys[i];
      const op = promiseReturningOperators[key];
      ObjectDefineProperty(fn, "name", { __proto__: null, value: op.name });
      ObjectDefineProperty(fn, "length", { __proto__: null, value: op.length });
      ObjectDefineProperty(Stream.Readable.prototype, key, {
        __proto__: null,
        value: fn,
        enumerable: false,
        configurable: true,
        writable: true
      });
    }
    Stream.Writable = require2("internal/streams/writable");
    Stream.Duplex = require2("internal/streams/duplex");
    Stream.Transform = require2("internal/streams/transform");
    Stream.PassThrough = require2("internal/streams/passthrough");
    Stream.duplexPair = require2("internal/streams/duplexpair");
    Stream.pipeline = pipeline;
    const { addAbortSignal } = require2("internal/streams/add-abort-signal");
    Stream.addAbortSignal = addAbortSignal;
    Stream.finished = eos;
    Stream.destroy = destroyer;
    Stream.compose = compose;
    Stream.setDefaultHighWaterMark = setDefaultHighWaterMark;
    Stream.getDefaultHighWaterMark = getDefaultHighWaterMark;
    ObjectDefineProperty(Stream, "promises", {
      __proto__: null,
      configurable: true,
      enumerable: true,
      get() {
        return promises;
      }
    });
    ObjectDefineProperty(pipeline, customPromisify, {
      __proto__: null,
      enumerable: true,
      get() {
        return promises.pipeline;
      }
    });
    ObjectDefineProperty(eos, customPromisify, {
      __proto__: null,
      enumerable: true,
      get() {
        return promises.finished;
      }
    });
    Stream.Stream = Stream;
    Stream._isArrayBufferView = isArrayBufferView;
    Stream._isUint8Array = isUint8Array;
    Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
      return new internalBuffer.FastBuffer(chunk.buffer, chunk.byteOffset, chunk.byteLength);
    };
  }

  // third_party/node/lib/string_decoder.js
  function string_decoder_default(exports, require2, module, process, internalBinding, primordials2) {
    const Buffer = require2("buffer").Buffer;
    const isEncoding = Buffer.isEncoding || function(encoding) {
      encoding = "" + encoding;
      switch (encoding && encoding.toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
        case "raw":
          return true;
        default:
          return false;
      }
    };
    function _normalizeEncoding(enc) {
      if (!enc)
        return "utf8";
      let retried;
      for (;; ) {
        switch (enc) {
          case "utf8":
          case "utf-8":
            return "utf8";
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return "utf16le";
          case "latin1":
          case "binary":
            return "latin1";
          case "base64":
          case "ascii":
          case "hex":
            return enc;
          default:
            if (retried)
              return;
            enc = ("" + enc).toLowerCase();
            retried = true;
        }
      }
    }
    function normalizeEncoding(enc) {
      const nenc = _normalizeEncoding(enc);
      if (typeof nenc !== "string" && (Buffer.isEncoding === isEncoding || !isEncoding(enc)))
        throw new Error("Unknown encoding: " + enc);
      return nenc || enc;
    }
    function StringDecoder(encoding) {
      this.encoding = normalizeEncoding(encoding);
      let nb;
      switch (this.encoding) {
        case "utf16le":
          this.text = utf16Text;
          this.end = utf16End;
          nb = 4;
          break;
        case "utf8":
          this.fillLast = utf8FillLast;
          nb = 4;
          break;
        case "base64":
          this.text = base64Text;
          this.end = base64End;
          nb = 3;
          break;
        default:
          this.write = simpleWrite;
          this.end = simpleEnd;
          return;
      }
      this.lastNeed = 0;
      this.lastTotal = 0;
      this.lastChar = Buffer.allocUnsafe(nb);
    }
    StringDecoder.prototype.write = function(buf) {
      if (buf.length === 0)
        return "";
      let r;
      let i;
      if (this.lastNeed) {
        r = this.fillLast(buf);
        if (r === undefined)
          return "";
        i = this.lastNeed;
        this.lastNeed = 0;
      } else {
        i = 0;
      }
      if (i < buf.length)
        return r ? r + this.text(buf, i) : this.text(buf, i);
      return r || "";
    };
    StringDecoder.prototype.end = utf8End;
    StringDecoder.prototype.text = utf8Text;
    StringDecoder.prototype.fillLast = function(buf) {
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
      this.lastNeed -= buf.length;
    };
    function utf8CheckByte(byte) {
      if (byte <= 127)
        return 0;
      else if (byte >> 5 === 6)
        return 2;
      else if (byte >> 4 === 14)
        return 3;
      else if (byte >> 3 === 30)
        return 4;
      return byte >> 6 === 2 ? -1 : -2;
    }
    function utf8CheckIncomplete(self, buf, i) {
      let j = buf.length - 1;
      if (j < i)
        return 0;
      let nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0)
          self.lastNeed = nb - 1;
        return nb;
      }
      if (--j < i || nb === -2)
        return 0;
      nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0)
          self.lastNeed = nb - 2;
        return nb;
      }
      if (--j < i || nb === -2)
        return 0;
      nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0) {
          if (nb === 2)
            nb = 0;
          else
            self.lastNeed = nb - 3;
        }
        return nb;
      }
      return 0;
    }
    function utf8CheckExtraBytes(self, buf) {
      if ((buf[0] & 192) !== 128) {
        self.lastNeed = 0;
        return "\ufffd";
      }
      if (self.lastNeed > 1 && buf.length > 1) {
        if ((buf[1] & 192) !== 128) {
          self.lastNeed = 1;
          return "\ufffd";
        }
        if (self.lastNeed > 2 && buf.length > 2) {
          if ((buf[2] & 192) !== 128) {
            self.lastNeed = 2;
            return "\ufffd";
          }
        }
      }
    }
    function utf8FillLast(buf) {
      const p = this.lastTotal - this.lastNeed;
      const r = utf8CheckExtraBytes(this, buf);
      if (r !== undefined)
        return r;
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, p, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, p, 0, buf.length);
      this.lastNeed -= buf.length;
    }
    function utf8Text(buf, i) {
      const total = utf8CheckIncomplete(this, buf, i);
      if (!this.lastNeed)
        return buf.toString("utf8", i);
      this.lastTotal = total;
      const end = buf.length - (total - this.lastNeed);
      buf.copy(this.lastChar, 0, end);
      return buf.toString("utf8", i, end);
    }
    function utf8End(buf) {
      const r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed)
        return r + "\ufffd";
      return r;
    }
    function utf16Text(buf, i) {
      if ((buf.length - i) % 2 === 0) {
        const r = buf.toString("utf16le", i);
        if (r) {
          const c = r.charCodeAt(r.length - 1);
          if (c >= 55296 && c <= 56319) {
            this.lastNeed = 2;
            this.lastTotal = 4;
            this.lastChar[0] = buf[buf.length - 2];
            this.lastChar[1] = buf[buf.length - 1];
            return r.slice(0, -1);
          }
        }
        return r;
      }
      this.lastNeed = 1;
      this.lastTotal = 2;
      this.lastChar[0] = buf[buf.length - 1];
      return buf.toString("utf16le", i, buf.length - 1);
    }
    function utf16End(buf) {
      const r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) {
        const end = this.lastTotal - this.lastNeed;
        return r + this.lastChar.toString("utf16le", 0, end);
      }
      return r;
    }
    function base64Text(buf, i) {
      const n = (buf.length - i) % 3;
      if (n === 0)
        return buf.toString("base64", i);
      this.lastNeed = 3 - n;
      this.lastTotal = 3;
      if (n === 1) {
        this.lastChar[0] = buf[buf.length - 1];
      } else {
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
      }
      return buf.toString("base64", i, buf.length - n);
    }
    function base64End(buf) {
      const r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed)
        return r + this.lastChar.toString("base64", 0, 3 - this.lastNeed);
      return r;
    }
    function simpleWrite(buf) {
      return buf.toString(this.encoding);
    }
    function simpleEnd(buf) {
      return buf && buf.length ? this.write(buf) : "";
    }
    exports.StringDecoder = StringDecoder;
  }

  // third_party/node/lib/timers/promises.js
  function promises_default2(exports, require2, module, process, internalBinding, primordials2) {
    const G = globalThis;
    function abortError(signal) {
      if (signal && signal.reason !== undefined)
        return signal.reason;
      const err = new Error("The operation was aborted");
      err.name = "AbortError";
      err.code = "ABORT_ERR";
      return err;
    }
    function setTimeout(after = 1, value, options = {}) {
      const { signal, ref = true } = options;
      return new Promise((resolve2, reject) => {
        if (signal && signal.aborted)
          return reject(abortError(signal));
        const cleanup = () => signal && signal.removeEventListener("abort", onAbort);
        const onAbort = () => {
          G.clearTimeout(timer);
          cleanup();
          reject(abortError(signal));
        };
        const timer = G.setTimeout(() => {
          cleanup();
          resolve2(value);
        }, after);
        if (ref === false && timer && typeof timer.unref === "function")
          timer.unref();
        if (signal)
          signal.addEventListener("abort", onAbort, { once: true });
      });
    }
    function setImmediate(value, options = {}) {
      const { signal, ref = true } = options;
      const set = G.setImmediate || ((fn) => G.setTimeout(fn, 0));
      const clear = G.clearImmediate || G.clearTimeout;
      return new Promise((resolve2, reject) => {
        if (signal && signal.aborted)
          return reject(abortError(signal));
        const cleanup = () => signal && signal.removeEventListener("abort", onAbort);
        const onAbort = () => {
          clear(timer);
          cleanup();
          reject(abortError(signal));
        };
        const timer = set(() => {
          cleanup();
          resolve2(value);
        });
        if (ref === false && timer && typeof timer.unref === "function")
          timer.unref();
        if (signal)
          signal.addEventListener("abort", onAbort, { once: true });
      });
    }
    async function* setInterval(after = 1, value, options = {}) {
      const { signal } = options;
      if (signal && signal.aborted)
        throw abortError(signal);
      while (true) {
        await setTimeout(after, undefined, { signal });
        yield value;
      }
    }
    module.exports = { setTimeout, setImmediate, setInterval };
  }

  // third_party/node/lib/url.js
  function url_default(exports, require2, module) {
    const internalUrl = require2("internal/url");
    const URL = globalThis.URL;
    const URLSearchParams = globalThis.URLSearchParams;
    function parseQueryToObject(search) {
      const obj = {};
      if (!search)
        return obj;
      const sp = new URLSearchParams(search[0] === "?" ? search.slice(1) : search);
      for (const key of sp.keys()) {
        const all = sp.getAll(key);
        obj[key] = all.length > 1 ? all : all[0];
      }
      return obj;
    }
    function parse(urlStr, parseQueryString = false, slashesDenoteHost = false) {
      if (urlStr && typeof urlStr === "object")
        return urlStr;
      const str = String(urlStr);
      const isAbsolute = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(str) || slashesDenoteHost && str.startsWith("//");
      if (!isAbsolute) {
        let pathname = str;
        let search2 = null;
        let hash = null;
        const hashIdx = str.indexOf("#");
        if (hashIdx !== -1) {
          hash = str.slice(hashIdx);
          pathname = str.slice(0, hashIdx);
        }
        const qIdx = pathname.indexOf("?");
        if (qIdx !== -1) {
          search2 = pathname.slice(qIdx);
          pathname = pathname.slice(0, qIdx);
        }
        const query2 = parseQueryString ? parseQueryToObject(search2) : search2 ? search2.slice(1) : null;
        return {
          protocol: null,
          slashes: null,
          auth: null,
          host: null,
          port: null,
          hostname: null,
          hash,
          search: search2,
          query: query2,
          pathname: pathname || null,
          path: `${pathname || ""}${search2 || ""}` || null,
          href: str
        };
      }
      const u = new URL(str);
      const search = u.search || null;
      const query = parseQueryString ? parseQueryToObject(search) : search ? search.slice(1) : null;
      return {
        protocol: u.protocol,
        slashes: str.includes("//"),
        auth: u.username ? `${u.username}${u.password ? ":" + u.password : ""}` : null,
        host: u.host || null,
        port: u.port || null,
        hostname: u.hostname || null,
        hash: u.hash || null,
        search,
        query,
        pathname: u.pathname || null,
        path: `${u.pathname || ""}${search || ""}` || null,
        href: u.href
      };
    }
    function format(urlObj) {
      if (typeof urlObj === "string")
        return urlObj;
      if (urlObj instanceof URL)
        return urlObj.href;
      if (urlObj && typeof urlObj.href === "string" && urlObj.protocol)
        return urlObj.href;
      let out = "";
      if (urlObj.protocol)
        out += urlObj.protocol.endsWith(":") ? urlObj.protocol : urlObj.protocol + ":";
      if (urlObj.slashes || urlObj.host || urlObj.hostname)
        out += "//";
      if (urlObj.auth)
        out += urlObj.auth + "@";
      if (urlObj.host)
        out += urlObj.host;
      else if (urlObj.hostname)
        out += urlObj.hostname + (urlObj.port ? ":" + urlObj.port : "");
      if (urlObj.pathname)
        out += urlObj.pathname;
      let search = urlObj.search;
      if (!search && urlObj.query) {
        search = typeof urlObj.query === "string" ? "?" + urlObj.query : "?" + new URLSearchParams(urlObj.query).toString();
      }
      if (search)
        out += search[0] === "?" ? search : "?" + search;
      if (urlObj.hash)
        out += urlObj.hash[0] === "#" ? urlObj.hash : "#" + urlObj.hash;
      return out;
    }
    function resolve2(from, to) {
      try {
        return new URL(to, from).href;
      } catch {
        return to;
      }
    }
    module.exports = {
      parse,
      format,
      resolve: resolve2,
      URL,
      URLSearchParams,
      domainToASCII: (d) => {
        try {
          return new URL("http://" + d).hostname;
        } catch {
          return "";
        }
      },
      domainToUnicode: (d) => d,
      fileURLToPath: internalUrl.fileURLToPath,
      pathToFileURL: internalUrl.pathToFileURL,
      urlToHttpOptions: internalUrl.urlToHttpOptions
    };
  }

  // third_party/node/lib/util.js
  function util_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayIsArray,
      ArrayPrototypePop,
      ArrayPrototypePush,
      Error: Error2,
      ErrorCaptureStackTrace,
      FunctionPrototypeBind,
      NumberIsSafeInteger,
      ObjectDefineProperties,
      ObjectDefineProperty,
      ObjectGetOwnPropertyDescriptors,
      ObjectGetOwnPropertyNames,
      ObjectKeys,
      ObjectSetPrototypeOf,
      ObjectValues,
      ReflectApply,
      RegExpPrototypeExec: RegExpPrototypeExec2,
      SafeMap,
      StringPrototypeSlice,
      StringPrototypeToWellFormed
    } = primordials2;
    const {
      ErrnoException,
      ExceptionWithHostPort,
      codes: {
        ERR_FALSY_VALUE_REJECTION,
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_ARG_VALUE,
        ERR_OUT_OF_RANGE
      },
      isErrorStackTraceLimitWritable
    } = require2("internal/errors");
    const { Buffer } = require2("buffer");
    const {
      format,
      formatWithOptions,
      inspect,
      stripVTControlCharacters
    } = require2("internal/util/inspect");
    const { debuglog } = require2("internal/util/debuglog");
    const {
      validateBoolean,
      validateFunction,
      validateNumber,
      validateString,
      validateOneOf,
      validateObject,
      validateInteger
    } = require2("internal/validators");
    const {
      isReadableStream,
      isWritableStream,
      isNodeStream
    } = require2("internal/streams/utils");
    const types = require2("internal/util/types");
    let utilColors;
    function lazyUtilColors() {
      utilColors ??= require2("internal/util/colors");
      return utilColors;
    }
    const { getOptionValue } = require2("internal/options");
    const binding = internalBinding("util");
    const {
      convertProcessSignalToExitCode,
      deprecate: internalDeprecate,
      getLazy,
      getSystemErrorMap,
      getSystemErrorName: internalErrorName,
      getSystemErrorMessage: internalErrorMessage,
      promisify,
      defineLazyProperties
    } = require2("internal/util");
    let abortController;
    function lazyAbortController() {
      abortController ??= require2("internal/abort_controller");
      return abortController;
    }
    let internalDeepEqual;
    const kEscape = "\x1B[";
    const kEscapeEnd = "m";
    const kDimCode = 2;
    const kBoldCode = 1;
    const kHexCloseSeq = kEscape + "39" + kEscapeEnd;
    let styleCache;
    const kHexStyleCacheMax = 256;
    let hexStyleCache;
    function getHexStyleCache() {
      hexStyleCache ??= new SafeMap;
      return hexStyleCache;
    }
    function getStyleCache() {
      if (styleCache === undefined) {
        styleCache = { __proto__: null };
        const colors = inspect.colors;
        for (const key of ObjectGetOwnPropertyNames(colors)) {
          const codes = colors[key];
          if (codes) {
            const openNum = codes[0];
            const closeNum = codes[1];
            styleCache[key] = {
              __proto__: null,
              openSeq: kEscape + openNum + kEscapeEnd,
              closeSeq: kEscape + closeNum + kEscapeEnd,
              keepClose: openNum === kDimCode || openNum === kBoldCode
            };
          }
        }
      }
      return styleCache;
    }
    function getHexStyle(hex) {
      const cache2 = getHexStyleCache();
      const cached = cache2.get(hex);
      if (cached !== undefined)
        return cached;
      const { 0: r, 1: g, 2: b } = hexToRgb(hex);
      const style = {
        __proto__: null,
        openSeq: kEscape + rgbToAnsi24Bit(r, g, b) + kEscapeEnd,
        closeSeq: kHexCloseSeq
      };
      if (cache2.size >= kHexStyleCacheMax)
        cache2.delete(cache2.keys().next().value);
      cache2.set(hex, style);
      return style;
    }
    function replaceCloseCode(str, closeSeq, openSeq, keepClose) {
      const closeLen = closeSeq.length;
      let index = str.indexOf(closeSeq);
      if (index === -1)
        return str;
      let result = "";
      let lastIndex = 0;
      const replacement = keepClose ? closeSeq + openSeq : openSeq;
      do {
        const afterClose = index + closeLen;
        if (afterClose < str.length) {
          result += str.slice(lastIndex, index) + replacement;
          lastIndex = afterClose;
        } else {
          break;
        }
        index = str.indexOf(closeSeq, lastIndex);
      } while (index !== -1);
      return result + str.slice(lastIndex);
    }
    const hexColorRegExp = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
    function hexToRgb(hex) {
      let hexStr;
      if (hex.length === 4) {
        hexStr = hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
      } else if (hex.length === 7) {
        hexStr = StringPrototypeSlice(hex, 1);
      } else {
        throw new ERR_OUT_OF_RANGE("hex", "#RGB or #RRGGBB", hex);
      }
      return Buffer.from(hexStr, "hex");
    }
    function rgbToAnsi24Bit(r, g, b) {
      return `38;2;${r};${g};${b}`;
    }
    function styleText(format2, text, options) {
      const validateStream = options?.validateStream ?? true;
      const cache2 = getStyleCache();
      if (!validateStream && typeof format2 === "string" && typeof text === "string") {
        if (format2 === "none")
          return text;
        const style = cache2[format2];
        if (style !== undefined) {
          const processed = replaceCloseCode(text, style.closeSeq, style.openSeq, style.keepClose);
          return style.openSeq + processed + style.closeSeq;
        }
        if (format2[0] === "#") {
          let hexStyle = getHexStyleCache().get(format2);
          if (hexStyle === undefined && RegExpPrototypeExec2(hexColorRegExp, format2) !== null) {
            hexStyle = getHexStyle(format2);
          }
          if (hexStyle !== undefined) {
            const processed = replaceCloseCode(text, hexStyle.closeSeq, hexStyle.openSeq, false);
            return hexStyle.openSeq + processed + hexStyle.closeSeq;
          }
        }
      }
      validateString(text, "text");
      if (options !== undefined) {
        validateObject(options, "options");
      }
      validateBoolean(validateStream, "options.validateStream");
      let skipColorize;
      if (validateStream) {
        const stream = options?.stream ?? process.stdout;
        if (!isReadableStream(stream) && !isWritableStream(stream) && !isNodeStream(stream)) {
          throw new ERR_INVALID_ARG_TYPE("stream", ["ReadableStream", "WritableStream", "Stream"], stream);
        }
        skipColorize = !lazyUtilColors().shouldColorize(stream);
      }
      const formatArray = ArrayIsArray(format2) ? format2 : [format2];
      let openCodes = "";
      let closeCodes = "";
      let processedText = text;
      for (const key of formatArray) {
        if (key === "none")
          continue;
        if (typeof key === "string" && key[0] === "#") {
          let hexStyle = getHexStyleCache().get(key);
          if (hexStyle === undefined) {
            if (RegExpPrototypeExec2(hexColorRegExp, key) === null) {
              throw new ERR_INVALID_ARG_VALUE("format", key, "must be a valid hex color (#RGB or #RRGGBB)");
            }
            if (skipColorize)
              continue;
            hexStyle = getHexStyle(key);
          } else if (skipColorize) {
            continue;
          }
          openCodes += hexStyle.openSeq;
          closeCodes = hexStyle.closeSeq + closeCodes;
          processedText = replaceCloseCode(processedText, hexStyle.closeSeq, hexStyle.openSeq, false);
          continue;
        }
        const style = cache2[key];
        if (style === undefined) {
          validateOneOf(key, "format", ObjectGetOwnPropertyNames(inspect.colors));
        }
        openCodes += style.openSeq;
        closeCodes = style.closeSeq + closeCodes;
        processedText = replaceCloseCode(processedText, style.closeSeq, style.openSeq, style.keepClose);
      }
      if (skipColorize)
        return text;
      return `${openCodes}${processedText}${closeCodes}`;
    }
    function inherits(ctor, superCtor) {
      if (ctor === undefined || ctor === null)
        throw new ERR_INVALID_ARG_TYPE("ctor", "Function", ctor);
      if (superCtor === undefined || superCtor === null)
        throw new ERR_INVALID_ARG_TYPE("superCtor", "Function", superCtor);
      if (superCtor.prototype === undefined) {
        throw new ERR_INVALID_ARG_TYPE("superCtor.prototype", "Object", superCtor.prototype);
      }
      ObjectDefineProperty(ctor, "super_", {
        __proto__: null,
        value: superCtor,
        writable: true,
        configurable: true
      });
      ObjectSetPrototypeOf(ctor.prototype, superCtor.prototype);
    }
    function _extend(target, source) {
      if (source === null || typeof source !== "object")
        return target;
      const keys = ObjectKeys(source);
      let i = keys.length;
      while (i--) {
        target[keys[i]] = source[keys[i]];
      }
      return target;
    }
    const callbackifyOnRejected = (reason, cb) => {
      if (!reason) {
        reason = new ERR_FALSY_VALUE_REJECTION.HideStackFramesError(reason);
        ErrorCaptureStackTrace(reason, callbackifyOnRejected);
      }
      return cb(reason);
    };
    function callbackify(original) {
      validateFunction(original, "original");
      function callbackified(...args) {
        const maybeCb = ArrayPrototypePop(args);
        validateFunction(maybeCb, "last argument");
        const cb = FunctionPrototypeBind(maybeCb, this);
        ReflectApply(original, this, args).then((ret) => process.nextTick(cb, null, ret), (rej) => process.nextTick(callbackifyOnRejected, rej, cb));
      }
      const descriptors = ObjectGetOwnPropertyDescriptors(original);
      if (typeof descriptors.length.value === "number") {
        descriptors.length.value++;
      }
      if (typeof descriptors.name.value === "string") {
        descriptors.name.value += "Callbackified";
      }
      const propertiesValues = ObjectValues(descriptors);
      for (let i = 0;i < propertiesValues.length; i++) {
        ObjectSetPrototypeOf(propertiesValues[i], null);
      }
      ObjectDefineProperties(callbackified, descriptors);
      return callbackified;
    }
    function getSystemErrorMessage(err) {
      validateNumber(err, "err");
      if (err >= 0 || !NumberIsSafeInteger(err)) {
        throw new ERR_OUT_OF_RANGE("err", "a negative integer", err);
      }
      return internalErrorMessage(err);
    }
    function getSystemErrorName(err) {
      validateNumber(err, "err");
      if (err >= 0 || !NumberIsSafeInteger(err)) {
        throw new ERR_OUT_OF_RANGE("err", "a negative integer", err);
      }
      return internalErrorName(err);
    }
    function _errnoException(...args) {
      if (isErrorStackTraceLimitWritable()) {
        const limit = Error2.stackTraceLimit;
        Error2.stackTraceLimit = 0;
        const e = new ErrnoException(...args);
        Error2.stackTraceLimit = limit;
        ErrorCaptureStackTrace(e, _errnoException);
        return e;
      }
      return new ErrnoException(...args);
    }
    function _exceptionWithHostPort(...args) {
      if (isErrorStackTraceLimitWritable()) {
        const limit = Error2.stackTraceLimit;
        Error2.stackTraceLimit = 0;
        const e = new ExceptionWithHostPort(...args);
        Error2.stackTraceLimit = limit;
        ErrorCaptureStackTrace(e, _exceptionWithHostPort);
        return e;
      }
      return new ExceptionWithHostPort(...args);
    }
    function parseEnv(content) {
      validateString(content, "content");
      return binding.parseEnv(content);
    }
    const lazySourceMap = getLazy(() => require2("internal/source_map/source_map_cache"));
    function reconstructCallSite(callSite) {
      const { scriptName, lineNumber, columnNumber } = callSite;
      const sourceMap = lazySourceMap().findSourceMap(scriptName);
      if (!sourceMap)
        return;
      const entry = sourceMap.findEntry(lineNumber - 1, columnNumber - 1);
      if (!entry?.originalSource)
        return;
      return {
        __proto__: null,
        functionName: entry.name ?? "",
        scriptName: entry.originalSource,
        lineNumber: entry.originalLine + 1,
        column: entry.originalColumn + 1,
        columnNumber: entry.originalColumn + 1
      };
    }
    function mapCallSite(callSites) {
      const result = [];
      for (let i = 0;i < callSites.length; ++i) {
        const callSite = callSites[i];
        const found = reconstructCallSite(callSite);
        ArrayPrototypePush(result, found ?? callSite);
      }
      return result;
    }
    function getCallSites(frameCount = 10, options) {
      if (options === undefined) {
        if (typeof frameCount === "object") {
          options = frameCount;
          validateObject(options, "options");
          if (options.sourceMap !== undefined) {
            validateBoolean(options.sourceMap, "options.sourceMap");
          }
          frameCount = 10;
        } else {
          options = {};
        }
      } else {
        validateObject(options, "options");
        if (options.sourceMap !== undefined) {
          validateBoolean(options.sourceMap, "options.sourceMap");
        }
      }
      validateInteger(frameCount, "frameCount", 1, 200);
      if (options.sourceMap === true || getOptionValue("--enable-source-maps") && options.sourceMap !== false) {
        return mapCallSite(binding.getCallSites(frameCount));
      }
      return binding.getCallSites(frameCount);
    }
    function deprecate(fn, msg, code, { modifyPrototype } = {}) {
      return internalDeprecate(fn, msg, code, undefined, modifyPrototype);
    }
    module.exports = {
      _errnoException,
      _exceptionWithHostPort,
      _extend: internalDeprecate(_extend, "The `util._extend` API is deprecated. Please use Object.assign() instead.", "DEP0060"),
      callbackify,
      convertProcessSignalToExitCode,
      debug: debuglog,
      debuglog,
      deprecate,
      format,
      styleText,
      formatWithOptions,
      getCallSites,
      getSystemErrorMap,
      getSystemErrorName,
      getSystemErrorMessage,
      inherits,
      inspect,
      isArray: internalDeprecate(ArrayIsArray, "The `util.isArray` API is deprecated. Please use `Array.isArray()` instead.", "DEP0044"),
      isDeepStrictEqual(a, b, skipPrototype) {
        if (internalDeepEqual === undefined) {
          internalDeepEqual = require2("internal/util/comparisons").isDeepStrictEqual;
        }
        return internalDeepEqual(a, b, skipPrototype);
      },
      promisify,
      stripVTControlCharacters,
      toUSVString(input) {
        return StringPrototypeToWellFormed(`${input}`);
      },
      get transferableAbortSignal() {
        return lazyAbortController().transferableAbortSignal;
      },
      get transferableAbortController() {
        return lazyAbortController().transferableAbortController;
      },
      get aborted() {
        return lazyAbortController().aborted;
      },
      types,
      parseEnv
    };
    defineLazyProperties(module.exports, "internal/util/parse_args/parse_args", ["parseArgs"]);
    defineLazyProperties(module.exports, "internal/encoding", ["TextDecoder", "TextEncoder"]);
    defineLazyProperties(module.exports, "internal/mime", ["MIMEType", "MIMEParams"]);
    defineLazyProperties(module.exports, "internal/util/diff", ["diff"]);
    defineLazyProperties(module.exports, "internal/util/trace_sigint", ["setTraceSigInt"]);
  }

  // third_party/node/internal/abort_controller.js
  function abort_controller_default(exports, require2, module, process, internalBinding, primordials2) {
    const notSupported = () => {
      throw new Error("Vivari: transferable AbortController is not supported");
    };
    module.exports = {
      AbortController: globalThis.AbortController,
      AbortSignal: globalThis.AbortSignal,
      transferableAbortController: notSupported,
      transferableAbortSignal: notSupported,
      aborted: (signal) => new Promise((resolve2) => {
        if (signal.aborted)
          return resolve2();
        signal.addEventListener("abort", () => resolve2(), { once: true });
      })
    };
  }

  // third_party/node/internal/assert/myers_diff.js
  function myers_diff_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypePush,
      Int32Array: Int32Array2,
      StringPrototypeEndsWith
    } = primordials2;
    const {
      codes: {
        ERR_OUT_OF_RANGE
      }
    } = require2("internal/errors");
    const colors = require2("internal/util/colors");
    const kNopLinesToCollapse = 5;
    const kOperations = {
      DELETE: -1,
      NOP: 0,
      INSERT: 1
    };
    function areLinesEqual(actual, expected, checkCommaDisparity) {
      if (actual === expected) {
        return true;
      }
      if (checkCommaDisparity) {
        return actual + "," === expected || actual === expected + ",";
      }
      return false;
    }
    function myersDiff(actual, expected, checkCommaDisparity = false) {
      const actualLength = actual.length;
      const expectedLength = expected.length;
      const max = actualLength + expectedLength;
      if (max > 2 ** 31 - 1) {
        throw new ERR_OUT_OF_RANGE("myersDiff input size", "< 2^31", max);
      }
      const v = new Int32Array2(2 * max + 1);
      const trace = [];
      for (let diffLevel = 0;diffLevel <= max; diffLevel++) {
        ArrayPrototypePush(trace, new Int32Array2(v));
        for (let diagonalIndex = -diffLevel;diagonalIndex <= diffLevel; diagonalIndex += 2) {
          const offset = diagonalIndex + max;
          const previousOffset = v[offset - 1];
          const nextOffset = v[offset + 1];
          let x = diagonalIndex === -diffLevel || diagonalIndex !== diffLevel && previousOffset < nextOffset ? nextOffset : previousOffset + 1;
          let y = x - diagonalIndex;
          while (x < actualLength && y < expectedLength && areLinesEqual(actual[x], expected[y], checkCommaDisparity)) {
            x++;
            y++;
          }
          v[offset] = x;
          if (x >= actualLength && y >= expectedLength) {
            return backtrack(trace, actual, expected, checkCommaDisparity);
          }
        }
      }
    }
    function backtrack(trace, actual, expected, checkCommaDisparity) {
      const actualLength = actual.length;
      const expectedLength = expected.length;
      const max = actualLength + expectedLength;
      let x = actualLength;
      let y = expectedLength;
      const result = [];
      for (let diffLevel = trace.length - 1;diffLevel >= 0; diffLevel--) {
        const v = trace[diffLevel];
        const diagonalIndex = x - y;
        const offset = diagonalIndex + max;
        let prevDiagonalIndex;
        if (diagonalIndex === -diffLevel || diagonalIndex !== diffLevel && v[offset - 1] < v[offset + 1]) {
          prevDiagonalIndex = diagonalIndex + 1;
        } else {
          prevDiagonalIndex = diagonalIndex - 1;
        }
        const prevX = v[prevDiagonalIndex + max];
        const prevY = prevX - prevDiagonalIndex;
        while (x > prevX && y > prevY) {
          const actualItem = actual[x - 1];
          const value = checkCommaDisparity && !StringPrototypeEndsWith(actualItem, ",") ? expected[y - 1] : actualItem;
          ArrayPrototypePush(result, [kOperations.NOP, value]);
          x--;
          y--;
        }
        if (diffLevel > 0) {
          if (x > prevX) {
            ArrayPrototypePush(result, [kOperations.INSERT, actual[--x]]);
          } else {
            ArrayPrototypePush(result, [kOperations.DELETE, expected[--y]]);
          }
        }
      }
      return result;
    }
    function printSimpleMyersDiff(diff) {
      let message = "";
      for (let diffIdx = diff.length - 1;diffIdx >= 0; diffIdx--) {
        const { 0: operation, 1: value } = diff[diffIdx];
        let color = colors.white;
        if (operation === kOperations.INSERT) {
          color = colors.green;
        } else if (operation === kOperations.DELETE) {
          color = colors.red;
        }
        message += `${color}${value}${colors.white}`;
      }
      return `
${message}`;
    }
    function printMyersDiff(diff, operator) {
      let message = "";
      let skipped = false;
      let nopCount = 0;
      for (let diffIdx = diff.length - 1;diffIdx >= 0; diffIdx--) {
        const { 0: operation, 1: value } = diff[diffIdx];
        const previousOperation = diffIdx < diff.length - 1 ? diff[diffIdx + 1][0] : null;
        if (previousOperation === kOperations.NOP && operation !== previousOperation) {
          if (nopCount === kNopLinesToCollapse + 1) {
            message += `${colors.white}  ${diff[diffIdx + 1][1]}
`;
          } else if (nopCount === kNopLinesToCollapse + 2) {
            message += `${colors.white}  ${diff[diffIdx + 2][1]}
`;
            message += `${colors.white}  ${diff[diffIdx + 1][1]}
`;
          } else if (nopCount >= kNopLinesToCollapse + 3) {
            message += `${colors.blue}...${colors.white}
`;
            message += `${colors.white}  ${diff[diffIdx + 1][1]}
`;
            skipped = true;
          }
          nopCount = 0;
        }
        if (operation === kOperations.INSERT) {
          if (operator === "partialDeepStrictEqual") {
            message += `${colors.gray}${colors.hasColors ? " " : "+"} ${value}${colors.white}
`;
          } else {
            message += `${colors.green}+${colors.white} ${value}
`;
          }
        } else if (operation === kOperations.DELETE) {
          message += `${colors.red}-${colors.white} ${value}
`;
        } else if (operation === kOperations.NOP) {
          if (nopCount < kNopLinesToCollapse) {
            message += `${colors.white}  ${value}
`;
          }
          nopCount++;
        }
      }
      message = message.trimEnd();
      return { message: `
${message}`, skipped };
    }
    module.exports = { myersDiff, printMyersDiff, printSimpleMyersDiff };
  }

  // third_party/node/internal/assert.js
  function assert_default2(exports, require2, module, process, internalBinding, primordials2) {
    function assert(value, message) {
      if (!value) {
        throw new Error(message || "Vivari internal assertion failed");
      }
    }
    assert.ok = assert;
    assert.fail = (message) => {
      throw new Error(message || "Vivari internal assertion failed");
    };
    module.exports = assert;
  }

  // third_party/node/internal/blob.js
  function blob_default(exports, require2, module, process, internalBinding, primordials2) {
    module.exports = {
      Blob: globalThis.Blob,
      resolveObjectURL() {
        return;
      },
      createBlobFromFilePath() {
        throw new Error("Vivari: fs.openAsBlob() is not supported yet");
      }
    };
  }

  // third_party/node/internal/buffer.js
  function buffer_default2(exports, require2, module, process, internalBinding, primordials2) {
    const {
      BigInt: BigInt2,
      Float32Array: Float32Array2,
      Float64Array: Float64Array2,
      MathFloor,
      Number: Number2,
      Symbol: Symbol2,
      Uint8Array: Uint8Array2
    } = primordials2;
    const {
      ERR_BUFFER_OUT_OF_BOUNDS,
      ERR_INVALID_ARG_TYPE,
      ERR_OUT_OF_RANGE
    } = require2("internal/errors").codes;
    const { validateNumber } = require2("internal/validators");
    const { isArrayBuffer } = require2("util/types");
    const {
      asciiSlice: asciiSlice2,
      base64Slice: base64Slice2,
      base64urlSlice: base64urlSlice2,
      latin1Slice: latin1Slice2,
      hexSlice: hexSlice2,
      ucs2Slice: ucs2Slice2,
      utf8Slice: utf8Slice2,
      asciiWriteStatic: asciiWriteStatic2,
      base64Write: base64Write2,
      base64urlWrite: base64urlWrite2,
      latin1WriteStatic: latin1WriteStatic2,
      hexWrite: hexWrite2,
      ucs2Write: ucs2Write2,
      utf8WriteStatic: utf8WriteStatic2,
      createUnsafeArrayBuffer,
      setDetachKey
    } = internalBinding("buffer");
    const {
      privateSymbols: {
        untransferable_object_private_symbol
      }
    } = internalBinding("util");
    const float32Array = new Float32Array2(1);
    const uInt8Float32Array = new Uint8Array2(float32Array.buffer);
    const float64Array = new Float64Array2(1);
    const uInt8Float64Array = new Uint8Array2(float64Array.buffer);
    float32Array[0] = -1;
    const bigEndian = uInt8Float32Array[3] === 0;
    function checkBounds(buf, offset, byteLength) {
      validateNumber(offset, "offset");
      if (buf[offset] === undefined || buf[offset + byteLength] === undefined)
        boundsError(offset, buf.length - (byteLength + 1));
    }
    function checkInt(value, min, max, buf, offset, byteLength) {
      if (value > max || value < min) {
        const n = typeof min === "bigint" ? "n" : "";
        let range;
        if (byteLength > 3) {
          if (min === 0 || min === 0n) {
            range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`;
          } else {
            range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and ` + `< 2${n} ** ${(byteLength + 1) * 8 - 1}${n}`;
          }
        } else {
          range = `>= ${min}${n} and <= ${max}${n}`;
        }
        throw new ERR_OUT_OF_RANGE("value", range, value);
      }
      checkBounds(buf, offset, byteLength);
    }
    function boundsError(value, length, type) {
      if (MathFloor(value) !== value) {
        validateNumber(value, type);
        throw new ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
      }
      if (length < 0)
        throw new ERR_BUFFER_OUT_OF_BOUNDS;
      throw new ERR_OUT_OF_RANGE(type || "offset", `>= ${type ? 1 : 0} and <= ${length}`, value);
    }
    function readBigUInt64LE(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
      const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
      return BigInt2(lo) + (BigInt2(hi) << 32n);
    }
    function readBigUInt64BE(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
      const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
      return (BigInt2(hi) << 32n) + BigInt2(lo);
    }
    function readBigInt64LE(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
      return (BigInt2(val) << 32n) + BigInt2(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
    }
    function readBigInt64BE(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      const val = (first << 24) + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
      return (BigInt2(val) << 32n) + BigInt2(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
    }
    function readUIntLE(offset, byteLength) {
      if (offset === undefined)
        throw new ERR_INVALID_ARG_TYPE("offset", "number", offset);
      if (byteLength === 6)
        return readUInt48LE(this, offset);
      if (byteLength === 5)
        return readUInt40LE(this, offset);
      if (byteLength === 3)
        return readUInt24LE(this, offset);
      if (byteLength === 4)
        return readUInt32LE(this, offset);
      if (byteLength === 2)
        return readUInt16LE(this, offset);
      if (byteLength === 1)
        return readUInt8(this, offset);
      boundsError(byteLength, 6, "byteLength");
    }
    function readUInt48LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 5];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 6);
      return first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 24 + (buf[++offset] + last * 2 ** 8) * 2 ** 32;
    }
    function readUInt40LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 4];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 5);
      return first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 24 + last * 2 ** 32;
    }
    function readUInt32LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 4);
      return first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + last * 2 ** 24;
    }
    function readUInt24LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 2];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 3);
      return first + buf[++offset] * 2 ** 8 + last * 2 ** 16;
    }
    function readUInt16LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 1];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 2);
      return first + last * 2 ** 8;
    }
    function readUInt8(buf, offset = 0) {
      validateNumber(offset, "offset");
      const val = buf[offset];
      if (val === undefined)
        boundsError(offset, buf.length - 1);
      return val;
    }
    function readUIntBE(offset, byteLength) {
      if (offset === undefined)
        throw new ERR_INVALID_ARG_TYPE("offset", "number", offset);
      if (byteLength === 6)
        return readUInt48BE(this, offset);
      if (byteLength === 5)
        return readUInt40BE(this, offset);
      if (byteLength === 3)
        return readUInt24BE(this, offset);
      if (byteLength === 4)
        return readUInt32BE(this, offset);
      if (byteLength === 2)
        return readUInt16BE(this, offset);
      if (byteLength === 1)
        return readUInt8(this, offset);
      boundsError(byteLength, 6, "byteLength");
    }
    function readUInt48BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 5];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 6);
      return (first * 2 ** 8 + buf[++offset]) * 2 ** 32 + buf[++offset] * 2 ** 24 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readUInt40BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 4];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 5);
      return first * 2 ** 32 + buf[++offset] * 2 ** 24 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readUInt32BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 4);
      return first * 2 ** 24 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readUInt24BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 2];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 3);
      return first * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readUInt16BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 1];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 2);
      return first * 2 ** 8 + last;
    }
    function readIntLE(offset, byteLength) {
      if (offset === undefined)
        throw new ERR_INVALID_ARG_TYPE("offset", "number", offset);
      if (byteLength === 6)
        return readInt48LE(this, offset);
      if (byteLength === 5)
        return readInt40LE(this, offset);
      if (byteLength === 3)
        return readInt24LE(this, offset);
      if (byteLength === 4)
        return readInt32LE(this, offset);
      if (byteLength === 2)
        return readInt16LE(this, offset);
      if (byteLength === 1)
        return readInt8(this, offset);
      boundsError(byteLength, 6, "byteLength");
    }
    function readInt48LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 5];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 6);
      const val = buf[offset + 4] + last * 2 ** 8;
      return (val | (val & 2 ** 15) * 131070) * 2 ** 32 + first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 24;
    }
    function readInt40LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 4];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 5);
      return (last | (last & 2 ** 7) * 33554430) * 2 ** 32 + first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 24;
    }
    function readInt32LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 4);
      return first + buf[++offset] * 2 ** 8 + buf[++offset] * 2 ** 16 + (last << 24);
    }
    function readInt24LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 2];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 3);
      const val = first + buf[++offset] * 2 ** 8 + last * 2 ** 16;
      return val | (val & 2 ** 23) * 510;
    }
    function readInt16LE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 1];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 2);
      const val = first + last * 2 ** 8;
      return val | (val & 2 ** 15) * 131070;
    }
    function readInt8(buf, offset = 0) {
      validateNumber(offset, "offset");
      const val = buf[offset];
      if (val === undefined)
        boundsError(offset, buf.length - 1);
      return val | (val & 2 ** 7) * 33554430;
    }
    function readIntBE(offset, byteLength) {
      if (offset === undefined)
        throw new ERR_INVALID_ARG_TYPE("offset", "number", offset);
      if (byteLength === 6)
        return readInt48BE(this, offset);
      if (byteLength === 5)
        return readInt40BE(this, offset);
      if (byteLength === 3)
        return readInt24BE(this, offset);
      if (byteLength === 4)
        return readInt32BE(this, offset);
      if (byteLength === 2)
        return readInt16BE(this, offset);
      if (byteLength === 1)
        return readInt8(this, offset);
      boundsError(byteLength, 6, "byteLength");
    }
    function readInt48BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 5];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 6);
      const val = buf[++offset] + first * 2 ** 8;
      return (val | (val & 2 ** 15) * 131070) * 2 ** 32 + buf[++offset] * 2 ** 24 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readInt40BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 4];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 5);
      return (first | (first & 2 ** 7) * 33554430) * 2 ** 32 + buf[++offset] * 2 ** 24 + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readInt32BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 4);
      return (first << 24) + buf[++offset] * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
    }
    function readInt24BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 2];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 3);
      const val = first * 2 ** 16 + buf[++offset] * 2 ** 8 + last;
      return val | (val & 2 ** 23) * 510;
    }
    function readInt16BE(buf, offset = 0) {
      validateNumber(offset, "offset");
      const first = buf[offset];
      const last = buf[offset + 1];
      if (first === undefined || last === undefined)
        boundsError(offset, buf.length - 2);
      const val = first * 2 ** 8 + last;
      return val | (val & 2 ** 15) * 131070;
    }
    function readFloatBackwards(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 4);
      uInt8Float32Array[3] = first;
      uInt8Float32Array[2] = this[++offset];
      uInt8Float32Array[1] = this[++offset];
      uInt8Float32Array[0] = last;
      return float32Array[0];
    }
    function readFloatForwards(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 3];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 4);
      uInt8Float32Array[0] = first;
      uInt8Float32Array[1] = this[++offset];
      uInt8Float32Array[2] = this[++offset];
      uInt8Float32Array[3] = last;
      return float32Array[0];
    }
    function readDoubleBackwards(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      uInt8Float64Array[7] = first;
      uInt8Float64Array[6] = this[++offset];
      uInt8Float64Array[5] = this[++offset];
      uInt8Float64Array[4] = this[++offset];
      uInt8Float64Array[3] = this[++offset];
      uInt8Float64Array[2] = this[++offset];
      uInt8Float64Array[1] = this[++offset];
      uInt8Float64Array[0] = last;
      return float64Array[0];
    }
    function readDoubleForwards(offset = 0) {
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === undefined || last === undefined)
        boundsError(offset, this.length - 8);
      uInt8Float64Array[0] = first;
      uInt8Float64Array[1] = this[++offset];
      uInt8Float64Array[2] = this[++offset];
      uInt8Float64Array[3] = this[++offset];
      uInt8Float64Array[4] = this[++offset];
      uInt8Float64Array[5] = this[++offset];
      uInt8Float64Array[6] = this[++offset];
      uInt8Float64Array[7] = last;
      return float64Array[0];
    }
    function writeBigU_Int64LE(buf, value, offset, min, max) {
      checkInt(value, min, max, buf, offset, 7);
      let lo = Number2(value & 0xffffffffn);
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      let hi = Number2(value >> 32n & 0xffffffffn);
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      return offset;
    }
    function writeBigUInt64LE(value, offset = 0) {
      return writeBigU_Int64LE(this, value, offset, 0n, 0xffffffffffffffffn);
    }
    function writeBigU_Int64BE(buf, value, offset, min, max) {
      checkInt(value, min, max, buf, offset, 7);
      let lo = Number2(value & 0xffffffffn);
      buf[offset + 7] = lo;
      lo = lo >> 8;
      buf[offset + 6] = lo;
      lo = lo >> 8;
      buf[offset + 5] = lo;
      lo = lo >> 8;
      buf[offset + 4] = lo;
      let hi = Number2(value >> 32n & 0xffffffffn);
      buf[offset + 3] = hi;
      hi = hi >> 8;
      buf[offset + 2] = hi;
      hi = hi >> 8;
      buf[offset + 1] = hi;
      hi = hi >> 8;
      buf[offset] = hi;
      return offset + 8;
    }
    function writeBigUInt64BE(value, offset = 0) {
      return writeBigU_Int64BE(this, value, offset, 0n, 0xffffffffffffffffn);
    }
    function writeBigInt64LE(value, offset = 0) {
      return writeBigU_Int64LE(this, value, offset, -0x8000000000000000n, 0x7fffffffffffffffn);
    }
    function writeBigInt64BE(value, offset = 0) {
      return writeBigU_Int64BE(this, value, offset, -0x8000000000000000n, 0x7fffffffffffffffn);
    }
    function writeUIntLE(value, offset, byteLength) {
      if (byteLength === 6)
        return writeU_Int48LE(this, value, offset, 0, 281474976710655);
      if (byteLength === 5)
        return writeU_Int40LE(this, value, offset, 0, 1099511627775);
      if (byteLength === 3)
        return writeU_Int24LE(this, value, offset, 0, 16777215);
      if (byteLength === 4)
        return writeU_Int32LE(this, value, offset, 0, 4294967295);
      if (byteLength === 2)
        return writeU_Int16LE(this, value, offset, 0, 65535);
      if (byteLength === 1)
        return writeU_Int8(this, value, offset, 0, 255);
      boundsError(byteLength, 6, "byteLength");
    }
    function writeU_Int48LE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 5);
      const newVal = MathFloor(value * 2 ** -32);
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      buf[offset++] = newVal;
      buf[offset++] = newVal >>> 8;
      return offset;
    }
    function writeU_Int40LE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 4);
      const newVal = value;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      buf[offset++] = MathFloor(newVal * 2 ** -32);
      return offset;
    }
    function writeU_Int32LE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 3);
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      return offset;
    }
    function writeUInt32LE(value, offset = 0) {
      return writeU_Int32LE(this, value, offset, 0, 4294967295);
    }
    function writeU_Int24LE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 2);
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      value = value >>> 8;
      buf[offset++] = value;
      return offset;
    }
    function writeU_Int16LE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 1);
      buf[offset++] = value;
      buf[offset++] = value >>> 8;
      return offset;
    }
    function writeUInt16LE(value, offset = 0) {
      return writeU_Int16LE(this, value, offset, 0, 65535);
    }
    function writeU_Int8(buf, value, offset, min, max) {
      value = +value;
      validateNumber(offset, "offset");
      if (value > max || value < min) {
        throw new ERR_OUT_OF_RANGE("value", `>= ${min} and <= ${max}`, value);
      }
      if (buf[offset] === undefined)
        boundsError(offset, buf.length - 1);
      buf[offset] = value;
      return offset + 1;
    }
    function writeUInt8(value, offset = 0) {
      return writeU_Int8(this, value, offset, 0, 255);
    }
    function writeUIntBE(value, offset, byteLength) {
      if (byteLength === 6)
        return writeU_Int48BE(this, value, offset, 0, 281474976710655);
      if (byteLength === 5)
        return writeU_Int40BE(this, value, offset, 0, 1099511627775);
      if (byteLength === 3)
        return writeU_Int24BE(this, value, offset, 0, 16777215);
      if (byteLength === 4)
        return writeU_Int32BE(this, value, offset, 0, 4294967295);
      if (byteLength === 2)
        return writeU_Int16BE(this, value, offset, 0, 65535);
      if (byteLength === 1)
        return writeU_Int8(this, value, offset, 0, 255);
      boundsError(byteLength, 6, "byteLength");
    }
    function writeU_Int48BE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 5);
      const newVal = MathFloor(value * 2 ** -32);
      buf[offset++] = newVal >>> 8;
      buf[offset++] = newVal;
      buf[offset + 3] = value;
      value = value >>> 8;
      buf[offset + 2] = value;
      value = value >>> 8;
      buf[offset + 1] = value;
      value = value >>> 8;
      buf[offset] = value;
      return offset + 4;
    }
    function writeU_Int40BE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 4);
      buf[offset++] = MathFloor(value * 2 ** -32);
      buf[offset + 3] = value;
      value = value >>> 8;
      buf[offset + 2] = value;
      value = value >>> 8;
      buf[offset + 1] = value;
      value = value >>> 8;
      buf[offset] = value;
      return offset + 4;
    }
    function writeU_Int32BE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 3);
      buf[offset + 3] = value;
      value = value >>> 8;
      buf[offset + 2] = value;
      value = value >>> 8;
      buf[offset + 1] = value;
      value = value >>> 8;
      buf[offset] = value;
      return offset + 4;
    }
    function writeUInt32BE(value, offset = 0) {
      return writeU_Int32BE(this, value, offset, 0, 4294967295);
    }
    function writeU_Int24BE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 2);
      buf[offset + 2] = value;
      value = value >>> 8;
      buf[offset + 1] = value;
      value = value >>> 8;
      buf[offset] = value;
      return offset + 3;
    }
    function writeU_Int16BE(buf, value, offset, min, max) {
      value = +value;
      checkInt(value, min, max, buf, offset, 1);
      buf[offset++] = value >>> 8;
      buf[offset++] = value;
      return offset;
    }
    function writeUInt16BE(value, offset = 0) {
      return writeU_Int16BE(this, value, offset, 0, 65535);
    }
    function writeIntLE(value, offset, byteLength) {
      if (byteLength === 6)
        return writeU_Int48LE(this, value, offset, -140737488355328, 140737488355327);
      if (byteLength === 5)
        return writeU_Int40LE(this, value, offset, -549755813888, 549755813887);
      if (byteLength === 3)
        return writeU_Int24LE(this, value, offset, -8388608, 8388607);
      if (byteLength === 4)
        return writeU_Int32LE(this, value, offset, -2147483648, 2147483647);
      if (byteLength === 2)
        return writeU_Int16LE(this, value, offset, -32768, 32767);
      if (byteLength === 1)
        return writeU_Int8(this, value, offset, -128, 127);
      boundsError(byteLength, 6, "byteLength");
    }
    function writeInt32LE(value, offset = 0) {
      return writeU_Int32LE(this, value, offset, -2147483648, 2147483647);
    }
    function writeInt16LE(value, offset = 0) {
      return writeU_Int16LE(this, value, offset, -32768, 32767);
    }
    function writeInt8(value, offset = 0) {
      return writeU_Int8(this, value, offset, -128, 127);
    }
    function writeIntBE(value, offset, byteLength) {
      if (byteLength === 6)
        return writeU_Int48BE(this, value, offset, -140737488355328, 140737488355327);
      if (byteLength === 5)
        return writeU_Int40BE(this, value, offset, -549755813888, 549755813887);
      if (byteLength === 3)
        return writeU_Int24BE(this, value, offset, -8388608, 8388607);
      if (byteLength === 4)
        return writeU_Int32BE(this, value, offset, -2147483648, 2147483647);
      if (byteLength === 2)
        return writeU_Int16BE(this, value, offset, -32768, 32767);
      if (byteLength === 1)
        return writeU_Int8(this, value, offset, -128, 127);
      boundsError(byteLength, 6, "byteLength");
    }
    function writeInt32BE(value, offset = 0) {
      return writeU_Int32BE(this, value, offset, -2147483648, 2147483647);
    }
    function writeInt16BE(value, offset = 0) {
      return writeU_Int16BE(this, value, offset, -32768, 32767);
    }
    function writeDoubleForwards(val, offset = 0) {
      val = +val;
      checkBounds(this, offset, 7);
      float64Array[0] = val;
      this[offset++] = uInt8Float64Array[0];
      this[offset++] = uInt8Float64Array[1];
      this[offset++] = uInt8Float64Array[2];
      this[offset++] = uInt8Float64Array[3];
      this[offset++] = uInt8Float64Array[4];
      this[offset++] = uInt8Float64Array[5];
      this[offset++] = uInt8Float64Array[6];
      this[offset++] = uInt8Float64Array[7];
      return offset;
    }
    function writeDoubleBackwards(val, offset = 0) {
      val = +val;
      checkBounds(this, offset, 7);
      float64Array[0] = val;
      this[offset++] = uInt8Float64Array[7];
      this[offset++] = uInt8Float64Array[6];
      this[offset++] = uInt8Float64Array[5];
      this[offset++] = uInt8Float64Array[4];
      this[offset++] = uInt8Float64Array[3];
      this[offset++] = uInt8Float64Array[2];
      this[offset++] = uInt8Float64Array[1];
      this[offset++] = uInt8Float64Array[0];
      return offset;
    }
    function writeFloatForwards(val, offset = 0) {
      val = +val;
      checkBounds(this, offset, 3);
      float32Array[0] = val;
      this[offset++] = uInt8Float32Array[0];
      this[offset++] = uInt8Float32Array[1];
      this[offset++] = uInt8Float32Array[2];
      this[offset++] = uInt8Float32Array[3];
      return offset;
    }
    function writeFloatBackwards(val, offset = 0) {
      val = +val;
      checkBounds(this, offset, 3);
      float32Array[0] = val;
      this[offset++] = uInt8Float32Array[3];
      this[offset++] = uInt8Float32Array[2];
      this[offset++] = uInt8Float32Array[1];
      this[offset++] = uInt8Float32Array[0];
      return offset;
    }

    class FastBuffer extends Uint8Array2 {
    }
    function asciiWrite(buf, string, offset = 0, length = buf.byteLength - offset) {
      if (offset < 0 || offset > buf.byteLength) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("offset");
      }
      if (length < 0 || length > buf.byteLength - offset) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("length");
      }
      return asciiWriteStatic2(buf, string, offset, length);
    }
    function latin1Write(buf, string, offset = 0, length = buf.byteLength - offset) {
      if (offset < 0 || offset > buf.byteLength) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("offset");
      }
      if (length < 0 || length > buf.byteLength - offset) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("length");
      }
      return latin1WriteStatic2(buf, string, offset, length);
    }
    function utf8Write(buf, string, offset = 0, length = buf.byteLength - offset) {
      if (offset < 0 || offset > buf.byteLength) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("offset");
      }
      if (length < 0 || length > buf.byteLength - offset) {
        throw new ERR_BUFFER_OUT_OF_BOUNDS("length");
      }
      return utf8WriteStatic2(buf, string, offset, length);
    }
    function addBufferPrototypeMethods(proto) {
      proto.readBigUInt64LE = readBigUInt64LE;
      proto.readBigUInt64BE = readBigUInt64BE;
      proto.readBigUint64LE = readBigUInt64LE;
      proto.readBigUint64BE = readBigUInt64BE;
      proto.readBigInt64LE = readBigInt64LE;
      proto.readBigInt64BE = readBigInt64BE;
      proto.writeBigUInt64LE = writeBigUInt64LE;
      proto.writeBigUInt64BE = writeBigUInt64BE;
      proto.writeBigUint64LE = writeBigUInt64LE;
      proto.writeBigUint64BE = writeBigUInt64BE;
      proto.writeBigInt64LE = writeBigInt64LE;
      proto.writeBigInt64BE = writeBigInt64BE;
      proto.readUIntLE = readUIntLE;
      proto.readUInt32LE = function(offset) {
        return readUInt32LE(this, offset);
      };
      proto.readUInt16LE = function(offset) {
        return readUInt16LE(this, offset);
      };
      proto.readUInt8 = function(offset) {
        return readUInt8(this, offset);
      };
      proto.readUIntBE = readUIntBE;
      proto.readUInt32BE = function(offset) {
        return readUInt32BE(this, offset);
      };
      proto.readUInt16BE = function(offset) {
        return readUInt16BE(this, offset);
      };
      proto.readUintLE = readUIntLE;
      proto.readUint32LE = proto.readUInt32LE;
      proto.readUint16LE = proto.readUInt16LE;
      proto.readUint8 = proto.readUInt8;
      proto.readUintBE = readUIntBE;
      proto.readUint32BE = proto.readUInt32BE;
      proto.readUint16BE = proto.readUInt16BE;
      proto.readIntLE = readIntLE;
      proto.readInt32LE = function(offset) {
        return readInt32LE(this, offset);
      };
      proto.readInt16LE = function(offset) {
        return readInt16LE(this, offset);
      };
      proto.readInt8 = function(offset) {
        return readInt8(this, offset);
      };
      proto.readIntBE = readIntBE;
      proto.readInt32BE = function(offset) {
        return readInt32BE(this, offset);
      };
      proto.readInt16BE = function(offset) {
        return readInt16BE(this, offset);
      };
      proto.writeUIntLE = writeUIntLE;
      proto.writeUInt32LE = writeUInt32LE;
      proto.writeUInt16LE = writeUInt16LE;
      proto.writeUInt8 = writeUInt8;
      proto.writeUIntBE = writeUIntBE;
      proto.writeUInt32BE = writeUInt32BE;
      proto.writeUInt16BE = writeUInt16BE;
      proto.writeUintLE = writeUIntLE;
      proto.writeUint32LE = writeUInt32LE;
      proto.writeUint16LE = writeUInt16LE;
      proto.writeUint8 = writeUInt8;
      proto.writeUintBE = writeUIntBE;
      proto.writeUint32BE = writeUInt32BE;
      proto.writeUint16BE = writeUInt16BE;
      proto.writeIntLE = writeIntLE;
      proto.writeInt32LE = writeInt32LE;
      proto.writeInt16LE = writeInt16LE;
      proto.writeInt8 = writeInt8;
      proto.writeIntBE = writeIntBE;
      proto.writeInt32BE = writeInt32BE;
      proto.writeInt16BE = writeInt16BE;
      proto.readFloatLE = bigEndian ? readFloatBackwards : readFloatForwards;
      proto.readFloatBE = bigEndian ? readFloatForwards : readFloatBackwards;
      proto.readDoubleLE = bigEndian ? readDoubleBackwards : readDoubleForwards;
      proto.readDoubleBE = bigEndian ? readDoubleForwards : readDoubleBackwards;
      proto.writeFloatLE = bigEndian ? writeFloatBackwards : writeFloatForwards;
      proto.writeFloatBE = bigEndian ? writeFloatForwards : writeFloatBackwards;
      proto.writeDoubleLE = bigEndian ? writeDoubleBackwards : writeDoubleForwards;
      proto.writeDoubleBE = bigEndian ? writeDoubleForwards : writeDoubleBackwards;
      proto.asciiSlice = function(start, end) {
        return asciiSlice2(this, start, end);
      };
      proto.base64Slice = function(start, end) {
        return base64Slice2(this, start, end);
      };
      proto.base64urlSlice = function(start, end) {
        return base64urlSlice2(this, start, end);
      };
      proto.latin1Slice = function(start, end) {
        return latin1Slice2(this, start, end);
      };
      proto.hexSlice = function(start, end) {
        return hexSlice2(this, start, end);
      };
      proto.ucs2Slice = function(start, end) {
        return ucs2Slice2(this, start, end);
      };
      proto.utf8Slice = function(start, end) {
        return utf8Slice2(this, start, end);
      };
      proto.asciiWrite = function(string, offset, length) {
        return asciiWrite(this, string, offset, length);
      };
      proto.base64Write = function(string, offset, length) {
        return base64Write2(this, string, offset, length);
      };
      proto.base64urlWrite = function(string, offset, length) {
        return base64urlWrite2(this, string, offset, length);
      };
      proto.latin1Write = function(string, offset, length) {
        return latin1Write(this, string, offset, length);
      };
      proto.hexWrite = function(string, offset, length) {
        return hexWrite2(this, string, offset, length);
      };
      proto.ucs2Write = function(string, offset, length) {
        return ucs2Write2(this, string, offset, length);
      };
      proto.utf8Write = function(string, offset, length) {
        return utf8Write(this, string, offset, length);
      };
    }
    const kDetachKey = Symbol2("detach_key_for_untransferable_arraybuffer");
    function markAsUntransferable(obj) {
      if (typeof obj !== "object" && typeof obj !== "function" || obj === null)
        return;
      obj[untransferable_object_private_symbol] = true;
      if (isArrayBuffer(obj)) {
        setDetachKey(obj, kDetachKey);
      }
    }
    function isMarkedAsUntransferable(obj) {
      if (obj == null)
        return false;
      return obj[untransferable_object_private_symbol] !== undefined;
    }
    function createUnsafeBuffer(size) {
      if (size <= 64) {
        return new FastBuffer(size);
      }
      return new FastBuffer(createUnsafeArrayBuffer(size));
    }
    module.exports = {
      FastBuffer,
      addBufferPrototypeMethods,
      markAsUntransferable,
      isMarkedAsUntransferable,
      createUnsafeBuffer,
      readUInt16BE,
      readUInt32BE,
      asciiWrite,
      latin1Write,
      utf8Write
    };
  }

  // third_party/node/internal/constants.js
  function constants_default(exports, require2, module, process, internalBinding, primordials2) {
    const isWindows = process.platform === "win32";
    module.exports = {
      CHAR_UPPERCASE_A: 65,
      CHAR_LOWERCASE_A: 97,
      CHAR_UPPERCASE_Z: 90,
      CHAR_LOWERCASE_Z: 122,
      CHAR_UPPERCASE_C: 67,
      CHAR_LOWERCASE_B: 98,
      CHAR_LOWERCASE_E: 101,
      CHAR_LOWERCASE_N: 110,
      CHAR_DOT: 46,
      CHAR_FORWARD_SLASH: 47,
      CHAR_BACKWARD_SLASH: 92,
      CHAR_VERTICAL_LINE: 124,
      CHAR_COLON: 58,
      CHAR_QUESTION_MARK: 63,
      CHAR_UNDERSCORE: 95,
      CHAR_LINE_FEED: 10,
      CHAR_CARRIAGE_RETURN: 13,
      CHAR_TAB: 9,
      CHAR_FORM_FEED: 12,
      CHAR_EXCLAMATION_MARK: 33,
      CHAR_HASH: 35,
      CHAR_SPACE: 32,
      CHAR_NO_BREAK_SPACE: 160,
      CHAR_ZERO_WIDTH_NOBREAK_SPACE: 65279,
      CHAR_LEFT_SQUARE_BRACKET: 91,
      CHAR_RIGHT_SQUARE_BRACKET: 93,
      CHAR_LEFT_ANGLE_BRACKET: 60,
      CHAR_RIGHT_ANGLE_BRACKET: 62,
      CHAR_LEFT_CURLY_BRACKET: 123,
      CHAR_RIGHT_CURLY_BRACKET: 125,
      CHAR_HYPHEN_MINUS: 45,
      CHAR_PLUS: 43,
      CHAR_DOUBLE_QUOTE: 34,
      CHAR_SINGLE_QUOTE: 39,
      CHAR_PERCENT: 37,
      CHAR_SEMICOLON: 59,
      CHAR_CIRCUMFLEX_ACCENT: 94,
      CHAR_GRAVE_ACCENT: 96,
      CHAR_AT: 64,
      CHAR_AMPERSAND: 38,
      CHAR_EQUAL: 61,
      CHAR_0: 48,
      CHAR_9: 57,
      EOL: isWindows ? `\r
` : `
`
    };
  }

  // third_party/node/internal/encoding.js
  function encoding_default(exports, require2, module, process, internalBinding, primordials2) {
    module.exports = {
      TextEncoder: globalThis.TextEncoder,
      TextDecoder: globalThis.TextDecoder
    };
  }

  // third_party/node/internal/errors.js
  function errors_default(exports, require2, module, process, internalBinding, primordials2) {
    const determineType = (actual) => {
      if (actual === null)
        return "null";
      if (actual === undefined)
        return "undefined";
      const t = typeof actual;
      if (t === "function")
        return `function ${actual.name || "(anonymous)"}`;
      if (t === "object") {
        const ctor = actual.constructor && actual.constructor.name;
        return ctor ? `an instance of ${ctor}` : "an object";
      }
      return `type ${t}`;
    };
    const makeNodeError = (Base, code, formatter) => {
      const Cls = class extends Base {
        constructor(...args) {
          super(formatter(...args));
          this.code = code;
          this.name = `${Base.name} [${code}]`;
        }
      };
      Cls.HideStackFramesError = Cls;
      return Cls;
    };
    const ERR_INVALID_ARG_TYPE = makeNodeError(TypeError, "ERR_INVALID_ARG_TYPE", (name, expected, actual) => {
      const exp = Array.isArray(expected) ? expected.join(" | ") : String(expected);
      return `The "${name}" argument must be of type ${exp}. Received ${determineType(actual)}`;
    });
    const ERR_INVALID_ARG_VALUE = makeNodeError(TypeError, "ERR_INVALID_ARG_VALUE", (name, value, reason = "is invalid") => {
      let v;
      try {
        v = typeof value === "string" ? `'${value}'` : String(value);
      } catch {
        v = "<value>";
      }
      return `The ${name.includes(".") ? "property" : "argument"} '${name}' ${v} ${reason}`;
    });
    const ERR_OUT_OF_RANGE = makeNodeError(RangeError, "ERR_OUT_OF_RANGE", (name, range, value) => `The value of "${name}" is out of range. It must be ${range}. Received ${value}`);
    const ERR_PARSE_ARGS_INVALID_OPTION_VALUE = makeNodeError(TypeError, "ERR_PARSE_ARGS_INVALID_OPTION_VALUE", (msg) => msg);
    const ERR_PARSE_ARGS_UNKNOWN_OPTION = makeNodeError(TypeError, "ERR_PARSE_ARGS_UNKNOWN_OPTION", (option, allowPositionals) => {
      const suggestDashDash = allowPositionals ? ` To specify a positional argument starting with a '-', place it at the end of the command after '--', as in '-- ${JSON.stringify(option)}` : "";
      return `Unknown option '${option}'.${suggestDashDash}`;
    });
    const ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL = makeNodeError(TypeError, "ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL", (positional) => `Unexpected argument '${positional}'. This command does not take positional arguments`);
    const ERR_UNKNOWN_SIGNAL = makeNodeError(TypeError, "ERR_UNKNOWN_SIGNAL", (signal) => `Unknown signal: ${signal}`);
    const ERR_SOCKET_BAD_PORT = makeNodeError(RangeError, "ERR_SOCKET_BAD_PORT", (name, port, allowZero = true) => `${name} should be ${allowZero ? ">=" : ">"} 0 and < 65536. Received ${port}`);
    const ERR_BUFFER_OUT_OF_BOUNDS = makeNodeError(RangeError, "ERR_BUFFER_OUT_OF_BOUNDS", (name) => name ? `"${name}" is outside of buffer bounds` : "Attempt to access memory outside buffer bounds");
    const ERR_INVALID_BUFFER_SIZE = makeNodeError(RangeError, "ERR_INVALID_BUFFER_SIZE", (size) => `Buffer size must be a multiple of ${size}`);
    const ERR_UNKNOWN_ENCODING = makeNodeError(TypeError, "ERR_UNKNOWN_ENCODING", (enc) => `Unknown encoding: ${enc}`);
    const ERR_INVALID_URI = makeNodeError(URIError, "ERR_INVALID_URI", () => "URI malformed");
    const ERR_BUFFER_TOO_LARGE = makeNodeError(RangeError, "ERR_BUFFER_TOO_LARGE", (max) => `Cannot create a Buffer larger than ${max} bytes`);
    const ERR_BROTLI_INVALID_PARAM = makeNodeError(RangeError, "ERR_BROTLI_INVALID_PARAM", (param) => `${param} is not a valid Brotli parameter`);
    const ERR_ZSTD_INVALID_PARAM = makeNodeError(RangeError, "ERR_ZSTD_INVALID_PARAM", (param) => `${param} is not a valid zstd parameter`);
    const ERR_TRAILING_JUNK_AFTER_STREAM_END = makeNodeError(Error, "ERR_TRAILING_JUNK_AFTER_STREAM_END", () => "Trailing junk found after the end of the compressed stream");
    const ERR_ZLIB_INITIALIZATION_FAILED = makeNodeError(Error, "ERR_ZLIB_INITIALIZATION_FAILED", () => "Initialization failed");
    const ERR_MISSING_ARGS = makeNodeError(TypeError, "ERR_MISSING_ARGS", (...args) => {
      const names = args.map((a) => `"${a}"`);
      const list = names.length > 1 ? `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}` : names[0];
      return `The ${list} argument${names.length > 1 ? "s" : ""} must be specified`;
    });
    const ERR_INCOMPATIBLE_OPTION_PAIR = makeNodeError(TypeError, "ERR_INCOMPATIBLE_OPTION_PAIR", (a, b) => `Option "${a}" cannot be used in combination with option "${b}"`);
    const ERR_ACCESS_DENIED = makeNodeError(Error, "ERR_ACCESS_DENIED", (message) => message || "Access to this API has been restricted");
    const ERR_INVALID_MIME_SYNTAX = makeNodeError(TypeError, "ERR_INVALID_MIME_SYNTAX", (production, str, invalidIndex) => `The MIME syntax for a ${production} in "${str}" is invalid` + (invalidIndex !== -1 ? ` at ${invalidIndex}` : ""));
    const ERR_FS_FILE_TOO_LARGE = makeNodeError(RangeError, "ERR_FS_FILE_TOO_LARGE", (size) => `File size (${size}) is greater than 2 GiB`);
    const makeSystemError = (code) => {
      const Cls = class extends Error {
        constructor(ctx = {}) {
          const syscall = ctx.syscall ? `${ctx.syscall} returned ${ctx.code}` : ctx.code;
          super([code + ":", syscall, ctx.message && `(${ctx.message})`, ctx.path].filter(Boolean).join(" "));
          this.code = code;
          this.info = ctx;
          if (ctx.errno !== undefined)
            this.errno = ctx.errno;
          if (ctx.syscall !== undefined)
            this.syscall = ctx.syscall;
          if (ctx.path !== undefined)
            this.path = ctx.path;
          if (ctx.dest !== undefined)
            this.dest = ctx.dest;
          this.name = "SystemError";
        }
      };
      Cls.HideStackFramesError = Cls;
      return Cls;
    };
    const ERR_FS_EISDIR = makeSystemError("ERR_FS_EISDIR");
    function UVException(ctx = {}) {
      const err = new Error(`${ctx.code || "EIO"}: ${ctx.message || "unknown error"}, ${ctx.syscall || ""}`);
      err.code = ctx.code;
      err.errno = ctx.errno;
      err.syscall = ctx.syscall;
      if (ctx.path !== undefined)
        err.path = ctx.path;
      if (ctx.dest !== undefined)
        err.dest = ctx.dest;
      return err;
    }

    class AbortError extends Error {
      constructor(message = "The operation was aborted", options = undefined) {
        super(message, options);
        this.code = "ABORT_ERR";
        this.name = "AbortError";
      }
    }

    class ConnResetException extends Error {
      constructor(msg) {
        super(msg);
        this.code = "ECONNRESET";
      }
    }
    function aggregateTwoErrors(innerError, outerError) {
      if (innerError && outerError && innerError !== outerError) {
        if (typeof AggregateError === "function") {
          const err = new AggregateError([outerError, innerError], outerError.message);
          err.code = outerError.code;
          return err;
        }
        outerError.previous = innerError;
      }
      return innerError || outerError;
    }
    const ERR_UNHANDLED_ERROR = makeNodeError(Error, "ERR_UNHANDLED_ERROR", (err) => `Unhandled error.${err === undefined ? "" : ` (${err})`}`);

    class ERR_FALSY_VALUE_REJECTION extends Error {
      constructor(reason) {
        super("Promise was rejected with a falsy value");
        this.code = "ERR_FALSY_VALUE_REJECTION";
        this.name = "Error [ERR_FALSY_VALUE_REJECTION]";
        this.reason = reason;
      }
    }
    ERR_FALSY_VALUE_REJECTION.HideStackFramesError = ERR_FALSY_VALUE_REJECTION;
    const uvErrname = (err) => {
      try {
        return internalBinding("uv").errname(err);
      } catch {
        return `UNKNOWN(${err})`;
      }
    };
    function ErrnoException(err, syscall, original) {
      const code = uvErrname(err);
      const e = new Error(`${syscall} ${code}${original ? ` ${original}` : ""}`);
      e.errno = err;
      e.code = code;
      e.syscall = syscall;
      return e;
    }
    function ExceptionWithHostPort(err, syscall, address, port, additional) {
      const code = uvErrname(err);
      let details = "";
      if (port && port > 0)
        details = ` ${address}:${port}`;
      else if (address)
        details = ` ${address}`;
      if (additional)
        details += ` - Local (${additional})`;
      const e = new Error(`${syscall} ${code}${details}`);
      e.errno = err;
      e.code = code;
      e.syscall = syscall;
      e.address = address;
      if (port)
        e.port = port;
      return e;
    }
    function isErrorStackTraceLimitWritable() {
      const desc = Object.getOwnPropertyDescriptor(Error, "stackTraceLimit");
      if (desc === undefined)
        return Object.isExtensible(Error);
      return Object.prototype.hasOwnProperty.call(desc, "writable") ? desc.writable : desc.set !== undefined;
    }
    const kEnhanceStackBeforeInspector = Symbol("kEnhanceStackBeforeInspector");
    const genericNodeError = (message, props) => Object.assign(new Error(message), props);
    const hideStackFrames = (fn) => {
      fn.withoutStackTrace = fn;
      return fn;
    };
    const ERR_METHOD_NOT_IMPLEMENTED = makeNodeError(Error, "ERR_METHOD_NOT_IMPLEMENTED", (method) => `The ${method} method is not implemented`);
    const ERR_MULTIPLE_CALLBACK = makeNodeError(Error, "ERR_MULTIPLE_CALLBACK", () => "Callback called multiple times");
    const ERR_ILLEGAL_CONSTRUCTOR = makeNodeError(TypeError, "ERR_ILLEGAL_CONSTRUCTOR", () => "Illegal constructor");
    const ERR_STREAM_ALREADY_FINISHED = makeNodeError(Error, "ERR_STREAM_ALREADY_FINISHED", (fn) => `Cannot call ${fn} after a stream was finished`);
    const ERR_STREAM_CANNOT_PIPE = makeNodeError(Error, "ERR_STREAM_CANNOT_PIPE", () => "Cannot pipe, not readable");
    const ERR_STREAM_DESTROYED = makeNodeError(Error, "ERR_STREAM_DESTROYED", (fn) => `Cannot call ${fn} after a stream was destroyed`);
    const ERR_STREAM_NULL_VALUES = makeNodeError(TypeError, "ERR_STREAM_NULL_VALUES", () => "May not write null values to stream");
    const ERR_STREAM_WRITE_AFTER_END = makeNodeError(Error, "ERR_STREAM_WRITE_AFTER_END", () => "write after end");
    const ERR_STREAM_PREMATURE_CLOSE = makeNodeError(Error, "ERR_STREAM_PREMATURE_CLOSE", () => "Premature close");
    const ERR_STREAM_UNABLE_TO_PIPE = makeNodeError(Error, "ERR_STREAM_UNABLE_TO_PIPE", () => "Cannot pipe to a closed or destroyed stream");
    const ERR_STREAM_PUSH_AFTER_EOF = makeNodeError(Error, "ERR_STREAM_PUSH_AFTER_EOF", () => "stream.push() after EOF");
    const ERR_STREAM_UNSHIFT_AFTER_END_EVENT = makeNodeError(Error, "ERR_STREAM_UNSHIFT_AFTER_END_EVENT", () => "stream.unshift() after end event");
    const ERR_INVALID_RETURN_VALUE = makeNodeError(TypeError, "ERR_INVALID_RETURN_VALUE", (input, name, value) => `Expected ${input} to be returned from the "${name}" function but got ${determineType(value)}.`);
    const ERR_HTTP_HEADERS_SENT = makeNodeError(Error, "ERR_HTTP_HEADERS_SENT", (arg) => `Cannot ${arg} headers after they are sent to the client`);
    const ERR_HTTP_INVALID_STATUS_CODE = makeNodeError(RangeError, "ERR_HTTP_INVALID_STATUS_CODE", (code) => `Invalid status code: ${code}`);
    const ERR_HTTP_REQUEST_TIMEOUT = makeNodeError(Error, "ERR_HTTP_REQUEST_TIMEOUT", () => "Request timeout");
    const ERR_HTTP_SOCKET_ASSIGNED = makeNodeError(Error, "ERR_HTTP_SOCKET_ASSIGNED", () => "ServerResponse has an already assigned socket");
    const ERR_HTTP_SOCKET_ENCODING = makeNodeError(Error, "ERR_HTTP_SOCKET_ENCODING", () => "Changing the socket encoding is not allowed per RFC7230 Section 3.");
    const ERR_HTTP_BODY_NOT_ALLOWED = makeNodeError(Error, "ERR_HTTP_BODY_NOT_ALLOWED", () => "Adding content for this request method or response status is not allowed.");
    const ERR_HTTP_CONTENT_LENGTH_MISMATCH = makeNodeError(Error, "ERR_HTTP_CONTENT_LENGTH_MISMATCH", (actual, expected) => `Response body's content-length of ${actual} byte(s) does not match the content-length of ${expected} byte(s) set in header`);
    const ERR_HTTP_INVALID_HEADER_VALUE = makeNodeError(TypeError, "ERR_HTTP_INVALID_HEADER_VALUE", (value, name) => `Invalid value "${value}" for header "${name}"`);
    const ERR_HTTP_TRAILER_INVALID = makeNodeError(Error, "ERR_HTTP_TRAILER_INVALID", () => "Trailers are invalid with this transfer encoding");
    const ERR_INVALID_CHAR = makeNodeError(TypeError, "ERR_INVALID_CHAR", (name, field) => field ? `Invalid character in ${name} ["${field}"]` : `Invalid character in ${name}`);
    const ERR_INVALID_HTTP_TOKEN = makeNodeError(TypeError, "ERR_INVALID_HTTP_TOKEN", (name, token) => `${name} must be a valid HTTP token ["${token}"]`);
    const ERR_INVALID_PROTOCOL = makeNodeError(TypeError, "ERR_INVALID_PROTOCOL", (protocol, expectedProtocol) => `Protocol "${protocol}" not supported. Expected "${expectedProtocol}"`);
    const ERR_UNESCAPED_CHARACTERS = makeNodeError(TypeError, "ERR_UNESCAPED_CHARACTERS", (name) => `${name} contains unescaped characters`);
    const ERR_SERVER_ALREADY_LISTEN = makeNodeError(Error, "ERR_SERVER_ALREADY_LISTEN", () => "Listen method has been called more than once without closing.");
    const ERR_SERVER_NOT_RUNNING = makeNodeError(Error, "ERR_SERVER_NOT_RUNNING", () => "Server is not running.");
    const ERR_SOCKET_CLOSED = makeNodeError(Error, "ERR_SOCKET_CLOSED", () => "Socket is closed");
    const ERR_SOCKET_CLOSED_BEFORE_CONNECTION = makeNodeError(Error, "ERR_SOCKET_CLOSED_BEFORE_CONNECTION", () => "Socket closed before the connection was established");
    const ERR_SOCKET_CONNECTION_TIMEOUT = makeNodeError(Error, "ERR_SOCKET_CONNECTION_TIMEOUT", () => "Socket connection timeout");
    const ERR_INVALID_ADDRESS_FAMILY = makeNodeError(RangeError, "ERR_INVALID_ADDRESS_FAMILY", (addressType, host, port) => `Invalid address family: ${addressType} ${host}:${port}`);
    const ERR_INVALID_FD_TYPE = makeNodeError(TypeError, "ERR_INVALID_FD_TYPE", (type) => `Unsupported fd type: ${type}`);
    const ERR_INVALID_HANDLE_TYPE = makeNodeError(TypeError, "ERR_INVALID_HANDLE_TYPE", () => "This handle type cannot be sent");
    const ERR_INVALID_IP_ADDRESS = makeNodeError(TypeError, "ERR_INVALID_IP_ADDRESS", (ip) => `Invalid IP address: ${ip}`);
    const ERR_IP_BLOCKED = makeNodeError(Error, "ERR_IP_BLOCKED", (ip) => `IP(${ip}) is blocked by net.BlockList`);
    const UVExceptionWithHostPort = ExceptionWithHostPort;
    const AggregateBase = typeof AggregateError === "function" ? AggregateError : Error;

    class NodeAggregateError extends AggregateBase {
      constructor(errors, message) {
        super(errors, message);
        this.code = errors && errors[0] && errors[0].code;
        this.name = "AggregateError";
        this.errors = errors;
      }
    }
    module.exports = {
      hideStackFrames,
      genericNodeError,
      UVException,
      AbortError,
      ConnResetException,
      aggregateTwoErrors,
      ErrnoException,
      ExceptionWithHostPort,
      UVExceptionWithHostPort,
      NodeAggregateError,
      isErrorStackTraceLimitWritable,
      kEnhanceStackBeforeInspector,
      codes: {
        ERR_UNHANDLED_ERROR,
        ERR_FALSY_VALUE_REJECTION,
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_ARG_VALUE,
        ERR_OUT_OF_RANGE,
        ERR_PARSE_ARGS_INVALID_OPTION_VALUE,
        ERR_PARSE_ARGS_UNKNOWN_OPTION,
        ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL,
        ERR_UNKNOWN_SIGNAL,
        ERR_SOCKET_BAD_PORT,
        ERR_BUFFER_OUT_OF_BOUNDS,
        ERR_INVALID_BUFFER_SIZE,
        ERR_UNKNOWN_ENCODING,
        ERR_INVALID_URI,
        ERR_BUFFER_TOO_LARGE,
        ERR_BROTLI_INVALID_PARAM,
        ERR_ZSTD_INVALID_PARAM,
        ERR_TRAILING_JUNK_AFTER_STREAM_END,
        ERR_ZLIB_INITIALIZATION_FAILED,
        ERR_MISSING_ARGS,
        ERR_INCOMPATIBLE_OPTION_PAIR,
        ERR_ACCESS_DENIED,
        ERR_FS_FILE_TOO_LARGE,
        ERR_FS_EISDIR,
        ERR_INVALID_MIME_SYNTAX,
        ERR_FS_CP_EINVAL: makeSystemError("ERR_FS_CP_EINVAL"),
        ERR_FS_CP_DIR_TO_NON_DIR: makeSystemError("ERR_FS_CP_DIR_TO_NON_DIR"),
        ERR_FS_CP_EEXIST: makeSystemError("ERR_FS_CP_EEXIST"),
        ERR_FS_CP_FIFO_PIPE: makeSystemError("ERR_FS_CP_FIFO_PIPE"),
        ERR_FS_CP_NON_DIR_TO_DIR: makeSystemError("ERR_FS_CP_NON_DIR_TO_DIR"),
        ERR_FS_CP_SOCKET: makeSystemError("ERR_FS_CP_SOCKET"),
        ERR_FS_CP_SYMLINK_TO_SUBDIRECTORY: makeSystemError("ERR_FS_CP_SYMLINK_TO_SUBDIRECTORY"),
        ERR_FS_CP_UNKNOWN: makeSystemError("ERR_FS_CP_UNKNOWN"),
        ERR_INVALID_ARG_TYPE_RANGE: ERR_OUT_OF_RANGE,
        ERR_METHOD_NOT_IMPLEMENTED,
        ERR_MULTIPLE_CALLBACK,
        ERR_ILLEGAL_CONSTRUCTOR,
        ERR_STREAM_ALREADY_FINISHED,
        ERR_STREAM_CANNOT_PIPE,
        ERR_STREAM_DESTROYED,
        ERR_STREAM_NULL_VALUES,
        ERR_STREAM_WRITE_AFTER_END,
        ERR_STREAM_PREMATURE_CLOSE,
        ERR_STREAM_UNABLE_TO_PIPE,
        ERR_STREAM_PUSH_AFTER_EOF,
        ERR_STREAM_UNSHIFT_AFTER_END_EVENT,
        ERR_INVALID_RETURN_VALUE,
        ERR_HTTP_HEADERS_SENT,
        ERR_HTTP_INVALID_STATUS_CODE,
        ERR_HTTP_REQUEST_TIMEOUT,
        ERR_HTTP_SOCKET_ASSIGNED,
        ERR_HTTP_SOCKET_ENCODING,
        ERR_HTTP_BODY_NOT_ALLOWED,
        ERR_HTTP_CONTENT_LENGTH_MISMATCH,
        ERR_HTTP_INVALID_HEADER_VALUE,
        ERR_HTTP_TRAILER_INVALID,
        ERR_INVALID_CHAR,
        ERR_INVALID_HTTP_TOKEN,
        ERR_INVALID_PROTOCOL,
        ERR_UNESCAPED_CHARACTERS,
        ERR_SERVER_ALREADY_LISTEN,
        ERR_SERVER_NOT_RUNNING,
        ERR_SOCKET_CLOSED,
        ERR_SOCKET_CLOSED_BEFORE_CONNECTION,
        ERR_SOCKET_CONNECTION_TIMEOUT,
        ERR_INVALID_ADDRESS_FAMILY,
        ERR_INVALID_FD_TYPE,
        ERR_INVALID_HANDLE_TYPE,
        ERR_INVALID_IP_ADDRESS,
        ERR_IP_BLOCKED
      }
    };
  }

  // third_party/node/internal/event_target.js
  function event_target_default(exports, require2, module, process, internalBinding, primordials2) {
    const kResistStopPropagation = Symbol("kResistStopPropagation");
    const kEvents = Symbol("kEvents");
    const isEventTarget = (obj) => obj != null && typeof obj.addEventListener === "function" && typeof obj.removeEventListener === "function";
    module.exports = {
      kResistStopPropagation,
      kEvents,
      isEventTarget,
      EventTarget: globalThis.EventTarget,
      Event: globalThis.Event
    };
  }

  // third_party/node/internal/events/abort_listener.js
  function abort_listener_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      SymbolDispose
    } = primordials2;
    const {
      validateAbortSignal,
      validateFunction
    } = require2("internal/validators");
    const {
      codes: {
        ERR_INVALID_ARG_TYPE
      }
    } = require2("internal/errors");
    let queueMicrotask;
    let kResistStopPropagation;
    function addAbortListener(signal, listener) {
      if (signal === undefined) {
        throw new ERR_INVALID_ARG_TYPE("signal", "AbortSignal", signal);
      }
      validateAbortSignal(signal, "signal");
      validateFunction(listener, "listener");
      let removeEventListener;
      if (signal.aborted) {
        queueMicrotask ??= require2("internal/process/task_queues").queueMicrotask;
        queueMicrotask(() => listener());
      } else {
        kResistStopPropagation ??= require2("internal/event_target").kResistStopPropagation;
        signal.addEventListener("abort", listener, { __proto__: null, once: true, [kResistStopPropagation]: true });
        removeEventListener = () => {
          signal.removeEventListener("abort", listener);
        };
      }
      return {
        __proto__: null,
        [SymbolDispose]() {
          removeEventListener?.();
        }
      };
    }
    module.exports = {
      __proto__: null,
      addAbortListener
    };
  }

  // third_party/node/internal/events/symbols.js
  function symbols_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Symbol: Symbol2
    } = primordials2;
    const kFirstEventParam = Symbol2("kFirstEventParam");
    module.exports = {
      kFirstEventParam
    };
  }

  // third_party/node/internal/fixed_queue.js
  function fixed_queue_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Array: Array2,
      ArrayPrototypeFill
    } = primordials2;
    const kSize = 2048;
    const kMask = kSize - 1;

    class FixedCircularBuffer {
      constructor() {
        this.bottom = 0;
        this.top = 0;
        this.list = ArrayPrototypeFill(new Array2(kSize), undefined);
        this.next = null;
      }
      isEmpty() {
        return this.top === this.bottom;
      }
      isFull() {
        return (this.top + 1 & kMask) === this.bottom;
      }
      push(data) {
        this.list[this.top] = data;
        this.top = this.top + 1 & kMask;
      }
      shift() {
        const nextItem = this.list[this.bottom];
        if (nextItem === undefined)
          return null;
        this.list[this.bottom] = undefined;
        this.bottom = this.bottom + 1 & kMask;
        return nextItem;
      }
    }
    module.exports = class FixedQueue {
      constructor() {
        this.head = this.tail = new FixedCircularBuffer;
      }
      isEmpty() {
        return this.head.isEmpty();
      }
      push(data) {
        if (this.head.isFull()) {
          this.head = this.head.next = new FixedCircularBuffer;
        }
        this.head.push(data);
      }
      shift() {
        const tail = this.tail;
        const next = tail.shift();
        if (tail.isEmpty() && tail.next !== null) {
          this.tail = tail.next;
          tail.next = null;
        }
        return next;
      }
    };
  }

  // third_party/node/internal/mime.js
  function mime_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      FunctionPrototypeCall,
      ObjectDefineProperty,
      RegExpPrototypeExec: RegExpPrototypeExec2,
      SafeMap,
      SafeStringPrototypeSearch: SafeStringPrototypeSearch2,
      StringPrototypeCharAt,
      StringPrototypeIndexOf,
      StringPrototypeSlice,
      StringPrototypeToLowerCase,
      SymbolIterator
    } = primordials2;
    const {
      ERR_INVALID_MIME_SYNTAX
    } = require2("internal/errors").codes;
    const NOT_HTTP_TOKEN_CODE_POINT = /[^!#$%&'*+\-.^_`|~A-Za-z0-9]/g;
    const NOT_HTTP_QUOTED_STRING_CODE_POINT = /[^\t\u0020-~\u0080-\u00FF]/g;
    const END_BEGINNING_WHITESPACE = /[^\r\n\t ]|$/;
    const START_ENDING_WHITESPACE = /[\r\n\t ]*$/;
    function toASCIILower(str) {
      if (!/[^\x00-\x7f]/.test(str))
        return StringPrototypeToLowerCase(str);
      let result = "";
      for (let i = 0;i < str.length; i++) {
        const char = str[i];
        result += char >= "A" && char <= "Z" ? StringPrototypeToLowerCase(char) : char;
      }
      return result;
    }
    const SOLIDUS = "/";
    const SEMICOLON = ";";
    function parseTypeAndSubtype(str) {
      let position = SafeStringPrototypeSearch2(str, END_BEGINNING_WHITESPACE);
      const typeEnd = StringPrototypeIndexOf(str, SOLIDUS, position);
      const trimmedType = typeEnd === -1 ? StringPrototypeSlice(str, position) : StringPrototypeSlice(str, position, typeEnd);
      const invalidTypeIndex = SafeStringPrototypeSearch2(trimmedType, NOT_HTTP_TOKEN_CODE_POINT);
      if (trimmedType === "" || invalidTypeIndex !== -1 || typeEnd === -1) {
        throw new ERR_INVALID_MIME_SYNTAX("type", str, invalidTypeIndex);
      }
      position = typeEnd + 1;
      const type = toASCIILower(trimmedType);
      const subtypeEnd = StringPrototypeIndexOf(str, SEMICOLON, position);
      const rawSubtype = subtypeEnd === -1 ? StringPrototypeSlice(str, position) : StringPrototypeSlice(str, position, subtypeEnd);
      position += rawSubtype.length;
      if (subtypeEnd !== -1) {
        position += 1;
      }
      const trimmedSubtype = StringPrototypeSlice(rawSubtype, 0, SafeStringPrototypeSearch2(rawSubtype, START_ENDING_WHITESPACE));
      const invalidSubtypeIndex = SafeStringPrototypeSearch2(trimmedSubtype, NOT_HTTP_TOKEN_CODE_POINT);
      if (trimmedSubtype === "" || invalidSubtypeIndex !== -1) {
        throw new ERR_INVALID_MIME_SYNTAX("subtype", str, invalidSubtypeIndex);
      }
      const subtype = toASCIILower(trimmedSubtype);
      return [
        type,
        subtype,
        position
      ];
    }
    const EQUALS_SEMICOLON_OR_END = /[;=]|$/;
    const QUOTED_VALUE_PATTERN = /^(?:([\\]$)|[\\][\s\S]|[^"])*(?:(")|$)/u;
    function removeBackslashes(str) {
      let ret = "";
      let i;
      for (i = 0;i < str.length - 1; i++) {
        const c = str[i];
        if (c === "\\") {
          i++;
          ret += str[i];
        } else {
          ret += c;
        }
      }
      if (i === str.length - 1) {
        ret += str[i];
      }
      return ret;
    }
    function escapeQuoteOrSolidus(str) {
      let result = "";
      for (let i = 0;i < str.length; i++) {
        const char = str[i];
        result += char === '"' || char === "\\" ? `\\${char}` : char;
      }
      return result;
    }
    const encode = (value) => {
      if (value.length === 0)
        return '""';
      const encode2 = SafeStringPrototypeSearch2(value, NOT_HTTP_TOKEN_CODE_POINT) !== -1;
      if (!encode2)
        return value;
      const escaped = escapeQuoteOrSolidus(value);
      return `"${escaped}"`;
    };

    class MIMEParams {
      #data = new SafeMap;
      #processed = true;
      #string = null;
      static instantiateMimeParams(str) {
        const instance = new MIMEParams;
        instance.#string = str;
        instance.#processed = false;
        return instance;
      }
      delete(name) {
        this.#parse();
        this.#data.delete(name);
      }
      get(name) {
        this.#parse();
        const data = this.#data;
        if (data.has(name)) {
          return data.get(name);
        }
        return null;
      }
      has(name) {
        this.#parse();
        return this.#data.has(name);
      }
      set(name, value) {
        this.#parse();
        const data = this.#data;
        name = `${name}`;
        value = `${value}`;
        const invalidNameIndex = SafeStringPrototypeSearch2(name, NOT_HTTP_TOKEN_CODE_POINT);
        if (name.length === 0 || invalidNameIndex !== -1) {
          throw new ERR_INVALID_MIME_SYNTAX("parameter name", name, invalidNameIndex);
        }
        const invalidValueIndex = SafeStringPrototypeSearch2(value, NOT_HTTP_QUOTED_STRING_CODE_POINT);
        if (invalidValueIndex !== -1) {
          throw new ERR_INVALID_MIME_SYNTAX("parameter value", value, invalidValueIndex);
        }
        data.set(name, value);
      }
      *entries() {
        this.#parse();
        yield* this.#data.entries();
      }
      *keys() {
        this.#parse();
        yield* this.#data.keys();
      }
      *values() {
        this.#parse();
        yield* this.#data.values();
      }
      toString() {
        this.#parse();
        let ret = "";
        for (const { 0: key, 1: value } of this.#data) {
          const encoded = encode(value);
          if (ret.length)
            ret += ";";
          ret += `${key}=${encoded}`;
        }
        return ret;
      }
      #parse() {
        if (this.#processed)
          return;
        const paramsMap = this.#data;
        let position = 0;
        const str = this.#string;
        const endOfSource = SafeStringPrototypeSearch2(StringPrototypeSlice(str, position), START_ENDING_WHITESPACE) + position;
        while (position < endOfSource) {
          position += SafeStringPrototypeSearch2(StringPrototypeSlice(str, position), END_BEGINNING_WHITESPACE);
          const afterParameterName = SafeStringPrototypeSearch2(StringPrototypeSlice(str, position), EQUALS_SEMICOLON_OR_END) + position;
          const parameterString = toASCIILower(StringPrototypeSlice(str, position, afterParameterName));
          position = afterParameterName;
          if (position < endOfSource) {
            const char2 = StringPrototypeCharAt(str, position);
            position += 1;
            if (char2 === ";") {
              continue;
            }
          }
          if (position >= endOfSource)
            break;
          const char = StringPrototypeCharAt(str, position);
          let parameterValue = null;
          if (char === '"') {
            position += 1;
            const insideMatch = RegExpPrototypeExec2(QUOTED_VALUE_PATTERN, StringPrototypeSlice(str, position));
            position += insideMatch[0].length;
            const inside = insideMatch[1] || insideMatch[2] ? StringPrototypeSlice(insideMatch[0], 0, -1) : insideMatch[0];
            parameterValue = removeBackslashes(inside);
            if (insideMatch[1])
              parameterValue += "\\";
          } else {
            const valueEnd = StringPrototypeIndexOf(str, SEMICOLON, position);
            const rawValue = valueEnd === -1 ? StringPrototypeSlice(str, position) : StringPrototypeSlice(str, position, valueEnd);
            position += rawValue.length;
            const trimmedValue = StringPrototypeSlice(rawValue, 0, SafeStringPrototypeSearch2(rawValue, START_ENDING_WHITESPACE));
            if (trimmedValue === "")
              continue;
            parameterValue = trimmedValue;
          }
          if (parameterString !== "" && SafeStringPrototypeSearch2(parameterString, NOT_HTTP_TOKEN_CODE_POINT) === -1 && SafeStringPrototypeSearch2(parameterValue, NOT_HTTP_QUOTED_STRING_CODE_POINT) === -1 && paramsMap.has(parameterString) === false) {
            paramsMap.set(parameterString, parameterValue);
          }
          position++;
        }
        this.#data = paramsMap;
        this.#processed = true;
      }
    }
    const MIMEParamsStringify = MIMEParams.prototype.toString;
    ObjectDefineProperty(MIMEParams.prototype, SymbolIterator, {
      __proto__: null,
      configurable: true,
      value: MIMEParams.prototype.entries,
      writable: true
    });
    ObjectDefineProperty(MIMEParams.prototype, "toJSON", {
      __proto__: null,
      configurable: true,
      value: MIMEParamsStringify,
      writable: true
    });
    const { instantiateMimeParams } = MIMEParams;
    delete MIMEParams.instantiateMimeParams;

    class MIMEType {
      #type;
      #subtype;
      #parameters;
      constructor(string) {
        string = `${string}`;
        const data = parseTypeAndSubtype(string);
        this.#type = data[0];
        this.#subtype = data[1];
        this.#parameters = instantiateMimeParams(StringPrototypeSlice(string, data[2]));
      }
      get type() {
        return this.#type;
      }
      set type(v) {
        v = `${v}`;
        const invalidTypeIndex = SafeStringPrototypeSearch2(v, NOT_HTTP_TOKEN_CODE_POINT);
        if (v.length === 0 || invalidTypeIndex !== -1) {
          throw new ERR_INVALID_MIME_SYNTAX("type", v, invalidTypeIndex);
        }
        this.#type = toASCIILower(v);
      }
      get subtype() {
        return this.#subtype;
      }
      set subtype(v) {
        v = `${v}`;
        const invalidSubtypeIndex = SafeStringPrototypeSearch2(v, NOT_HTTP_TOKEN_CODE_POINT);
        if (v.length === 0 || invalidSubtypeIndex !== -1) {
          throw new ERR_INVALID_MIME_SYNTAX("subtype", v, invalidSubtypeIndex);
        }
        this.#subtype = toASCIILower(v);
      }
      get essence() {
        return `${this.#type}/${this.#subtype}`;
      }
      get params() {
        return this.#parameters;
      }
      toString() {
        let ret = `${this.#type}/${this.#subtype}`;
        const paramStr = FunctionPrototypeCall(MIMEParamsStringify, this.#parameters);
        if (paramStr.length)
          ret += `;${paramStr}`;
        return ret;
      }
    }
    ObjectDefineProperty(MIMEType.prototype, "toJSON", {
      __proto__: null,
      configurable: true,
      value: MIMEType.prototype.toString,
      writable: true
    });
    module.exports = {
      MIMEParams,
      MIMEType
    };
  }

  // third_party/node/internal/options.js
  function options_default(exports, require2, module, process, internalBinding, primordials2) {
    const DEFAULTS = {
      "--insecure-http-parser": false,
      "--max-http-header-size": 16384,
      "--http-parser": "llhttp",
      "--pending-deprecation": false,
      "--throw-deprecation": false,
      "--no-deprecation": false,
      "--trace-deprecation": false
    };
    function getOptionValue(name) {
      return Object.prototype.hasOwnProperty.call(DEFAULTS, name) ? DEFAULTS[name] : undefined;
    }
    function getEmbedderOptions() {
      return { __proto__: null };
    }
    module.exports = { getOptionValue, getEmbedderOptions };
  }

  // third_party/node/internal/process/task_queues.js
  function task_queues_default(exports, require2, module, process, internalBinding, primordials2) {
    const queueMicrotask = typeof globalThis.queueMicrotask === "function" ? (cb) => globalThis.queueMicrotask(cb) : (cb) => Promise.resolve().then(cb);
    module.exports = {
      queueMicrotask,
      nextTick: (cb, ...args) => process.nextTick(cb, ...args)
    };
  }

  // third_party/node/internal/querystring.js
  function querystring_default2(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Array: Array2,
      Int8Array: Int8Array2,
      NumberPrototypeToString,
      StringPrototypeCharCodeAt,
      StringPrototypeSlice,
      StringPrototypeToUpperCase
    } = primordials2;
    const { ERR_INVALID_URI } = require2("internal/errors").codes;
    const hexTable = new Array2(256);
    for (let i = 0;i < 256; ++i)
      hexTable[i] = "%" + StringPrototypeToUpperCase((i < 16 ? "0" : "") + NumberPrototypeToString(i, 16));
    const isHexTable = new Int8Array2([
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]);
    function encodeStr(str, noEscapeTable, hexTable2) {
      const len = str.length;
      if (len === 0)
        return "";
      let out = "";
      let lastPos = 0;
      let i = 0;
      outer:
        for (;i < len; i++) {
          let c = StringPrototypeCharCodeAt(str, i);
          while (c < 128) {
            if (noEscapeTable[c] !== 1) {
              if (lastPos < i)
                out += StringPrototypeSlice(str, lastPos, i);
              lastPos = i + 1;
              out += hexTable2[c];
            }
            if (++i === len)
              break outer;
            c = StringPrototypeCharCodeAt(str, i);
          }
          if (lastPos < i)
            out += StringPrototypeSlice(str, lastPos, i);
          if (c < 2048) {
            lastPos = i + 1;
            out += hexTable2[192 | c >> 6] + hexTable2[128 | c & 63];
            continue;
          }
          if (c < 55296 || c >= 57344) {
            lastPos = i + 1;
            out += hexTable2[224 | c >> 12] + hexTable2[128 | c >> 6 & 63] + hexTable2[128 | c & 63];
            continue;
          }
          ++i;
          if (i >= len)
            throw new ERR_INVALID_URI;
          const c2 = StringPrototypeCharCodeAt(str, i) & 1023;
          lastPos = i + 1;
          c = 65536 + ((c & 1023) << 10 | c2);
          out += hexTable2[240 | c >> 18] + hexTable2[128 | c >> 12 & 63] + hexTable2[128 | c >> 6 & 63] + hexTable2[128 | c & 63];
        }
      if (lastPos === 0)
        return str;
      if (lastPos < len)
        return out + StringPrototypeSlice(str, lastPos);
      return out;
    }
    module.exports = {
      encodeStr,
      hexTable,
      isHexTable
    };
  }

  // third_party/node/internal/streams/add-abort-signal.js
  function add_abort_signal_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      SymbolDispose
    } = primordials2;
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE
      }
    } = require2("internal/errors");
    const {
      isNodeStream,
      isWebStream,
      kControllerErrorFunction
    } = require2("internal/streams/utils");
    const { eos } = require2("internal/streams/end-of-stream");
    let addAbortListener;
    const validateAbortSignal = (signal, name) => {
      if (typeof signal !== "object" || !("aborted" in signal)) {
        throw new ERR_INVALID_ARG_TYPE(name, "AbortSignal", signal);
      }
    };
    module.exports.addAbortSignal = function addAbortSignal(signal, stream) {
      validateAbortSignal(signal, "signal");
      if (!isNodeStream(stream) && !isWebStream(stream)) {
        throw new ERR_INVALID_ARG_TYPE("stream", ["ReadableStream", "WritableStream", "Stream"], stream);
      }
      return module.exports.addAbortSignalNoValidate(signal, stream);
    };
    module.exports.addAbortSignalNoValidate = function(signal, stream) {
      if (typeof signal !== "object" || !("aborted" in signal)) {
        return stream;
      }
      const onAbort = isNodeStream(stream) ? () => {
        stream.destroy(new AbortError(undefined, { cause: signal.reason }));
      } : () => {
        stream[kControllerErrorFunction](new AbortError(undefined, { cause: signal.reason }));
      };
      if (signal.aborted) {
        onAbort();
      } else {
        addAbortListener ??= require2("internal/events/abort_listener").addAbortListener;
        const disposable = addAbortListener(signal, onAbort);
        eos(stream, disposable[SymbolDispose]);
      }
      return stream;
    };
  }

  // third_party/node/internal/streams/compose.js
  function compose_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypeSlice
    } = primordials2;
    const { pipeline } = require2("internal/streams/pipeline");
    const Duplex = require2("internal/streams/duplex");
    const { destroyer } = require2("internal/streams/destroy");
    const {
      isNodeStream,
      isReadable,
      isWritable,
      isWebStream,
      isTransformStream,
      isWritableStream,
      isReadableStream
    } = require2("internal/streams/utils");
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_VALUE,
        ERR_MISSING_ARGS
      }
    } = require2("internal/errors");
    const { eos } = require2("internal/streams/end-of-stream");
    module.exports = function compose(...streams) {
      if (streams.length === 0) {
        throw new ERR_MISSING_ARGS("streams");
      }
      if (streams.length === 1) {
        return Duplex.from(streams[0]);
      }
      const orgStreams = ArrayPrototypeSlice(streams);
      if (typeof streams[0] === "function") {
        streams[0] = Duplex.from(streams[0]);
      }
      if (typeof streams[streams.length - 1] === "function") {
        const idx = streams.length - 1;
        streams[idx] = Duplex.from(streams[idx]);
      }
      for (let n = 0;n < streams.length; ++n) {
        if (!isNodeStream(streams[n]) && !isWebStream(streams[n])) {
          continue;
        }
        if (n < streams.length - 1 && !(isReadable(streams[n]) || isReadableStream(streams[n]) || isTransformStream(streams[n]))) {
          throw new ERR_INVALID_ARG_VALUE(`streams[${n}]`, orgStreams[n], "must be readable");
        }
        if (n > 0 && !(isWritable(streams[n]) || isWritableStream(streams[n]) || isTransformStream(streams[n]))) {
          throw new ERR_INVALID_ARG_VALUE(`streams[${n}]`, orgStreams[n], "must be writable");
        }
      }
      let ondrain;
      let onfinish;
      let onclose;
      let d;
      function onfinished(err) {
        const cb = onclose;
        onclose = null;
        if (cb) {
          cb(err);
        } else if (err) {
          d.destroy(err);
        } else if (!readable && !writable) {
          d.destroy();
        }
      }
      const head = streams[0];
      const tail = pipeline(streams, onfinished);
      const writable = !!(isWritable(head) || isWritableStream(head) || isTransformStream(head));
      const readable = !!(isReadable(tail) || isReadableStream(tail) || isTransformStream(tail));
      d = new Duplex({
        writableObjectMode: !!head?.writableObjectMode,
        readableObjectMode: !!tail?.readableObjectMode,
        writable,
        readable
      });
      if (writable) {
        if (isNodeStream(head)) {
          d._write = function(chunk, encoding, callback) {
            if (head.write(chunk, encoding)) {
              callback();
            } else {
              ondrain = callback;
            }
          };
          d._final = function(callback) {
            head.end();
            onfinish = callback;
          };
          head.on("drain", function() {
            if (ondrain) {
              const cb = ondrain;
              ondrain = null;
              cb();
            }
          });
        } else if (isWebStream(head)) {
          const writable2 = isTransformStream(head) ? head.writable : head;
          const writer = writable2.getWriter();
          d._write = async function(chunk, encoding, callback) {
            try {
              await writer.ready;
              writer.write(chunk).catch(() => {});
              callback();
            } catch (err) {
              callback(err);
            }
          };
          d._final = async function(callback) {
            try {
              await writer.ready;
              writer.close().catch(() => {});
              onfinish = callback;
            } catch (err) {
              callback(err);
            }
          };
        }
        const toRead = isTransformStream(tail) ? tail.readable : tail;
        eos(toRead, () => {
          if (onfinish) {
            const cb = onfinish;
            onfinish = null;
            cb();
          }
        });
      }
      if (readable) {
        if (isNodeStream(tail)) {
          d._read = function() {
            tail.resume();
          };
          tail.on("data", function(chunk) {
            if (!d.push(chunk)) {
              tail.pause();
            }
          });
          tail.on("end", function() {
            d.push(null);
          });
        } else if (isWebStream(tail)) {
          const readable2 = isTransformStream(tail) ? tail.readable : tail;
          const reader = readable2.getReader();
          d._read = async function() {
            while (true) {
              try {
                const { value, done } = await reader.read();
                if (!d.push(value)) {
                  return;
                }
                if (done) {
                  d.push(null);
                  return;
                }
              } catch {
                return;
              }
            }
          };
        }
      }
      d._destroy = function(err, callback) {
        if (!err && onclose !== null) {
          err = new AbortError;
        }
        ondrain = null;
        onfinish = null;
        if (isNodeStream(tail)) {
          destroyer(tail, err);
        }
        if (onclose === null) {
          callback(err);
        } else {
          onclose = callback;
        }
      };
      return d;
    };
  }

  // third_party/node/internal/streams/destroy.js
  function destroy_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Symbol: Symbol2
    } = primordials2;
    const {
      AbortError,
      aggregateTwoErrors,
      codes: {
        ERR_MULTIPLE_CALLBACK
      }
    } = require2("internal/errors");
    const {
      kIsDestroyed,
      isDestroyed,
      isFinished,
      isServerRequest,
      kState,
      kErrorEmitted,
      kEmitClose,
      kClosed,
      kCloseEmitted,
      kConstructed,
      kDestroyed,
      kAutoDestroy,
      kErrored
    } = require2("internal/streams/utils");
    const kDestroy = Symbol2("kDestroy");
    const kConstruct = Symbol2("kConstruct");
    function checkError(err, w, r) {
      if (err) {
        err.stack;
        if (w && !w.errored) {
          w.errored = err;
        }
        if (r && !r.errored) {
          r.errored = err;
        }
      }
    }
    function destroy(err, cb) {
      const r = this._readableState;
      const w = this._writableState;
      const s = w || r;
      if (w && (w[kState] & kDestroyed) !== 0 || r && (r[kState] & kDestroyed) !== 0) {
        if (typeof cb === "function") {
          cb();
        }
        return this;
      }
      checkError(err, w, r);
      if (w) {
        w[kState] |= kDestroyed;
      }
      if (r) {
        r[kState] |= kDestroyed;
      }
      if ((s[kState] & kConstructed) === 0) {
        this.once(kDestroy, function(er) {
          _destroy(this, aggregateTwoErrors(er, err), cb);
        });
      } else {
        _destroy(this, err, cb);
      }
      return this;
    }
    function _destroy(self, err, cb) {
      let called = false;
      function onDestroy(err2) {
        if (called) {
          return;
        }
        called = true;
        const r = self._readableState;
        const w = self._writableState;
        checkError(err2, w, r);
        if (w) {
          w[kState] |= kClosed;
        }
        if (r) {
          r[kState] |= kClosed;
        }
        if (typeof cb === "function") {
          cb(err2);
        }
        if (err2) {
          process.nextTick(emitErrorCloseNT, self, err2);
        } else {
          process.nextTick(emitCloseNT, self);
        }
      }
      try {
        self._destroy(err || null, onDestroy);
      } catch (err2) {
        onDestroy(err2);
      }
    }
    function emitErrorCloseNT(self, err) {
      emitErrorNT(self, err);
      emitCloseNT(self);
    }
    function emitCloseNT(self) {
      const r = self._readableState;
      const w = self._writableState;
      if (w) {
        w[kState] |= kCloseEmitted;
      }
      if (r) {
        r[kState] |= kCloseEmitted;
      }
      if (w && (w[kState] & kEmitClose) !== 0 || r && (r[kState] & kEmitClose) !== 0) {
        self.emit("close");
      }
    }
    function emitErrorNT(self, err) {
      const r = self._readableState;
      const w = self._writableState;
      if (w && (w[kState] & kErrorEmitted) !== 0 || r && (r[kState] & kErrorEmitted) !== 0) {
        return;
      }
      if (w) {
        w[kState] |= kErrorEmitted;
      }
      if (r) {
        r[kState] |= kErrorEmitted;
      }
      self.emit("error", err);
    }
    function undestroy() {
      const r = this._readableState;
      const w = this._writableState;
      if (r) {
        r.constructed = true;
        r.closed = false;
        r.closeEmitted = false;
        r.destroyed = false;
        r.errored = null;
        r.errorEmitted = false;
        r.reading = false;
        r.ended = r.readable === false;
        r.endEmitted = r.readable === false;
      }
      if (w) {
        w.constructed = true;
        w.destroyed = false;
        w.closed = false;
        w.closeEmitted = false;
        w.errored = null;
        w.errorEmitted = false;
        w.finalCalled = false;
        w.prefinished = false;
        w.ended = w.writable === false;
        w.ending = w.writable === false;
        w.finished = w.writable === false;
      }
    }
    function errorOrDestroy(stream, err, sync) {
      const r = stream._readableState;
      const w = stream._writableState;
      if (w && (w[kState] ? (w[kState] & kDestroyed) !== 0 : w.destroyed) || r && (r[kState] ? (r[kState] & kDestroyed) !== 0 : r.destroyed)) {
        return this;
      }
      if (r && (r[kState] & kAutoDestroy) !== 0 || w && (w[kState] & kAutoDestroy) !== 0) {
        stream.destroy(err);
      } else if (err) {
        err.stack;
        if (w && (w[kState] & kErrored) === 0) {
          w.errored = err;
        }
        if (r && (r[kState] & kErrored) === 0) {
          r.errored = err;
        }
        if (sync) {
          process.nextTick(emitErrorNT, stream, err);
        } else {
          emitErrorNT(stream, err);
        }
      }
    }
    function construct(stream, cb) {
      if (typeof stream._construct !== "function") {
        return;
      }
      const r = stream._readableState;
      const w = stream._writableState;
      if (r) {
        r[kState] &= ~kConstructed;
      }
      if (w) {
        w[kState] &= ~kConstructed;
      }
      stream.once(kConstruct, cb);
      if (stream.listenerCount(kConstruct) > 1) {
        return;
      }
      process.nextTick(constructNT, stream);
    }
    function constructNT(stream) {
      let called = false;
      function onConstruct(err) {
        if (called) {
          errorOrDestroy(stream, err ?? new ERR_MULTIPLE_CALLBACK);
          return;
        }
        called = true;
        const r = stream._readableState;
        const w = stream._writableState;
        const s = w || r;
        if (r) {
          r[kState] |= kConstructed;
        }
        if (w) {
          w[kState] |= kConstructed;
        }
        if (s.destroyed) {
          stream.emit(kDestroy, err);
        } else if (err) {
          errorOrDestroy(stream, err, true);
        } else {
          stream.emit(kConstruct);
        }
      }
      try {
        stream._construct((err) => {
          process.nextTick(onConstruct, err);
        });
      } catch (err) {
        process.nextTick(onConstruct, err);
      }
    }
    function isRequest(stream) {
      return stream?.setHeader && typeof stream.abort === "function";
    }
    function emitCloseLegacy(stream) {
      stream.emit("close");
    }
    function emitErrorCloseLegacy(stream, err) {
      stream.emit("error", err);
      process.nextTick(emitCloseLegacy, stream);
    }
    function destroyer(stream, err) {
      if (!stream || isDestroyed(stream)) {
        return;
      }
      if (!err && !isFinished(stream)) {
        err = new AbortError;
      }
      if (isServerRequest(stream)) {
        stream.socket = null;
        stream.destroy(err);
      } else if (isRequest(stream)) {
        stream.abort();
      } else if (isRequest(stream.req)) {
        stream.req.abort();
      } else if (typeof stream.destroy === "function") {
        stream.destroy(err);
      } else if (typeof stream.close === "function") {
        stream.close();
      } else if (err) {
        process.nextTick(emitErrorCloseLegacy, stream, err);
      } else {
        process.nextTick(emitCloseLegacy, stream);
      }
      if (!stream.destroyed) {
        stream[kIsDestroyed] = true;
      }
    }
    module.exports = {
      construct,
      destroyer,
      destroy,
      undestroy,
      errorOrDestroy
    };
  }

  // third_party/node/internal/streams/duplex.js
  function duplex_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ObjectDefineProperties,
      ObjectGetOwnPropertyDescriptor,
      ObjectKeys,
      ObjectSetPrototypeOf
    } = primordials2;
    module.exports = Duplex;
    const Stream = require2("internal/streams/legacy").Stream;
    const Readable = require2("internal/streams/readable");
    const Writable = require2("internal/streams/writable");
    const {
      addAbortSignal
    } = require2("internal/streams/add-abort-signal");
    const destroyImpl = require2("internal/streams/destroy");
    const { kOnConstructed } = require2("internal/streams/utils");
    ObjectSetPrototypeOf(Duplex.prototype, Readable.prototype);
    ObjectSetPrototypeOf(Duplex, Readable);
    {
      const keys = ObjectKeys(Writable.prototype);
      for (let i = 0;i < keys.length; i++) {
        const method = keys[i];
        Duplex.prototype[method] ||= Writable.prototype[method];
      }
    }
    Duplex.prototype.destroy = Writable.prototype.destroy;
    function Duplex(options) {
      if (!(this instanceof Duplex))
        return new Duplex(options);
      this._events ??= {
        close: undefined,
        error: undefined,
        prefinish: undefined,
        finish: undefined,
        drain: undefined,
        data: undefined,
        end: undefined,
        readable: undefined
      };
      this._readableState = new Readable.ReadableState(options, this, true);
      this._writableState = new Writable.WritableState(options, this, true);
      if (options) {
        this.allowHalfOpen = options.allowHalfOpen !== false;
        if (options.readable === false) {
          this._readableState.readable = false;
          this._readableState.ended = true;
          this._readableState.endEmitted = true;
        }
        if (options.writable === false) {
          this._writableState.writable = false;
          this._writableState.ending = true;
          this._writableState.ended = true;
          this._writableState.finished = true;
        }
        if (typeof options.read === "function")
          this._read = options.read;
        if (typeof options.write === "function")
          this._write = options.write;
        if (typeof options.writev === "function")
          this._writev = options.writev;
        if (typeof options.destroy === "function")
          this._destroy = options.destroy;
        if (typeof options.final === "function")
          this._final = options.final;
        if (typeof options.construct === "function")
          this._construct = options.construct;
        if (options.signal)
          addAbortSignal(options.signal, this);
      } else {
        this.allowHalfOpen = true;
      }
      Stream.call(this, options);
      if (this._construct != null) {
        destroyImpl.construct(this, () => {
          this._readableState[kOnConstructed](this);
          this._writableState[kOnConstructed](this);
        });
      }
    }
    ObjectDefineProperties(Duplex.prototype, {
      writable: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writable") },
      writableHighWaterMark: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableHighWaterMark") },
      writableObjectMode: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableObjectMode") },
      writableBuffer: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableBuffer") },
      writableLength: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableLength") },
      writableFinished: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableFinished") },
      writableCorked: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableCorked") },
      writableEnded: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableEnded") },
      writableNeedDrain: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableNeedDrain") },
      destroyed: {
        __proto__: null,
        get() {
          if (this._readableState === undefined || this._writableState === undefined) {
            return false;
          }
          return this._readableState.destroyed && this._writableState.destroyed;
        },
        set(value) {
          if (this._readableState && this._writableState) {
            this._readableState.destroyed = value;
            this._writableState.destroyed = value;
          }
        }
      }
    });
    let webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === undefined)
        webStreamsAdapters = require2("internal/webstreams/adapters");
      return webStreamsAdapters;
    }
    Duplex.fromWeb = function(pair, options) {
      return lazyWebStreams().newStreamDuplexFromReadableWritablePair(pair, options);
    };
    Duplex.toWeb = function(duplex, options) {
      return lazyWebStreams().newReadableWritablePairFromDuplex(duplex, options);
    };
    let duplexify;
    Duplex.from = function(body) {
      duplexify ??= require2("internal/streams/duplexify");
      return duplexify(body, "body");
    };
  }

  // third_party/node/internal/streams/duplexify.js
  function duplexify_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      FunctionPrototypeCall,
      PromiseWithResolvers
    } = primordials2;
    const {
      isReadable,
      isWritable,
      isIterable,
      isNodeStream,
      isReadableNodeStream,
      isWritableNodeStream,
      isDuplexNodeStream,
      isReadableStream,
      isWritableStream
    } = require2("internal/streams/utils");
    const { eos } = require2("internal/streams/end-of-stream");
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_RETURN_VALUE
      }
    } = require2("internal/errors");
    const { destroyer } = require2("internal/streams/destroy");
    const Duplex = require2("internal/streams/duplex");
    const Readable = require2("internal/streams/readable");
    const Writable = require2("internal/streams/writable");
    const from = require2("internal/streams/from");
    const {
      isBlob
    } = require2("internal/blob");
    const { AbortController } = require2("internal/abort_controller");

    class Duplexify extends Duplex {
      constructor(options) {
        super(options);
        if (options?.readable === false) {
          this._readableState.readable = false;
          this._readableState.ended = true;
          this._readableState.endEmitted = true;
        }
        if (options?.writable === false) {
          this._writableState.writable = false;
          this._writableState.ending = true;
          this._writableState.ended = true;
          this._writableState.finished = true;
        }
      }
    }
    module.exports = function duplexify(body, name) {
      if (isDuplexNodeStream(body)) {
        return body;
      }
      if (isReadableNodeStream(body)) {
        return _duplexify({ __proto__: null, readable: body });
      }
      if (isWritableNodeStream(body)) {
        return _duplexify({ __proto__: null, writable: body });
      }
      if (isNodeStream(body)) {
        return _duplexify({ __proto__: null, writable: false, readable: false });
      }
      if (isReadableStream(body)) {
        return _duplexify({ __proto__: null, readable: Readable.fromWeb(body) });
      }
      if (isWritableStream(body)) {
        return _duplexify({ __proto__: null, writable: Writable.fromWeb(body) });
      }
      if (typeof body === "function") {
        const { value, write, final, destroy } = fromAsyncGen(body);
        if (isDuplexNodeStream(value)) {
          return value;
        }
        if (isIterable(value)) {
          return from(Duplexify, value, {
            objectMode: true,
            write,
            final,
            destroy
          });
        }
        const then2 = value?.then;
        if (typeof then2 === "function") {
          let d;
          const promise = FunctionPrototypeCall(then2, value, (val) => {
            if (val != null) {
              throw new ERR_INVALID_RETURN_VALUE("nully", "body", val);
            }
          }, (err) => {
            destroyer(d, err);
          });
          return d = new Duplexify({
            objectMode: true,
            readable: false,
            write,
            final(cb) {
              final(async () => {
                try {
                  await promise;
                  process.nextTick(cb, null);
                } catch (err) {
                  process.nextTick(cb, err);
                }
              });
            },
            destroy
          });
        }
        throw new ERR_INVALID_RETURN_VALUE("Iterable, AsyncIterable or AsyncFunction", name, value);
      }
      if (isBlob(body)) {
        return duplexify(body.arrayBuffer());
      }
      if (isIterable(body)) {
        return from(Duplexify, body, {
          objectMode: true,
          writable: false
        });
      }
      if (isReadableStream(body?.readable) && isWritableStream(body?.writable)) {
        return Duplexify.fromWeb(body);
      }
      if (typeof body?.writable === "object" || typeof body?.readable === "object") {
        const readable = body?.readable ? isReadableNodeStream(body?.readable) ? body?.readable : duplexify(body.readable) : undefined;
        const writable = body?.writable ? isWritableNodeStream(body?.writable) ? body?.writable : duplexify(body.writable) : undefined;
        return _duplexify({ __proto__: null, readable, writable });
      }
      const then = body?.then;
      if (typeof then === "function") {
        let d;
        FunctionPrototypeCall(then, body, (val) => {
          if (val != null) {
            d.push(val);
          }
          d.push(null);
        }, (err) => {
          destroyer(d, err);
        });
        return d = new Duplexify({
          objectMode: true,
          writable: false,
          read() {}
        });
      }
      throw new ERR_INVALID_ARG_TYPE(name, [
        "Blob",
        "ReadableStream",
        "WritableStream",
        "Stream",
        "Iterable",
        "AsyncIterable",
        "Function",
        "{ readable, writable } pair",
        "Promise"
      ], body);
    };
    function fromAsyncGen(fn) {
      let { promise, resolve: resolve2 } = PromiseWithResolvers();
      const ac = new AbortController;
      const signal = ac.signal;
      const value = fn(async function* () {
        while (true) {
          const _promise = promise;
          promise = null;
          const { chunk, done, cb } = await _promise;
          process.nextTick(cb);
          if (done)
            return;
          if (signal.aborted)
            throw new AbortError(undefined, { cause: signal.reason });
          ({ promise, resolve: resolve2 } = PromiseWithResolvers());
          yield chunk;
        }
      }(), { signal });
      return {
        value,
        write(chunk, encoding, cb) {
          const _resolve = resolve2;
          resolve2 = null;
          _resolve({ __proto__: null, chunk, done: false, cb });
        },
        final(cb) {
          const _resolve = resolve2;
          resolve2 = null;
          _resolve({ __proto__: null, done: true, cb });
        },
        destroy(err, cb) {
          ac.abort(err);
          if (resolve2 !== null) {
            const _resolve = resolve2;
            resolve2 = null;
            _resolve({ __proto__: null, done: true, cb() {} });
          }
          cb(err);
        }
      };
    }
    function _duplexify(pair) {
      const r = pair.readable && typeof pair.readable.read !== "function" ? Readable.wrap(pair.readable) : pair.readable;
      const w = pair.writable;
      let readable = !!isReadable(r);
      let writable = !!isWritable(w);
      let ondrain;
      let onfinish;
      let onreadable;
      let onclose;
      let d;
      function onfinished(err) {
        const cb = onclose;
        onclose = null;
        if (cb) {
          cb(err);
        } else if (err) {
          d.destroy(err);
        }
      }
      d = new Duplexify({
        readableObjectMode: !!r?.readableObjectMode,
        writableObjectMode: !!w?.writableObjectMode,
        readable,
        writable
      });
      if (writable) {
        eos(w, (err) => {
          writable = false;
          if (err) {
            destroyer(r, err);
          }
          onfinished(err);
        });
        d._write = function(chunk, encoding, callback) {
          if (w.write(chunk, encoding)) {
            callback();
          } else {
            ondrain = callback;
          }
        };
        d._final = function(callback) {
          w.end();
          onfinish = callback;
        };
        w.on("drain", function() {
          if (ondrain) {
            const cb = ondrain;
            ondrain = null;
            cb();
          }
        });
        w.on("finish", function() {
          if (onfinish) {
            const cb = onfinish;
            onfinish = null;
            cb();
          }
        });
      }
      if (readable) {
        eos(r, (err) => {
          readable = false;
          if (err) {
            destroyer(w, err);
          }
          onfinished(err);
        });
        r.on("readable", function() {
          if (onreadable) {
            const cb = onreadable;
            onreadable = null;
            cb();
          }
        });
        r.on("end", function() {
          d.push(null);
        });
        d._read = function() {
          while (true) {
            const buf = r.read();
            if (buf === null) {
              onreadable = d._read;
              return;
            }
            if (!d.push(buf)) {
              return;
            }
          }
        };
      }
      d._destroy = function(err, callback) {
        if (!err && onclose !== null) {
          err = new AbortError;
        }
        onreadable = null;
        ondrain = null;
        onfinish = null;
        if (onclose === null) {
          callback(err);
        } else {
          onclose = callback;
          destroyer(w, err);
          destroyer(r, err);
        }
      };
      return d;
    }
  }

  // third_party/node/internal/streams/duplexpair.js
  function duplexpair_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Symbol: Symbol2
    } = primordials2;
    const { Duplex } = require2("stream");
    const assert = require2("internal/assert");
    const kCallback = Symbol2("Callback");
    const kInitOtherSide = Symbol2("InitOtherSide");

    class DuplexSide extends Duplex {
      #otherSide = null;
      constructor(options) {
        super(options);
        this[kCallback] = null;
        this.#otherSide = null;
      }
      [kInitOtherSide](otherSide) {
        if (this.#otherSide === null) {
          this.#otherSide = otherSide;
        } else {
          assert(this.#otherSide === null);
        }
      }
      _read() {
        const callback = this[kCallback];
        if (callback) {
          this[kCallback] = null;
          callback();
        }
      }
      _write(chunk, encoding, callback) {
        assert(this.#otherSide !== null);
        assert(this.#otherSide[kCallback] === null);
        if (chunk.length === 0) {
          process.nextTick(callback);
        } else {
          this.#otherSide.push(chunk);
          this.#otherSide[kCallback] = callback;
        }
      }
      _final(callback) {
        this.#otherSide.on("end", callback);
        this.#otherSide.push(null);
      }
      _destroy(err, callback) {
        const otherSide = this.#otherSide;
        if (otherSide !== null && !otherSide.destroyed) {
          process.nextTick(() => {
            if (otherSide.destroyed)
              return;
            if (err) {
              otherSide.destroy();
            } else {
              otherSide.push(null);
            }
          });
        }
        callback(err);
      }
    }
    function duplexPair(options) {
      const side0 = new DuplexSide(options);
      const side1 = new DuplexSide(options);
      side0[kInitOtherSide](side1);
      side1[kInitOtherSide](side0);
      return [side0, side1];
    }
    module.exports = duplexPair;
  }

  // third_party/node/internal/streams/end-of-stream.js
  function end_of_stream_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Promise: Promise2,
      PromisePrototypeThen,
      SymbolDispose
    } = primordials2;
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_STREAM_PREMATURE_CLOSE
      }
    } = require2("internal/errors");
    const {
      kEmptyObject,
      once
    } = require2("internal/util");
    const {
      validateAbortSignal,
      validateFunction,
      validateObject,
      validateBoolean
    } = require2("internal/validators");
    const {
      isClosed,
      isReadable,
      isReadableNodeStream,
      isReadableStream,
      isReadableFinished,
      isReadableErrored,
      isWritable,
      isWritableNodeStream,
      isWritableStream,
      isWritableFinished,
      isWritableErrored,
      isNodeStream,
      willEmitClose: _willEmitClose,
      kIsClosedPromise
    } = require2("internal/streams/utils");
    let AsyncResource;
    let addAbortListener;
    function isRequest(stream) {
      return stream.setHeader && typeof stream.abort === "function";
    }
    const nop = () => {};
    function bindAsyncResource(fn, type) {
      AsyncResource ??= require2("async_hooks").AsyncResource;
      const resource = new AsyncResource(type);
      return function(...args) {
        return resource.runInAsyncScope(fn, this, ...args);
      };
    }
    function eos(stream, options, callback) {
      if (arguments.length === 2) {
        callback = options;
        options = kEmptyObject;
      } else if (options == null) {
        options = kEmptyObject;
      } else {
        validateObject(options, "options");
      }
      validateFunction(callback, "callback");
      validateAbortSignal(options.signal, "options.signal");
      callback = once(bindAsyncResource(callback, "STREAM_END_OF_STREAM"));
      if (isReadableStream(stream) || isWritableStream(stream)) {
        return eosWeb(stream, options, callback);
      }
      if (!isNodeStream(stream)) {
        throw new ERR_INVALID_ARG_TYPE("stream", ["ReadableStream", "WritableStream", "Stream"], stream);
      }
      const readable = options.readable ?? isReadableNodeStream(stream);
      const writable = options.writable ?? isWritableNodeStream(stream);
      const wState = stream._writableState;
      const rState = stream._readableState;
      const onlegacyfinish = () => {
        if (!stream.writable) {
          onfinish();
        }
      };
      let willEmitClose = _willEmitClose(stream) && isReadableNodeStream(stream) === readable && isWritableNodeStream(stream) === writable;
      let writableFinished = isWritableFinished(stream, false);
      const onfinish = () => {
        writableFinished = true;
        if (stream.destroyed) {
          willEmitClose = false;
        }
        if (willEmitClose && (!stream.readable || readable)) {
          return;
        }
        if (!readable || readableFinished) {
          callback.call(stream);
        }
      };
      let readableFinished = isReadableFinished(stream, false);
      const onend = () => {
        readableFinished = true;
        if (stream.destroyed) {
          willEmitClose = false;
        }
        if (willEmitClose && (!stream.writable || writable)) {
          return;
        }
        if (!writable || writableFinished) {
          callback.call(stream);
        }
      };
      const onerror = (err) => {
        callback.call(stream, err);
      };
      let closed = isClosed(stream);
      const onclose = () => {
        closed = true;
        const errored = isWritableErrored(stream) || isReadableErrored(stream);
        if (errored && typeof errored !== "boolean") {
          return callback.call(stream, errored);
        }
        if (readable && !readableFinished && isReadableNodeStream(stream, true)) {
          if (!isReadableFinished(stream, false))
            return callback.call(stream, new ERR_STREAM_PREMATURE_CLOSE);
        }
        if (writable && !writableFinished) {
          if (!isWritableFinished(stream, false))
            return callback.call(stream, new ERR_STREAM_PREMATURE_CLOSE);
        }
        callback.call(stream);
      };
      const onclosed = () => {
        closed = true;
        const errored = isWritableErrored(stream) || isReadableErrored(stream);
        if (errored && typeof errored !== "boolean") {
          return callback.call(stream, errored);
        }
        callback.call(stream);
      };
      const onrequest = () => {
        stream.req.on("finish", onfinish);
      };
      if (isRequest(stream)) {
        stream.on("complete", onfinish);
        if (!willEmitClose) {
          stream.on("abort", onclose);
        }
        if (stream.req) {
          onrequest();
        } else {
          stream.on("request", onrequest);
        }
      } else if (writable && !wState) {
        stream.on("end", onlegacyfinish);
        stream.on("close", onlegacyfinish);
      }
      if (!willEmitClose && typeof stream.aborted === "boolean") {
        stream.on("aborted", onclose);
      }
      stream.on("end", onend);
      stream.on("finish", onfinish);
      if (options.error !== false) {
        stream.on("error", onerror);
      }
      stream.on("close", onclose);
      if (closed) {
        process.nextTick(onclose);
      } else if (wState?.errorEmitted || rState?.errorEmitted) {
        if (!willEmitClose) {
          process.nextTick(onclosed);
        }
      } else if (!readable && (!willEmitClose || isReadable(stream)) && (writableFinished || isWritable(stream) === false) && (wState == null || wState.pendingcb === undefined || wState.pendingcb === 0)) {
        process.nextTick(onclosed);
      } else if (!writable && (!willEmitClose || isWritable(stream)) && (readableFinished || isReadable(stream) === false)) {
        process.nextTick(onclosed);
      } else if (rState && stream.req && stream.aborted) {
        process.nextTick(onclosed);
      }
      const cleanup = () => {
        callback = nop;
        stream.removeListener("aborted", onclose);
        stream.removeListener("complete", onfinish);
        stream.removeListener("abort", onclose);
        stream.removeListener("request", onrequest);
        if (stream.req)
          stream.req.removeListener("finish", onfinish);
        stream.removeListener("end", onlegacyfinish);
        stream.removeListener("close", onlegacyfinish);
        stream.removeListener("finish", onfinish);
        stream.removeListener("end", onend);
        stream.removeListener("error", onerror);
        stream.removeListener("close", onclose);
      };
      if (options.signal && !closed) {
        const abort = () => {
          const endCallback = callback;
          cleanup();
          endCallback.call(stream, new AbortError(undefined, { cause: options.signal.reason }));
        };
        if (options.signal.aborted) {
          process.nextTick(abort);
        } else {
          addAbortListener ??= require2("internal/events/abort_listener").addAbortListener;
          const disposable = addAbortListener(options.signal, abort);
          const originalCallback = callback;
          callback = once((...args) => {
            disposable[SymbolDispose]();
            originalCallback.apply(stream, args);
          });
        }
      }
      return cleanup;
    }
    function eosWeb(stream, options, callback) {
      let isAborted = false;
      let abort = nop;
      if (options.signal) {
        abort = () => {
          isAborted = true;
          callback.call(stream, new AbortError(undefined, { cause: options.signal.reason }));
        };
        if (options.signal.aborted) {
          process.nextTick(abort);
        } else {
          addAbortListener ??= require2("internal/events/abort_listener").addAbortListener;
          const disposable = addAbortListener(options.signal, abort);
          const originalCallback = callback;
          callback = once((...args) => {
            disposable[SymbolDispose]();
            originalCallback.apply(stream, args);
          });
        }
      }
      const resolverFn = (...args) => {
        if (!isAborted) {
          process.nextTick(() => callback.apply(stream, args));
        }
      };
      PromisePrototypeThen(stream[kIsClosedPromise].promise, resolverFn, resolverFn);
      return nop;
    }
    function finished(stream, opts) {
      let autoCleanup = false;
      if (opts === null) {
        opts = kEmptyObject;
      }
      if (opts?.cleanup) {
        validateBoolean(opts.cleanup, "cleanup");
        autoCleanup = opts.cleanup;
      }
      return new Promise2((resolve2, reject) => {
        const cleanup = eos(stream, opts, (err) => {
          if (autoCleanup) {
            cleanup();
          }
          if (err) {
            reject(err);
          } else {
            resolve2();
          }
        });
      });
    }
    module.exports = {
      eos,
      finished
    };
  }

  // third_party/node/internal/streams/from.js
  function from_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      PromisePrototypeThen,
      SymbolAsyncIterator,
      SymbolIterator
    } = primordials2;
    const { Buffer } = require2("buffer");
    const {
      aggregateTwoErrors,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_STREAM_NULL_VALUES
      }
    } = require2("internal/errors");
    function from(Readable, iterable, opts) {
      let iterator;
      if (typeof iterable === "string" || iterable instanceof Buffer) {
        return new Readable({
          objectMode: true,
          ...opts,
          read() {
            this.push(iterable);
            this.push(null);
          }
        });
      }
      let isAsync;
      if (iterable?.[SymbolAsyncIterator]) {
        isAsync = true;
        iterator = iterable[SymbolAsyncIterator]();
      } else if (iterable?.[SymbolIterator]) {
        isAsync = false;
        iterator = iterable[SymbolIterator]();
      } else {
        throw new ERR_INVALID_ARG_TYPE("iterable", ["Iterable"], iterable);
      }
      const readable = new Readable({
        objectMode: true,
        highWaterMark: 1,
        ...opts
      });
      const originalDestroy = readable._destroy;
      let reading = false;
      let isAsyncValues = false;
      readable._read = function() {
        if (!reading) {
          reading = true;
          if (isAsync) {
            nextAsync();
          } else if (isAsyncValues) {
            nextSyncWithAsyncValues();
          } else {
            nextSyncWithSyncValues();
          }
        }
      };
      readable._destroy = function(error, cb) {
        originalDestroy.call(this, error, (destroyError) => {
          const combinedError = destroyError || error;
          PromisePrototypeThen(close(combinedError), () => process.nextTick(cb, combinedError), (closeError) => process.nextTick(cb, aggregateTwoErrors(combinedError, closeError)));
        });
      };
      async function close(error) {
        const hadError = error !== undefined && error !== null;
        const hasThrow = typeof iterator.throw === "function";
        if (hadError && hasThrow) {
          const { value, done } = await iterator.throw(error);
          await value;
          if (done) {
            return;
          }
        }
        if (typeof iterator.return === "function") {
          const { value } = await iterator.return();
          await value;
        }
      }
      function nextSyncWithSyncValues() {
        for (;; ) {
          try {
            const { value, done } = iterator.next();
            if (done) {
              readable.push(null);
              return;
            }
            if (value && typeof value.then === "function") {
              return changeToAsyncValues(value);
            }
            if (value === null) {
              reading = false;
              throw new ERR_STREAM_NULL_VALUES;
            }
            if (readable.push(value)) {
              continue;
            }
            reading = false;
          } catch (err) {
            readable.destroy(err);
          }
          break;
        }
      }
      async function changeToAsyncValues(value) {
        isAsyncValues = true;
        try {
          const res = await value;
          if (res === null) {
            reading = false;
            throw new ERR_STREAM_NULL_VALUES;
          }
          if (readable.push(res)) {
            nextSyncWithAsyncValues();
            return;
          }
          reading = false;
        } catch (err) {
          readable.destroy(err);
        }
      }
      async function nextSyncWithAsyncValues() {
        for (;; ) {
          try {
            const { value, done } = iterator.next();
            if (done) {
              readable.push(null);
              return;
            }
            const res = value && typeof value.then === "function" ? await value : value;
            if (res === null) {
              reading = false;
              throw new ERR_STREAM_NULL_VALUES;
            }
            if (readable.push(res)) {
              continue;
            }
            reading = false;
          } catch (err) {
            readable.destroy(err);
          }
          break;
        }
      }
      async function nextAsync() {
        for (;; ) {
          try {
            const { value, done } = await iterator.next();
            if (done) {
              readable.push(null);
              return;
            }
            if (value === null) {
              reading = false;
              throw new ERR_STREAM_NULL_VALUES;
            }
            if (readable.push(value)) {
              continue;
            }
            reading = false;
          } catch (err) {
            readable.destroy(err);
          }
          break;
        }
      }
      return readable;
    }
    module.exports = from;
  }

  // third_party/node/internal/streams/legacy.js
  function legacy_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayIsArray,
      ObjectSetPrototypeOf,
      ReflectOwnKeys
    } = primordials2;
    const EE = require2("events");
    function Stream(opts) {
      EE.call(this, opts);
    }
    ObjectSetPrototypeOf(Stream.prototype, EE.prototype);
    ObjectSetPrototypeOf(Stream, EE);
    Stream.prototype.pipe = function(dest, options) {
      const source = this;
      function ondata(chunk) {
        if (dest.writable && dest.write(chunk) === false && source.pause) {
          source.pause();
        }
      }
      source.on("data", ondata);
      function ondrain() {
        if (source.readable && source.resume) {
          source.resume();
        }
      }
      dest.on("drain", ondrain);
      if (!dest._isStdio && (!options || options.end !== false)) {
        source.on("end", onend);
        source.on("close", onclose);
      }
      let didOnEnd = false;
      function onend() {
        if (didOnEnd)
          return;
        didOnEnd = true;
        dest.end();
      }
      function onclose() {
        if (didOnEnd)
          return;
        didOnEnd = true;
        if (typeof dest.destroy === "function")
          dest.destroy();
      }
      function onerror(er) {
        cleanup();
        if (this.listenerCount?.("error") === 0) {
          this.emit("error", er);
        }
      }
      prependListener(source, "error", onerror);
      prependListener(dest, "error", onerror);
      function cleanup() {
        source.removeListener("data", ondata);
        dest.removeListener("drain", ondrain);
        source.removeListener("end", onend);
        source.removeListener("close", onclose);
        source.removeListener("error", onerror);
        dest.removeListener("error", onerror);
        source.removeListener("end", cleanup);
        source.removeListener("close", cleanup);
        dest.removeListener("close", cleanup);
      }
      source.on("end", cleanup);
      source.on("close", cleanup);
      dest.on("close", cleanup);
      dest.emit("pipe", source);
      return dest;
    };
    Stream.prototype.eventNames = function eventNames() {
      const names = [];
      for (const key of ReflectOwnKeys(this._events)) {
        if (typeof this._events[key] === "function" || ArrayIsArray(this._events[key]) && this._events[key].length > 0) {
          names.push(key);
        }
      }
      return names;
    };
    function prependListener(emitter, event, fn) {
      if (typeof emitter.prependListener === "function")
        return emitter.prependListener(event, fn);
      if (!emitter._events || !emitter._events[event])
        emitter.on(event, fn);
      else if (ArrayIsArray(emitter._events[event]))
        emitter._events[event].unshift(fn);
      else
        emitter._events[event] = [fn, emitter._events[event]];
    }
    module.exports = { Stream, prependListener };
  }

  // third_party/node/internal/streams/operators.js
  function operators_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypePush,
      Boolean: Boolean2,
      MathFloor,
      Number: Number2,
      NumberIsNaN,
      Promise: Promise2,
      PromisePrototypeThen,
      PromiseReject,
      PromiseResolve,
      Symbol: Symbol2
    } = primordials2;
    const { AbortController, AbortSignal } = require2("internal/abort_controller");
    const {
      AbortError,
      codes: {
        ERR_MISSING_ARGS,
        ERR_OUT_OF_RANGE
      }
    } = require2("internal/errors");
    const {
      validateAbortSignal,
      validateInteger,
      validateObject,
      validateFunction
    } = require2("internal/validators");
    const { kWeakHandler, kResistStopPropagation } = require2("internal/event_target");
    const { finished } = require2("internal/streams/end-of-stream");
    const kEmpty = Symbol2("kEmpty");
    const kEof = Symbol2("kEof");
    function map(fn, options) {
      validateFunction(fn, "fn");
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      let concurrency = 1;
      if (options?.concurrency != null) {
        concurrency = MathFloor(options.concurrency);
      }
      let highWaterMark = concurrency - 1;
      if (options?.highWaterMark != null) {
        highWaterMark = MathFloor(options.highWaterMark);
      }
      validateInteger(concurrency, "options.concurrency", 1);
      validateInteger(highWaterMark, "options.highWaterMark", 0);
      highWaterMark += concurrency;
      return async function* map2() {
        const signal = AbortSignal.any([options?.signal].filter(Boolean2));
        const stream = this;
        const queue = [];
        const signalOpt = { signal };
        let next;
        let resume;
        let done = false;
        let cnt = 0;
        function onCatch() {
          done = true;
          afterItemProcessed();
        }
        function afterItemProcessed() {
          cnt -= 1;
          maybeResume();
        }
        function maybeResume() {
          if (resume && !done && cnt < concurrency && queue.length < highWaterMark) {
            resume();
            resume = null;
          }
        }
        async function pump() {
          try {
            for await (let val of stream) {
              if (done) {
                return;
              }
              if (signal.aborted) {
                throw new AbortError;
              }
              try {
                val = fn(val, signalOpt);
                if (val === kEmpty) {
                  continue;
                }
                val = PromiseResolve(val);
              } catch (err) {
                val = PromiseReject(err);
              }
              cnt += 1;
              PromisePrototypeThen(val, afterItemProcessed, onCatch);
              queue.push(val);
              if (next) {
                next();
                next = null;
              }
              if (!done && (queue.length >= highWaterMark || cnt >= concurrency)) {
                await new Promise2((resolve2) => {
                  resume = resolve2;
                });
              }
            }
            queue.push(kEof);
          } catch (err) {
            const val = PromiseReject(err);
            PromisePrototypeThen(val, afterItemProcessed, onCatch);
            queue.push(val);
          } finally {
            done = true;
            if (next) {
              next();
              next = null;
            }
          }
        }
        pump();
        try {
          while (true) {
            while (queue.length > 0) {
              const val = await queue[0];
              if (val === kEof) {
                return;
              }
              if (signal.aborted) {
                throw new AbortError;
              }
              if (val !== kEmpty) {
                yield val;
              }
              queue.shift();
              maybeResume();
            }
            await new Promise2((resolve2) => {
              next = resolve2;
            });
          }
        } finally {
          done = true;
          if (resume) {
            resume();
            resume = null;
          }
        }
      }.call(this);
    }
    async function some(fn, options = undefined) {
      for await (const unused of filter.call(this, fn, options)) {
        return true;
      }
      return false;
    }
    async function every(fn, options = undefined) {
      validateFunction(fn, "fn");
      return !await some.call(this, async (...args) => {
        return !await fn(...args);
      }, options);
    }
    async function find(fn, options) {
      for await (const result of filter.call(this, fn, options)) {
        return result;
      }
      return;
    }
    async function forEach(fn, options) {
      validateFunction(fn, "fn");
      async function forEachFn(value, options2) {
        await fn(value, options2);
        return kEmpty;
      }
      for await (const unused of map.call(this, forEachFn, options))
        ;
    }
    function filter(fn, options) {
      validateFunction(fn, "fn");
      async function filterFn(value, options2) {
        if (await fn(value, options2)) {
          return value;
        }
        return kEmpty;
      }
      return map.call(this, filterFn, options);
    }

    class ReduceAwareErrMissingArgs extends ERR_MISSING_ARGS {
      constructor() {
        super("reduce");
        this.message = "Reduce of an empty stream requires an initial value";
      }
    }
    async function reduce(reducer, initialValue, options) {
      validateFunction(reducer, "reducer");
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      let hasInitialValue = arguments.length > 1;
      if (options?.signal?.aborted) {
        const err = new AbortError(undefined, { cause: options.signal.reason });
        this.once("error", () => {});
        await finished(this.destroy(err));
        throw err;
      }
      const ac = new AbortController;
      const signal = ac.signal;
      if (options?.signal) {
        const opts = { once: true, [kWeakHandler]: this, [kResistStopPropagation]: true };
        options.signal.addEventListener("abort", () => ac.abort(), opts);
      }
      let gotAnyItemFromStream = false;
      try {
        for await (const value of this) {
          gotAnyItemFromStream = true;
          if (options?.signal?.aborted) {
            throw new AbortError;
          }
          if (!hasInitialValue) {
            initialValue = value;
            hasInitialValue = true;
          } else {
            initialValue = await reducer(initialValue, value, { signal });
          }
        }
        if (!gotAnyItemFromStream && !hasInitialValue) {
          throw new ReduceAwareErrMissingArgs;
        }
      } finally {
        ac.abort();
      }
      return initialValue;
    }
    async function toArray(options) {
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      const result = [];
      for await (const val of this) {
        if (options?.signal?.aborted) {
          throw new AbortError(undefined, { cause: options.signal.reason });
        }
        ArrayPrototypePush(result, val);
      }
      return result;
    }
    function flatMap(fn, options) {
      const values = map.call(this, fn, options);
      return async function* flatMap2() {
        for await (const val of values) {
          yield* val;
        }
      }.call(this);
    }
    function toIntegerOrInfinity(number) {
      number = Number2(number);
      if (NumberIsNaN(number)) {
        return 0;
      }
      if (number < 0) {
        throw new ERR_OUT_OF_RANGE("number", ">= 0", number);
      }
      return number;
    }
    function drop(number, options = undefined) {
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      number = toIntegerOrInfinity(number);
      return async function* drop2() {
        if (options?.signal?.aborted) {
          throw new AbortError;
        }
        for await (const val of this) {
          if (options?.signal?.aborted) {
            throw new AbortError;
          }
          if (number-- <= 0) {
            yield val;
          }
        }
      }.call(this);
    }
    function take(number, options = undefined) {
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      number = toIntegerOrInfinity(number);
      return async function* take2() {
        if (options?.signal?.aborted) {
          throw new AbortError;
        }
        for await (const val of this) {
          if (options?.signal?.aborted) {
            throw new AbortError;
          }
          if (number-- > 0) {
            yield val;
          }
          if (number <= 0) {
            return;
          }
        }
      }.call(this);
    }
    module.exports.streamReturningOperators = {
      drop,
      filter,
      flatMap,
      map,
      take
    };
    module.exports.promiseReturningOperators = {
      every,
      forEach,
      reduce,
      toArray,
      some,
      find
    };
  }

  // third_party/node/internal/streams/passthrough.js
  function passthrough_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ObjectSetPrototypeOf
    } = primordials2;
    module.exports = PassThrough;
    const Transform = require2("internal/streams/transform");
    ObjectSetPrototypeOf(PassThrough.prototype, Transform.prototype);
    ObjectSetPrototypeOf(PassThrough, Transform);
    function PassThrough(options) {
      if (!(this instanceof PassThrough))
        return new PassThrough(options);
      Transform.call(this, options);
    }
    PassThrough.prototype._transform = function(chunk, encoding, cb) {
      cb(null, chunk);
    };
  }

  // third_party/node/internal/streams/pipeline.js
  function pipeline_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayIsArray,
      Promise: Promise2,
      SymbolAsyncIterator,
      SymbolDispose
    } = primordials2;
    const { eos } = require2("internal/streams/end-of-stream");
    const { once } = require2("internal/util");
    const destroyImpl = require2("internal/streams/destroy");
    const Duplex = require2("internal/streams/duplex");
    const {
      AbortError,
      aggregateTwoErrors,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_RETURN_VALUE,
        ERR_MISSING_ARGS,
        ERR_STREAM_DESTROYED,
        ERR_STREAM_PREMATURE_CLOSE,
        ERR_STREAM_UNABLE_TO_PIPE
      }
    } = require2("internal/errors");
    const {
      validateFunction,
      validateAbortSignal
    } = require2("internal/validators");
    const {
      isIterable,
      isReadable,
      isReadableNodeStream,
      isNodeStream,
      isTransformStream,
      isWebStream,
      isReadableStream,
      isReadableFinished
    } = require2("internal/streams/utils");
    const { AbortController } = require2("internal/abort_controller");
    let PassThrough;
    let Readable;
    let addAbortListener;
    function destroyer(stream, reading, writing) {
      let finished = false;
      stream.on("close", () => {
        finished = true;
      });
      const cleanup = eos(stream, { readable: reading, writable: writing }, (err) => {
        finished = !err;
      });
      return {
        destroy: (err) => {
          if (finished)
            return;
          finished = true;
          destroyImpl.destroyer(stream, err || new ERR_STREAM_DESTROYED("pipe"));
        },
        cleanup
      };
    }
    function popCallback(streams) {
      validateFunction(streams[streams.length - 1], "streams[stream.length - 1]");
      return streams.pop();
    }
    function makeAsyncIterable(val) {
      if (isIterable(val)) {
        return val;
      } else if (isReadableNodeStream(val)) {
        return fromReadable(val);
      }
      throw new ERR_INVALID_ARG_TYPE("val", ["Readable", "Iterable", "AsyncIterable"], val);
    }
    async function* fromReadable(val) {
      Readable ??= require2("internal/streams/readable");
      yield* Readable.prototype[SymbolAsyncIterator].call(val);
    }
    async function pumpToNode(iterable, writable, finish, { end }) {
      let error;
      let onresolve = null;
      const resume = (err) => {
        if (err) {
          error = err;
        }
        if (onresolve) {
          const callback = onresolve;
          onresolve = null;
          callback();
        }
      };
      const wait = () => new Promise2((resolve2, reject) => {
        if (error) {
          reject(error);
        } else {
          onresolve = () => {
            if (error) {
              reject(error);
            } else {
              resolve2();
            }
          };
        }
      });
      writable.on("drain", resume);
      const cleanup = eos(writable, { readable: false }, resume);
      try {
        if (writable.writableNeedDrain) {
          await wait();
        }
        for await (const chunk of iterable) {
          if (!writable.write(chunk)) {
            await wait();
          }
        }
        if (end) {
          writable.end();
          await wait();
        }
        finish();
      } catch (err) {
        finish(error !== err ? aggregateTwoErrors(error, err) : err);
      } finally {
        cleanup();
        writable.off("drain", resume);
      }
    }
    async function pumpToWeb(readable, writable, finish, { end }) {
      if (isTransformStream(writable)) {
        writable = writable.writable;
      }
      const writer = writable.getWriter();
      try {
        for await (const chunk of readable) {
          await writer.ready;
          writer.write(chunk).catch(() => {});
        }
        await writer.ready;
        if (end) {
          await writer.close();
        }
        finish();
      } catch (err) {
        try {
          await writer.abort(err);
          finish(err);
        } catch (err2) {
          finish(err2);
        }
      }
    }
    function pipeline(...streams) {
      return pipelineImpl(streams, once(popCallback(streams)));
    }
    function pipelineImpl(streams, callback, opts) {
      if (streams.length === 1 && ArrayIsArray(streams[0])) {
        streams = streams[0];
      }
      if (streams.length < 2) {
        throw new ERR_MISSING_ARGS("streams");
      }
      const ac = new AbortController;
      const signal = ac.signal;
      const outerSignal = opts?.signal;
      const lastStreamCleanup = [];
      validateAbortSignal(outerSignal, "options.signal");
      function abort() {
        finishImpl(new AbortError(undefined, { cause: outerSignal?.reason }));
      }
      addAbortListener ??= require2("internal/events/abort_listener").addAbortListener;
      let disposable;
      if (outerSignal) {
        disposable = addAbortListener(outerSignal, abort);
      }
      let error;
      let value;
      const destroys = [];
      let finishCount = 0;
      function finish(err) {
        finishImpl(err, --finishCount === 0);
      }
      function finishOnlyHandleError(err) {
        finishImpl(err, false);
      }
      function finishImpl(err, final) {
        if (err && (!error || error.code === "ERR_STREAM_PREMATURE_CLOSE" || error.name === "AbortError")) {
          error = err;
        }
        if (!error && !final) {
          return;
        }
        while (destroys.length) {
          destroys.shift()(error);
        }
        disposable?.[SymbolDispose]();
        ac.abort();
        if (final) {
          if (!error) {
            lastStreamCleanup.forEach((fn) => fn());
          }
          process.nextTick(callback, error, value);
        }
      }
      let ret;
      for (let i = 0;i < streams.length; i++) {
        const stream = streams[i];
        const reading = i < streams.length - 1;
        const writing = i > 0;
        const next = i + 1 < streams.length ? streams[i + 1] : null;
        const end = reading || opts?.end !== false;
        const isLastStream = i === streams.length - 1;
        if (isNodeStream(stream)) {
          let onError = function(err) {
            if (err && err.name !== "AbortError" && err.code !== "ERR_STREAM_PREMATURE_CLOSE") {
              finishOnlyHandleError(err);
            }
          };
          if (next !== null && (next?.closed || next?.destroyed)) {
            throw new ERR_STREAM_UNABLE_TO_PIPE;
          }
          if (end) {
            const { destroy, cleanup } = destroyer(stream, reading, writing);
            destroys.push(destroy);
            if (isReadable(stream) && isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          }
          stream.on("error", onError);
          if (isReadable(stream) && isLastStream) {
            lastStreamCleanup.push(() => {
              stream.removeListener("error", onError);
            });
          }
        }
        if (i === 0) {
          if (typeof stream === "function") {
            ret = stream({ signal });
            if (!isIterable(ret)) {
              throw new ERR_INVALID_RETURN_VALUE("Iterable, AsyncIterable or Stream", "source", ret);
            }
          } else if (isIterable(stream) || isReadableNodeStream(stream) || isTransformStream(stream)) {
            ret = stream;
          } else {
            ret = Duplex.from(stream);
          }
        } else if (typeof stream === "function") {
          if (isTransformStream(ret)) {
            ret = makeAsyncIterable(ret?.readable);
          } else {
            ret = makeAsyncIterable(ret);
          }
          ret = stream(ret, { signal });
          if (reading) {
            if (!isIterable(ret, true)) {
              throw new ERR_INVALID_RETURN_VALUE("AsyncIterable", `transform[${i - 1}]`, ret);
            }
          } else {
            PassThrough ??= require2("internal/streams/passthrough");
            const pt = new PassThrough({
              objectMode: true
            });
            const then = ret?.then;
            if (typeof then === "function") {
              finishCount++;
              then.call(ret, (val) => {
                value = val;
                if (val != null) {
                  pt.write(val);
                }
                if (end) {
                  pt.end();
                }
                process.nextTick(finish);
              }, (err) => {
                pt.destroy(err);
                process.nextTick(finish, err);
              });
            } else if (isIterable(ret, true)) {
              finishCount++;
              pumpToNode(ret, pt, finish, { end });
            } else if (isReadableStream(ret) || isTransformStream(ret)) {
              const toRead = ret.readable || ret;
              finishCount++;
              pumpToNode(toRead, pt, finish, { end });
            } else {
              throw new ERR_INVALID_RETURN_VALUE("AsyncIterable or Promise", "destination", ret);
            }
            ret = pt;
            const { destroy, cleanup } = destroyer(ret, false, true);
            destroys.push(destroy);
            if (isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          }
        } else if (isNodeStream(stream)) {
          if (isReadableNodeStream(ret)) {
            finishCount += 2;
            const cleanup = pipe(ret, stream, finish, finishOnlyHandleError, { end });
            if (isReadable(stream) && isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          } else if (isTransformStream(ret) || isReadableStream(ret)) {
            const toRead = ret.readable || ret;
            finishCount++;
            pumpToNode(toRead, stream, finish, { end });
          } else if (isIterable(ret)) {
            finishCount++;
            pumpToNode(ret, stream, finish, { end });
          } else {
            throw new ERR_INVALID_ARG_TYPE("val", ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"], ret);
          }
          ret = stream;
        } else if (isWebStream(stream)) {
          if (isReadableNodeStream(ret)) {
            finishCount++;
            pumpToWeb(makeAsyncIterable(ret), stream, finish, { end });
          } else if (isReadableStream(ret) || isIterable(ret)) {
            finishCount++;
            pumpToWeb(ret, stream, finish, { end });
          } else if (isTransformStream(ret)) {
            finishCount++;
            pumpToWeb(ret.readable, stream, finish, { end });
          } else {
            throw new ERR_INVALID_ARG_TYPE("val", ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"], ret);
          }
          ret = stream;
        } else {
          ret = Duplex.from(stream);
        }
      }
      if (signal?.aborted || outerSignal?.aborted) {
        process.nextTick(abort);
      }
      return ret;
    }
    function pipe(src, dst, finish, finishOnlyHandleError, { end }) {
      let ended = false;
      dst.on("close", () => {
        if (!ended) {
          finishOnlyHandleError(new ERR_STREAM_PREMATURE_CLOSE);
        }
      });
      src.pipe(dst, { end: false });
      if (end) {
        let endFn = function() {
          ended = true;
          dst.end();
        };
        if (isReadableFinished(src)) {
          process.nextTick(endFn);
        } else {
          src.once("end", endFn);
        }
      } else {
        finish();
      }
      eos(src, { readable: true, writable: false }, (err) => {
        const rState = src._readableState;
        if (err && err.code === "ERR_STREAM_PREMATURE_CLOSE" && (rState?.ended && !rState.errored && !rState.errorEmitted)) {
          src.once("end", finish).once("error", finish);
        } else {
          finish(err);
        }
      });
      return eos(dst, { readable: false, writable: true }, finish);
    }
    module.exports = { pipelineImpl, pipeline };
  }

  // third_party/node/internal/streams/readable.js
  function readable_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypeIndexOf,
      NumberIsInteger,
      NumberIsNaN,
      NumberParseInt,
      ObjectDefineProperties,
      ObjectKeys,
      ObjectSetPrototypeOf,
      Promise: Promise2,
      SafeSet,
      Symbol: Symbol2,
      SymbolAsyncDispose,
      SymbolAsyncIterator,
      SymbolSpecies,
      TypedArrayPrototypeSet
    } = primordials2;
    module.exports = Readable;
    Readable.ReadableState = ReadableState;
    const EE = require2("events");
    const { Stream, prependListener } = require2("internal/streams/legacy");
    const { Buffer } = require2("buffer");
    const {
      addAbortSignal,
      addAbortSignalNoValidate
    } = require2("internal/streams/add-abort-signal");
    const { eos } = require2("internal/streams/end-of-stream");
    let debug = require2("internal/util/debuglog").debuglog("stream", (fn) => {
      debug = fn;
    });
    const destroyImpl = require2("internal/streams/destroy");
    const {
      getHighWaterMark,
      getDefaultHighWaterMark
    } = require2("internal/streams/state");
    const {
      kState,
      kObjectMode,
      kErrorEmitted,
      kAutoDestroy,
      kEmitClose,
      kDestroyed,
      kClosed,
      kCloseEmitted,
      kErrored,
      kConstructed,
      kOnConstructed
    } = require2("internal/streams/utils");
    const {
      AbortError,
      aggregateTwoErrors,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_METHOD_NOT_IMPLEMENTED,
        ERR_OUT_OF_RANGE,
        ERR_STREAM_PUSH_AFTER_EOF,
        ERR_STREAM_UNSHIFT_AFTER_END_EVENT,
        ERR_UNKNOWN_ENCODING
      }
    } = require2("internal/errors");
    const {
      validateAbortSignal,
      validateObject
    } = require2("internal/validators");
    const FastBuffer = Buffer[SymbolSpecies];
    const { StringDecoder } = require2("string_decoder");
    const from = require2("internal/streams/from");
    ObjectSetPrototypeOf(Readable.prototype, Stream.prototype);
    ObjectSetPrototypeOf(Readable, Stream);
    const nop = () => {};
    const { errorOrDestroy } = destroyImpl;
    const kErroredValue = Symbol2("kErroredValue");
    const kDefaultEncodingValue = Symbol2("kDefaultEncodingValue");
    const kDecoderValue = Symbol2("kDecoderValue");
    const kEncodingValue = Symbol2("kEncodingValue");
    const kEnded = 1 << 9;
    const kEndEmitted = 1 << 10;
    const kReading = 1 << 11;
    const kSync = 1 << 12;
    const kNeedReadable = 1 << 13;
    const kEmittedReadable = 1 << 14;
    const kReadableListening = 1 << 15;
    const kResumeScheduled = 1 << 16;
    const kMultiAwaitDrain = 1 << 17;
    const kReadingMore = 1 << 18;
    const kDataEmitted = 1 << 19;
    const kDefaultUTF8Encoding = 1 << 20;
    const kDecoder = 1 << 21;
    const kEncoding = 1 << 22;
    const kHasFlowing = 1 << 23;
    const kFlowing = 1 << 24;
    const kHasPaused = 1 << 25;
    const kPaused = 1 << 26;
    const kDataListening = 1 << 27;
    function makeBitMapDescriptor(bit) {
      return {
        enumerable: false,
        get() {
          return (this[kState] & bit) !== 0;
        },
        set(value) {
          if (value)
            this[kState] |= bit;
          else
            this[kState] &= ~bit;
        }
      };
    }
    ObjectDefineProperties(ReadableState.prototype, {
      objectMode: makeBitMapDescriptor(kObjectMode),
      ended: makeBitMapDescriptor(kEnded),
      endEmitted: makeBitMapDescriptor(kEndEmitted),
      reading: makeBitMapDescriptor(kReading),
      constructed: makeBitMapDescriptor(kConstructed),
      sync: makeBitMapDescriptor(kSync),
      needReadable: makeBitMapDescriptor(kNeedReadable),
      emittedReadable: makeBitMapDescriptor(kEmittedReadable),
      readableListening: makeBitMapDescriptor(kReadableListening),
      resumeScheduled: makeBitMapDescriptor(kResumeScheduled),
      errorEmitted: makeBitMapDescriptor(kErrorEmitted),
      emitClose: makeBitMapDescriptor(kEmitClose),
      autoDestroy: makeBitMapDescriptor(kAutoDestroy),
      destroyed: makeBitMapDescriptor(kDestroyed),
      closed: makeBitMapDescriptor(kClosed),
      closeEmitted: makeBitMapDescriptor(kCloseEmitted),
      multiAwaitDrain: makeBitMapDescriptor(kMultiAwaitDrain),
      readingMore: makeBitMapDescriptor(kReadingMore),
      dataEmitted: makeBitMapDescriptor(kDataEmitted),
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kErrored) !== 0 ? this[kErroredValue] : null;
        },
        set(value) {
          if (value) {
            this[kErroredValue] = value;
            this[kState] |= kErrored;
          } else {
            this[kState] &= ~kErrored;
          }
        }
      },
      defaultEncoding: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kDefaultUTF8Encoding) !== 0 ? "utf8" : this[kDefaultEncodingValue];
        },
        set(value) {
          if (value === "utf8" || value === "utf-8") {
            this[kState] |= kDefaultUTF8Encoding;
          } else {
            this[kState] &= ~kDefaultUTF8Encoding;
            this[kDefaultEncodingValue] = value;
          }
        }
      },
      decoder: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kDecoder) !== 0 ? this[kDecoderValue] : null;
        },
        set(value) {
          if (value) {
            this[kDecoderValue] = value;
            this[kState] |= kDecoder;
          } else {
            this[kState] &= ~kDecoder;
          }
        }
      },
      encoding: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kEncoding) !== 0 ? this[kEncodingValue] : null;
        },
        set(value) {
          if (value) {
            this[kEncodingValue] = value;
            this[kState] |= kEncoding;
          } else {
            this[kState] &= ~kEncoding;
          }
        }
      },
      flowing: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kHasFlowing) !== 0 ? (this[kState] & kFlowing) !== 0 : null;
        },
        set(value) {
          if (value == null) {
            this[kState] &= ~(kHasFlowing | kFlowing);
          } else if (value) {
            this[kState] |= kHasFlowing | kFlowing;
          } else {
            this[kState] |= kHasFlowing;
            this[kState] &= ~kFlowing;
          }
        }
      }
    });
    function ReadableState(options, stream, isDuplex) {
      this[kState] = kEmitClose | kAutoDestroy | kConstructed | kSync;
      if (options?.objectMode)
        this[kState] |= kObjectMode;
      if (isDuplex && options?.readableObjectMode)
        this[kState] |= kObjectMode;
      this.highWaterMark = options ? getHighWaterMark(this, options, "readableHighWaterMark", isDuplex) : getDefaultHighWaterMark(false);
      this.buffer = [];
      this.bufferIndex = 0;
      this.length = 0;
      this.pipes = [];
      if (options && options.emitClose === false)
        this[kState] &= ~kEmitClose;
      if (options && options.autoDestroy === false)
        this[kState] &= ~kAutoDestroy;
      const defaultEncoding = options?.defaultEncoding;
      if (defaultEncoding == null || defaultEncoding === "utf8" || defaultEncoding === "utf-8") {
        this[kState] |= kDefaultUTF8Encoding;
      } else if (Buffer.isEncoding(defaultEncoding)) {
        this.defaultEncoding = defaultEncoding;
      } else {
        throw new ERR_UNKNOWN_ENCODING(defaultEncoding);
      }
      this.awaitDrainWriters = null;
      if (options?.encoding) {
        this.decoder = new StringDecoder(options.encoding);
        this.encoding = options.encoding;
      }
    }
    ReadableState.prototype[kOnConstructed] = function onConstructed(stream) {
      if ((this[kState] & kNeedReadable) !== 0) {
        maybeReadMore(stream, this);
      }
    };
    function Readable(options) {
      if (!(this instanceof Readable))
        return new Readable(options);
      this._events ??= {
        close: undefined,
        error: undefined,
        data: undefined,
        end: undefined,
        readable: undefined
      };
      this._readableState = new ReadableState(options, this, false);
      if (options) {
        if (typeof options.read === "function")
          this._read = options.read;
        if (typeof options.destroy === "function")
          this._destroy = options.destroy;
        if (typeof options.construct === "function")
          this._construct = options.construct;
        if (options.signal)
          addAbortSignal(options.signal, this);
      }
      Stream.call(this, options);
      if (this._construct != null) {
        destroyImpl.construct(this, () => {
          this._readableState[kOnConstructed](this);
        });
      }
    }
    Readable.prototype.destroy = destroyImpl.destroy;
    Readable.prototype._undestroy = destroyImpl.undestroy;
    Readable.prototype._destroy = function(err, cb) {
      cb(err);
    };
    Readable.prototype[EE.captureRejectionSymbol] = function(err) {
      this.destroy(err);
    };
    Readable.prototype[SymbolAsyncDispose] = async function() {
      let error;
      if (!this.destroyed) {
        error = this.readableEnded ? null : new AbortError;
        this.destroy(error);
      }
      await new Promise2((resolve2, reject) => eos(this, (err) => err && err !== error ? reject(err) : resolve2(null)));
    };
    Readable.prototype.push = function(chunk, encoding) {
      debug("push", chunk);
      const state = this._readableState;
      return (state[kState] & kObjectMode) === 0 ? readableAddChunkPushByteMode(this, state, chunk, encoding) : readableAddChunkPushObjectMode(this, state, chunk, encoding);
    };
    Readable.prototype.unshift = function(chunk, encoding) {
      debug("unshift", chunk);
      const state = this._readableState;
      return (state[kState] & kObjectMode) === 0 ? readableAddChunkUnshiftByteMode(this, state, chunk, encoding) : readableAddChunkUnshiftObjectMode(this, state, chunk);
    };
    function readableAddChunkUnshiftByteMode(stream, state, chunk, encoding) {
      if (chunk === null) {
        state[kState] &= ~kReading;
        onEofChunk(stream, state);
        return false;
      }
      if (typeof chunk === "string") {
        encoding ||= state.defaultEncoding;
        if (state.encoding !== encoding) {
          if (state.encoding) {
            chunk = Buffer.from(chunk, encoding).toString(state.encoding);
          } else {
            chunk = Buffer.from(chunk, encoding);
          }
        }
      } else if (Stream._isArrayBufferView(chunk)) {
        chunk = Stream._uint8ArrayToBuffer(chunk);
      } else if (chunk !== undefined && !(chunk instanceof Buffer)) {
        errorOrDestroy(stream, new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer", "TypedArray", "DataView"], chunk));
        return false;
      }
      if (!(chunk && chunk.length > 0)) {
        return canPushMore(state);
      }
      return readableAddChunkUnshiftValue(stream, state, chunk);
    }
    function readableAddChunkUnshiftObjectMode(stream, state, chunk) {
      if (chunk === null) {
        state[kState] &= ~kReading;
        onEofChunk(stream, state);
        return false;
      }
      return readableAddChunkUnshiftValue(stream, state, chunk);
    }
    function readableAddChunkUnshiftValue(stream, state, chunk) {
      if ((state[kState] & kEndEmitted) !== 0)
        errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT);
      else if ((state[kState] & (kDestroyed | kErrored)) !== 0)
        return false;
      else
        addChunk(stream, state, chunk, true);
      return canPushMore(state);
    }
    function readableAddChunkPushByteMode(stream, state, chunk, encoding) {
      if (chunk === null) {
        state[kState] &= ~kReading;
        onEofChunk(stream, state);
        return false;
      }
      if (typeof chunk === "string") {
        encoding ||= state.defaultEncoding;
        if (state.encoding !== encoding) {
          chunk = Buffer.from(chunk, encoding);
          encoding = "";
        }
      } else if (chunk instanceof Buffer) {
        encoding = "";
      } else if (Stream._isArrayBufferView(chunk)) {
        chunk = Stream._uint8ArrayToBuffer(chunk);
        encoding = "";
      } else if (chunk !== undefined) {
        errorOrDestroy(stream, new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer", "TypedArray", "DataView"], chunk));
        return false;
      }
      if (!chunk || chunk.length <= 0) {
        state[kState] &= ~kReading;
        maybeReadMore(stream, state);
        return canPushMore(state);
      }
      if ((state[kState] & kEnded) !== 0) {
        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF);
        return false;
      }
      if ((state[kState] & (kDestroyed | kErrored)) !== 0) {
        return false;
      }
      state[kState] &= ~kReading;
      if ((state[kState] & kDecoder) !== 0 && !encoding) {
        chunk = state[kDecoderValue].write(chunk);
        if (chunk.length === 0) {
          maybeReadMore(stream, state);
          return canPushMore(state);
        }
      }
      addChunk(stream, state, chunk, false);
      return canPushMore(state);
    }
    function readableAddChunkPushObjectMode(stream, state, chunk, encoding) {
      if (chunk === null) {
        state[kState] &= ~kReading;
        onEofChunk(stream, state);
        return false;
      }
      if ((state[kState] & kEnded) !== 0) {
        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF);
        return false;
      }
      if ((state[kState] & (kDestroyed | kErrored)) !== 0) {
        return false;
      }
      state[kState] &= ~kReading;
      if ((state[kState] & kDecoder) !== 0 && !encoding) {
        chunk = state[kDecoderValue].write(chunk);
      }
      addChunk(stream, state, chunk, false);
      return canPushMore(state);
    }
    function canPushMore(state) {
      return (state[kState] & kEnded) === 0 && (state.length < state.highWaterMark || state.length === 0);
    }
    function addChunk(stream, state, chunk, addToFront) {
      if ((state[kState] & (kFlowing | kSync | kDataListening)) === (kFlowing | kDataListening) && state.length === 0) {
        if ((state[kState] & kMultiAwaitDrain) !== 0) {
          state.awaitDrainWriters.clear();
        } else {
          state.awaitDrainWriters = null;
        }
        state[kState] |= kDataEmitted;
        stream.emit("data", chunk);
      } else {
        state.length += (state[kState] & kObjectMode) !== 0 ? 1 : chunk.length;
        if (addToFront) {
          if (state.bufferIndex > 0) {
            state.buffer[--state.bufferIndex] = chunk;
          } else {
            state.buffer.unshift(chunk);
          }
        } else {
          state.buffer.push(chunk);
        }
        if ((state[kState] & kNeedReadable) !== 0)
          emitReadable(stream);
      }
      maybeReadMore(stream, state);
    }
    Readable.prototype.isPaused = function() {
      const state = this._readableState;
      return (state[kState] & kPaused) !== 0 || (state[kState] & (kHasFlowing | kFlowing)) === kHasFlowing;
    };
    Readable.prototype.setEncoding = function(enc) {
      const state = this._readableState;
      const decoder = new StringDecoder(enc);
      state.decoder = decoder;
      state.encoding = state.decoder.encoding;
      let content = "";
      for (const data of state.buffer.slice(state.bufferIndex)) {
        content += decoder.write(data);
      }
      state.buffer.length = 0;
      state.bufferIndex = 0;
      if (content !== "")
        state.buffer.push(content);
      state.length = content.length;
      return this;
    };
    const MAX_HWM = 1073741824;
    function computeNewHighWaterMark(n) {
      if (n > MAX_HWM) {
        throw new ERR_OUT_OF_RANGE("size", "<= 1GiB", n);
      } else {
        n--;
        n |= n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        n++;
      }
      return n;
    }
    function howMuchToRead(n, state) {
      if (n <= 0 || state.length === 0 && (state[kState] & kEnded) !== 0)
        return 0;
      if ((state[kState] & kObjectMode) !== 0)
        return 1;
      if (NumberIsNaN(n)) {
        if ((state[kState] & kFlowing) !== 0 && state.length)
          return state.buffer[state.bufferIndex].length;
        return state.length;
      }
      if (n <= state.length)
        return n;
      return (state[kState] & kEnded) !== 0 ? state.length : 0;
    }
    Readable.prototype.read = function(n) {
      debug("read", n);
      if (n === undefined) {
        n = NaN;
      } else if (!NumberIsInteger(n)) {
        n = NumberParseInt(n, 10);
      }
      const state = this._readableState;
      const nOrig = n;
      if (n > state.highWaterMark)
        state.highWaterMark = computeNewHighWaterMark(n);
      if (n !== 0)
        state[kState] &= ~kEmittedReadable;
      if (n === 0 && (state[kState] & kNeedReadable) !== 0 && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || (state[kState] & kEnded) !== 0)) {
        debug("read: emitReadable");
        if (state.length === 0 && (state[kState] & kEnded) !== 0)
          endReadable(this);
        else
          emitReadable(this);
        return null;
      }
      n = howMuchToRead(n, state);
      if (n === 0 && (state[kState] & kEnded) !== 0) {
        if (state.length === 0)
          endReadable(this);
        return null;
      }
      let doRead = (state[kState] & kNeedReadable) !== 0;
      debug("need readable", doRead);
      if (state.length === 0 || state.length - n < state.highWaterMark) {
        doRead = true;
        debug("length less than watermark", doRead);
      }
      if ((state[kState] & (kReading | kEnded | kDestroyed | kErrored | kConstructed)) !== kConstructed) {
        doRead = false;
        debug("reading, ended or constructing", doRead);
      } else if (doRead) {
        debug("do read");
        state[kState] |= kReading | kSync;
        if (state.length === 0)
          state[kState] |= kNeedReadable;
        try {
          this._read(state.highWaterMark);
        } catch (err) {
          errorOrDestroy(this, err);
        }
        state[kState] &= ~kSync;
        if ((state[kState] & kReading) === 0)
          n = howMuchToRead(nOrig, state);
      }
      let ret;
      if (n > 0)
        ret = fromList(n, state);
      else
        ret = null;
      if (ret === null) {
        state[kState] |= state.length <= state.highWaterMark ? kNeedReadable : 0;
        n = 0;
      } else {
        state.length -= n;
        if ((state[kState] & kMultiAwaitDrain) !== 0) {
          state.awaitDrainWriters.clear();
        } else {
          state.awaitDrainWriters = null;
        }
      }
      if (state.length === 0) {
        if ((state[kState] & kEnded) === 0)
          state[kState] |= kNeedReadable;
        if (nOrig !== n && (state[kState] & kEnded) !== 0)
          endReadable(this);
      }
      if (ret !== null && (state[kState] & (kErrorEmitted | kCloseEmitted)) === 0) {
        state[kState] |= kDataEmitted;
        this.emit("data", ret);
      }
      return ret;
    };
    function onEofChunk(stream, state) {
      debug("onEofChunk");
      if ((state[kState] & kEnded) !== 0)
        return;
      const decoder = (state[kState] & kDecoder) !== 0 ? state[kDecoderValue] : null;
      if (decoder) {
        const chunk = decoder.end();
        if (chunk?.length) {
          state.buffer.push(chunk);
          state.length += (state[kState] & kObjectMode) !== 0 ? 1 : chunk.length;
        }
      }
      state[kState] |= kEnded;
      if ((state[kState] & kSync) !== 0) {
        emitReadable(stream);
      } else {
        state[kState] &= ~kNeedReadable;
        state[kState] |= kEmittedReadable;
        emitReadable_(stream);
      }
    }
    function emitReadable(stream) {
      const state = stream._readableState;
      debug("emitReadable");
      state[kState] &= ~kNeedReadable;
      if ((state[kState] & kEmittedReadable) === 0) {
        debug("emitReadable", (state[kState] & kFlowing) !== 0);
        state[kState] |= kEmittedReadable;
        process.nextTick(emitReadable_, stream);
      }
    }
    function emitReadable_(stream) {
      const state = stream._readableState;
      debug("emitReadable_");
      if ((state[kState] & (kDestroyed | kErrored)) === 0 && (state.length || (state[kState] & kEnded) !== 0)) {
        stream.emit("readable");
        state[kState] &= ~kEmittedReadable;
      }
      state[kState] |= (state[kState] & (kFlowing | kEnded)) === 0 && state.length <= state.highWaterMark ? kNeedReadable : 0;
      flow(stream);
    }
    function maybeReadMore(stream, state) {
      if ((state[kState] & (kReadingMore | kReading | kConstructed)) === kConstructed) {
        state[kState] |= kReadingMore;
        process.nextTick(maybeReadMore_, stream, state);
      }
    }
    function maybeReadMore_(stream, state) {
      while ((state[kState] & (kReading | kEnded)) === 0 && (state.length < state.highWaterMark || (state[kState] & kFlowing) !== 0 && state.length === 0)) {
        const len = state.length;
        debug("maybeReadMore read 0");
        stream.read(0);
        if (len === state.length)
          break;
      }
      state[kState] &= ~kReadingMore;
    }
    Readable.prototype._read = function(n) {
      throw new ERR_METHOD_NOT_IMPLEMENTED("_read()");
    };
    Readable.prototype.pipe = function(dest, pipeOpts) {
      const src = this;
      const state = this._readableState;
      if (state.pipes.length === 1) {
        if ((state[kState] & kMultiAwaitDrain) === 0) {
          state[kState] |= kMultiAwaitDrain;
          state.awaitDrainWriters = new SafeSet(state.awaitDrainWriters ? [state.awaitDrainWriters] : []);
        }
      }
      state.pipes.push(dest);
      debug("pipe count=%d opts=%j", state.pipes.length, pipeOpts);
      const doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
      const endFn = doEnd ? onend : unpipe;
      if ((state[kState] & kEndEmitted) !== 0)
        process.nextTick(endFn);
      else
        src.once("end", endFn);
      dest.on("unpipe", onunpipe);
      function onunpipe(readable, unpipeInfo) {
        debug("onunpipe");
        if (readable === src) {
          if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
            unpipeInfo.hasUnpiped = true;
            cleanup();
          }
        }
      }
      function onend() {
        debug("onend");
        dest.end();
      }
      let ondrain;
      let cleanedUp = false;
      function cleanup() {
        debug("cleanup");
        dest.removeListener("close", onclose);
        dest.removeListener("finish", onfinish);
        if (ondrain) {
          dest.removeListener("drain", ondrain);
        }
        dest.removeListener("error", onerror);
        dest.removeListener("unpipe", onunpipe);
        src.removeListener("end", onend);
        src.removeListener("end", unpipe);
        src.removeListener("data", ondata);
        cleanedUp = true;
        if (ondrain && state.awaitDrainWriters && (!dest._writableState || dest._writableState.needDrain))
          ondrain();
      }
      function pause() {
        if (!cleanedUp) {
          if (state.pipes.length === 1 && state.pipes[0] === dest) {
            debug("false write response, pause", 0);
            state.awaitDrainWriters = dest;
            state[kState] &= ~kMultiAwaitDrain;
          } else if (state.pipes.length > 1 && state.pipes.includes(dest)) {
            debug("false write response, pause", state.awaitDrainWriters.size);
            state.awaitDrainWriters.add(dest);
          }
          src.pause();
        }
        if (!ondrain) {
          ondrain = pipeOnDrain(src, dest);
          dest.on("drain", ondrain);
        }
      }
      src.on("data", ondata);
      function ondata(chunk) {
        debug("ondata");
        try {
          const ret = dest.write(chunk);
          debug("dest.write", ret);
          if (ret === false) {
            pause();
          }
        } catch (error) {
          dest.destroy(error);
        }
      }
      function onerror(er) {
        debug("onerror", er);
        unpipe();
        dest.removeListener("error", onerror);
        if (dest.listenerCount("error") === 0) {
          const s = dest._writableState || dest._readableState;
          if (s && !s.errorEmitted) {
            errorOrDestroy(dest, er);
          } else {
            dest.emit("error", er);
          }
        }
      }
      prependListener(dest, "error", onerror);
      function onclose() {
        dest.removeListener("finish", onfinish);
        unpipe();
      }
      dest.once("close", onclose);
      function onfinish() {
        debug("onfinish");
        dest.removeListener("close", onclose);
        unpipe();
      }
      dest.once("finish", onfinish);
      function unpipe() {
        debug("unpipe");
        src.unpipe(dest);
      }
      dest.emit("pipe", src);
      if (dest.writableNeedDrain === true) {
        pause();
      } else if ((state[kState] & kFlowing) === 0) {
        debug("pipe resume");
        src.resume();
      }
      return dest;
    };
    function pipeOnDrain(src, dest) {
      return function pipeOnDrainFunctionResult() {
        const state = src._readableState;
        if (state.awaitDrainWriters === dest) {
          debug("pipeOnDrain", 1);
          state.awaitDrainWriters = null;
        } else if ((state[kState] & kMultiAwaitDrain) !== 0) {
          debug("pipeOnDrain", state.awaitDrainWriters.size);
          state.awaitDrainWriters.delete(dest);
        }
        if ((!state.awaitDrainWriters || state.awaitDrainWriters.size === 0) && (state[kState] & kDataListening) !== 0) {
          src.resume();
        }
      };
    }
    Readable.prototype.unpipe = function(dest) {
      const state = this._readableState;
      const unpipeInfo = { hasUnpiped: false };
      if (state.pipes.length === 0)
        return this;
      if (!dest) {
        const dests = state.pipes;
        state.pipes = [];
        this.pause();
        for (let i = 0;i < dests.length; i++)
          dests[i].emit("unpipe", this, { hasUnpiped: false });
        return this;
      }
      const index = ArrayPrototypeIndexOf(state.pipes, dest);
      if (index === -1)
        return this;
      state.pipes.splice(index, 1);
      if (state.pipes.length === 0)
        this.pause();
      dest.emit("unpipe", this, unpipeInfo);
      return this;
    };
    Readable.prototype.on = function(ev, fn) {
      const res = Stream.prototype.on.call(this, ev, fn);
      const state = this._readableState;
      if (ev === "data") {
        state[kState] |= kDataListening;
        state[kState] |= this.listenerCount("readable") > 0 ? kReadableListening : 0;
        if ((state[kState] & (kHasFlowing | kFlowing)) !== kHasFlowing) {
          this.resume();
        }
      } else if (ev === "readable") {
        if ((state[kState] & (kEndEmitted | kReadableListening)) === 0) {
          state[kState] |= kReadableListening | kNeedReadable | kHasFlowing;
          state[kState] &= ~(kFlowing | kEmittedReadable);
          debug("on readable");
          if (state.length) {
            emitReadable(this);
          } else if ((state[kState] & kReading) === 0) {
            process.nextTick(nReadingNextTick, this);
          }
        }
      }
      return res;
    };
    Readable.prototype.addListener = Readable.prototype.on;
    Readable.prototype.removeListener = function(ev, fn) {
      const state = this._readableState;
      const res = Stream.prototype.removeListener.call(this, ev, fn);
      if (ev === "readable") {
        process.nextTick(updateReadableListening, this);
      } else if (ev === "data" && this.listenerCount("data") === 0) {
        state[kState] &= ~kDataListening;
      }
      return res;
    };
    Readable.prototype.off = Readable.prototype.removeListener;
    Readable.prototype.removeAllListeners = function(ev) {
      const res = Stream.prototype.removeAllListeners.apply(this, arguments);
      if (ev === "readable" || ev === undefined) {
        process.nextTick(updateReadableListening, this);
      }
      return res;
    };
    function updateReadableListening(self) {
      const state = self._readableState;
      if (self.listenerCount("readable") > 0) {
        state[kState] |= kReadableListening;
      } else {
        state[kState] &= ~kReadableListening;
      }
      if ((state[kState] & (kHasPaused | kPaused | kResumeScheduled)) === (kHasPaused | kResumeScheduled)) {
        state[kState] |= kHasFlowing | kFlowing;
      } else if ((state[kState] & kDataListening) !== 0) {
        self.resume();
      } else if ((state[kState] & kReadableListening) === 0) {
        state[kState] &= ~(kHasFlowing | kFlowing);
      }
    }
    function nReadingNextTick(self) {
      debug("readable nexttick read 0");
      self.read(0);
    }
    Readable.prototype.resume = function() {
      const state = this._readableState;
      if ((state[kState] & kFlowing) === 0) {
        debug("resume");
        state[kState] |= kHasFlowing;
        if ((state[kState] & kReadableListening) === 0) {
          state[kState] |= kFlowing;
        } else {
          state[kState] &= ~kFlowing;
        }
        resume(this, state);
      }
      state[kState] |= kHasPaused;
      state[kState] &= ~kPaused;
      return this;
    };
    function resume(stream, state) {
      if ((state[kState] & kResumeScheduled) === 0) {
        state[kState] |= kResumeScheduled;
        process.nextTick(resume_, stream, state);
      }
    }
    function resume_(stream, state) {
      debug("resume", (state[kState] & kReading) !== 0);
      if ((state[kState] & kReading) === 0) {
        stream.read(0);
      }
      state[kState] &= ~kResumeScheduled;
      stream.emit("resume");
      flow(stream);
      if ((state[kState] & (kFlowing | kReading)) === kFlowing)
        stream.read(0);
    }
    Readable.prototype.pause = function() {
      const state = this._readableState;
      debug("call pause");
      if ((state[kState] & (kHasFlowing | kFlowing)) !== kHasFlowing) {
        debug("pause");
        state[kState] |= kHasFlowing;
        state[kState] &= ~kFlowing;
        this.emit("pause");
      }
      state[kState] |= kHasPaused | kPaused;
      return this;
    };
    function flow(stream) {
      const state = stream._readableState;
      debug("flow");
      while ((state[kState] & kFlowing) !== 0 && stream.read() !== null)
        ;
    }
    Readable.prototype.wrap = function(stream) {
      let paused = false;
      stream.on("data", (chunk) => {
        if (!this.push(chunk) && stream.pause) {
          paused = true;
          stream.pause();
        }
      });
      stream.on("end", () => {
        this.push(null);
      });
      stream.on("error", (err) => {
        errorOrDestroy(this, err);
      });
      stream.on("close", () => {
        this.destroy();
      });
      stream.on("destroy", () => {
        this.destroy();
      });
      this._read = () => {
        if (paused && stream.resume) {
          paused = false;
          stream.resume();
        }
      };
      const streamKeys = ObjectKeys(stream);
      for (let j = 1;j < streamKeys.length; j++) {
        const i = streamKeys[j];
        if (this[i] === undefined && typeof stream[i] === "function") {
          this[i] = stream[i].bind(stream);
        }
      }
      return this;
    };
    Readable.prototype[SymbolAsyncIterator] = function() {
      return streamToAsyncIterator(this);
    };
    Readable.prototype.iterator = function(options) {
      if (options !== undefined) {
        validateObject(options, "options");
      }
      return streamToAsyncIterator(this, options);
    };
    function streamToAsyncIterator(stream, options) {
      if (typeof stream.read !== "function") {
        stream = Readable.wrap(stream, { objectMode: true });
      }
      const iter = createAsyncIterator(stream, options);
      iter.stream = stream;
      return iter;
    }
    async function* createAsyncIterator(stream, options) {
      let callback = nop;
      function next(resolve2) {
        if (this === stream) {
          callback();
          callback = nop;
        } else {
          callback = resolve2;
        }
      }
      stream.on("readable", next);
      let error;
      const cleanup = eos(stream, { writable: false }, (err) => {
        error = err ? aggregateTwoErrors(error, err) : null;
        callback();
        callback = nop;
      });
      try {
        while (true) {
          const chunk = stream.destroyed ? null : stream.read();
          if (chunk !== null) {
            yield chunk;
          } else if (error) {
            throw error;
          } else if (error === null) {
            return;
          } else {
            await new Promise2(next);
          }
        }
      } catch (err) {
        error = aggregateTwoErrors(error, err);
        throw error;
      } finally {
        if ((error || options?.destroyOnReturn !== false) && (error === undefined || stream._readableState.autoDestroy)) {
          destroyImpl.destroyer(stream, null);
        } else {
          stream.off("readable", next);
          cleanup();
        }
      }
    }
    let composeImpl;
    Readable.prototype.compose = function compose(stream, options) {
      if (options != null) {
        validateObject(options, "options");
      }
      if (options?.signal != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      composeImpl ??= require2("internal/streams/compose");
      const composedStream = composeImpl(this, stream);
      if (options?.signal) {
        addAbortSignalNoValidate(options.signal, composedStream);
      }
      return composedStream;
    };
    ObjectDefineProperties(Readable.prototype, {
      readable: {
        __proto__: null,
        get() {
          const r = this._readableState;
          return !!r && r.readable !== false && !r.destroyed && !r.errorEmitted && !r.endEmitted;
        },
        set(val) {
          if (this._readableState) {
            this._readableState.readable = !!val;
          }
        }
      },
      readableDidRead: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.dataEmitted;
        }
      },
      readableAborted: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return !!(this._readableState.readable !== false && (this._readableState.destroyed || this._readableState.errored) && !this._readableState.endEmitted);
        }
      },
      readableHighWaterMark: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.highWaterMark;
        }
      },
      readableBuffer: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState?.buffer;
        }
      },
      readableFlowing: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.flowing;
        },
        set: function(state) {
          if (this._readableState) {
            this._readableState.flowing = state;
          }
        }
      },
      readableLength: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState.length;
        }
      },
      readableObjectMode: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.objectMode : false;
        }
      },
      readableEncoding: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.encoding : null;
        }
      },
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.errored : null;
        }
      },
      closed: {
        __proto__: null,
        get() {
          return this._readableState ? this._readableState.closed : false;
        }
      },
      destroyed: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.destroyed : false;
        },
        set(value) {
          if (!this._readableState) {
            return;
          }
          this._readableState.destroyed = value;
        }
      },
      readableEnded: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.endEmitted : false;
        }
      }
    });
    ObjectDefineProperties(ReadableState.prototype, {
      pipesCount: {
        __proto__: null,
        get() {
          return this.pipes.length;
        }
      },
      paused: {
        __proto__: null,
        get() {
          return (this[kState] & kPaused) !== 0;
        },
        set(value) {
          this[kState] |= kHasPaused;
          if (value) {
            this[kState] |= kPaused;
          } else {
            this[kState] &= ~kPaused;
          }
        }
      }
    });
    Readable._fromList = fromList;
    function fromList(n, state) {
      if (state.length === 0)
        return null;
      let idx = state.bufferIndex;
      let ret;
      const buf = state.buffer;
      const len = buf.length;
      if ((state[kState] & kObjectMode) !== 0) {
        ret = buf[idx];
        buf[idx++] = null;
      } else if (!n || n >= state.length) {
        if ((state[kState] & kDecoder) !== 0) {
          ret = "";
          while (idx < len) {
            ret += buf[idx];
            buf[idx++] = null;
          }
        } else if (len - idx === 0) {
          ret = new FastBuffer;
        } else if (len - idx === 1) {
          ret = buf[idx];
          buf[idx++] = null;
        } else {
          ret = Buffer.allocUnsafe(state.length);
          let i = 0;
          while (idx < len) {
            TypedArrayPrototypeSet(ret, buf[idx], i);
            i += buf[idx].length;
            buf[idx++] = null;
          }
        }
      } else if (n < buf[idx].length) {
        ret = buf[idx].slice(0, n);
        buf[idx] = buf[idx].slice(n);
      } else if (n === buf[idx].length) {
        ret = buf[idx];
        buf[idx++] = null;
      } else if ((state[kState] & kDecoder) !== 0) {
        ret = "";
        while (idx < len) {
          const str = buf[idx];
          if (n > str.length) {
            ret += str;
            n -= str.length;
            buf[idx++] = null;
          } else {
            if (n === str.length) {
              ret += str;
              buf[idx++] = null;
            } else {
              ret += str.slice(0, n);
              buf[idx] = str.slice(n);
            }
            break;
          }
        }
      } else {
        ret = Buffer.allocUnsafe(n);
        const retLen = n;
        while (idx < len) {
          const data = buf[idx];
          if (n > data.length) {
            TypedArrayPrototypeSet(ret, data, retLen - n);
            n -= data.length;
            buf[idx++] = null;
          } else {
            if (n === data.length) {
              TypedArrayPrototypeSet(ret, data, retLen - n);
              buf[idx++] = null;
            } else {
              TypedArrayPrototypeSet(ret, new FastBuffer(data.buffer, data.byteOffset, n), retLen - n);
              buf[idx] = new FastBuffer(data.buffer, data.byteOffset + n, data.length - n);
            }
            break;
          }
        }
      }
      if (idx === len) {
        state.buffer.length = 0;
        state.bufferIndex = 0;
      } else if (idx > 1024) {
        state.buffer.splice(0, idx);
        state.bufferIndex = 0;
      } else {
        state.bufferIndex = idx;
      }
      return ret;
    }
    function endReadable(stream) {
      const state = stream._readableState;
      debug("endReadable");
      if ((state[kState] & kEndEmitted) === 0) {
        state[kState] |= kEnded;
        process.nextTick(endReadableNT, state, stream);
      }
    }
    function endReadableNT(state, stream) {
      debug("endReadableNT");
      if ((state[kState] & (kErrored | kCloseEmitted | kEndEmitted)) === 0 && state.length === 0) {
        state[kState] |= kEndEmitted;
        stream.emit("end");
        if (stream.writable && stream.allowHalfOpen === false) {
          process.nextTick(endWritableNT, stream);
        } else if (state.autoDestroy) {
          const wState = stream._writableState;
          const autoDestroy = !wState || wState.autoDestroy && (wState.finished || wState.writable === false);
          if (autoDestroy) {
            stream.destroy();
          }
        }
      }
    }
    function endWritableNT(stream) {
      const writable = stream.writable && !stream.writableEnded && !stream.destroyed;
      if (writable) {
        stream.end();
      }
    }
    Readable.from = function(iterable, opts) {
      return from(Readable, iterable, opts);
    };
    let webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === undefined)
        webStreamsAdapters = require2("internal/webstreams/adapters");
      return webStreamsAdapters;
    }
    Readable.fromWeb = function(readableStream, options) {
      return lazyWebStreams().newStreamReadableFromReadableStream(readableStream, options);
    };
    Readable.toWeb = function(streamReadable, options) {
      return lazyWebStreams().newReadableStreamFromStreamReadable(streamReadable, options);
    };
    Readable.wrap = function(src, options) {
      return new Readable({
        objectMode: src.readableObjectMode ?? src.objectMode ?? true,
        ...options,
        destroy(err, callback) {
          destroyImpl.destroyer(src, err);
          callback(err);
        }
      }).wrap(src);
    };
  }

  // third_party/node/internal/streams/state.js
  function state_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      MathFloor,
      NumberIsInteger
    } = primordials2;
    const { validateInteger } = require2("internal/validators");
    const { ERR_INVALID_ARG_VALUE } = require2("internal/errors").codes;
    let defaultHighWaterMarkBytes = process.platform === "win32" ? 16 * 1024 : 64 * 1024;
    let defaultHighWaterMarkObjectMode = 16;
    function highWaterMarkFrom(options, isDuplex, duplexKey) {
      return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
    }
    function getDefaultHighWaterMark(objectMode) {
      return objectMode ? defaultHighWaterMarkObjectMode : defaultHighWaterMarkBytes;
    }
    function setDefaultHighWaterMark(objectMode, value) {
      validateInteger(value, "value", 0);
      if (objectMode) {
        defaultHighWaterMarkObjectMode = value;
      } else {
        defaultHighWaterMarkBytes = value;
      }
    }
    function getHighWaterMark(state, options, duplexKey, isDuplex) {
      const hwm = highWaterMarkFrom(options, isDuplex, duplexKey);
      if (hwm != null) {
        if (!NumberIsInteger(hwm) || hwm < 0) {
          const name = isDuplex ? `options.${duplexKey}` : "options.highWaterMark";
          throw new ERR_INVALID_ARG_VALUE(name, hwm);
        }
        return MathFloor(hwm);
      }
      return getDefaultHighWaterMark(state.objectMode);
    }
    module.exports = {
      getHighWaterMark,
      getDefaultHighWaterMark,
      setDefaultHighWaterMark
    };
  }

  // third_party/node/internal/streams/transform.js
  function transform_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ObjectSetPrototypeOf,
      Symbol: Symbol2
    } = primordials2;
    module.exports = Transform;
    const {
      ERR_METHOD_NOT_IMPLEMENTED
    } = require2("internal/errors").codes;
    const Duplex = require2("internal/streams/duplex");
    const { getHighWaterMark } = require2("internal/streams/state");
    ObjectSetPrototypeOf(Transform.prototype, Duplex.prototype);
    ObjectSetPrototypeOf(Transform, Duplex);
    const kCallback = Symbol2("kCallback");
    function Transform(options) {
      if (!(this instanceof Transform))
        return new Transform(options);
      const readableHighWaterMark = options ? getHighWaterMark(this, options, "readableHighWaterMark", true) : null;
      if (readableHighWaterMark === 0) {
        options = {
          ...options,
          highWaterMark: null,
          readableHighWaterMark,
          writableHighWaterMark: options.writableHighWaterMark || 0
        };
      }
      Duplex.call(this, options);
      this._readableState.sync = false;
      this[kCallback] = null;
      if (options) {
        if (typeof options.transform === "function")
          this._transform = options.transform;
        if (typeof options.flush === "function")
          this._flush = options.flush;
      }
      this.on("prefinish", prefinish);
    }
    function final(cb) {
      if (typeof this._flush === "function" && !this.destroyed) {
        this._flush((er, data) => {
          if (er) {
            if (cb) {
              cb(er);
            } else {
              this.destroy(er);
            }
            return;
          }
          if (data != null) {
            this.push(data);
          }
          this.push(null);
          if (cb) {
            cb();
          }
        });
      } else {
        this.push(null);
        if (cb) {
          cb();
        }
      }
    }
    function prefinish() {
      if (this._final !== final) {
        final.call(this);
      }
    }
    Transform.prototype._final = final;
    Transform.prototype._transform = function(chunk, encoding, callback) {
      throw new ERR_METHOD_NOT_IMPLEMENTED("_transform()");
    };
    Transform.prototype._write = function(chunk, encoding, callback) {
      const rState = this._readableState;
      const wState = this._writableState;
      const length = rState.length;
      this._transform(chunk, encoding, (err, val) => {
        if (err) {
          callback(err);
          return;
        }
        if (val != null) {
          this.push(val);
        }
        if (rState.ended) {
          process.nextTick(callback);
        } else if (wState.ended || length === rState.length || rState.length < rState.highWaterMark) {
          callback();
        } else {
          this[kCallback] = callback;
        }
      });
    };
    Transform.prototype._read = function() {
      if (this[kCallback]) {
        const callback = this[kCallback];
        this[kCallback] = null;
        callback();
      }
    };
  }

  // third_party/node/internal/streams/utils.js
  function utils_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      Symbol: Symbol2,
      SymbolAsyncIterator,
      SymbolFor,
      SymbolIterator
    } = primordials2;
    const kIsDestroyed = SymbolFor("nodejs.stream.destroyed");
    const kIsErrored = SymbolFor("nodejs.stream.errored");
    const kIsReadable = SymbolFor("nodejs.stream.readable");
    const kIsWritable = SymbolFor("nodejs.stream.writable");
    const kIsDisturbed = SymbolFor("nodejs.stream.disturbed");
    const kOnConstructed = Symbol2("kOnConstructed");
    const kIsClosedPromise = SymbolFor("nodejs.webstream.isClosedPromise");
    const kControllerErrorFunction = SymbolFor("nodejs.webstream.controllerErrorFunction");
    const kState = Symbol2("kState");
    const kObjectMode = 1 << 0;
    const kErrorEmitted = 1 << 1;
    const kAutoDestroy = 1 << 2;
    const kEmitClose = 1 << 3;
    const kDestroyed = 1 << 4;
    const kClosed = 1 << 5;
    const kCloseEmitted = 1 << 6;
    const kErrored = 1 << 7;
    const kConstructed = 1 << 8;
    function isReadableNodeStream(obj, strict = false) {
      return !!(obj && typeof obj.pipe === "function" && typeof obj.on === "function" && (!strict || typeof obj.pause === "function" && typeof obj.resume === "function") && (!obj._writableState || obj._readableState?.readable !== false) && (!obj._writableState || obj._readableState));
    }
    function isWritableNodeStream(obj) {
      return !!(obj && typeof obj.write === "function" && typeof obj.on === "function" && (!obj._readableState || obj._writableState?.writable !== false));
    }
    function isDuplexNodeStream(obj) {
      return !!(obj && (typeof obj.pipe === "function" && obj._readableState) && typeof obj.on === "function" && typeof obj.write === "function");
    }
    function isNodeStream(obj) {
      return obj && (obj._readableState || obj._writableState || typeof obj.write === "function" && typeof obj.on === "function" || typeof obj.pipe === "function" && typeof obj.on === "function");
    }
    function isReadableStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.pipeThrough === "function" && typeof obj.getReader === "function" && typeof obj.cancel === "function");
    }
    function isWritableStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.getWriter === "function" && typeof obj.abort === "function");
    }
    function isTransformStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.readable === "object" && typeof obj.writable === "object");
    }
    function isWebStream(obj) {
      return isReadableStream(obj) || isWritableStream(obj) || isTransformStream(obj);
    }
    function isIterable(obj, isAsync) {
      if (obj == null)
        return false;
      if (isAsync === true)
        return typeof obj[SymbolAsyncIterator] === "function";
      if (isAsync === false)
        return typeof obj[SymbolIterator] === "function";
      return typeof obj[SymbolAsyncIterator] === "function" || typeof obj[SymbolIterator] === "function";
    }
    function isDestroyed(stream) {
      if (!isNodeStream(stream))
        return null;
      const wState = stream._writableState;
      const rState = stream._readableState;
      const state = wState || rState;
      return !!(stream.destroyed || stream[kIsDestroyed] || state?.destroyed);
    }
    function isWritableEnded(stream) {
      if (!isWritableNodeStream(stream))
        return null;
      if (stream.writableEnded === true)
        return true;
      const wState = stream._writableState;
      if (wState?.errored)
        return false;
      if (typeof wState?.ended !== "boolean")
        return null;
      return wState.ended;
    }
    function isWritableFinished(stream, strict) {
      if (!isWritableNodeStream(stream))
        return null;
      if (stream.writableFinished === true)
        return true;
      const wState = stream._writableState;
      if (wState?.errored)
        return false;
      if (typeof wState?.finished !== "boolean")
        return null;
      return !!(wState.finished || strict === false && wState.ended === true && wState.length === 0);
    }
    function isReadableEnded(stream) {
      if (!isReadableNodeStream(stream))
        return null;
      if (stream.readableEnded === true)
        return true;
      const rState = stream._readableState;
      if (!rState || rState.errored)
        return false;
      if (typeof rState?.ended !== "boolean")
        return null;
      return rState.ended;
    }
    function isReadableFinished(stream, strict) {
      if (!isReadableNodeStream(stream))
        return null;
      const rState = stream._readableState;
      if (rState?.errored)
        return false;
      if (typeof rState?.endEmitted !== "boolean")
        return null;
      return !!(rState.endEmitted || strict === false && rState.ended === true && rState.length === 0);
    }
    function isReadable(stream) {
      if (stream && stream[kIsReadable] != null)
        return stream[kIsReadable];
      if (typeof stream?.readable !== "boolean")
        return null;
      if (isDestroyed(stream))
        return false;
      return isReadableNodeStream(stream) && stream.readable && !isReadableFinished(stream);
    }
    function isWritable(stream) {
      if (stream && stream[kIsWritable] != null)
        return stream[kIsWritable];
      if (typeof stream?.writable !== "boolean")
        return null;
      if (isDestroyed(stream))
        return false;
      return isWritableNodeStream(stream) && stream.writable && !isWritableEnded(stream);
    }
    function isFinished(stream, opts) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (isDestroyed(stream)) {
        return true;
      }
      if (opts?.readable !== false && isReadable(stream)) {
        return false;
      }
      if (opts?.writable !== false && isWritable(stream)) {
        return false;
      }
      return true;
    }
    function isWritableErrored(stream) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (stream.writableErrored) {
        return stream.writableErrored;
      }
      return stream._writableState?.errored ?? null;
    }
    function isReadableErrored(stream) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (stream.readableErrored) {
        return stream.readableErrored;
      }
      return stream._readableState?.errored ?? null;
    }
    function isClosed(stream) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (typeof stream.closed === "boolean") {
        return stream.closed;
      }
      const wState = stream._writableState;
      const rState = stream._readableState;
      if (typeof wState?.closed === "boolean" || typeof rState?.closed === "boolean") {
        return wState?.closed || rState?.closed;
      }
      if (typeof stream._closed === "boolean" && isOutgoingMessage(stream)) {
        return stream._closed;
      }
      return null;
    }
    function isOutgoingMessage(stream) {
      return typeof stream._closed === "boolean" && typeof stream._defaultKeepAlive === "boolean" && typeof stream._removedConnection === "boolean" && typeof stream._removedContLen === "boolean";
    }
    function isServerResponse(stream) {
      return typeof stream._sent100 === "boolean" && isOutgoingMessage(stream);
    }
    function isServerRequest(stream) {
      return typeof stream._consuming === "boolean" && typeof stream._dumped === "boolean" && stream.req?.upgradeOrConnect === undefined;
    }
    function willEmitClose(stream) {
      if (!isNodeStream(stream))
        return null;
      const wState = stream._writableState;
      const rState = stream._readableState;
      const state = wState || rState;
      return !state && isServerResponse(stream) || !!(state?.autoDestroy && state.emitClose && state.closed === false);
    }
    function isDisturbed(stream) {
      return !!(stream && (stream[kIsDisturbed] ?? (stream.readableDidRead || stream.readableAborted)));
    }
    function isErrored(stream) {
      return !!(stream && (stream[kIsErrored] ?? stream.readableErrored ?? stream.writableErrored ?? stream._readableState?.errorEmitted ?? stream._writableState?.errorEmitted ?? stream._readableState?.errored ?? stream._writableState?.errored));
    }
    module.exports = {
      kOnConstructed,
      isDestroyed,
      kIsDestroyed,
      isDisturbed,
      kIsDisturbed,
      isErrored,
      kIsErrored,
      isReadable,
      kIsReadable,
      kIsClosedPromise,
      kControllerErrorFunction,
      kIsWritable,
      isClosed,
      isDuplexNodeStream,
      isFinished,
      isIterable,
      isReadableNodeStream,
      isReadableStream,
      isReadableEnded,
      isReadableFinished,
      isReadableErrored,
      isNodeStream,
      isWebStream,
      isWritable,
      isWritableNodeStream,
      isWritableStream,
      isWritableEnded,
      isWritableFinished,
      isWritableErrored,
      isServerRequest,
      isServerResponse,
      willEmitClose,
      isTransformStream,
      kState,
      kObjectMode,
      kErrorEmitted,
      kAutoDestroy,
      kEmitClose,
      kDestroyed,
      kClosed,
      kCloseEmitted,
      kErrored,
      kConstructed
    };
  }

  // third_party/node/internal/streams/writable.js
  function writable_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayPrototypeSlice,
      Error: Error2,
      FunctionPrototypeSymbolHasInstance,
      ObjectDefineProperties,
      ObjectDefineProperty,
      ObjectSetPrototypeOf,
      Promise: Promise2,
      StringPrototypeToLowerCase,
      Symbol: Symbol2,
      SymbolAsyncDispose,
      SymbolHasInstance
    } = primordials2;
    module.exports = Writable;
    Writable.WritableState = WritableState;
    const EE = require2("events");
    const Stream = require2("internal/streams/legacy").Stream;
    const { Buffer } = require2("buffer");
    const destroyImpl = require2("internal/streams/destroy");
    const { eos } = require2("internal/streams/end-of-stream");
    const {
      addAbortSignal
    } = require2("internal/streams/add-abort-signal");
    const {
      getHighWaterMark,
      getDefaultHighWaterMark
    } = require2("internal/streams/state");
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_METHOD_NOT_IMPLEMENTED,
        ERR_MULTIPLE_CALLBACK,
        ERR_STREAM_ALREADY_FINISHED,
        ERR_STREAM_CANNOT_PIPE,
        ERR_STREAM_DESTROYED,
        ERR_STREAM_NULL_VALUES,
        ERR_STREAM_WRITE_AFTER_END,
        ERR_UNKNOWN_ENCODING
      }
    } = require2("internal/errors");
    const {
      kState,
      kObjectMode,
      kErrorEmitted,
      kAutoDestroy,
      kEmitClose,
      kDestroyed,
      kClosed,
      kCloseEmitted,
      kErrored,
      kConstructed,
      kOnConstructed
    } = require2("internal/streams/utils");
    const { errorOrDestroy } = destroyImpl;
    ObjectSetPrototypeOf(Writable.prototype, Stream.prototype);
    ObjectSetPrototypeOf(Writable, Stream);
    function nop() {}
    const kOnFinishedValue = Symbol2("kOnFinishedValue");
    const kErroredValue = Symbol2("kErroredValue");
    const kDefaultEncodingValue = Symbol2("kDefaultEncodingValue");
    const kWriteCbValue = Symbol2("kWriteCbValue");
    const kAfterWriteTickInfoValue = Symbol2("kAfterWriteTickInfoValue");
    const kBufferedValue = Symbol2("kBufferedValue");
    const kSync = 1 << 9;
    const kFinalCalled = 1 << 10;
    const kNeedDrain = 1 << 11;
    const kEnding = 1 << 12;
    const kFinished = 1 << 13;
    const kDecodeStrings = 1 << 14;
    const kWriting = 1 << 15;
    const kBufferProcessing = 1 << 16;
    const kPrefinished = 1 << 17;
    const kAllBuffers = 1 << 18;
    const kAllNoop = 1 << 19;
    const kOnFinished = 1 << 20;
    const kHasWritable = 1 << 21;
    const kWritable = 1 << 22;
    const kCorked = 1 << 23;
    const kDefaultUTF8Encoding = 1 << 24;
    const kWriteCb = 1 << 25;
    const kExpectWriteCb = 1 << 26;
    const kAfterWriteTickInfo = 1 << 27;
    const kAfterWritePending = 1 << 28;
    const kBuffered = 1 << 29;
    const kEnded = 1 << 30;
    function makeBitMapDescriptor(bit) {
      return {
        enumerable: false,
        get() {
          return (this[kState] & bit) !== 0;
        },
        set(value) {
          if (value)
            this[kState] |= bit;
          else
            this[kState] &= ~bit;
        }
      };
    }
    ObjectDefineProperties(WritableState.prototype, {
      objectMode: makeBitMapDescriptor(kObjectMode),
      finalCalled: makeBitMapDescriptor(kFinalCalled),
      needDrain: makeBitMapDescriptor(kNeedDrain),
      ending: makeBitMapDescriptor(kEnding),
      ended: makeBitMapDescriptor(kEnded),
      finished: makeBitMapDescriptor(kFinished),
      destroyed: makeBitMapDescriptor(kDestroyed),
      decodeStrings: makeBitMapDescriptor(kDecodeStrings),
      writing: makeBitMapDescriptor(kWriting),
      sync: makeBitMapDescriptor(kSync),
      bufferProcessing: makeBitMapDescriptor(kBufferProcessing),
      constructed: makeBitMapDescriptor(kConstructed),
      prefinished: makeBitMapDescriptor(kPrefinished),
      errorEmitted: makeBitMapDescriptor(kErrorEmitted),
      emitClose: makeBitMapDescriptor(kEmitClose),
      autoDestroy: makeBitMapDescriptor(kAutoDestroy),
      closed: makeBitMapDescriptor(kClosed),
      closeEmitted: makeBitMapDescriptor(kCloseEmitted),
      allBuffers: makeBitMapDescriptor(kAllBuffers),
      allNoop: makeBitMapDescriptor(kAllNoop),
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kErrored) !== 0 ? this[kErroredValue] : null;
        },
        set(value) {
          if (value) {
            this[kErroredValue] = value;
            this[kState] |= kErrored;
          } else {
            this[kState] &= ~kErrored;
          }
        }
      },
      writable: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kHasWritable) !== 0 ? (this[kState] & kWritable) !== 0 : undefined;
        },
        set(value) {
          if (value == null) {
            this[kState] &= ~(kHasWritable | kWritable);
          } else if (value) {
            this[kState] |= kHasWritable | kWritable;
          } else {
            this[kState] |= kHasWritable;
            this[kState] &= ~kWritable;
          }
        }
      },
      defaultEncoding: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kDefaultUTF8Encoding) !== 0 ? "utf8" : this[kDefaultEncodingValue];
        },
        set(value) {
          if (value === "utf8" || value === "utf-8") {
            this[kState] |= kDefaultUTF8Encoding;
          } else {
            this[kState] &= ~kDefaultUTF8Encoding;
            this[kDefaultEncodingValue] = value;
          }
        }
      },
      writecb: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kWriteCb) !== 0 ? this[kWriteCbValue] : nop;
        },
        set(value) {
          this[kWriteCbValue] = value;
          if (value) {
            this[kState] |= kWriteCb;
          } else {
            this[kState] &= ~kWriteCb;
          }
        }
      },
      afterWriteTickInfo: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kAfterWriteTickInfo) !== 0 ? this[kAfterWriteTickInfoValue] : null;
        },
        set(value) {
          this[kAfterWriteTickInfoValue] = value;
          if (value) {
            this[kState] |= kAfterWriteTickInfo;
          } else {
            this[kState] &= ~kAfterWriteTickInfo;
          }
        }
      },
      buffered: {
        __proto__: null,
        enumerable: false,
        get() {
          return (this[kState] & kBuffered) !== 0 ? this[kBufferedValue] : [];
        },
        set(value) {
          this[kBufferedValue] = value;
          if (value) {
            this[kState] |= kBuffered;
          } else {
            this[kState] &= ~kBuffered;
          }
        }
      }
    });
    function WritableState(options, stream, isDuplex) {
      this[kState] = kSync | kConstructed | kEmitClose | kAutoDestroy;
      if (options?.objectMode)
        this[kState] |= kObjectMode;
      if (isDuplex && options?.writableObjectMode)
        this[kState] |= kObjectMode;
      this.highWaterMark = options ? getHighWaterMark(this, options, "writableHighWaterMark", isDuplex) : getDefaultHighWaterMark(false);
      if (!options || options.decodeStrings !== false)
        this[kState] |= kDecodeStrings;
      if (options && options.emitClose === false)
        this[kState] &= ~kEmitClose;
      if (options && options.autoDestroy === false)
        this[kState] &= ~kAutoDestroy;
      const defaultEncoding = options ? options.defaultEncoding : null;
      if (defaultEncoding == null || defaultEncoding === "utf8" || defaultEncoding === "utf-8") {
        this[kState] |= kDefaultUTF8Encoding;
      } else if (Buffer.isEncoding(defaultEncoding)) {
        this[kState] &= ~kDefaultUTF8Encoding;
        this[kDefaultEncodingValue] = defaultEncoding;
      } else {
        throw new ERR_UNKNOWN_ENCODING(defaultEncoding);
      }
      this.length = 0;
      this.corked = 0;
      this.onwrite = (er) => onwrite(stream, er);
      this.writelen = 0;
      resetBuffer(this);
      this.pendingcb = 0;
    }
    function resetBuffer(state) {
      state[kBufferedValue] = null;
      state.bufferedIndex = 0;
      state[kState] |= kAllBuffers | kAllNoop;
      state[kState] &= ~kBuffered;
    }
    WritableState.prototype.getBuffer = function getBuffer() {
      return (this[kState] & kBuffered) === 0 ? [] : ArrayPrototypeSlice(this.buffered, this.bufferedIndex);
    };
    ObjectDefineProperty(WritableState.prototype, "bufferedRequestCount", {
      __proto__: null,
      get() {
        return (this[kState] & kBuffered) === 0 ? 0 : this[kBufferedValue].length - this.bufferedIndex;
      }
    });
    WritableState.prototype[kOnConstructed] = function onConstructed(stream) {
      if ((this[kState] & kWriting) === 0) {
        clearBuffer(stream, this);
      }
      if ((this[kState] & kEnding) !== 0) {
        finishMaybe(stream, this);
      }
    };
    function Writable(options) {
      if (!(this instanceof Writable))
        return new Writable(options);
      this._events ??= {
        close: undefined,
        error: undefined,
        prefinish: undefined,
        finish: undefined,
        drain: undefined
      };
      this._writableState = new WritableState(options, this, false);
      if (options) {
        if (typeof options.write === "function")
          this._write = options.write;
        if (typeof options.writev === "function")
          this._writev = options.writev;
        if (typeof options.destroy === "function")
          this._destroy = options.destroy;
        if (typeof options.final === "function")
          this._final = options.final;
        if (typeof options.construct === "function")
          this._construct = options.construct;
        if (options.signal)
          addAbortSignal(options.signal, this);
      }
      Stream.call(this, options);
      if (this._construct != null) {
        destroyImpl.construct(this, () => {
          this._writableState[kOnConstructed](this);
        });
      }
    }
    ObjectDefineProperty(Writable, SymbolHasInstance, {
      __proto__: null,
      value: function(object) {
        if (FunctionPrototypeSymbolHasInstance(this, object))
          return true;
        if (this !== Writable)
          return false;
        return object && object._writableState instanceof WritableState;
      }
    });
    Writable.prototype.pipe = function() {
      errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE);
    };
    function _write(stream, chunk, encoding, cb) {
      const state = stream._writableState;
      if (cb == null || typeof cb !== "function") {
        cb = nop;
      }
      if (chunk === null) {
        throw new ERR_STREAM_NULL_VALUES;
      }
      if ((state[kState] & kObjectMode) === 0) {
        if (!encoding) {
          encoding = (state[kState] & kDefaultUTF8Encoding) !== 0 ? "utf8" : state.defaultEncoding;
        } else if (encoding !== "buffer" && !Buffer.isEncoding(encoding)) {
          throw new ERR_UNKNOWN_ENCODING(encoding);
        }
        if (typeof chunk === "string") {
          if ((state[kState] & kDecodeStrings) !== 0) {
            chunk = Buffer.from(chunk, encoding);
            encoding = "buffer";
          }
        } else if (chunk instanceof Buffer) {
          encoding = "buffer";
        } else if (Stream._isArrayBufferView(chunk)) {
          chunk = Stream._uint8ArrayToBuffer(chunk);
          encoding = "buffer";
        } else {
          throw new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer", "TypedArray", "DataView"], chunk);
        }
      }
      let err;
      if ((state[kState] & kEnding) !== 0) {
        err = new ERR_STREAM_WRITE_AFTER_END;
      } else if ((state[kState] & kDestroyed) !== 0) {
        err = new ERR_STREAM_DESTROYED("write");
      }
      if (err) {
        process.nextTick(cb, err);
        errorOrDestroy(stream, err, true);
        return err;
      }
      state.pendingcb++;
      return writeOrBuffer(stream, state, chunk, encoding, cb);
    }
    Writable.prototype.write = function(chunk, encoding, cb) {
      if (encoding != null && typeof encoding === "function") {
        cb = encoding;
        encoding = null;
      }
      return _write(this, chunk, encoding, cb) === true;
    };
    Writable.prototype.cork = function() {
      const state = this._writableState;
      state[kState] |= kCorked;
      state.corked++;
    };
    Writable.prototype.uncork = function() {
      const state = this._writableState;
      if (state.corked) {
        state.corked--;
        if (!state.corked) {
          state[kState] &= ~kCorked;
        }
        if ((state[kState] & kWriting) === 0)
          clearBuffer(this, state);
      }
    };
    Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
      if (typeof encoding === "string")
        encoding = StringPrototypeToLowerCase(encoding);
      if (!Buffer.isEncoding(encoding))
        throw new ERR_UNKNOWN_ENCODING(encoding);
      this._writableState.defaultEncoding = encoding;
      return this;
    };
    function writeOrBuffer(stream, state, chunk, encoding, callback) {
      const len = (state[kState] & kObjectMode) !== 0 ? 1 : chunk.length;
      state.length += len;
      if ((state[kState] & (kWriting | kErrored | kCorked | kConstructed)) !== kConstructed) {
        if ((state[kState] & kBuffered) === 0) {
          state[kState] |= kBuffered;
          state[kBufferedValue] = [];
        }
        state[kBufferedValue].push({ chunk, encoding, callback });
        if ((state[kState] & kAllBuffers) !== 0 && encoding !== "buffer") {
          state[kState] &= ~kAllBuffers;
        }
        if ((state[kState] & kAllNoop) !== 0 && callback !== nop) {
          state[kState] &= ~kAllNoop;
        }
      } else {
        state.writelen = len;
        if (callback !== nop) {
          state.writecb = callback;
        }
        state[kState] |= kWriting | kSync | kExpectWriteCb;
        stream._write(chunk, encoding, state.onwrite);
        state[kState] &= ~kSync;
      }
      const ret = state.length < state.highWaterMark || state.length === 0;
      if (!ret) {
        state[kState] |= kNeedDrain;
      }
      return ret && (state[kState] & (kDestroyed | kErrored)) === 0;
    }
    function doWrite(stream, state, writev, len, chunk, encoding, cb) {
      state.writelen = len;
      if (cb !== nop) {
        state.writecb = cb;
      }
      state[kState] |= kWriting | kSync | kExpectWriteCb;
      if ((state[kState] & kDestroyed) !== 0)
        state.onwrite(new ERR_STREAM_DESTROYED("write"));
      else if (writev)
        stream._writev(chunk, state.onwrite);
      else
        stream._write(chunk, encoding, state.onwrite);
      state[kState] &= ~kSync;
    }
    function onwriteError(stream, state, er, cb) {
      --state.pendingcb;
      cb(er);
      errorBuffer(state);
      errorOrDestroy(stream, er);
    }
    function onwrite(stream, er) {
      const state = stream._writableState;
      if ((state[kState] & kExpectWriteCb) === 0) {
        errorOrDestroy(stream, new ERR_MULTIPLE_CALLBACK);
        return;
      }
      const sync = (state[kState] & kSync) !== 0;
      const cb = (state[kState] & kWriteCb) !== 0 ? state[kWriteCbValue] : nop;
      state.writecb = null;
      state[kState] &= ~(kWriting | kExpectWriteCb);
      state.length -= state.writelen;
      state.writelen = 0;
      if (er) {
        er.stack;
        if ((state[kState] & kErrored) === 0) {
          state[kErroredValue] = er;
          state[kState] |= kErrored;
        }
        if (stream._readableState && !stream._readableState.errored) {
          stream._readableState.errored = er;
        }
        if (sync) {
          process.nextTick(onwriteError, stream, state, er, cb);
        } else {
          onwriteError(stream, state, er, cb);
        }
      } else {
        if ((state[kState] & kBuffered) !== 0) {
          clearBuffer(stream, state);
        }
        if (sync) {
          const needDrain = (state[kState] & kNeedDrain) !== 0 && state.length === 0;
          const needTick = needDrain || state[kState] & kDestroyed !== 0 || cb !== nop;
          if (cb === nop) {
            if ((state[kState] & kAfterWritePending) === 0 && needTick) {
              process.nextTick(afterWrite, stream, state, 1, cb);
              state[kState] |= kAfterWritePending;
            } else {
              state.pendingcb--;
              if ((state[kState] & kEnding) !== 0) {
                finishMaybe(stream, state, true);
              }
            }
          } else if ((state[kState] & kAfterWriteTickInfo) !== 0 && state[kAfterWriteTickInfoValue].cb === cb) {
            state[kAfterWriteTickInfoValue].count++;
          } else if (needTick) {
            state[kAfterWriteTickInfoValue] = { count: 1, cb, stream, state };
            process.nextTick(afterWriteTick, state[kAfterWriteTickInfoValue]);
            state[kState] |= kAfterWritePending | kAfterWriteTickInfo;
          } else {
            state.pendingcb--;
            if ((state[kState] & kEnding) !== 0) {
              finishMaybe(stream, state, true);
            }
          }
        } else {
          afterWrite(stream, state, 1, cb);
        }
      }
    }
    function afterWriteTick({ stream, state, count, cb }) {
      state[kState] &= ~kAfterWriteTickInfo;
      state[kAfterWriteTickInfoValue] = null;
      return afterWrite(stream, state, count, cb);
    }
    function afterWrite(stream, state, count, cb) {
      state[kState] &= ~kAfterWritePending;
      const needDrain = (state[kState] & (kEnding | kNeedDrain | kDestroyed)) === kNeedDrain && state.length === 0;
      if (needDrain) {
        state[kState] &= ~kNeedDrain;
        stream.emit("drain");
      }
      while (count-- > 0) {
        state.pendingcb--;
        cb(null);
      }
      if ((state[kState] & kDestroyed) !== 0) {
        errorBuffer(state);
      }
      if ((state[kState] & kEnding) !== 0) {
        finishMaybe(stream, state, true);
      }
    }
    function errorBuffer(state) {
      if ((state[kState] & kWriting) !== 0) {
        return;
      }
      if ((state[kState] & kBuffered) !== 0) {
        for (let n = state.bufferedIndex;n < state.buffered.length; ++n) {
          const { chunk, callback } = state[kBufferedValue][n];
          const len = (state[kState] & kObjectMode) !== 0 ? 1 : chunk.length;
          state.length -= len;
          callback(state.errored ?? new ERR_STREAM_DESTROYED("write"));
        }
      }
      callFinishedCallbacks(state, state.errored ?? new ERR_STREAM_DESTROYED("end"));
      resetBuffer(state);
    }
    function clearBuffer(stream, state) {
      if ((state[kState] & (kDestroyed | kBufferProcessing | kCorked | kBuffered | kConstructed)) !== (kBuffered | kConstructed)) {
        return;
      }
      const objectMode = (state[kState] & kObjectMode) !== 0;
      const { [kBufferedValue]: buffered, bufferedIndex } = state;
      const bufferedLength = buffered.length - bufferedIndex;
      if (!bufferedLength) {
        return;
      }
      let i = bufferedIndex;
      state[kState] |= kBufferProcessing;
      if (bufferedLength > 1 && stream._writev) {
        state.pendingcb -= bufferedLength - 1;
        const callback = (state[kState] & kAllNoop) !== 0 ? nop : (err) => {
          for (let n = i;n < buffered.length; ++n) {
            buffered[n].callback(err);
          }
        };
        const chunks = (state[kState] & kAllNoop) !== 0 && i === 0 ? buffered : ArrayPrototypeSlice(buffered, i);
        chunks.allBuffers = (state[kState] & kAllBuffers) !== 0;
        doWrite(stream, state, true, state.length, chunks, "", callback);
        resetBuffer(state);
      } else {
        do {
          const { chunk, encoding, callback } = buffered[i];
          buffered[i++] = null;
          const len = objectMode ? 1 : chunk.length;
          doWrite(stream, state, false, len, chunk, encoding, callback);
        } while (i < buffered.length && (state[kState] & kWriting) === 0);
        if (i === buffered.length) {
          resetBuffer(state);
        } else if (i > 256) {
          buffered.splice(0, i);
          state.bufferedIndex = 0;
        } else {
          state.bufferedIndex = i;
        }
      }
      state[kState] &= ~kBufferProcessing;
    }
    Writable.prototype._write = function(chunk, encoding, cb) {
      if (this._writev) {
        this._writev([{ chunk, encoding }], cb);
      } else {
        throw new ERR_METHOD_NOT_IMPLEMENTED("_write()");
      }
    };
    Writable.prototype._writev = null;
    Writable.prototype.end = function(chunk, encoding, cb) {
      const state = this._writableState;
      if (typeof chunk === "function") {
        cb = chunk;
        chunk = null;
        encoding = null;
      } else if (typeof encoding === "function") {
        cb = encoding;
        encoding = null;
      }
      let err;
      if (chunk != null) {
        const ret = _write(this, chunk, encoding);
        if (ret instanceof Error2) {
          err = ret;
        }
      }
      if ((state[kState] & kCorked) !== 0) {
        state.corked = 1;
        this.uncork();
      }
      if (err) {} else if ((state[kState] & (kEnding | kErrored)) === 0) {
        state[kState] |= kEnding;
        finishMaybe(this, state, true);
        state[kState] |= kEnded;
      } else if ((state[kState] & kFinished) !== 0) {
        err = new ERR_STREAM_ALREADY_FINISHED("end");
      } else if ((state[kState] & kDestroyed) !== 0) {
        err = new ERR_STREAM_DESTROYED("end");
      }
      if (typeof cb === "function") {
        if (err) {
          process.nextTick(cb, err);
        } else if ((state[kState] & kErrored) !== 0) {
          process.nextTick(cb, state[kErroredValue]);
        } else if ((state[kState] & kFinished) !== 0) {
          process.nextTick(cb, null);
        } else {
          state[kState] |= kOnFinished;
          state[kOnFinishedValue] ??= [];
          state[kOnFinishedValue].push(cb);
        }
      }
      return this;
    };
    function needFinish(state) {
      return (state[kState] & (kEnding | kDestroyed | kConstructed | kFinished | kWriting | kErrorEmitted | kCloseEmitted | kErrored | kBuffered)) === (kEnding | kConstructed) && state.length === 0;
    }
    function onFinish(stream, state, err) {
      if ((state[kState] & kPrefinished) !== 0) {
        errorOrDestroy(stream, err ?? new ERR_MULTIPLE_CALLBACK);
        return;
      }
      state.pendingcb--;
      if (err) {
        callFinishedCallbacks(state, err);
        errorOrDestroy(stream, err, (state[kState] & kSync) !== 0);
      } else if (needFinish(state)) {
        state[kState] |= kPrefinished;
        stream.emit("prefinish");
        state.pendingcb++;
        process.nextTick(finish, stream, state);
      }
    }
    function prefinish(stream, state) {
      if ((state[kState] & (kPrefinished | kFinalCalled)) !== 0) {
        return;
      }
      if (typeof stream._final === "function" && (state[kState] & kDestroyed) === 0) {
        state[kState] |= kFinalCalled | kSync;
        state.pendingcb++;
        try {
          stream._final((err) => onFinish(stream, state, err));
        } catch (err) {
          onFinish(stream, state, err);
        }
        state[kState] &= ~kSync;
      } else {
        state[kState] |= kFinalCalled | kPrefinished;
        stream.emit("prefinish");
      }
    }
    function finishMaybe(stream, state, sync) {
      if (needFinish(state)) {
        prefinish(stream, state);
        if (state.pendingcb === 0) {
          if (sync) {
            state.pendingcb++;
            process.nextTick((stream2, state2) => {
              if (needFinish(state2)) {
                finish(stream2, state2);
              } else {
                state2.pendingcb--;
              }
            }, stream, state);
          } else if (needFinish(state)) {
            state.pendingcb++;
            finish(stream, state);
          }
        }
      }
    }
    function finish(stream, state) {
      state.pendingcb--;
      state[kState] |= kFinished;
      callFinishedCallbacks(state, null);
      stream.emit("finish");
      if ((state[kState] & kAutoDestroy) !== 0) {
        const rState = stream._readableState;
        const autoDestroy = !rState || rState.autoDestroy && (rState.endEmitted || rState.readable === false);
        if (autoDestroy) {
          stream.destroy();
        }
      }
    }
    function callFinishedCallbacks(state, err) {
      if ((state[kState] & kOnFinished) === 0) {
        return;
      }
      const onfinishCallbacks = state[kOnFinishedValue];
      state[kOnFinishedValue] = null;
      state[kState] &= ~kOnFinished;
      for (let i = 0;i < onfinishCallbacks.length; i++) {
        onfinishCallbacks[i](err);
      }
    }
    ObjectDefineProperties(Writable.prototype, {
      closed: {
        __proto__: null,
        get() {
          return this._writableState ? (this._writableState[kState] & kClosed) !== 0 : false;
        }
      },
      destroyed: {
        __proto__: null,
        get() {
          return this._writableState ? (this._writableState[kState] & kDestroyed) !== 0 : false;
        },
        set(value) {
          if (!this._writableState)
            return;
          if (value)
            this._writableState[kState] |= kDestroyed;
          else
            this._writableState[kState] &= ~kDestroyed;
        }
      },
      writable: {
        __proto__: null,
        get() {
          const w = this._writableState;
          return !!w && w.writable !== false && (w[kState] & (kEnding | kEnded | kDestroyed | kErrored)) === 0;
        },
        set(val) {
          if (this._writableState) {
            this._writableState.writable = !!val;
          }
        }
      },
      writableFinished: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state ? (state[kState] & kFinished) !== 0 : false;
        }
      },
      writableObjectMode: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state ? (state[kState] & kObjectMode) !== 0 : false;
        }
      },
      writableBuffer: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state && state.getBuffer();
        }
      },
      writableEnded: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state ? (state[kState] & kEnding) !== 0 : false;
        }
      },
      writableNeedDrain: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state ? (state[kState] & (kDestroyed | kEnding | kNeedDrain)) === kNeedDrain : false;
        }
      },
      writableHighWaterMark: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state?.highWaterMark;
        }
      },
      writableCorked: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state ? state.corked : 0;
        }
      },
      writableLength: {
        __proto__: null,
        get() {
          const state = this._writableState;
          return state?.length;
        }
      },
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          const state = this._writableState;
          return state ? state.errored : null;
        }
      },
      writableAborted: {
        __proto__: null,
        get: function() {
          const state = this._writableState;
          return (state[kState] & (kHasWritable | kWritable)) !== kHasWritable && (state[kState] & (kDestroyed | kErrored)) !== 0 && (state[kState] & kFinished) === 0;
        }
      }
    });
    const destroy = destroyImpl.destroy;
    Writable.prototype.destroy = function(err, cb) {
      const state = this._writableState;
      if ((state[kState] & (kBuffered | kOnFinished)) !== 0 && (state[kState] & kDestroyed) === 0) {
        process.nextTick(errorBuffer, state);
      }
      destroy.call(this, err, cb);
      return this;
    };
    Writable.prototype._undestroy = destroyImpl.undestroy;
    Writable.prototype._destroy = function(err, cb) {
      cb(err);
    };
    Writable.prototype[EE.captureRejectionSymbol] = function(err) {
      this.destroy(err);
    };
    let webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === undefined)
        webStreamsAdapters = require2("internal/webstreams/adapters");
      return webStreamsAdapters;
    }
    Writable.fromWeb = function(writableStream, options) {
      return lazyWebStreams().newStreamWritableFromWritableStream(writableStream, options);
    };
    Writable.toWeb = function(streamWritable) {
      return lazyWebStreams().newWritableStreamFromStreamWritable(streamWritable);
    };
    Writable.prototype[SymbolAsyncDispose] = async function() {
      let error;
      if (!this.destroyed) {
        error = this.writableFinished ? null : new AbortError;
        this.destroy(error);
      }
      await new Promise2((resolve2, reject) => eos(this, (err) => err && err.name !== "AbortError" ? reject(err) : resolve2(null)));
    };
  }

  // third_party/node/internal/url.js
  function url_default2(exports, require2, module, process, internalBinding, primordials2) {
    const URL = globalThis.URL;
    const URLSearchParams = globalThis.URLSearchParams;
    const isURL = (self) => self != null && (self instanceof URL || typeof self === "object" && typeof self.href === "string" && typeof self.origin === "string");
    function urlToHttpOptions(url) {
      const { hostname, pathname, port, username, password, search } = url;
      const options = {
        __proto__: null,
        ...url,
        protocol: url.protocol,
        hostname: hostname && hostname[0] === "[" ? hostname.slice(1, -1) : hostname,
        hash: url.hash,
        search,
        pathname,
        path: `${pathname || ""}${search || ""}`,
        href: url.href
      };
      if (port !== "")
        options.port = Number(port);
      if (username || password) {
        options.auth = `${decodeURIComponent(username)}:${decodeURIComponent(password)}`;
      }
      return options;
    }
    function fileURLToPath(url) {
      const u = typeof url === "string" ? new URL(url) : url;
      const pathname = decodeURIComponent(u.pathname);
      return pathname || "/";
    }
    function toPathIfFileURL(fileURLOrPath) {
      if (fileURLOrPath && typeof fileURLOrPath === "object" && fileURLOrPath.protocol === "file:" && typeof fileURLOrPath.pathname === "string") {
        return fileURLToPath(fileURLOrPath);
      }
      return fileURLOrPath;
    }
    module.exports = {
      URL,
      URLParse: (input, base) => {
        try {
          return base === undefined ? new URL(input) : new URL(input, base);
        } catch {
          return null;
        }
      },
      URLSearchParams,
      isURL,
      urlToHttpOptions,
      fileURLToPath,
      toPathIfFileURL,
      pathToFileURL: (p) => {
        const path = require2("path");
        const filepath = String(p);
        let resolved = path.resolve(filepath);
        const last = filepath.charCodeAt(filepath.length - 1);
        if (last === 47 && resolved[resolved.length - 1] !== "/") {
          resolved += "/";
        }
        const u = new URL("file:///");
        u.pathname = resolved;
        return u;
      }
    };
  }

  // third_party/node/internal/util/colors.js
  function colors_default(exports, require2, module, process, internalBinding, primordials2) {
    const shouldColorize = (stream) => {
      const env = process.env || {};
      if (env.NODE_DISABLE_COLORS !== undefined || env.NO_COLOR !== undefined || env.TERM === "dumb") {
        return false;
      }
      if (env.FORCE_COLOR !== undefined) {
        return env.FORCE_COLOR === "" || ["1", "2", "3", "true"].includes(env.FORCE_COLOR);
      }
      return !!(stream && stream.isTTY);
    };
    module.exports = {
      __proto__: null,
      shouldColorize,
      hasColors: false,
      blue: "",
      green: "",
      white: "",
      yellow: "",
      red: "",
      gray: "",
      clear: "",
      reset: "",
      refresh() {
        if (shouldColorize(process.stderr)) {
          module.exports.blue = "\x1B[34m";
          module.exports.green = "\x1B[32m";
          module.exports.white = "\x1B[39m";
          module.exports.yellow = "\x1B[33m";
          module.exports.red = "\x1B[31m";
          module.exports.gray = "\x1B[90m";
          module.exports.clear = "\x1Bc";
          module.exports.reset = "\x1B[0m";
          module.exports.hasColors = true;
        } else {
          module.exports.blue = "";
          module.exports.green = "";
          module.exports.white = "";
          module.exports.yellow = "";
          module.exports.red = "";
          module.exports.gray = "";
          module.exports.clear = "";
          module.exports.reset = "";
          module.exports.hasColors = false;
        }
      }
    };
    module.exports.refresh();
  }

  // third_party/node/internal/util/comparisons.js
  function comparisons_default(exports, require2, module, process, internalBinding, primordials2) {
    function isDeepStrictEqual(a, b) {
      return equal(a, b, new Map);
    }
    function equal(a, b, seen) {
      if (Object.is(a, b))
        return true;
      if (typeof a !== "object" || typeof b !== "object" || a === null || b === null)
        return false;
      if (Object.getPrototypeOf(a) !== Object.getPrototypeOf(b))
        return false;
      const s = seen.get(a);
      if (s !== undefined)
        return s === b;
      seen.set(a, b);
      if (a instanceof Date)
        return a.getTime() === b.getTime();
      if (a instanceof RegExp)
        return a.source === b.source && a.flags === b.flags;
      if (ArrayBuffer.isView(a) && !(a instanceof DataView)) {
        if (a.length !== b.length)
          return false;
        for (let i = 0;i < a.length; i++)
          if (a[i] !== b[i])
            return false;
        return true;
      }
      if (a instanceof Map) {
        if (a.size !== b.size)
          return false;
        for (const [k, v] of a) {
          if (!b.has(k) || !equal(v, b.get(k), seen))
            return false;
        }
        return true;
      }
      if (a instanceof Set) {
        if (a.size !== b.size)
          return false;
        for (const v of a)
          if (!b.has(v))
            return false;
        return true;
      }
      const ka = Reflect.ownKeys(a).filter((k) => enumerable(a, k));
      const kb = Reflect.ownKeys(b).filter((k) => enumerable(b, k));
      if (ka.length !== kb.length)
        return false;
      for (const k of ka) {
        if (!Object.prototype.propertyIsEnumerable.call(b, k))
          return false;
        if (!equal(a[k], b[k], seen))
          return false;
      }
      return true;
    }
    const enumerable = (obj, key) => Object.prototype.propertyIsEnumerable.call(obj, key);
    module.exports = { isDeepStrictEqual, isDeepEqual: isDeepStrictEqual };
  }

  // third_party/node/internal/util/debuglog.js
  function debuglog_default(exports, require2, module, process, internalBinding, primordials2) {
    function debuglog(_set, _cb) {
      const logger = () => {};
      logger.enabled = false;
      return logger;
    }
    module.exports = { debuglog, debug: debuglog };
  }

  // third_party/node/internal/util/diff.js
  function diff_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      ArrayIsArray,
      ArrayPrototypeReverse
    } = primordials2;
    const { validateStringArray, validateString } = require2("internal/validators");
    const { myersDiff } = require2("internal/assert/myers_diff");
    function validateInput(value, name) {
      if (!ArrayIsArray(value)) {
        validateString(value, name);
        return;
      }
      validateStringArray(value, name);
    }
    function diff(actual, expected) {
      if (actual === expected) {
        return [];
      }
      validateInput(actual, "actual");
      validateInput(expected, "expected");
      return ArrayPrototypeReverse(myersDiff(actual, expected));
    }
    module.exports = {
      diff
    };
  }

  // third_party/node/internal/util/inspect.js
  function inspect_default(exports, require2, module, process, internalBinding, primordials2) {
    const customInspectSymbol = Symbol.for("nodejs.util.inspect.custom");
    const colors = {
      __proto__: null,
      reset: [0, 0],
      bold: [1, 22],
      dim: [2, 22],
      italic: [3, 23],
      underline: [4, 24],
      blink: [5, 25],
      inverse: [7, 27],
      hidden: [8, 28],
      strikethrough: [9, 29],
      doubleunderline: [21, 24],
      black: [30, 39],
      red: [31, 39],
      green: [32, 39],
      yellow: [33, 39],
      blue: [34, 39],
      magenta: [35, 39],
      cyan: [36, 39],
      white: [37, 39],
      bgBlack: [40, 49],
      bgRed: [41, 49],
      bgGreen: [42, 49],
      bgYellow: [43, 49],
      bgBlue: [44, 49],
      bgMagenta: [45, 49],
      bgCyan: [46, 49],
      bgWhite: [47, 49],
      gray: [90, 39],
      grey: [90, 39],
      redBright: [91, 39],
      greenBright: [92, 39],
      yellowBright: [93, 39],
      blueBright: [94, 39],
      magentaBright: [95, 39],
      cyanBright: [96, 39],
      whiteBright: [97, 39]
    };
    const styles = {
      __proto__: null,
      special: "cyan",
      number: "yellow",
      bigint: "yellow",
      boolean: "yellow",
      undefined: "grey",
      null: "bold",
      string: "green",
      symbol: "green",
      date: "magenta",
      regexp: "red",
      module: "underline"
    };
    const quoteString = (s) => {
      if (!s.includes("'"))
        return `'${s}'`;
      if (!s.includes('"'))
        return `"${s}"`;
      return `'${s.replace(/'/g, "\\'")}'`;
    };
    const fnName = (fn) => {
      const isClass = /^class[\s{]/.test(Function.prototype.toString.call(fn).slice(0, 6));
      const kind = isClass ? "class" : "Function";
      return fn.name ? `[${kind}: ${fn.name}]` : `[${kind} (anonymous)]`;
    };
    function formatValue(value, ctx, depth) {
      const t = typeof value;
      if (value === null)
        return "null";
      if (t === "undefined")
        return "undefined";
      if (t === "boolean" || t === "number")
        return String(value);
      if (t === "bigint")
        return `${value}n`;
      if (t === "string")
        return depth === 0 ? value : quoteString(value);
      if (t === "symbol")
        return value.toString();
      if (t === "function")
        return decorateProps(value, ctx, depth, fnName(value));
      const custom = value[customInspectSymbol];
      if (typeof custom === "function") {
        try {
          const r = custom.call(value, ctx.depth == null ? null : ctx.depth - depth, ctx, inspect);
          return typeof r === "string" ? r : formatValue(r, ctx, depth);
        } catch {}
      }
      if (value instanceof Error)
        return value.stack || `${value.name}: ${value.message}`;
      if (value instanceof RegExp)
        return RegExp.prototype.toString.call(value);
      if (value instanceof Date)
        return Number.isNaN(value.getTime()) ? "Invalid Date" : value.toISOString();
      if (ctx.seen.includes(value))
        return "[Circular *1]";
      if (ctx.depth != null && depth > ctx.depth) {
        return Array.isArray(value) ? "[Array]" : "[Object]";
      }
      ctx.seen.push(value);
      try {
        return formatRaw(value, ctx, depth);
      } finally {
        ctx.seen.pop();
      }
    }
    function formatRaw(value, ctx, depth) {
      if (Array.isArray(value)) {
        const items2 = value.map((v) => formatValue(v, ctx, depth + 1));
        return decorateProps(value, ctx, depth, wrap("[", "]", items2), value.length);
      }
      if (value instanceof Map) {
        const items2 = [];
        for (const [k, v] of value)
          items2.push(`${formatValue(k, ctx, depth + 1)} => ${formatValue(v, ctx, depth + 1)}`);
        return `Map(${value.size}) ${wrap("{", "}", items2)}`;
      }
      if (value instanceof Set) {
        const items2 = [];
        for (const v of value)
          items2.push(formatValue(v, ctx, depth + 1));
        return `Set(${value.size}) ${wrap("{", "}", items2)}`;
      }
      if (ArrayBuffer.isView(value) && !(value instanceof DataView)) {
        const items2 = Array.prototype.map.call(value, (v) => typeof v === "bigint" ? `${v}n` : String(v));
        const ctorName = value.constructor ? value.constructor.name : "TypedArray";
        return `${ctorName}(${value.length}) ${wrap("[", "]", items2)}`;
      }
      const keys = Object.keys(value);
      for (const s of Object.getOwnPropertySymbols(value)) {
        if (Object.getOwnPropertyDescriptor(value, s).enumerable)
          keys.push(s);
      }
      const items = keys.map((k) => {
        const label = typeof k === "symbol" ? `[${k.toString()}]` : keyLabel(k);
        return `${label}: ${formatValue(value[k], ctx, depth + 1)}`;
      });
      const prefix = ctorPrefix(value);
      return `${prefix}${wrap("{", "}", items)}`;
    }
    function decorateProps(value, ctx, depth, base, skipIndices = 0) {
      const extra = [];
      for (const k of Object.keys(value)) {
        if (skipIndices && /^(?:0|[1-9]\d*)$/.test(k) && Number(k) < skipIndices)
          continue;
        extra.push(`${keyLabel(k)}: ${formatValue(value[k], ctx, depth + 1)}`);
      }
      if (extra.length === 0)
        return base;
      return `${base} ${wrap("{", "}", extra)}`;
    }
    const keyLabel = (k) => /^[A-Za-z_$][\w$]*$/.test(k) ? k : quoteString(k);
    function ctorPrefix(value) {
      const proto = Object.getPrototypeOf(value);
      if (proto === Object.prototype)
        return "";
      if (proto === null)
        return "[Object: null prototype] ";
      const name = proto.constructor && proto.constructor.name;
      return name && name !== "Object" ? `${name} ` : "";
    }
    function wrap(open, close, items) {
      if (items.length === 0)
        return open === "[" ? "[]" : "{}";
      const oneLine = `${open} ${items.join(", ")} ${close}`;
      if (oneLine.length <= 72 && !oneLine.includes(`
`))
        return oneLine;
      const indented = items.map((i) => `  ${i.replace(/\n/g, `
  `)}`).join(`,
`);
      return `${open}
${indented}
${close}`;
    }
    function inspect(value, opts) {
      let ctx;
      if (typeof opts === "boolean")
        ctx = { depth: 2, showHidden: opts };
      else
        ctx = { depth: 2, ...opts || {} };
      if (ctx.depth === null)
        ctx.depth = null;
      ctx.seen = [];
      return formatValue(value, ctx, 0);
    }
    inspect.custom = customInspectSymbol;
    inspect.colors = colors;
    inspect.styles = styles;
    inspect.defaultOptions = { depth: 2, colors: false, showHidden: false };
    const formatRegExp = /%[sdifjoOc%]/g;
    function formatWithOptions(inspectOptions, ...args) {
      const first = args[0];
      let a = 0;
      let str = "";
      let join = "";
      if (typeof first === "string") {
        if (args.length === 1)
          return first;
        let lastPos = 0;
        for (let i = 0;i < first.length - 1; i++) {
          if (first.charCodeAt(i) === 37) {
            const nextChar = first.charCodeAt(++i);
            if (a + 1 !== args.length) {
              let repl;
              switch (nextChar) {
                case 115:
                  {
                    const val = args[++a];
                    if (typeof val === "number")
                      repl = String(val);
                    else if (typeof val === "bigint")
                      repl = `${val}n`;
                    else if (typeof val !== "object" || val === null)
                      repl = String(val);
                    else
                      repl = inspect(val, { ...inspectOptions, depth: 0 });
                  }
                  break;
                case 106:
                  repl = tryStringify(args[++a]);
                  break;
                case 100:
                  {
                    const val = args[++a];
                    repl = typeof val === "bigint" ? `${val}n` : typeof val === "symbol" ? "NaN" : String(Number(val));
                  }
                  break;
                case 79:
                  repl = inspect(args[++a], inspectOptions);
                  break;
                case 111:
                  repl = inspect(args[++a], { ...inspectOptions, showHidden: true, depth: 4 });
                  break;
                case 105:
                  repl = String(parseInt(args[++a], 10));
                  break;
                case 102:
                  repl = String(parseFloat(args[++a]));
                  break;
                case 99:
                  a += 1;
                  repl = "";
                  break;
                case 37:
                  str += first.slice(lastPos, i);
                  lastPos = i + 1;
                  continue;
                default:
                  continue;
              }
              if (lastPos !== i - 1)
                str += first.slice(lastPos, i - 1);
              str += repl;
              lastPos = i + 1;
            } else if (nextChar === 37) {
              str += first.slice(lastPos, i);
              lastPos = i + 1;
            }
          }
        }
        if (lastPos !== 0) {
          a++;
          join = " ";
          if (lastPos < first.length)
            str += first.slice(lastPos);
        }
      }
      while (a < args.length) {
        const value = args[a];
        str += join;
        str += typeof value !== "string" ? inspect(value, inspectOptions) : value;
        join = " ";
        a++;
      }
      return str;
    }
    function format(...args) {
      return formatWithOptions(undefined, ...args);
    }
    function tryStringify(arg) {
      try {
        return JSON.stringify(arg);
      } catch (err) {
        if (err instanceof RangeError)
          return "[Circular]";
        throw err;
      }
    }
    const ansiPattern = "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))";
    const ansiRegex = new RegExp(ansiPattern, "g");
    function stripVTControlCharacters(str) {
      if (typeof str !== "string")
        throw new TypeError('The "str" argument must be of type string');
      return str.replace(ansiRegex, "");
    }
    function identicalSequenceRange(a, b) {
      for (let i = 0;i < a.length - 3; i++) {
        const pos = b.indexOf(a[i]);
        if (pos !== -1) {
          const rest = b.length - pos;
          if (rest > 3) {
            let len = 1;
            const maxLen = Math.min(a.length - i, rest);
            while (maxLen > len && a[i + len] === b[pos + len])
              len++;
            if (len > 3)
              return [len, i];
          }
        }
      }
      return [0, 0];
    }
    module.exports = {
      inspect,
      format,
      formatWithOptions,
      stripVTControlCharacters,
      identicalSequenceRange
    };
  }

  // third_party/node/internal/util/parse_args/parse_args.js
  function parse_args_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      validateArray,
      validateBoolean,
      validateBooleanArray,
      validateObject,
      validateString,
      validateStringArray,
      validateUnion
    } = require2("internal/validators");
    const {
      findLongOptionForShort,
      isLoneLongOption,
      isLoneShortOption,
      isLongOptionAndValue,
      isOptionValue,
      isOptionLikeValue,
      isShortOptionAndValue,
      isShortOptionGroup,
      useDefaultValueOption,
      objectGetOwn,
      optionsGetOwn
    } = require2("internal/util/parse_args/utils");
    const {
      codes: {
        ERR_INVALID_ARG_VALUE,
        ERR_PARSE_ARGS_INVALID_OPTION_VALUE,
        ERR_PARSE_ARGS_UNKNOWN_OPTION,
        ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL
      }
    } = require2("internal/errors");
    const kEmptyObject = Object.freeze({ __proto__: null });
    function getMainArgs() {
      const argv = Array.isArray(process.argv) ? process.argv : [];
      const execArgv = Array.isArray(process.execArgv) ? process.execArgv : [];
      if (execArgv.includes("-e") || execArgv.includes("--eval") || execArgv.includes("-p") || execArgv.includes("--print")) {
        return argv.slice(1);
      }
      return argv.slice(2);
    }
    function checkOptionUsage(config, token) {
      if (!Object.prototype.hasOwnProperty.call(config.options, token.name)) {
        throw new ERR_PARSE_ARGS_UNKNOWN_OPTION(token.rawName, config.allowPositionals);
      }
      const short = optionsGetOwn(config.options, token.name, "short");
      const shortAndLong = `${short ? `-${short}, ` : ""}--${token.name}`;
      const type = optionsGetOwn(config.options, token.name, "type");
      if (type === "string" && typeof token.value !== "string") {
        throw new ERR_PARSE_ARGS_INVALID_OPTION_VALUE(`Option '${shortAndLong} <value>' argument missing`);
      }
      if (type === "boolean" && token.value !== undefined) {
        throw new ERR_PARSE_ARGS_INVALID_OPTION_VALUE(`Option '${shortAndLong}' does not take an argument`);
      }
    }
    function checkOptionLikeValue(token) {
      if (!token.inlineValue && isOptionLikeValue(token.value)) {
        const errorMessage = `Option '${token.rawName}' argument is ambiguous.
` + `Did you forget to specify the option argument for '${token.rawName}'?
` + `To specify an option argument starting with a dash use ` + `'${token.rawName}=-XYZ' or '${token.rawName} -- -XYZ'.`;
        throw new ERR_PARSE_ARGS_INVALID_OPTION_VALUE(errorMessage);
      }
    }
    function storeOption(longOption, optionValue, options, values) {
      if (longOption === "__proto__") {
        return;
      }
      const newValue = optionValue ?? true;
      if (optionsGetOwn(options, longOption, "multiple")) {
        if (values[longOption]) {
          values[longOption].push(newValue);
        } else {
          values[longOption] = [newValue];
        }
      } else {
        values[longOption] = newValue;
      }
    }
    function storeDefaultOption(longOption, optionValue, values) {
      if (longOption === "__proto__") {
        return;
      }
      values[longOption] = optionValue;
    }
    function argsToTokens(args, options) {
      const tokens = [];
      let index = -1;
      let groupCount = 0;
      const remainingArgs = args.slice();
      while (remainingArgs.length > 0) {
        const arg = remainingArgs.shift();
        const nextArg = remainingArgs[0];
        if (groupCount > 0) {
          groupCount--;
        } else {
          index++;
        }
        if (arg === "--") {
          tokens.push({ kind: "option-terminator", index });
          for (const arg2 of remainingArgs) {
            tokens.push({ kind: "positional", index: ++index, value: arg2 });
          }
          break;
        }
        if (isLoneShortOption(arg)) {
          const shortOption = arg.charAt(1);
          const longOption = findLongOptionForShort(shortOption, options);
          let value;
          let inlineValue;
          if (optionsGetOwn(options, longOption, "type") === "string" && isOptionValue(nextArg)) {
            value = remainingArgs.shift();
            inlineValue = false;
          }
          tokens.push({ kind: "option", name: longOption, rawName: arg, index, value, inlineValue });
          if (value != null)
            ++index;
          continue;
        }
        if (isShortOptionGroup(arg, options)) {
          const expanded = [];
          for (let i = 1;i < arg.length; i++) {
            const shortOption = arg.charAt(i);
            const longOption = findLongOptionForShort(shortOption, options);
            if (optionsGetOwn(options, longOption, "type") !== "string" || i === arg.length - 1) {
              expanded.push(`-${shortOption}`);
            } else {
              expanded.push(`-${arg.slice(i)}`);
              break;
            }
          }
          remainingArgs.unshift(...expanded);
          groupCount = expanded.length;
          continue;
        }
        if (isShortOptionAndValue(arg, options)) {
          const shortOption = arg.charAt(1);
          const longOption = findLongOptionForShort(shortOption, options);
          const value = arg.slice(2);
          tokens.push({
            kind: "option",
            name: longOption,
            rawName: `-${shortOption}`,
            index,
            value,
            inlineValue: true
          });
          continue;
        }
        if (isLoneLongOption(arg)) {
          const longOption = arg.slice(2);
          let value;
          let inlineValue;
          if (optionsGetOwn(options, longOption, "type") === "string" && isOptionValue(nextArg)) {
            value = remainingArgs.shift();
            inlineValue = false;
          }
          tokens.push({ kind: "option", name: longOption, rawName: arg, index, value, inlineValue });
          if (value != null)
            ++index;
          continue;
        }
        if (isLongOptionAndValue(arg)) {
          const equalIndex = arg.indexOf("=");
          const longOption = arg.slice(2, equalIndex);
          const value = arg.slice(equalIndex + 1);
          tokens.push({
            kind: "option",
            name: longOption,
            rawName: `--${longOption}`,
            index,
            value,
            inlineValue: true
          });
          continue;
        }
        tokens.push({ kind: "positional", index, value: arg });
      }
      return tokens;
    }
    const parseArgs = (config = kEmptyObject) => {
      const args = objectGetOwn(config, "args") ?? getMainArgs();
      const strict = objectGetOwn(config, "strict") ?? true;
      const allowPositionals = objectGetOwn(config, "allowPositionals") ?? !strict;
      const returnTokens = objectGetOwn(config, "tokens") ?? false;
      const options = objectGetOwn(config, "options") ?? { __proto__: null };
      const parseConfig = { args, strict, options, allowPositionals };
      validateArray(args, "args");
      validateBoolean(strict, "strict");
      validateBoolean(allowPositionals, "allowPositionals");
      validateBoolean(returnTokens, "tokens");
      validateObject(options, "options");
      Object.entries(options).forEach(([longOption, optionConfig]) => {
        validateObject(optionConfig, `options.${longOption}`);
        const optionType = objectGetOwn(optionConfig, "type");
        validateUnion(optionType, `options.${longOption}.type`, ["string", "boolean"]);
        if (Object.prototype.hasOwnProperty.call(optionConfig, "short")) {
          const shortOption = optionConfig.short;
          validateString(shortOption, `options.${longOption}.short`);
          if (shortOption.length !== 1) {
            throw new ERR_INVALID_ARG_VALUE(`options.${longOption}.short`, shortOption, "must be a single character");
          }
        }
        const multipleOption = objectGetOwn(optionConfig, "multiple");
        if (Object.prototype.hasOwnProperty.call(optionConfig, "multiple")) {
          validateBoolean(multipleOption, `options.${longOption}.multiple`);
        }
        const defaultValue = objectGetOwn(optionConfig, "default");
        if (defaultValue !== undefined) {
          let validator;
          switch (optionType) {
            case "string":
              validator = multipleOption ? validateStringArray : validateString;
              break;
            case "boolean":
              validator = multipleOption ? validateBooleanArray : validateBoolean;
              break;
          }
          validator(defaultValue, `options.${longOption}.default`);
        }
      });
      const tokens = argsToTokens(args, options);
      const result = {
        values: { __proto__: null },
        positionals: []
      };
      if (returnTokens) {
        result.tokens = tokens;
      }
      tokens.forEach((token) => {
        if (token.kind === "option") {
          if (strict) {
            checkOptionUsage(parseConfig, token);
            checkOptionLikeValue(token);
          }
          storeOption(token.name, token.value, options, result.values);
        } else if (token.kind === "positional") {
          if (!allowPositionals) {
            throw new ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL(token.value);
          }
          result.positionals.push(token.value);
        }
      });
      Object.entries(options).forEach(([longOption, optionConfig]) => {
        const mustSetDefault = useDefaultValueOption(longOption, optionConfig, result.values);
        if (mustSetDefault) {
          storeDefaultOption(longOption, objectGetOwn(optionConfig, "default"), result.values);
        }
      });
      return result;
    };
    module.exports = { parseArgs };
  }

  // third_party/node/internal/util/parse_args/utils.js
  function utils_default2(exports, require2, module, process, internalBinding, primordials2) {
    const { validateObject } = require2("internal/validators");
    function isOptionValue(value) {
      if (value == null)
        return false;
      return true;
    }
    function isOptionLikeValue(value) {
      if (value == null)
        return false;
      return value.length > 1 && value.charAt(0) === "-";
    }
    function isLoneShortOption(arg) {
      return arg.length === 2 && arg.charAt(0) === "-" && arg.charAt(1) !== "-";
    }
    function isLoneLongOption(arg) {
      return arg.length > 2 && arg.startsWith("--") && !arg.includes("=", 3);
    }
    function isLongOptionAndValue(arg) {
      return arg.length > 2 && arg.startsWith("--") && arg.includes("=", 3);
    }
    function isShortOptionGroup(arg, options) {
      if (arg.length <= 2)
        return false;
      if (arg.charAt(0) !== "-")
        return false;
      if (arg.charAt(1) === "-")
        return false;
      const firstShort = arg.charAt(1);
      const longOption = findLongOptionForShort(firstShort, options);
      return optionsGetOwn(options, longOption, "type") !== "string";
    }
    function isShortOptionAndValue(arg, options) {
      validateObject(options, "options");
      if (arg.length <= 2)
        return false;
      if (arg.charAt(0) !== "-")
        return false;
      if (arg.charAt(1) === "-")
        return false;
      const shortOption = arg.charAt(1);
      const longOption = findLongOptionForShort(shortOption, options);
      return optionsGetOwn(options, longOption, "type") === "string";
    }
    function findLongOptionForShort(shortOption, options) {
      validateObject(options, "options");
      const longOptionEntry = Object.entries(options).find(([, optionConfig]) => objectGetOwn(optionConfig, "short") === shortOption);
      return longOptionEntry?.[0] ?? shortOption;
    }
    function useDefaultValueOption(longOption, optionConfig, values) {
      return objectGetOwn(optionConfig, "default") !== undefined && values[longOption] === undefined;
    }
    function objectGetOwn(obj, prop) {
      if (Object.prototype.hasOwnProperty.call(obj, prop))
        return obj[prop];
    }
    function optionsGetOwn(options, longOption, prop) {
      if (Object.prototype.hasOwnProperty.call(options, longOption))
        return objectGetOwn(options[longOption], prop);
    }
    module.exports = {
      findLongOptionForShort,
      isLoneLongOption,
      isLoneShortOption,
      isLongOptionAndValue,
      isOptionValue,
      isOptionLikeValue,
      isShortOptionAndValue,
      isShortOptionGroup,
      useDefaultValueOption,
      objectGetOwn,
      optionsGetOwn
    };
  }

  // third_party/node/internal/util/types.js
  function types_default(exports, require2, module, process, internalBinding, primordials2) {
    const hasShared = typeof SharedArrayBuffer !== "undefined";
    const tagIs = (tag) => {
      const s = `[object ${tag}]`;
      return (v) => Object.prototype.toString.call(v) === s;
    };
    const isDate = tagIs("Date");
    const isRegExp = tagIs("RegExp");
    const isNativeError = (v) => {
      if (v instanceof Error)
        return true;
      const t = Object.prototype.toString.call(v);
      return t === "[object Error]" || t === "[object DOMException]";
    };
    const boxed = (tag) => {
      const s = `[object ${tag}]`;
      return (v) => typeof v === "object" && v !== null && Object.prototype.toString.call(v) === s;
    };
    const isNumberObject = boxed("Number");
    const isStringObject = boxed("String");
    const isBooleanObject = boxed("Boolean");
    const isBigIntObject = boxed("BigInt");
    const isSymbolObject = boxed("Symbol");
    module.exports = {
      isArrayBuffer: (v) => v instanceof ArrayBuffer,
      isAnyArrayBuffer: (v) => v instanceof ArrayBuffer || hasShared && v instanceof SharedArrayBuffer,
      isSharedArrayBuffer: (v) => hasShared && v instanceof SharedArrayBuffer,
      isArrayBufferView: (v) => ArrayBuffer.isView(v),
      isTypedArray: (v) => ArrayBuffer.isView(v) && !(v instanceof DataView),
      isDataView: (v) => v instanceof DataView,
      isUint8Array: (v) => v instanceof Uint8Array,
      isUint8ClampedArray: (v) => v instanceof Uint8ClampedArray,
      isUint16Array: (v) => v instanceof Uint16Array,
      isUint32Array: (v) => v instanceof Uint32Array,
      isInt8Array: (v) => v instanceof Int8Array,
      isInt16Array: (v) => v instanceof Int16Array,
      isInt32Array: (v) => v instanceof Int32Array,
      isFloat32Array: (v) => v instanceof Float32Array,
      isFloat64Array: (v) => v instanceof Float64Array,
      isBigInt64Array: (v) => v instanceof BigInt64Array,
      isBigUint64Array: (v) => v instanceof BigUint64Array,
      isDate,
      isRegExp,
      isNativeError,
      isPromise: (v) => v instanceof Promise,
      isMap: (v) => v instanceof Map,
      isSet: (v) => v instanceof Set,
      isWeakMap: (v) => v instanceof WeakMap,
      isWeakSet: (v) => v instanceof WeakSet,
      isNumberObject,
      isStringObject,
      isBooleanObject,
      isBigIntObject,
      isSymbolObject,
      isBoxedPrimitive: (v) => isNumberObject(v) || isStringObject(v) || isBooleanObject(v) || isBigIntObject(v) || isSymbolObject(v),
      isGeneratorFunction: tagIs("GeneratorFunction"),
      isAsyncFunction: tagIs("AsyncFunction"),
      isGeneratorObject: tagIs("Generator"),
      isArgumentsObject: tagIs("Arguments"),
      isMapIterator: tagIs("Map Iterator"),
      isSetIterator: tagIs("Set Iterator"),
      isModuleNamespaceObject: tagIs("Module"),
      isProxy: () => false,
      isExternal: () => false,
      isKeyObject: (v) => v != null && typeof v === "object" && v[Symbol.for("vivari.crypto.KeyObject")] === true,
      isCryptoKey: () => false
    };
  }

  // third_party/node/internal/util.js
  function util_default2(exports, require2, module, process, internalBinding, primordials2) {
    const isWindows = process.platform === "win32";
    function getLazy(initializer) {
      let value;
      let initialized = false;
      return () => {
        if (initialized === false) {
          value = initializer();
          initialized = true;
        }
        return value;
      };
    }
    const customInspectSymbol = Symbol.for("nodejs.util.inspect.custom");
    const kIsEncodingSymbol = Symbol("kIsEncoding");
    const encodingsMap = {
      __proto__: null,
      ascii: "ascii",
      utf8: "utf8",
      "utf-8": "utf8",
      utf16le: "utf16le",
      "utf-16le": "utf16le",
      ucs2: "utf16le",
      "ucs-2": "utf16le",
      base64: "base64",
      base64url: "base64url",
      latin1: "latin1",
      binary: "latin1",
      hex: "hex",
      buffer: "buffer"
    };
    function normalizeEncoding(enc) {
      if (enc == null || enc === "utf8" || enc === "utf-8")
        return "utf8";
      const low = ("" + enc).toLowerCase();
      const mapped = encodingsMap[low];
      if (mapped)
        return mapped === "buffer" ? undefined : mapped;
      return;
    }
    function defineLazyProperties(target, id, keys, enumerable = true) {
      for (const key of keys) {
        let cached;
        let loaded = false;
        Object.defineProperty(target, key, {
          configurable: true,
          enumerable,
          get() {
            if (!loaded) {
              cached = require2(id)[key];
              loaded = true;
            }
            return cached;
          },
          set(value) {
            Object.defineProperty(target, key, {
              value,
              writable: true,
              enumerable,
              configurable: true
            });
          }
        });
      }
    }
    function deprecate(fn, msg, code) {
      let warned = false;
      function deprecated(...args) {
        if (!warned) {
          warned = true;
          if (typeof process.emitWarning === "function") {
            try {
              process.emitWarning(msg, "DeprecationWarning", code);
            } catch {}
          }
        }
        return Reflect.apply(fn, this, args);
      }
      return deprecated;
    }
    function lazyDOMException(message, name) {
      if (typeof DOMException === "function")
        return new DOMException(message, name);
      const err = new Error(message);
      err.name = name;
      return err;
    }
    const isMacOS = process.platform === "darwin";
    const kEmptyObject = Object.freeze({ __proto__: null });
    function once(callback) {
      let called = false;
      let value;
      return function(...args) {
        if (!called) {
          called = true;
          value = Reflect.apply(callback, this, args);
        }
        return value;
      };
    }
    function setOwnProperty(obj, key, value) {
      Object.defineProperty(obj, key, {
        __proto__: null,
        configurable: true,
        enumerable: true,
        writable: true,
        value
      });
      return value;
    }
    const customPromisifyArgs = Symbol("customPromisifyArgs");
    const kCustomPromisifiedSymbol = Symbol.for("nodejs.util.promisify.custom");
    function promisify(original) {
      if (typeof original !== "function") {
        throw new TypeError('The "original" argument must be of type function');
      }
      if (original[kCustomPromisifiedSymbol]) {
        const fn2 = original[kCustomPromisifiedSymbol];
        if (typeof fn2 !== "function") {
          throw new TypeError("The [util.promisify.custom] property must be of type function");
        }
        return fn2;
      }
      const argumentNames = original[customPromisifyArgs];
      function fn(...args) {
        return new Promise((resolve2, reject) => {
          Reflect.apply(original, this, [
            ...args,
            (err, ...values) => {
              if (err)
                return reject(err);
              if (argumentNames !== undefined && values.length > 1) {
                const obj = {};
                for (let i = 0;i < argumentNames.length; i++)
                  obj[argumentNames[i]] = values[i];
                resolve2(obj);
              } else {
                resolve2(values[0]);
              }
            }
          ]);
        });
      }
      Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
      Object.defineProperty(fn, kCustomPromisifiedSymbol, {
        value: fn,
        enumerable: false,
        writable: false,
        configurable: true
      });
      return Object.defineProperties(fn, Object.getOwnPropertyDescriptors(original));
    }
    promisify.custom = kCustomPromisifiedSymbol;
    function spliceOne(list, index) {
      for (;index + 1 < list.length; index++)
        list[index] = list[index + 1];
      list.pop();
    }
    const getSystemErrorMap = () => new Map;
    const getSystemErrorName = (err) => `Unknown system error ${err}`;
    const getSystemErrorMessage = (err) => `Unknown system error ${err}`;
    const convertProcessSignalToExitCode = () => 128;
    const SideEffectFreeRegExpPrototypeExec = (regexp, string) => RegExp.prototype.exec.call(regexp, string);
    const guessHandleType = () => "TCP";
    const assignFunctionName = (name, fn) => {
      Object.defineProperty(fn, "name", { value: name, configurable: true });
      return fn;
    };
    const deprecateInstantiation = (ctor, _code, ...args) => new ctor(...args);
    const sleep = (msec) => {
      const end = Date.now() + msec;
      while (Date.now() < end)
        ;
    };
    module.exports = {
      isWindows,
      isMacOS,
      getLazy,
      guessHandleType,
      assignFunctionName,
      deprecateInstantiation,
      sleep,
      customInspectSymbol,
      kIsEncodingSymbol,
      kEmptyObject,
      encodingsMap,
      normalizeEncoding,
      defineLazyProperties,
      deprecate,
      lazyDOMException,
      once,
      setOwnProperty,
      customPromisifyArgs,
      promisify,
      spliceOne,
      getSystemErrorMap,
      getSystemErrorName,
      getSystemErrorMessage,
      convertProcessSignalToExitCode,
      SideEffectFreeRegExpPrototypeExec
    };
  }

  // third_party/node/internal/v8/startup_snapshot.js
  function startup_snapshot_default(exports, require2, module, process, internalBinding, primordials2) {
    module.exports = {
      namespace: {
        addSerializeCallback: () => {},
        addDeserializeCallback: () => {},
        setDeserializeMainFunction: () => {},
        isBuildingSnapshot: () => false
      }
    };
  }

  // third_party/node/internal/validators.js
  function validators_default(exports, require2, module, process, internalBinding, primordials2) {
    const {
      codes: { ERR_INVALID_ARG_TYPE, ERR_INVALID_ARG_VALUE, ERR_OUT_OF_RANGE, ERR_SOCKET_BAD_PORT }
    } = require2("internal/errors");
    const MIN = Number.MIN_SAFE_INTEGER;
    const MAX = Number.MAX_SAFE_INTEGER;
    const INT32_MIN = -2147483648;
    const INT32_MAX = 2147483647;
    const UINT32_MAX = 4294967295;
    function validateString(value, name) {
      if (typeof value !== "string")
        throw new ERR_INVALID_ARG_TYPE(name, "string", value);
    }
    function validateInteger(value, name, min = MIN, max = MAX) {
      if (typeof value !== "number")
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      if (!Number.isInteger(value))
        throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      if (value < min || value > max)
        throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${max}`, value);
    }
    function validateArray(value, name, minLength = 0) {
      if (!Array.isArray(value))
        throw new ERR_INVALID_ARG_TYPE(name, "Array", value);
      if (value.length < minLength)
        throw new ERR_INVALID_ARG_VALUE(name, value, `must be longer than ${minLength}`);
    }
    function validateBuffer(buffer, name = "buffer") {
      if (!ArrayBuffer.isView(buffer))
        throw new ERR_INVALID_ARG_TYPE(name, ["Buffer", "TypedArray", "DataView"], buffer);
    }
    function validateNumber(value, name, min = undefined, max) {
      if (typeof value !== "number")
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
    }
    function validateBoolean(value, name) {
      if (typeof value !== "boolean")
        throw new ERR_INVALID_ARG_TYPE(name, "boolean", value);
    }
    function validateFunction(value, name) {
      if (typeof value !== "function")
        throw new ERR_INVALID_ARG_TYPE(name, "Function", value);
    }
    const kValidateObjectNone = 0;
    const kValidateObjectAllowNullable = 1 << 0;
    const kValidateObjectAllowArray = 1 << 1;
    const kValidateObjectAllowFunction = 1 << 2;
    function validateObject(value, name, options = kValidateObjectNone) {
      if (options === kValidateObjectNone) {
        if (value === null || Array.isArray(value)) {
          throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
        }
        if (typeof value !== "object") {
          throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
        }
      } else {
        const throwOnNullable = (kValidateObjectAllowNullable & options) === 0;
        if (throwOnNullable && value === null) {
          throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
        }
        const throwOnArray = (kValidateObjectAllowArray & options) === 0;
        if (throwOnArray && Array.isArray(value)) {
          throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
        }
        const throwOnFunction = (kValidateObjectAllowFunction & options) === 0;
        const typeofValue = typeof value;
        if (typeofValue !== "object" && (throwOnFunction || typeofValue !== "function")) {
          throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
        }
      }
    }
    function validateInt32(value, name, min = INT32_MIN, max = INT32_MAX) {
      if (typeof value !== "number")
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      if (!Number.isInteger(value))
        throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      if (value < min || value > max)
        throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${max}`, value);
    }
    function validateUint32(value, name, positive = false) {
      if (typeof value !== "number")
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      if (!Number.isInteger(value))
        throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      const min = positive ? 1 : 0;
      if (value < min || value > UINT32_MAX)
        throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${UINT32_MAX}`, value);
    }
    const isInt32 = (value) => value === (value | 0);
    function parseFileMode(value, name, def) {
      value ??= def;
      if (typeof value === "string") {
        const parsed = Number.parseInt(value, 8);
        if (Number.isNaN(parsed)) {
          throw new ERR_INVALID_ARG_VALUE(name, value, "must be a 32-bit unsigned integer or an octal string");
        }
        value = parsed;
      }
      validateUint32(value, name);
      return value;
    }
    function validateOneOf(value, name, oneOf) {
      if (!oneOf.includes(value)) {
        const list = oneOf.map((v) => typeof v === "string" ? `'${v}'` : String(v)).join(", ");
        throw new ERR_INVALID_ARG_VALUE(name, value, `must be one of: ${list}`);
      }
    }
    function validateUnion(value, name, union) {
      if (!union.includes(value)) {
        const list = union.map((v) => typeof v === "string" ? `'${v}'` : String(v)).join("|");
        throw new ERR_INVALID_ARG_TYPE(name, list, value);
      }
    }
    function validateStringArray(value, name) {
      validateArray(value, name);
      for (let i = 0;i < value.length; i++) {
        validateString(value[i], `${name}[${i}]`);
      }
    }
    function validateBooleanArray(value, name) {
      validateArray(value, name);
      for (let i = 0;i < value.length; i++) {
        validateBoolean(value[i], `${name}[${i}]`);
      }
    }
    function validateEncoding() {}
    function validateStringWithoutNullBytes(value, name) {
      validateString(value, name);
      if (value.includes("\x00")) {
        throw new ERR_INVALID_ARG_VALUE(name, value, "must be a string without null bytes");
      }
    }
    function validatePort(port, name = "Port", allowZero = true) {
      if (typeof port !== "number" && typeof port !== "string" || typeof port === "string" && String(port).trim().length === 0 || +port !== +port >>> 0 || port > 65535 || port === 0 && !allowZero) {
        throw new ERR_SOCKET_BAD_PORT(name, port, allowZero);
      }
      return port | 0;
    }
    function validateAbortSignal(signal, name) {
      if (signal !== undefined && (signal === null || typeof signal !== "object" || !("aborted" in signal))) {
        throw new ERR_INVALID_ARG_TYPE(name, "AbortSignal", signal);
      }
    }
    function validateFiniteNumber(number, name) {
      if (number === undefined)
        return false;
      if (Number.isFinite(number))
        return true;
      if (Number.isNaN(number))
        return false;
      validateNumber(number, name);
      throw new ERR_OUT_OF_RANGE(name, "a finite number", number);
    }
    function checkRangesOrGetDefault(number, name, lower, upper, def) {
      if (!validateFiniteNumber(number, name))
        return def;
      if (number < lower || number > upper)
        throw new ERR_OUT_OF_RANGE(name, `>= ${lower} and <= ${upper}`, number);
      return number;
    }
    module.exports = {
      validateString,
      validateNumber,
      validateFiniteNumber,
      checkRangesOrGetDefault,
      validateBoolean,
      validateFunction,
      validateInteger,
      validateInt32,
      validateUint32,
      validateArray,
      validateBuffer,
      validateObject,
      validateOneOf,
      validateUnion,
      validateStringArray,
      validateBooleanArray,
      validateEncoding,
      validateAbortSignal,
      validatePort,
      validateStringWithoutNullBytes,
      isInt32,
      parseFileMode,
      kValidateObjectNone,
      kValidateObjectAllowNullable,
      kValidateObjectAllowArray,
      kValidateObjectAllowFunction
    };
    for (const key of Object.keys(module.exports)) {
      const v = module.exports[key];
      if (typeof v === "function" && v.withoutStackTrace === undefined) {
        v.withoutStackTrace = v;
      }
    }
  }

  // third_party/node/internal/webstreams/adapters.js
  function adapters_default(exports, require2, module, process, internalBinding, primordials2) {
    const { Writable, Readable, Duplex, destroy } = require2("stream");
    const { eos: finished } = require2("internal/streams/end-of-stream");
    const {
      isDestroyed,
      isReadable,
      isWritable,
      isWritableEnded,
      isReadableStream,
      isWritableStream
    } = require2("internal/streams/utils");
    const { Buffer } = require2("buffer");
    const { TextEncoder: TextEncoder2 } = require2("internal/encoding");
    const { kEmptyObject, normalizeEncoding } = require2("internal/util");
    const { validateBoolean, validateObject } = require2("internal/validators");
    const {
      AbortError,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_ARG_VALUE,
        ERR_STREAM_PREMATURE_CLOSE
      }
    } = require2("internal/errors");
    const encoder2 = new TextEncoder2;
    function webClass(name) {
      const C = globalThis[name];
      if (typeof C !== "function") {
        const err = new Error(`Vivari: cannot convert between Node and Web streams \u2014 this realm has no ` + `global ${name}. Web Streams are not bundled; \`stream/web\` re-exports ` + `whatever the host realm provides (see node/loader.js).`);
        err.code = "ERR_METHOD_NOT_IMPLEMENTED";
        throw err;
      }
      return C;
    }
    function countStrategy(highWaterMark) {
      const C = globalThis.CountQueuingStrategy;
      return typeof C === "function" ? new C({ highWaterMark }) : { highWaterMark };
    }
    function byteLengthStrategy(highWaterMark) {
      const C = globalThis.ByteLengthQueuingStrategy;
      return typeof C === "function" ? new C({ highWaterMark }) : { highWaterMark, size: (chunk) => chunk.byteLength };
    }
    function createDeferredPromise() {
      let resolve2;
      let reject;
      const promise = new Promise((res, rej) => {
        resolve2 = res;
        reject = rej;
      });
      return { promise, resolve: resolve2, reject };
    }
    const ZLIB_FAILURES = new Set([
      ...Object.entries(internalBinding("constants").zlib || {}).filter(([, value]) => value < 0).map(([code]) => code),
      "Z_NEED_DICT"
    ]);
    function handleKnownInternalErrors(cause) {
      switch (true) {
        case cause?.code === "ERR_STREAM_PREMATURE_CLOSE": {
          return new AbortError(undefined, { cause });
        }
        case ZLIB_FAILURES.has(cause?.code): {
          const error = new TypeError(undefined, { cause });
          error.code = cause.code;
          return error;
        }
        default:
          return cause;
      }
    }
    function newWritableStreamFromStreamWritable(streamWritable) {
      const WritableStream = webClass("WritableStream");
      const checkIfWritableOrOutgoingMessage = streamWritable && typeof streamWritable?.write === "function" && typeof streamWritable?.on === "function";
      if (!checkIfWritableOrOutgoingMessage) {
        throw new ERR_INVALID_ARG_TYPE("streamWritable", "stream.Writable", streamWritable);
      }
      if (isDestroyed(streamWritable) || !isWritable(streamWritable)) {
        const writable = new WritableStream;
        writable.close();
        return writable;
      }
      const highWaterMark = streamWritable.writableHighWaterMark;
      const strategy = streamWritable.writableObjectMode ? countStrategy(highWaterMark) : { highWaterMark };
      let controller;
      let backpressurePromise;
      let closed;
      function onDrain() {
        if (backpressurePromise !== undefined)
          backpressurePromise.resolve();
      }
      const cleanup = finished(streamWritable, (error) => {
        error = handleKnownInternalErrors(error);
        cleanup();
        streamWritable.on("error", () => {});
        if (error != null) {
          if (backpressurePromise !== undefined)
            backpressurePromise.reject(error);
          if (closed !== undefined) {
            closed.reject(error);
            closed = undefined;
          }
          controller.error(error);
          controller = undefined;
          return;
        }
        if (closed !== undefined) {
          closed.resolve();
          closed = undefined;
          return;
        }
        controller.error(new AbortError);
        controller = undefined;
      });
      streamWritable.on("drain", onDrain);
      return new WritableStream({
        start(c) {
          controller = c;
        },
        write(chunk) {
          if (streamWritable.writableNeedDrain || !streamWritable.write(chunk)) {
            backpressurePromise = createDeferredPromise();
            return backpressurePromise.promise.finally(() => {
              backpressurePromise = undefined;
            });
          }
        },
        abort(reason) {
          destroy(streamWritable, reason);
        },
        close() {
          if (closed === undefined && !isWritableEnded(streamWritable)) {
            closed = createDeferredPromise();
            streamWritable.end();
            return closed.promise;
          }
          controller = undefined;
          return Promise.resolve();
        }
      }, strategy);
    }
    function newStreamWritableFromWritableStream(writableStream, options = kEmptyObject) {
      if (!isWritableStream(writableStream)) {
        throw new ERR_INVALID_ARG_TYPE("writableStream", "WritableStream", writableStream);
      }
      validateObject(options, "options");
      const {
        highWaterMark,
        decodeStrings = true,
        objectMode = false,
        signal
      } = options;
      validateBoolean(objectMode, "options.objectMode");
      validateBoolean(decodeStrings, "options.decodeStrings");
      const writer = writableStream.getWriter();
      let closed = false;
      const writable = new Writable({
        highWaterMark,
        objectMode,
        decodeStrings,
        signal,
        writev(chunks, callback) {
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => destroy(writable, err));
            }
          }
          writer.ready.then(() => Promise.all(chunks.map((data) => writer.write(data.chunk))).then(() => done(), done), done);
        },
        write(chunk, encoding, callback) {
          if (typeof chunk === "string" && decodeStrings && !objectMode) {
            const enc = normalizeEncoding(encoding);
            if (enc === "utf8") {
              chunk = encoder2.encode(chunk);
            } else {
              chunk = Buffer.from(chunk, encoding);
              chunk = new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
            }
          }
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              destroy(writable, err);
            }
          }
          writer.ready.then(() => writer.write(chunk).then(() => done(), done), done);
        },
        destroy(error, callback) {
          function done() {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => {
                throw err;
              });
            }
          }
          if (!closed) {
            if (error != null) {
              writer.abort(error).then(done, done);
            } else {
              writer.close().then(done, done);
            }
            return;
          }
          done();
        },
        final(callback) {
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => destroy(writable, err));
            }
          }
          if (!closed) {
            writer.close().then(() => done(), done);
          }
        }
      });
      writer.closed.then(() => {
        closed = true;
        if (!isWritableEnded(writable))
          destroy(writable, new ERR_STREAM_PREMATURE_CLOSE);
      }, (error) => {
        closed = true;
        destroy(writable, error);
      });
      return writable;
    }
    function newReadableStreamFromStreamReadable(streamReadable, options = kEmptyObject) {
      const ReadableStream = webClass("ReadableStream");
      if (typeof streamReadable?._readableState !== "object") {
        throw new ERR_INVALID_ARG_TYPE("streamReadable", "stream.Readable", streamReadable);
      }
      if (isDestroyed(streamReadable) || !isReadable(streamReadable)) {
        const readable = new ReadableStream;
        readable.cancel();
        return readable;
      }
      const objectMode = streamReadable.readableObjectMode;
      const highWaterMark = streamReadable.readableHighWaterMark;
      const evaluateStrategyOrFallback = (strategy2) => {
        if (strategy2)
          return strategy2;
        if (objectMode) {
          return countStrategy(highWaterMark);
        }
        return byteLengthStrategy(highWaterMark);
      };
      const strategy = evaluateStrategyOrFallback(options?.strategy);
      let controller;
      let wasCanceled = false;
      function onData(chunk) {
        if (Buffer.isBuffer(chunk) && !objectMode)
          chunk = new Uint8Array(chunk);
        controller.enqueue(chunk);
        if (controller.desiredSize <= 0)
          streamReadable.pause();
      }
      streamReadable.pause();
      const cleanup = finished(streamReadable, (error) => {
        error = handleKnownInternalErrors(error);
        cleanup();
        streamReadable.on("error", () => {});
        if (error)
          return controller.error(error);
        if (wasCanceled) {
          return;
        }
        controller.close();
      });
      streamReadable.on("data", onData);
      return new ReadableStream({
        start(c) {
          controller = c;
        },
        pull() {
          streamReadable.resume();
        },
        cancel(reason) {
          wasCanceled = true;
          destroy(streamReadable, reason);
        }
      }, strategy);
    }
    function newStreamReadableFromReadableStream(readableStream, options = kEmptyObject) {
      if (!isReadableStream(readableStream)) {
        throw new ERR_INVALID_ARG_TYPE("readableStream", "ReadableStream", readableStream);
      }
      validateObject(options, "options");
      const { highWaterMark, encoding, objectMode = false, signal } = options;
      if (encoding !== undefined && !Buffer.isEncoding(encoding))
        throw new ERR_INVALID_ARG_VALUE(encoding, "options.encoding");
      validateBoolean(objectMode, "options.objectMode");
      const reader = readableStream.getReader();
      let closed = false;
      const readable = new Readable({
        objectMode,
        highWaterMark,
        encoding,
        signal,
        read() {
          reader.read().then((chunk) => {
            if (chunk.done) {
              readable.push(null);
            } else {
              readable.push(chunk.value);
            }
          }, (error) => destroy(readable, error));
        },
        destroy(error, callback) {
          function done() {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => {
                throw err;
              });
            }
          }
          if (!closed) {
            reader.cancel(error).then(done, done);
            return;
          }
          done();
        }
      });
      reader.closed.then(() => {
        closed = true;
      }, (error) => {
        closed = true;
        destroy(readable, error);
      });
      return readable;
    }
    function newReadableWritablePairFromDuplex(duplex) {
      const ReadableStream = webClass("ReadableStream");
      const WritableStream = webClass("WritableStream");
      if (typeof duplex?._writableState !== "object" || typeof duplex?._readableState !== "object") {
        throw new ERR_INVALID_ARG_TYPE("duplex", "stream.Duplex", duplex);
      }
      if (isDestroyed(duplex)) {
        const writable2 = new WritableStream;
        const readable2 = new ReadableStream;
        writable2.close();
        readable2.cancel();
        return { readable: readable2, writable: writable2 };
      }
      const writable = isWritable(duplex) ? newWritableStreamFromStreamWritable(duplex) : new WritableStream;
      if (!isWritable(duplex))
        writable.close();
      const readable = isReadable(duplex) ? newReadableStreamFromStreamReadable(duplex) : new ReadableStream;
      if (!isReadable(duplex))
        readable.cancel();
      return { writable, readable };
    }
    function newStreamDuplexFromReadableWritablePair(pair = kEmptyObject, options = kEmptyObject) {
      validateObject(pair, "pair");
      const { readable: readableStream, writable: writableStream } = pair;
      if (!isReadableStream(readableStream)) {
        throw new ERR_INVALID_ARG_TYPE("pair.readable", "ReadableStream", readableStream);
      }
      if (!isWritableStream(writableStream)) {
        throw new ERR_INVALID_ARG_TYPE("pair.writable", "WritableStream", writableStream);
      }
      validateObject(options, "options");
      const {
        allowHalfOpen = false,
        objectMode = false,
        encoding,
        decodeStrings = true,
        highWaterMark,
        signal
      } = options;
      validateBoolean(objectMode, "options.objectMode");
      if (encoding !== undefined && !Buffer.isEncoding(encoding))
        throw new ERR_INVALID_ARG_VALUE(encoding, "options.encoding");
      const writer = writableStream.getWriter();
      const reader = readableStream.getReader();
      let writableClosed = false;
      let readableClosed = false;
      const duplex = new Duplex({
        allowHalfOpen,
        highWaterMark,
        objectMode,
        encoding,
        decodeStrings,
        signal,
        writev(chunks, callback) {
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => destroy(duplex, err));
            }
          }
          writer.ready.then(() => Promise.all(chunks.map((data) => writer.write(data.chunk))).then(() => done(), done), done);
        },
        write(chunk, encoding2, callback) {
          if (typeof chunk === "string" && decodeStrings && !objectMode) {
            const enc = normalizeEncoding(encoding2);
            if (enc === "utf8") {
              chunk = encoder2.encode(chunk);
            } else {
              chunk = Buffer.from(chunk, encoding2);
              chunk = new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
            }
          }
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              destroy(duplex, err);
            }
          }
          writer.ready.then(() => writer.write(chunk).then(() => done(), done), done);
        },
        final(callback) {
          function done(error) {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => destroy(duplex, err));
            }
          }
          if (!writableClosed) {
            writer.close().then(() => done(), done);
          }
        },
        read() {
          reader.read().then((chunk) => {
            if (chunk.done) {
              duplex.push(null);
            } else {
              duplex.push(chunk.value);
            }
          }, (error) => destroy(duplex, error));
        },
        destroy(error, callback) {
          function done() {
            try {
              callback(error);
            } catch (err) {
              process.nextTick(() => {
                throw err;
              });
            }
          }
          async function closeWriter() {
            if (!writableClosed)
              await writer.abort(error);
          }
          async function closeReader() {
            if (!readableClosed)
              await reader.cancel(error);
          }
          if (!writableClosed || !readableClosed) {
            Promise.all([closeWriter(), closeReader()]).then(done, done);
            return;
          }
          done();
        }
      });
      writer.closed.then(() => {
        writableClosed = true;
        if (!isWritableEnded(duplex))
          destroy(duplex, new ERR_STREAM_PREMATURE_CLOSE);
      }, (error) => {
        writableClosed = true;
        readableClosed = true;
        destroy(duplex, error);
      });
      reader.closed.then(() => {
        readableClosed = true;
      }, (error) => {
        writableClosed = true;
        readableClosed = true;
        destroy(duplex, error);
      });
      return duplex;
    }
    const streamBaseNotImplemented = (name) => () => {
      const err = new Error(`Vivari: ${name}() is not implemented \u2014 it wraps a libuv StreamBase handle, ` + `and this runtime's internalBinding('stream_wrap') is a JS shim without the ` + `readStart/onread/writeBuffer contract it needs. Convert the socket with ` + `Readable.toWeb()/Writable.toWeb() instead.`);
      err.code = "ERR_METHOD_NOT_IMPLEMENTED";
      throw err;
    };
    module.exports = {
      newWritableStreamFromStreamWritable,
      newReadableStreamFromStreamReadable,
      newStreamWritableFromWritableStream,
      newStreamReadableFromReadableStream,
      newReadableWritablePairFromDuplex,
      newStreamDuplexFromReadableWritablePair,
      newWritableStreamFromStreamBase: streamBaseNotImplemented("newWritableStreamFromStreamBase"),
      newReadableStreamFromStreamBase: streamBaseNotImplemented("newReadableStreamFromStreamBase")
    };
  }

  // runtime/dist/.gen/nodelib-entry.js
  globalThis.__bat_nodelib({
    primordials,
    createBufferBinding,
    uv: { ...UV_CODES, errname, getErrorMap },
    constants: { os: { signals: OS_SIGNALS, errno: OS_ERRNO, priority: OS_PRIORITY, dlopen: OS_DLOPEN, UV_UDP_REUSEADDR }, fs: FS_CONSTANTS, crypto: CRYPTO_CONSTANTS },
    factories: { __proto__: null, assert: assert_default, buffer: buffer_default, diagnostics_channel: diagnostics_channel_default, events: events_default, path: path_default, punycode: punycode_default, querystring: querystring_default, "stream/consumers": consumers_default, "stream/promises": promises_default, stream: stream_default, string_decoder: string_decoder_default, "timers/promises": promises_default2, url: url_default, util: util_default, "internal/abort_controller": abort_controller_default, "internal/assert/myers_diff": myers_diff_default, "internal/assert": assert_default2, "internal/blob": blob_default, "internal/buffer": buffer_default2, "internal/constants": constants_default, "internal/encoding": encoding_default, "internal/errors": errors_default, "internal/event_target": event_target_default, "internal/events/abort_listener": abort_listener_default, "internal/events/symbols": symbols_default, "internal/fixed_queue": fixed_queue_default, "internal/mime": mime_default, "internal/options": options_default, "internal/process/task_queues": task_queues_default, "internal/querystring": querystring_default2, "internal/streams/add-abort-signal": add_abort_signal_default, "internal/streams/compose": compose_default, "internal/streams/destroy": destroy_default, "internal/streams/duplex": duplex_default, "internal/streams/duplexify": duplexify_default, "internal/streams/duplexpair": duplexpair_default, "internal/streams/end-of-stream": end_of_stream_default, "internal/streams/from": from_default, "internal/streams/legacy": legacy_default, "internal/streams/operators": operators_default, "internal/streams/passthrough": passthrough_default, "internal/streams/pipeline": pipeline_default, "internal/streams/readable": readable_default, "internal/streams/state": state_default, "internal/streams/transform": transform_default, "internal/streams/utils": utils_default, "internal/streams/writable": writable_default, "internal/url": url_default2, "internal/util/colors": colors_default, "internal/util/comparisons": comparisons_default, "internal/util/debuglog": debuglog_default, "internal/util/diff": diff_default, "internal/util/inspect": inspect_default, "internal/util/parse_args/parse_args": parse_args_default, "internal/util/parse_args/utils": utils_default2, "internal/util/types": types_default, "internal/util": util_default2, "internal/v8/startup_snapshot": startup_snapshot_default, "internal/validators": validators_default, "internal/webstreams/adapters": adapters_default }
  });
})();

//# sourceURL=bat:///bat-nodelib.js
