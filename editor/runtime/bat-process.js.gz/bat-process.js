(() => {
  // runtime/src/kernel/errno.ts
  var ERRNO = {
    1: "EPERM",
    2: "ENOENT",
    3: "ESRCH",
    4: "EINTR",
    5: "EIO",
    9: "EBADF",
    10: "ECHILD",
    11: "EAGAIN",
    12: "ENOMEM",
    13: "EACCES",
    14: "EFAULT",
    17: "EEXIST",
    18: "EXDEV",
    20: "ENOTDIR",
    21: "EISDIR",
    22: "EINVAL",
    24: "EMFILE",
    25: "ENOTTY",
    28: "ENOSPC",
    29: "ESPIPE",
    30: "EROFS",
    32: "EPIPE",
    34: "ERANGE",
    36: "ENAMETOOLONG",
    38: "ENOSYS",
    39: "ENOTEMPTY",
    40: "ELOOP",
    88: "ENOTSOCK",
    98: "EADDRINUSE",
    104: "ECONNRESET",
    107: "ENOTCONN",
    110: "ETIMEDOUT",
    111: "ECONNREFUSED"
  };
  var ENOENT = 2;
  var EAGAIN = 11;
  var ENOTDIR = 20;
  var ERANGE = 34;
  function kernelError(rc, syscall, path) {
    const errno = -rc;
    const code = ERRNO[errno] ?? `E${errno}`;
    const e = new Error(`${code}: ${syscall}${path !== undefined ? ` '${path}'` : ""}`);
    e.code = code;
    e.errno = errno;
    e.syscall = syscall;
    if (path !== undefined)
      e.path = path;
    return e;
  }

  // runtime/src/kernel/wait.ts
  var hostSetTimeout = globalThis.setTimeout.bind(globalThis);
  var hostClearTimeout = globalThis.clearTimeout.bind(globalThis);
  var pending = new Map;
  async function waitWord(i32, index, seen, timeoutMs) {
    let wait = pending.get(index);
    if (!wait || wait.seen !== seen) {
      const r = Atomics.waitAsync(i32, index, seen);
      if (!r.async)
        return;
      const mine = {
        seen,
        woke: r.value.then(() => {
          if (pending.get(index) === mine)
            pending.delete(index);
        })
      };
      pending.set(index, mine);
      wait = mine;
    }
    let timer;
    await Promise.race([wait.woke, new Promise((resolve) => timer = hostSetTimeout(resolve, timeoutMs))]);
    hostClearTimeout(timer);
  }

  // runtime/src/kernel/kernel.ts
  var K_FILE = 0;
  var K_DIR = 1;
  var K_SYMLINK = 2;
  var K_FIFO = 3;
  var K_SOCKET = 4;
  var K_CHAR = 5;
  var O_RDONLY = 0;
  var O_WRONLY = 1;
  var O_RDWR = 2;
  var O_CREAT = 64;
  var O_EXCL = 128;
  var O_TRUNC = 512;
  var O_APPEND = 1024;
  var O_NONBLOCK = 2048;
  var O_DIRECTORY = 65536;
  var O_NOFOLLOW = 131072;
  var POLLIN = 1;
  var POLLOUT = 4;
  var POLLHUP = 16;
  var TOKEN_CHILD = 2147483648;
  var TOKEN_WATCH = 1073741824;
  var TOKEN_SIGNAL = 1073741825;
  var STDIO_INHERIT = 0;
  var STDIO_PIPE = 1;
  var STDIO_NULL = 2;
  var STDIO_FD = 3;
  var SCRATCH = 256 * 1024;
  var PATH_A = 0;
  var PATH_B = 8192;
  var STAT = 16384;
  var OUT = 16512;
  var DATA = 20480;
  var DATA_CAP = SCRATCH - DATA;
  var encoder = new TextEncoder;
  var decoder = new TextDecoder;
  function createKernel(inst) {
    let x = inst.x;
    const scratch = x.bat_alloc(SCRATCH) >>> 0;
    if (!scratch)
      throw new Error("kernel: out of memory");
    let u8 = inst.u8();
    let i32 = inst.i32();
    let f64 = new Float64Array(u8.buffer);
    let u32 = new Uint32Array(u8.buffer);
    const genIdx = x.BAT_MEM_GEN.value >>> 2;
    let gen = Atomics.load(i32, genIdx);
    const sync = () => {
      const g = Atomics.load(i32, genIdx);
      if (g !== gen) {
        gen = g;
        u8 = inst.u8();
        i32 = inst.i32();
        f64 = new Float64Array(u8.buffer);
        u32 = new Uint32Array(u8.buffer);
      }
    };
    const pathA = scratch + PATH_A;
    const pathB = scratch + PATH_B;
    const statP = scratch + STAT;
    const outP = scratch + OUT;
    const dataP = scratch + DATA;
    const put = (s, at, cap = 8192) => {
      const n = s.length;
      if (n <= cap) {
        let i = 0;
        for (;i < n; i++) {
          const c = s.charCodeAt(i);
          if (c > 127)
            break;
          u8[at + i] = c;
        }
        if (i === n)
          return n;
      }
      const bytes = encoder.encode(s);
      if (bytes.length > cap)
        throw kernelError(-36, "path", s);
      u8.set(bytes, at);
      return bytes.length;
    };
    let priv = new Uint8Array(4096);
    const text = (ptr, len) => {
      if (len <= 24) {
        let s = "";
        let i = 0;
        for (;i < len; i++) {
          const c = u8[ptr + i];
          if (c > 127)
            break;
          s += String.fromCharCode(c);
        }
        if (i === len)
          return s;
      }
      if (len > priv.length)
        priv = new Uint8Array(Math.max(len, priv.length * 2));
      priv.set(u8.subarray(ptr, ptr + len));
      return decoder.decode(priv.subarray(0, len));
    };
    const readStat = () => {
      const w = statP >>> 2;
      const d = statP >>> 3;
      return {
        kind: u32[w],
        mode: u32[w + 1],
        size: f64[d + 1],
        mtimeMs: f64[d + 2],
        ctimeMs: f64[d + 3],
        ino: f64[d + 4],
        nlink: u32[w + 10],
        dev: u32[w + 11],
        facts: u32[w + 12],
        compiledLen: u32[w + 13],
        birthtimeMs: f64[d + 7]
      };
    };
    const check = (rc, syscall, path) => {
      if (rc < 0)
        throw kernelError(rc, syscall, path);
      return rc;
    };
    const withBuf = (size, fn) => {
      if (size <= DATA_CAP)
        return fn(dataP, DATA_CAP);
      const p = x.bat_alloc(size) >>> 0;
      if (!p)
        throw kernelError(-12, "alloc");
      try {
        sync();
        return fn(p, size);
      } finally {
        x.bat_free(p, size);
      }
    };
    function tryStat(path, nofollow = false) {
      sync();
      const rc = x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
      if (rc === 0)
        return readStat();
      if (rc === -ENOENT || rc === -ENOTDIR)
        return;
      throw kernelError(rc, nofollow ? "lstat" : "stat", path);
    }
    function stat(path, nofollow = false) {
      sync();
      check(x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP), nofollow ? "lstat" : "stat", path);
      return readStat();
    }
    function statRaw(path, nofollow = false) {
      sync();
      return x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
    }
    const st = {
      get kind() {
        return u32[statP >>> 2];
      },
      get mode() {
        return u32[(statP >>> 2) + 1];
      },
      get size() {
        return f64[(statP >>> 3) + 1];
      },
      get mtimeMs() {
        return f64[(statP >>> 3) + 2];
      },
      get ctimeMs() {
        return f64[(statP >>> 3) + 3];
      },
      get ino() {
        return f64[(statP >>> 3) + 4];
      },
      get nlink() {
        return u32[(statP >>> 2) + 10];
      },
      get dev() {
        return u32[(statP >>> 2) + 11];
      },
      get facts() {
        return u32[(statP >>> 2) + 12];
      },
      get compiledLen() {
        return u32[(statP >>> 2) + 13];
      },
      get birthtimeMs() {
        return f64[(statP >>> 3) + 7];
      }
    };
    function kindOf(path) {
      sync();
      const rc = x.bat_stat(pathA, put(path, pathA), 0, statP);
      return rc === 0 ? u32[statP >>> 2] : -1;
    }
    function readFileRaw(path, compiled) {
      sync();
      const n = put(path, pathA);
      let rc = x.bat_read_file(pathA, n, compiled ? 1 : 0, dataP, DATA_CAP, statP);
      if (rc >= 0) {
        sync();
        const st2 = readStat();
        return { data: u8.slice(dataP, dataP + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
      }
      if (rc !== -ERANGE)
        return rc;
      for (let attempt = 0;attempt < 4; attempt++) {
        const size = f64[(statP >>> 3) + 1];
        const p = x.bat_alloc(size || 1) >>> 0;
        if (!p)
          return -12;
        try {
          sync();
          rc = x.bat_read_file(pathA, put(path, pathA), compiled ? 1 : 0, p, size, statP);
          if (rc >= 0) {
            sync();
            const st2 = readStat();
            return { data: u8.slice(p, p + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
          }
        } finally {
          x.bat_free(p, size || 1);
        }
        if (rc !== -ERANGE)
          return rc;
      }
      return rc;
    }
    function readFileInto(path, dst, compiled = false) {
      sync();
      const n = put(path, pathA);
      const flags = compiled ? 1 : 0;
      if (dst.length <= DATA_CAP) {
        const rc = x.bat_read_file(pathA, n, flags, dataP, dst.length, statP);
        if (rc >= 0) {
          sync();
          dst.set(u8.subarray(dataP, dataP + rc));
          return rc;
        }
        if (rc === -ERANGE)
          return -f64[(statP >>> 3) + 1] - 1;
        throw kernelError(rc, "open", path);
      }
      const p = x.bat_alloc(dst.length) >>> 0;
      if (!p)
        throw kernelError(-12, "alloc");
      try {
        sync();
        const rc = x.bat_read_file(pathA, put(path, pathA), flags, p, dst.length, statP);
        if (rc >= 0) {
          sync();
          dst.set(u8.subarray(p, p + rc));
          return rc;
        }
        if (rc === -ERANGE)
          return -f64[(statP >>> 3) + 1] - 1;
        throw kernelError(rc, "open", path);
      } finally {
        x.bat_free(p, dst.length);
      }
    }
    function readFile(path) {
      const r = readFileRaw(path, false);
      if (typeof r === "number")
        throw kernelError(r, "open", path);
      return r.data;
    }
    function tryReadFile(path) {
      const r = readFileRaw(path, false);
      if (typeof r !== "number")
        return r.data;
      if (r === -ENOENT || r === -ENOTDIR)
        return;
      throw kernelError(r, "open", path);
    }
    function readModule(path) {
      const r = readFileRaw(path, true);
      if (typeof r !== "number")
        return r;
      if (r === -ENOENT || r === -ENOTDIR)
        return;
      throw kernelError(r, "open", path);
    }
    function readText(path) {
      return decoder.decode(readFile(path));
    }
    function writeFile(path, data, opts = {}) {
      const bytes = typeof data === "string" ? encoder.encode(data) : data;
      const flags = (opts.append ? 1 : 0) | (opts.excl ? 2 : 0);
      withBuf(bytes.length, (ptr) => {
        u8.set(bytes, ptr);
        check(x.bat_write_file(pathA, put(path, pathA), ptr, bytes.length, opts.mode ?? 420, flags), "open", path);
      });
    }
    function mkdir(path, opts = {}) {
      sync();
      check(x.bat_mkdir(pathA, put(path, pathA), opts.mode ?? 493, opts.recursive ? 1 : 0), "mkdir", path);
    }
    function rmdir(path) {
      sync();
      check(x.bat_rmdir(pathA, put(path, pathA)), "rmdir", path);
    }
    function unlink(path) {
      sync();
      check(x.bat_unlink(pathA, put(path, pathA)), "unlink", path);
    }
    function rename(from, to) {
      sync();
      check(x.bat_rename(pathA, put(from, pathA), pathB, put(to, pathB)), "rename", from);
    }
    function symlink(target, path) {
      sync();
      check(x.bat_symlink(pathB, put(target, pathB), pathA, put(path, pathA)), "symlink", path);
    }
    function link(existing, path) {
      sync();
      check(x.bat_link(pathA, put(existing, pathA), pathB, put(path, pathB)), "link", path);
    }
    function readlink(path) {
      sync();
      const n = check(x.bat_readlink(pathA, put(path, pathA), dataP, DATA_CAP), "readlink", path);
      return text(dataP, n);
    }
    function realpath(path) {
      sync();
      const n = check(x.bat_realpath(pathA, put(path, pathA), dataP, DATA_CAP), "realpath", path);
      return text(dataP, n);
    }
    function chmod(path, mode, nofollow = false) {
      sync();
      check(x.bat_chmod(pathA, put(path, pathA), mode, nofollow ? 1 : 0), "chmod", path);
    }
    function utimes(path, mtimeMs, nofollow = false) {
      sync();
      check(x.bat_utimes(pathA, put(path, pathA), mtimeMs, nofollow ? 1 : 0), "utime", path);
    }
    function truncate(path, size = 0) {
      sync();
      check(x.bat_truncate(pathA, put(path, pathA), size), "truncate", path);
    }
    function readdir(path) {
      sync();
      const n = put(path, pathA);
      const parse = (ptr, len) => {
        const out = [];
        let i = ptr;
        const end = ptr + len;
        while (i < end) {
          const l = u8[i + 1] | u8[i + 2] << 8;
          out.push({ kind: u8[i], name: text(i + 3, l) });
          i += 3 + l;
        }
        return out;
      };
      let rc = x.bat_readdir(pathA, n, dataP, DATA_CAP);
      if (rc >= 0)
        return parse(dataP, rc);
      if (rc !== -ERANGE)
        throw kernelError(rc, "scandir", path);
      const need = u32[dataP >>> 2] + 4096;
      return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
        rc = check(x.bat_readdir(pathA, put(path, pathA), ptr, cap), "scandir", path);
        return parse(ptr, rc);
      });
    }
    function open(path, flags = O_RDONLY, mode = 420) {
      sync();
      return check(x.bat_open(pathA, put(path, pathA), flags, mode), "open", path);
    }
    function close(fd) {
      check(x.bat_close(fd), "close");
    }
    function read(fd, dst, pos) {
      sync();
      return withBuf(dst.length, (ptr) => {
        const rc = pos === undefined ? x.bat_read(fd, ptr, dst.length) : x.bat_pread(fd, ptr, dst.length, pos);
        if (rc < 0)
          throw kernelError(rc, "read");
        sync();
        dst.set(u8.subarray(ptr, ptr + rc));
        return rc;
      });
    }
    function readRaw(fd, dst) {
      sync();
      return withBuf(dst.length, (ptr) => {
        const rc = x.bat_read(fd, ptr, dst.length);
        if (rc > 0) {
          sync();
          dst.set(u8.subarray(ptr, ptr + rc));
        }
        return rc;
      });
    }
    function write(fd, src, pos) {
      sync();
      return withBuf(src.length, (ptr) => {
        u8.set(src, ptr);
        return check(pos === undefined ? x.bat_write(fd, ptr, src.length) : x.bat_pwrite(fd, ptr, src.length, pos), "write");
      });
    }
    function writeRaw(fd, src) {
      sync();
      return withBuf(src.length, (ptr) => {
        u8.set(src, ptr);
        return x.bat_write(fd, ptr, src.length);
      });
    }
    function seek(fd, offset, whence = 0) {
      const r = x.bat_seek(fd, offset, whence);
      if (r < 0)
        throw kernelError(r, "lseek");
      return r;
    }
    function fstat(fd) {
      sync();
      check(x.bat_fstat(fd, statP), "fstat");
      return readStat();
    }
    function ftruncate(fd, size = 0) {
      check(x.bat_ftruncate(fd, size), "ftruncate");
    }
    function fsetmeta(fd, mode, mtimeMs) {
      check(x.bat_fsetmeta(fd, mode ?? -1, mtimeMs ?? -1), "futimes");
    }
    function setNonblock(fd, on) {
      check(x.bat_set_nonblock(fd, on ? 1 : 0), "fcntl");
    }
    function dup(fd) {
      return check(x.bat_dup(fd), "dup");
    }
    function fdPath(fd) {
      sync();
      return text(dataP, check(x.bat_fd_path(fd, dataP, DATA_CAP), "fcntl"));
    }
    function pipe() {
      sync();
      check(x.bat_pipe(outP), "pipe");
      return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
    }
    function listen(port) {
      return check(x.bat_listen(port), "listen");
    }
    function connect(port) {
      return check(x.bat_connect(port), "connect");
    }
    function accept(fd) {
      const rc = x.bat_accept(fd);
      if (rc === -EAGAIN)
        return;
      return check(rc, "accept");
    }
    function shutdown(fd) {
      check(x.bat_shutdown(fd), "shutdown");
    }
    function sockPorts(fd) {
      sync();
      check(x.bat_sock_ports(fd, outP), "getsockname");
      return { local: u32[outP >>> 2], peer: u32[(outP >>> 2) + 1] };
    }
    function socketpair() {
      sync();
      check(x.bat_socketpair(outP), "socketpair");
      return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
    }
    function ttyOpen(cols, rows) {
      sync();
      check(x.bat_tty_open(cols, rows, outP), "openpty");
      return { master: i32[outP >>> 2], slave: i32[(outP >>> 2) + 1] };
    }
    function isatty(fd) {
      return x.bat_isatty(fd) === 1;
    }
    function ttyGetattr(fd) {
      sync();
      check(x.bat_tty_getattr(fd, dataP), "tcgetattr");
      return u8.slice(dataP, dataP + 44);
    }
    function ttySetattr(fd, termios, action = 0) {
      sync();
      u8.set(termios.subarray(0, 44), dataP);
      check(x.bat_tty_setattr(fd, action, dataP), "tcsetattr");
    }
    function ttyWinsize(fd) {
      sync();
      check(x.bat_tty_winsize(fd, dataP), "ioctl");
      const dv = inst.dv();
      return { rows: dv.getUint16(dataP, true), cols: dv.getUint16(dataP + 2, true), xpixel: dv.getUint16(dataP + 4, true), ypixel: dv.getUint16(dataP + 6, true) };
    }
    function ttyResize(fd, cols, rows, xpixel = 0, ypixel = 0) {
      check(x.bat_tty_resize(fd, cols, rows, xpixel, ypixel), "ioctl");
    }
    function subscribe(fd, mask) {
      check(x.bat_fd_subscribe(fd, mask), "poll");
    }
    function pollFd(fd) {
      return check(x.bat_fd_poll(fd), "poll");
    }
    function poll(fds, timeoutMs) {
      sync();
      const base = dataP >>> 2;
      fds.forEach((f, i) => {
        i32[base + i * 3] = f.fd;
        u32[base + i * 3 + 1] = f.events;
        u32[base + i * 3 + 2] = 0;
      });
      check(x.bat_poll(dataP, fds.length, timeoutMs), "poll");
      sync();
      return fds.map((_, i) => u32[base + i * 3 + 2]);
    }
    function takeEvents() {
      sync();
      const n = x.bat_events_take(dataP, 256);
      const out = [];
      const base = dataP >>> 2;
      for (let i = 0;i < n; i++)
        out.push([u32[base + i * 2], u32[base + i * 2 + 1]]);
      return out;
    }
    function runEvents(on) {
      let stopped = false;
      const word = x.bat_event_word() >>> 2;
      const loop = async () => {
        while (!stopped) {
          sync();
          const seen = Atomics.load(i32, word);
          const events = takeEvents();
          for (const [token, mask] of events) {
            try {
              on(token, mask);
            } catch (e) {
              inst.host.log(3, `event handler: ${e?.stack ?? e}`);
            }
          }
          if (events.length === 0) {
            const r = Atomics.waitAsync(i32, word, seen);
            if (r.async)
              await r.value;
          }
        }
      };
      loop();
      return () => {
        stopped = true;
        Atomics.notify(i32, word);
      };
    }
    function watchAdd(path, recursive) {
      sync();
      return check(x.bat_watch_add(pathA, put(path, pathA), recursive ? 1 : 0), "watch", path);
    }
    function watchRemove(id) {
      x.bat_watch_remove(id);
    }
    function watchRead() {
      sync();
      const out = [];
      for (;; ) {
        const n = x.bat_watch_read(dataP, DATA_CAP);
        if (n <= 0)
          break;
        const dv = inst.dv();
        let i = dataP;
        const end = dataP + n;
        while (i < end) {
          const len = dv.getUint16(i + 8, true);
          out.push({ id: dv.getUint32(i, true), kind: dv.getUint32(i + 4, true), path: text(i + 10, len) });
          i += 10 + len;
        }
      }
      return out;
    }
    function getpid() {
      return check(x.bat_getpid(), "getpid");
    }
    function getppid() {
      return check(x.bat_getppid(), "getppid");
    }
    function chdir(path) {
      sync();
      check(x.bat_chdir(pathA, put(path, pathA)), "chdir", path);
    }
    function getcwd() {
      sync();
      return text(dataP, check(x.bat_getcwd(dataP, DATA_CAP), "getcwd"));
    }
    function spawn(req) {
      const env = Object.entries(req.env ?? {}).map(([k, v]) => `${k}=${v}`);
      const strings = [req.exec, req.cwd ?? "", ...req.argv, ...env].map((s) => encoder.encode(s));
      const size = 4 + 24 + 8 + strings.reduce((n, s) => n + 4 + s.length, 0);
      return withBuf(size + 16, (ptr) => {
        const dv = inst.dv();
        let o = ptr;
        const w32 = (v) => {
          dv.setUint32(o, v, true);
          o += 4;
        };
        w32(0);
        for (let i = 0;i < 3; i++) {
          const s = req.stdio?.[i] ?? "inherit";
          if (typeof s === "object") {
            w32(STDIO_FD);
            w32(s.fd);
          } else {
            w32(s === "pipe" ? STDIO_PIPE : s === "null" ? STDIO_NULL : STDIO_INHERIT);
            w32(0);
          }
        }
        w32(req.argv.length);
        w32(env.length);
        for (const s of strings) {
          w32(s.length);
          u8.set(s, o);
          o += s.length;
        }
        const fdsP = o + 3 & ~3;
        const pid = check(x.bat_spawn(ptr, size, fdsP), "spawn", req.exec);
        sync();
        const b = fdsP >>> 2;
        return { pid, stdio: [i32[b], i32[b + 1], i32[b + 2]] };
      });
    }
    function procInfo(pid) {
      sync();
      const parse = (ptr) => {
        const dv = inst.dv();
        let o = ptr;
        const r32 = () => {
          const v = dv.getUint32(o, true);
          o += 4;
          return v;
        };
        const str = () => {
          const n = r32();
          const s = text(o, n);
          o += n;
          return s;
        };
        const argc = r32();
        const envc = r32();
        const exec = str();
        const cwd = str();
        const argv = Array.from({ length: argc }, str);
        const env = {};
        for (let i = 0;i < envc; i++) {
          const kv = str();
          const eq = kv.indexOf("=");
          env[kv.slice(0, eq)] = kv.slice(eq + 1);
        }
        return { exec, cwd, argv, env };
      };
      const rc = x.bat_proc_info(pid, dataP, DATA_CAP);
      if (rc >= 0)
        return parse(dataP);
      if (rc !== -ERANGE)
        throw kernelError(rc, "procinfo");
      const need = u32[dataP >>> 2];
      return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
        check(x.bat_proc_info(pid, ptr, cap), "procinfo");
        return parse(ptr);
      });
    }
    function exit(code) {
      x.bat_proc_exit(code);
    }
    function waitpid(pid, nohang = false) {
      const rc = x.bat_waitpid(pid, nohang || !inst.canBlock ? 1 : 0);
      if (rc === -EAGAIN)
        return;
      return check(rc, "waitpid");
    }
    function kill(pid, signal) {
      check(x.bat_kill(pid, signal), "kill");
    }
    function sigTake() {
      return x.bat_sig_take() >>> 0;
    }
    function procList() {
      sync();
      const n = x.bat_proc_list(dataP, 1024);
      const b = dataP >>> 2;
      return Array.from({ length: n }, (_, i) => ({
        pid: u32[b + i * 4],
        ppid: u32[b + i * 4 + 1],
        state: u32[b + i * 4 + 2],
        status: i32[b + i * 4 + 3]
      }));
    }
    function imageNames() {
      sync();
      const n = x.bat_image_count();
      return Array.from({ length: n }, (_, id) => {
        const rc = x.bat_image_name(id, dataP, DATA_CAP);
        return rc >= 0 ? text(dataP, rc) : undefined;
      });
    }
    function imageStats(id) {
      sync();
      check(x.bat_image_stats(id, outP), "imagestats");
      const d = outP >>> 3;
      return { entries: f64[d], fileLen: f64[d + 1], cachedBytes: f64[d + 2], hostReads: f64[d + 3] };
    }
    function imageCacheStats() {
      sync();
      x.bat_image_cache_stats(outP);
      const d = outP >>> 3;
      return { limit: f64[d], bytes: f64[d + 1], peakBytes: f64[d + 2], loads: f64[d + 3], evictions: f64[d + 4] };
    }
    function memoryStats() {
      sync();
      x.bat_mem_stats(outP);
      const d = outP >>> 3;
      return { size: f64[d], maximum: f64[d + 1], heapStart: f64[d + 2], heapEnd: f64[d + 3], inUse: f64[d + 4], peakInUse: f64[d + 5], refused: f64[d + 6], grows: f64[d + 7] };
    }
    function imageSection(id, section) {
      sync();
      if (x.bat_image_section(id, section, outP) < 0)
        return;
      const ptr = u32[outP >>> 2];
      return u8.slice(ptr, ptr + u32[(outP >>> 2) + 1]);
    }
    async function flush() {
      const target = x.bat_flush_begin();
      if (target < 0)
        return;
      const word = x.BAT_PERSIST_WORD.value >>> 2;
      for (;; ) {
        sync();
        const seen = Atomics.load(i32, word);
        if (x.bat_persist_durable() >= target)
          return;
        await waitWord(i32, word, seen, 1000);
      }
    }
    function flushSync(timeoutMs = -1) {
      const target = x.bat_flush_begin();
      if (target < 0)
        return;
      check(x.bat_flush_wait(target, timeoutMs), "fsync");
    }
    const overlayGenIdx = x.BAT_OVERLAY_GEN.value >>> 2;
    function overlayGeneration() {
      return Atomics.load(i32, overlayGenIdx);
    }
    async function retrying(fn) {
      const word = x.BAT_FAULT_WORD.value >>> 2;
      for (;; ) {
        sync();
        const seen = Atomics.load(i32, word);
        try {
          return fn();
        } catch (e) {
          if (e?.errno !== EAGAIN)
            throw e;
        }
        await waitWord(i32, word, seen, 100);
      }
    }
    function release() {
      inst.release();
      x = self.x = inst.x;
      u8 = inst.u8();
      i32 = inst.i32();
      f64 = new Float64Array(u8.buffer);
      u32 = new Uint32Array(u8.buffer);
    }
    const self = {
      inst,
      x,
      release,
      stat,
      tryStat,
      statRaw,
      st,
      kindOf,
      readFile,
      readFileInto,
      tryReadFile,
      readModule,
      readText,
      writeFile,
      mkdir,
      rmdir,
      unlink,
      rename,
      symlink,
      link,
      readlink,
      realpath,
      chmod,
      utimes,
      truncate,
      readdir,
      open,
      close,
      read,
      readRaw,
      write,
      writeRaw,
      seek,
      fstat,
      ftruncate,
      fsetmeta,
      setNonblock,
      dup,
      fdPath,
      pipe,
      listen,
      connect,
      accept,
      shutdown,
      sockPorts,
      socketpair,
      ttyOpen,
      isatty,
      ttyGetattr,
      ttySetattr,
      ttyWinsize,
      ttyResize,
      subscribe,
      pollFd,
      poll,
      takeEvents,
      runEvents,
      watchAdd,
      watchRemove,
      watchRead,
      getpid,
      getppid,
      chdir,
      getcwd,
      spawn,
      procInfo,
      exit,
      waitpid,
      kill,
      sigTake,
      procList,
      imageNames,
      imageStats,
      imageSection,
      imageCacheStats,
      memoryStats,
      flush,
      flushSync,
      overlayGeneration,
      retrying
    };
    return self;
  }

  // runtime/src/process/loop.ts
  var ctx = { frame: undefined, active: false };
  var kRefed = Symbol("refed");
  var TIMEOUT_MAX = 2 ** 31 - 1;
  function createLoop(host) {
    let kernel;
    let hooks;
    let refs = 0;
    let stopped = false;
    const stats = { turns: 0, timers: 0, immediates: 0, ticks: 0, events: 0, wakeTimer: 0, wakeKernel: 0, wakePing: 0 };
    const now = () => performance.now();
    let ticks = [];
    let tickScheduled = false;
    let draining = false;
    function drainTicks() {
      if (draining)
        return;
      draining = true;
      try {
        while (ticks.length) {
          const batch = ticks;
          ticks = [];
          for (let i = 0;i < batch.length; i++) {
            const t = batch[i];
            const prev = ctx.frame;
            ctx.frame = t.frame;
            try {
              if (t.args === undefined)
                t.fn();
              else
                t.fn(...t.args);
            } catch (e) {
              hooks?.uncaught(e);
            } finally {
              ctx.frame = prev;
            }
            stats.ticks++;
          }
        }
      } finally {
        draining = false;
        tickScheduled = false;
      }
    }
    function nextTick(fn, ...args) {
      if (typeof fn !== "function")
        throw typeError("ERR_INVALID_ARG_TYPE", 'The "callback" argument must be of type function');
      ticks.push({ fn, args: args.length ? args : undefined, frame: ctx.frame });
      if (!tickScheduled) {
        tickScheduled = true;
        host.queueMicrotask(drainTicks);
      }
    }
    function queueMicrotaskBound(fn) {
      if (typeof fn !== "function")
        throw typeError("ERR_INVALID_ARG_TYPE", 'The "callback" argument must be of type function');
      const frame = ctx.frame;
      host.queueMicrotask(() => {
        const prev = ctx.frame;
        ctx.frame = frame;
        try {
          fn();
        } catch (e) {
          hooks?.uncaught(e);
        } finally {
          ctx.frame = prev;
        }
      });
    }
    function run(fn, frame, thisArg, args) {
      const prev = ctx.frame;
      ctx.frame = frame;
      try {
        if (args === undefined)
          fn.call(thisArg);
        else
          fn.apply(thisArg, args);
      } catch (e) {
        hooks?.uncaught(e);
      } finally {
        if (!ctx.active)
          ctx.frame = prev;
      }
      if (ticks.length)
        drainTicks();
      if (ctx.active)
        ctx.frame = frame;
      ran++;
    }
    let ran = 0;
    function call(fn, thisArg, ...args) {
      if (stopped)
        return;
      run(fn, ctx.frame, thisArg, args.length ? args : undefined);
    }
    function bind(fn) {
      const frame = ctx.frame;
      if (frame === undefined && !ctx.active)
        return fn;
      return function(...args) {
        const prev = ctx.frame;
        ctx.frame = frame;
        try {
          return fn.apply(this, args);
        } finally {
          ctx.frame = prev;
        }
      };
    }
    let timerSeq = 0;
    const heap = [];
    const less = (a, b) => a._due < b._due || a._due === b._due && a._seq < b._seq;
    function heapPush(t) {
      let i = heap.length;
      heap.push(t);
      while (i > 0) {
        const p = i - 1 >> 1;
        if (!less(t, heap[p]))
          break;
        heap[i] = heap[p];
        i = p;
      }
      heap[i] = t;
    }
    function heapPop() {
      const top = heap[0];
      const last = heap.pop();
      const n = heap.length;
      if (n > 0) {
        let i = 0;
        for (;; ) {
          let c = 2 * i + 1;
          if (c >= n)
            break;
          if (c + 1 < n && less(heap[c + 1], heap[c]))
            c++;
          if (!less(heap[c], last))
            break;
          heap[i] = heap[c];
          i = c;
        }
        heap[i] = last;
      }
      return top;
    }
    let nextTimerId = 1;

    class Timeout {
      _idleTimeout;
      _onTimeout;
      _timerArgs;
      _repeat;
      _destroyed = false;
      _due = 0;
      _seq = 0;
      _queued = false;
      _frame;
      [kRefed] = true;
      _id = nextTimerId++;
      constructor(fn, ms, args, repeat) {
        ms = +ms;
        if (!(ms >= 1 && ms <= TIMEOUT_MAX))
          ms = 1;
        this._idleTimeout = ms;
        this._onTimeout = fn;
        this._timerArgs = args;
        this._repeat = repeat ? ms : null;
        this._frame = ctx.frame;
        refs++;
        arm(this);
      }
      ref() {
        if (!this[kRefed]) {
          this[kRefed] = true;
          if (!this._destroyed)
            refs++;
        }
        return this;
      }
      unref() {
        if (this[kRefed]) {
          this[kRefed] = false;
          if (!this._destroyed)
            released();
        }
        return this;
      }
      hasRef() {
        return this[kRefed];
      }
      refresh() {
        if (!this._destroyed)
          arm(this);
        return this;
      }
      close() {
        clearTimeout(this);
        return this;
      }
      [Symbol.toPrimitive]() {
        timersById.set(this._id, this);
        return this._id;
      }
      [Symbol.dispose]() {
        clearTimeout(this);
      }
    }
    const timersById = new Map;
    function arm(t) {
      t._due = now() + t._idleTimeout;
      t._seq = ++timerSeq;
      heapPush({ _due: t._due, _seq: t._seq, t });
      scheduleWake();
    }
    function clearTimeout(t) {
      if (typeof t === "number" || typeof t === "string")
        t = timersById.get(+t);
      if (!t || !(t instanceof Timeout) || t._destroyed)
        return;
      t._destroyed = true;
      t._onTimeout = null;
      timersById.delete(t._id);
      if (t[kRefed])
        released();
    }
    function setTimeout2(fn, ms, ...args) {
      if (typeof fn !== "function")
        throw typeError("ERR_INVALID_ARG_TYPE", 'The "callback" argument must be of type function');
      return new Timeout(fn, ms, args.length ? args : undefined, false);
    }
    function setInterval(fn, ms, ...args) {
      if (typeof fn !== "function")
        throw typeError("ERR_INVALID_ARG_TYPE", 'The "callback" argument must be of type function');
      return new Timeout(fn, ms, args.length ? args : undefined, true);
    }
    let timerLimit = 0;
    function stepTimer() {
      const t0 = now();
      while (heap.length && heap[0]._due <= t0 && heap[0]._seq <= timerLimit) {
        const e = heapPop();
        const t = e.t;
        if (t._destroyed || t._seq !== e._seq)
          continue;
        const fn = t._onTimeout;
        if (t._repeat !== null) {
          t._idleTimeout = t._repeat;
          t._due = t0 + t._repeat;
          t._seq = ++timerSeq;
          heapPush({ _due: t._due, _seq: t._seq, t });
        } else {
          t._destroyed = true;
          timersById.delete(t._id);
          if (t[kRefed])
            refs--;
        }
        stats.timers++;
        run(fn, t._frame, t, t._timerArgs);
        return true;
      }
      return false;
    }

    class Immediate {
      _onImmediate;
      _args;
      _frame;
      [kRefed] = true;
      _destroyed = false;
      constructor(fn, args) {
        this._onImmediate = fn;
        this._args = args;
        this._frame = ctx.frame;
      }
      ref() {
        if (!this[kRefed]) {
          this[kRefed] = true;
          if (!this._destroyed)
            refs++;
        }
        return this;
      }
      unref() {
        if (this[kRefed]) {
          this[kRefed] = false;
          if (!this._destroyed)
            released();
        }
        return this;
      }
      hasRef() {
        return this[kRefed];
      }
      [Symbol.dispose]() {
        clearImmediate(this);
      }
    }
    let immediates = [];
    function setImmediate(fn, ...args) {
      if (typeof fn !== "function")
        throw typeError("ERR_INVALID_ARG_TYPE", 'The "callback" argument must be of type function');
      const im = new Immediate(fn, args.length ? args : undefined);
      immediates.push(im);
      refs++;
      ping();
      return im;
    }
    function clearImmediate(im) {
      if (!im || !(im instanceof Immediate) || im._destroyed)
        return;
      im._destroyed = true;
      im._onImmediate = null;
      if (im[kRefed])
        released();
    }
    function defer(fn) {
      setImmediate(fn);
    }
    let immediateBatch = [];
    let immediateAt = 0;
    function stepImmediate() {
      while (immediateAt < immediateBatch.length) {
        const im = immediateBatch[immediateAt++];
        if (im._destroyed)
          continue;
        im._destroyed = true;
        if (im[kRefed])
          refs--;
        stats.immediates++;
        run(im._onImmediate, im._frame, im, im._args);
        return true;
      }
      return false;
    }
    const fdHandlers = new Map;
    const childHandlers = new Map;
    const watchHandlers = new Map;
    const exited = new Map;
    let waiting = false;
    let ready = [];
    let readyAt = 0;
    function takeKernel() {
      const k = kernel;
      if (!k)
        return;
      for (;; ) {
        const events = k.takeEvents();
        if (events.length === 0)
          return;
        for (let i = 0;i < events.length; i++) {
          const token = events[i][0];
          const mask = events[i][1];
          stats.events++;
          if (token === TOKEN_WATCH) {
            for (const e of k.watchRead()) {
              const h = watchHandlers.get(e.id);
              if (h)
                ready.push([h[0], [e.kind, e.path], h[1]]);
            }
          } else if (token === TOKEN_SIGNAL) {
            const bits = k.sigTake();
            for (let s = 1;s < 32; s++)
              if (bits & 1 << s)
                ready.push([(sig) => hooks?.signal(sig), [s], undefined]);
          } else if (token >= TOKEN_CHILD) {
            const pid = token - TOKEN_CHILD;
            const h = childHandlers.get(pid);
            if (h) {
              childHandlers.delete(pid);
              ready.push([h[0], [mask], h[1]]);
            } else
              exited.set(pid, mask);
          } else {
            ready.push([(m) => fdHandlers.get(token)?.[0](m), [mask], fdHandlers.get(token)?.[1]]);
          }
        }
      }
    }
    function stepKernel() {
      if (readyAt < ready.length) {
        const [h, args, frame] = ready[readyAt++];
        if (readyAt === ready.length) {
          ready = [];
          readyAt = 0;
        }
        run(h, frame, undefined, args);
        return true;
      }
      return false;
    }
    function armKernelWait() {
      const k = kernel;
      if (!k || waiting || stopped)
        return;
      const i32 = k.inst.i32();
      const word = k.x.bat_event_word() >>> 2;
      const seen = Atomics.load(i32, word);
      takeKernel();
      if (ready.length) {
        ping();
        return;
      }
      const r = Atomics.waitAsync(i32, word, seen);
      if (!r.async) {
        ping();
        return;
      }
      waiting = true;
      r.value.then(() => {
        waiting = false;
        stats.wakeKernel++;
        turn();
      });
    }
    const channel = new host.MessageChannel;
    let pinged = false;
    channel.port1.onmessage = () => {
      pinged = false;
      stats.wakePing++;
      turn();
    };
    function ping() {
      if (!pinged && !stopped) {
        pinged = true;
        channel.port2.postMessage(0);
      }
    }
    let hostTimer;
    let hostTimerDue = Infinity;
    function scheduleWake() {
      while (heap.length && (heap[0].t._destroyed || heap[0].t._seq !== heap[0]._seq))
        heapPop();
      if (heap.length === 0 || stopped)
        return;
      const due = heap[0]._due;
      const delay = due - now();
      if (delay < 4) {
        ping();
        return;
      }
      if (hostTimer !== undefined && hostTimerDue <= due)
        return;
      if (hostTimer !== undefined)
        host.clearTimeout(hostTimer);
      hostTimerDue = due;
      hostTimer = host.setTimeout(() => {
        hostTimer = undefined;
        hostTimerDue = Infinity;
        stats.wakeTimer++;
        turn();
      }, delay);
    }
    let exitCheck = 0;
    let ranAtTurnStart = 0;
    let inTurn = false;
    function released() {
      refs--;
      if (refs <= 0 && !inTurn)
        ping();
    }
    let phase = 0;
    function turn() {
      if (stopped || inTurn)
        return;
      inTurn = true;
      try {
        if (phase === 0) {
          stats.turns++;
          timerLimit = timerSeq;
          phase = 1;
          ranAtTurnStart = ran;
        }
        for (;; ) {
          let did;
          if (phase === 1) {
            did = stepTimer();
            if (!did) {
              phase = 2;
              takeKernel();
              continue;
            }
          } else if (phase === 2) {
            did = stepKernel();
            if (!did) {
              phase = 3;
              immediateBatch = immediates;
              immediates = [];
              immediateAt = 0;
              continue;
            }
          } else {
            did = stepImmediate();
            if (!did) {
              phase = 0;
              immediateBatch = [];
              break;
            }
          }
          if (stopped)
            return;
          if (ctx.active) {
            ping();
            return;
          }
        }
      } finally {
        inTurn = false;
      }
      if (immediates.length)
        ping();
      scheduleWake();
      armKernelWait();
      if (ran !== ranAtTurnStart)
        exitCheck = 0;
      if (refs <= 0 && ticks.length === 0 && ready.length === 0) {
        if (exitCheck === 0) {
          exitCheck = 1;
          ping();
        } else if (exitCheck === 1) {
          exitCheck = 2;
          hooks?.beforeExit();
          if (ticks.length)
            drainTicks();
          ping();
        } else {
          exitCheck = 0;
          hooks?.drained();
        }
      } else
        exitCheck = 0;
    }
    return {
      stats,
      Timeout,
      Immediate,
      ref() {
        refs++;
      },
      unref() {
        released();
      },
      refs: () => refs,
      defer,
      onFd(fd, mask, cb) {
        fdHandlers.set(fd, [cb, ctx.frame]);
        kernel.subscribe(fd, mask);
        ping();
      },
      offFd(fd) {
        if (fdHandlers.delete(fd)) {
          try {
            kernel.subscribe(fd, 0);
          } catch {}
        }
      },
      onChild(pid, cb) {
        const status = exited.get(pid);
        if (status !== undefined) {
          exited.delete(pid);
          nextTick(cb, status);
        } else
          childHandlers.set(pid, [cb, ctx.frame]);
      },
      onWatch(id, cb) {
        watchHandlers.set(id, [cb, ctx.frame]);
      },
      offWatch(id) {
        watchHandlers.delete(id);
      },
      call,
      bind,
      nextTick,
      setImmediate,
      setTimeout: setTimeout2,
      setInterval,
      clearTimeout,
      clearImmediate,
      queueMicrotask: queueMicrotaskBound,
      drainTicks,
      turn,
      start(k, h) {
        kernel = k;
        hooks = h;
        ping();
      },
      stop() {
        stopped = true;
        if (hostTimer !== undefined)
          host.clearTimeout(hostTimer);
        if (kernel && waiting) {
          try {
            Atomics.notify(kernel.inst.i32(), kernel.x.bat_event_word() >>> 2);
          } catch {}
        }
      }
    };
  }
  function typeError(code, message) {
    const e = new TypeError(message);
    e.code = code;
    return e;
  }

  // runtime/src/node/registry.ts
  var factories = new Map;
  function registerBuiltin(name, factory, opts = {}) {
    factories.set(name, { factory, opts });
  }
  function unsupported(name, what) {
    const e = new Error(`${name}: ${what} is not supported in this runtime`);
    e.code = "ERR_FEATURE_UNAVAILABLE_ON_PLATFORM";
    throw e;
  }

  // runtime/src/node/async_hooks.ts
  class Held {
    frame;
    value;
    threw;
    constructor(frame, value, threw) {
      this.frame = frame;
      this.value = value;
      this.threw = threw;
    }
  }
  var nativePromise = Promise;
  var nativeThen = Promise.prototype.then;
  function awaitWrap(x) {
    if (!ctx.active)
      return x;
    const frame = ctx.frame;
    return nativeThen.call(nativePromise.resolve(x), (v) => new Held(frame, v, false), (e) => new Held(frame, e, true));
  }
  function awaitUnwrap(v) {
    if (v instanceof Held) {
      ctx.frame = v.frame;
      if (v.threw)
        throw v.value;
      return v.value;
    }
    return v;
  }
  var activated = false;
  function activate(rt) {
    if (activated)
      return;
    activated = true;
    ctx.active = true;
    const g = rt.host.global;
    const wrap = (fn, frame) => function(v) {
      const prev = ctx.frame;
      ctx.frame = frame;
      try {
        return fn.call(this, v);
      } finally {
        ctx.frame = prev;
      }
    };
    g.Promise.prototype.then = function then(onFulfilled, onRejected) {
      const frame = ctx.frame;
      return nativeThen.call(this, typeof onFulfilled === "function" ? wrap(onFulfilled, frame) : onFulfilled, typeof onRejected === "function" ? wrap(onRejected, frame) : onRejected);
    };
    Object.defineProperty(g, "queueMicrotask", { value: rt.loop.queueMicrotask, writable: true, configurable: true, enumerable: true });
  }
  function create(rt) {
    let nextId = 2;

    class AsyncResource {
      type;
      #frame;
      #id = nextId++;
      constructor(type, _options) {
        if (typeof type !== "string")
          throw Object.assign(new TypeError('The "type" argument must be of type string'), { code: "ERR_INVALID_ARG_TYPE" });
        this.type = type;
        this.#frame = ctx.frame;
      }
      runInAsyncScope(fn, thisArg, ...args) {
        const prev = ctx.frame;
        ctx.frame = this.#frame;
        try {
          return fn.apply(thisArg, args);
        } finally {
          ctx.frame = prev;
        }
      }
      bind(fn, thisArg) {
        const self = this;
        const bound = function(...args) {
          return self.runInAsyncScope(fn, thisArg ?? this, ...args);
        };
        Object.defineProperty(bound, "length", { value: fn.length, configurable: true });
        return bound;
      }
      static bind(fn, type, thisArg) {
        return new AsyncResource(type || fn.name || "bound-anonymous-fn").bind(fn, thisArg);
      }
      emitDestroy() {
        return this;
      }
      asyncId() {
        return this.#id;
      }
      triggerAsyncId() {
        return 1;
      }
    }

    class AsyncLocalStorage {
      #enabled = true;
      #default;
      name;
      constructor(options) {
        activate(rt);
        this.#default = options?.defaultValue;
        this.name = options?.name ?? "";
      }
      static bind(fn) {
        return AsyncResource.bind(fn);
      }
      static snapshot() {
        const frame = ctx.frame;
        return (fn, ...args) => {
          const prev = ctx.frame;
          ctx.frame = frame;
          try {
            return fn(...args);
          } finally {
            ctx.frame = prev;
          }
        };
      }
      run(store, fn, ...args) {
        this.#enabled = true;
        const prev = ctx.frame;
        const frame = new Map(prev);
        frame.set(this, store);
        ctx.frame = frame;
        let result;
        try {
          result = fn(...args);
        } catch (e) {
          ctx.frame = prev;
          throw e;
        }
        ctx.frame = prev;
        return result;
      }
      exit(fn, ...args) {
        const prev = ctx.frame;
        if (prev?.has(this)) {
          const frame = new Map(prev);
          frame.delete(this);
          ctx.frame = frame;
        }
        try {
          return fn(...args);
        } finally {
          ctx.frame = prev;
        }
      }
      getStore() {
        if (!this.#enabled)
          return;
        const frame = ctx.frame;
        return frame !== undefined && frame.has(this) ? frame.get(this) : this.#default;
      }
      enterWith(store) {
        this.#enabled = true;
        const frame = new Map(ctx.frame);
        frame.set(this, store);
        ctx.frame = frame;
      }
      disable() {
        this.#enabled = false;
      }
    }
    const executionAsyncResource = () => rt.process;
    return {
      AsyncLocalStorage,
      AsyncResource,
      createHook: () => ({ enable() {
        return this;
      }, disable() {
        return this;
      } }),
      executionAsyncId: () => 1,
      triggerAsyncId: () => 0,
      executionAsyncResource,
      asyncWrapProviders: Object.freeze({ __proto__: null })
    };
  }
  registerBuiltin("async_hooks", create);
  registerBuiltin("internal/async_hooks", (rt) => {
    const pub = rt.require("async_hooks");
    const symbols = { owner_symbol: Symbol("owner_symbol"), async_id_symbol: Symbol("async_id_symbol"), trigger_async_id_symbol: Symbol("trigger_async_id_symbol") };
    let id = 1;
    return {
      ...pub,
      symbols,
      newAsyncId: () => ++id,
      getNewAsyncId: () => ++id,
      getOrSetAsyncId: (o) => o[symbols.async_id_symbol] ??= ++id,
      defaultTriggerAsyncIdScope: (_id, fn, ...args) => fn(...args),
      enabledHooksExist: () => false
    };
  }, { hidden: true });

  // runtime/src/process/sh.ts
  var SHELL_EXEC = "/bin/sh";
  var SHELL_NAMES = ["sh", "bash", "zsh", "dash", "ash"];
  var SHELL_PROGRAMS = new Set("[ basename cat chmod cp cut date dirname du echo env false find grep egrep fgrep head hostname id ln ls mkdir mktemp mv printenv printf pwd readlink realpath rm rmdir sed seq sleep sort tail tee test touch tr true uname uniq wc which whoami xargs npm npx bunx yarn pnpm bun nproc stat rev tac".split(" "));
  var ABORT = Symbol("sh.abort");
  function createShell(rt) {
    const k = rt.kernel;
    const decoder2 = new TextDecoder;
    const encoder2 = new TextEncoder;
    let x;
    let stash = new Uint8Array(0);
    let deadline = Infinity;
    let timedOut = false;
    let asProcess = false;
    let signal = 0;
    const sleeper = new Int32Array(new SharedArrayBuffer(4));
    const mem = () => new Uint8Array(x.memory.buffer);
    const str = (p, n) => decoder2.decode(new Uint8Array(x.memory.buffer, p, n));
    const call = (fn) => {
      try {
        return fn() ?? 0;
      } catch (e) {
        if (e === ABORT)
          throw e;
        return -(e?.errno > 0 ? e.errno : 5);
      }
    };
    const running = new Set;
    const abort = () => {
      for (const pid of running) {
        try {
          k.kill(pid, signal || 15);
        } catch {}
      }
      running.clear();
      throw ABORT;
    };
    const keep = (bytes) => {
      stash = bytes;
      return bytes.length;
    };
    const interrupted = () => {
      if (asProcess && !signal) {
        const mask = k.sigTake();
        if (mask) {
          for (let s = 1;s < 32; s++)
            if (mask & 1 << s)
              signal ||= s;
        }
      }
      if (performance.now() > deadline)
        timedOut = true;
      return signal !== 0 || timedOut;
    };
    const imports = {
      sh_open: (p, n, flags, mode) => call(() => k.open(str(p, n), flags, mode)),
      sh_close: (fd) => call(() => k.close(fd)),
      sh_read: (fd, p, n) => call(() => {
        const got = k.read(fd, new Uint8Array(x.memory.buffer, p, n));
        if (asProcess && interrupted())
          abort();
        return got;
      }),
      sh_write: (fd, p, n) => call(() => {
        if (asProcess && interrupted())
          abort();
        return k.write(fd, new Uint8Array(x.memory.buffer, p, n));
      }),
      sh_stat: (p, n, follow, out) => call(() => {
        const st = k.stat(str(p, n), !follow);
        new Float64Array(x.memory.buffer, out, 4).set([st.kind, st.mode & 4095, st.size, st.mtimeMs]);
      }),
      sh_readdir: (p, n) => call(() => keep(encoder2.encode(k.readdir(str(p, n)).map((e) => `${e.kind}${e.name}`).join("\x00")))),
      sh_readlink: (p, n) => call(() => keep(encoder2.encode(k.readlink(str(p, n))))),
      sh_realpath: (p, n) => call(() => keep(encoder2.encode(k.realpath(str(p, n))))),
      sh_take: (p, cap) => {
        mem().set(stash.subarray(0, cap), p);
      },
      sh_mkdir: (p, n, mode) => call(() => k.mkdir(str(p, n), { mode })),
      sh_rmdir: (p, n) => call(() => k.rmdir(str(p, n))),
      sh_unlink: (p, n) => call(() => k.unlink(str(p, n))),
      sh_rename: (p, n, q, m) => call(() => k.rename(str(p, n), str(q, m))),
      sh_symlink: (p, n, q, m) => call(() => k.symlink(str(p, n), str(q, m))),
      sh_chmod: (p, n, mode) => call(() => k.chmod(str(p, n), mode)),
      sh_utimes: (p, n, ms) => call(() => k.utimes(str(p, n), ms)),
      sh_pipe: (out) => call(() => {
        const [r, w] = k.pipe();
        new Int32Array(x.memory.buffer, out, 2).set([r, w]);
      }),
      sh_spawn: (p, n) => call(() => {
        if (interrupted())
          abort();
        const dv = new DataView(x.memory.buffer, p, n);
        let o = 0;
        const i32 = () => {
          const v = dv.getInt32(o, true);
          o += 4;
          return v;
        };
        const text = () => {
          const len = i32();
          const s = str(p + o, len);
          o += len;
          return s;
        };
        const fds = [i32(), i32(), i32()];
        const argc = i32();
        const envc = i32();
        const exec = text();
        const cwd = text();
        const argv = Array.from({ length: argc }, text);
        const env = {};
        for (let i = 0;i < envc; i++) {
          const kv = text();
          const eq = kv.indexOf("=");
          if (eq > 0)
            env[kv.slice(0, eq)] = kv.slice(eq + 1);
        }
        delete env.NODE_CHANNEL_FD;
        const pid = k.spawn({ exec, argv, env, cwd, stdio: fds.map((fd) => fd < 0 ? "null" : { fd }) }).pid;
        running.add(pid);
        return pid;
      }),
      sh_wait: (pid) => {
        running.delete(pid);
        if (!asProcess && deadline === Infinity) {
          try {
            return k.waitpid(pid) ?? 127;
          } catch {
            return 127;
          }
        }
        const word = k.x.bat_event_word() >>> 2;
        let killedAt = 0;
        for (;; ) {
          const i32 = k.inst.i32();
          const seen = Atomics.load(i32, word);
          let st;
          try {
            st = k.waitpid(pid, true);
          } catch {
            st = 127;
          }
          if (st !== undefined) {
            if (killedAt || interrupted())
              abort();
            return st;
          }
          if (interrupted()) {
            const now = performance.now();
            try {
              if (!killedAt)
                k.kill(pid, signal || 15);
              else if (now - killedAt > 2000)
                k.kill(pid, 9);
            } catch {}
            killedAt ||= now;
          }
          Atomics.wait(i32, word, seen, killedAt ? 50 : Math.max(1, Math.min(deadline - performance.now(), 1000)));
        }
      },
      sh_kill: (pid, sig) => call(() => k.kill(pid, sig)),
      sh_now: () => Date.now(),
      sh_sleep: (ms) => {
        const until = performance.now() + ms;
        for (;; ) {
          const left = until - performance.now();
          if (interrupted())
            abort();
          if (left <= 0)
            return;
          Atomics.wait(sleeper, 0, 0, Math.min(left, asProcess || deadline !== Infinity ? 50 : left));
        }
      },
      sh_tz: () => -new Date().getTimezoneOffset(),
      sh_pid: () => k.getpid()
    };
    const instance = () => x ??= new WebAssembly.Instance(rt.wasmModule("sh"), { sh: imports }).exports;
    function run(req) {
      const sh = instance();
      deadline = req.timeoutMs && req.timeoutMs > 0 ? performance.now() + req.timeoutMs : Infinity;
      timedOut = false;
      asProcess = !!req.asProcess;
      signal = 0;
      running.clear();
      const strings = [req.cwd, ...req.argv, ...Object.entries(req.env).map(([key, v]) => `${key}=${v}`)].map((s) => encoder2.encode(s));
      const input = req.stdio[0] === "memory" ? req.input ?? new Uint8Array(0) : new Uint8Array(0);
      const size = 20 + strings.reduce((n, s) => n + 4 + s.length, 0) + 4 + input.length;
      const p = sh.sh_alloc(size);
      const dv = new DataView(sh.memory.buffer, p, size);
      const u8 = mem();
      let o = 0;
      for (const s of req.stdio) {
        dv.setInt32(o, s === "null" ? -1 : s === "memory" ? -2 : s, true);
        o += 4;
      }
      dv.setUint32(o, req.argv.length, true);
      dv.setUint32(o + 4, Object.keys(req.env).length, true);
      o += 8;
      for (const s of [...strings, input]) {
        dv.setUint32(o, s.length, true);
        u8.set(s, p + o + 4);
        o += 4 + s.length;
      }
      let status;
      try {
        status = sh.sh_run(p, size);
      } catch (e) {
        x = undefined;
        if (e === ABORT)
          return { status: signal ? 128 + signal : 124, stdout: new Uint8Array(0), stderr: new Uint8Array(0), timedOut, signal };
        const text = encoder2.encode(`sh: internal error: ${e?.message ?? e}
`);
        if (typeof req.stdio[2] === "number") {
          try {
            k.write(req.stdio[2], text);
          } catch {}
        }
        return { status: 134, stdout: new Uint8Array(0), stderr: req.stdio[2] === "memory" ? text : new Uint8Array(0), timedOut, signal };
      }
      const out = (which) => {
        const len = sh.sh_out_len(which);
        return len ? new Uint8Array(sh.memory.buffer, sh.sh_out_ptr(which), len).slice() : new Uint8Array(0);
      };
      const result = { status, stdout: out(0), stderr: out(1), timedOut, signal };
      sh.sh_free(p, size);
      return result;
    }
    return { run };
  }
  function shellArgv(file, args) {
    const slash = file.lastIndexOf("/");
    const base = file.slice(slash + 1);
    const conventional = slash < 0 || /^\/(usr\/(local\/)?)?bin$/.test(file.slice(0, slash));
    if (!conventional)
      return;
    if (SHELL_NAMES.includes(base) || SHELL_PROGRAMS.has(base))
      return [base, ...args];
    return;
  }

  // runtime/src/node/process.ts
  var SIGNALS = {
    SIGHUP: 1,
    SIGINT: 2,
    SIGQUIT: 3,
    SIGILL: 4,
    SIGTRAP: 5,
    SIGABRT: 6,
    SIGBUS: 7,
    SIGFPE: 8,
    SIGKILL: 9,
    SIGUSR1: 10,
    SIGSEGV: 11,
    SIGUSR2: 12,
    SIGPIPE: 13,
    SIGALRM: 14,
    SIGTERM: 15,
    SIGCHLD: 17,
    SIGCONT: 18,
    SIGSTOP: 19,
    SIGTSTP: 20,
    SIGTTIN: 21,
    SIGTTOU: 22,
    SIGWINCH: 28
  };
  var SIGNAL_NAMES = Object.fromEntries(Object.entries(SIGNALS).map(([k, v]) => [v, k]));
  var FATAL = new Set([1, 2, 3, 6, 13, 14, 15, 10, 12]);
  var SIGWINCH = 28;
  var BRKINT = 2;
  var INPCK = 16;
  var ISTRIP = 32;
  var ICRNL = 256;
  var IXON = 1024;
  var CS8 = 48;
  var ISIG = 1;
  var ICANON = 2;
  var ECHO = 8;
  var IEXTEN = 32768;
  var CC = 16;
  var VTIME = 5;
  var VMIN = 6;
  var encoder2 = new TextEncoder;
  function createProcess(rt, loop, end) {
    const kernel = rt.kernel;
    const isTty = (fd) => {
      try {
        return kernel.isatty(fd);
      } catch {
        return false;
      }
    };
    const cooked = new Map;
    function setRawMode(fd, raw) {
      const saved = cooked.get(fd);
      if (!raw) {
        if (saved)
          kernel.ttySetattr(fd, saved);
        cooked.delete(fd);
        return;
      }
      const termios = kernel.ttyGetattr(fd);
      if (!saved)
        cooked.set(fd, termios.slice());
      const view = new DataView(termios.buffer);
      view.setUint32(0, view.getUint32(0, true) & ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON), true);
      view.setUint32(8, view.getUint32(8, true) | CS8, true);
      view.setUint32(12, view.getUint32(12, true) & ~(ECHO | ICANON | IEXTEN | ISIG), true);
      termios[CC + VMIN] = 1;
      termios[CC + VTIME] = 0;
      kernel.ttySetattr(fd, termios);
    }
    function finish(code) {
      for (const [fd, termios] of cooked) {
        try {
          kernel.ttySetattr(fd, termios);
        } catch {}
      }
      cooked.clear();
      return end(code);
    }
    const terminals = [];
    function asTerminalOutput(s, fd) {
      let size = { cols: 80, rows: 24 };
      const refresh = () => {
        try {
          const now = kernel.ttyWinsize(fd);
          const changed = now.cols !== size.cols || now.rows !== size.rows;
          size = now;
          return changed;
        } catch {
          return false;
        }
      };
      refresh();
      s.isTTY = true;
      s._type = "tty";
      Object.defineProperties(s, {
        columns: { get: () => size.cols, enumerable: true, configurable: true },
        rows: { get: () => size.rows, enumerable: true, configurable: true }
      });
      s.getWindowSize = () => [size.cols, size.rows];
      s.getColorDepth = (env = proc.env) => env.COLORTERM === "truecolor" || env.COLORTERM === "24bit" ? 24 : /256/.test(env.TERM ?? "") ? 8 : 4;
      s.hasColors = (count = 16, env) => (typeof count === "number" ? count : 16) <= 2 ** s.getColorDepth(typeof count === "object" && count ? count : env);
      for (const name of ["cursorTo", "moveCursor", "clearLine", "clearScreenDown"])
        s[name] = (...args) => rt.require("readline")[name](s, ...args);
      terminals.push({ stream: s, refresh });
    }
    const proc = {};
    rt.process = proc;
    let cwd;
    let exiting = false;
    let mainPending = true;
    const startMs = performance.now();
    const version = rt.config.version;
    function writeFd(fd, text) {
      const bytes = encoder2.encode(text);
      let off = 0;
      try {
        while (off < bytes.length)
          off += kernel.write(fd, off ? bytes.subarray(off) : bytes);
      } catch {}
    }
    function exit(code) {
      if (code !== undefined)
        proc.exitCode = code;
      if (!exiting) {
        exiting = true;
        proc._exiting = true;
        let c = +(proc.exitCode ?? 0) | 0;
        try {
          proc.emit("exit", c);
        } catch (e) {
          writeFd(2, `${describe(e)}
`);
          c = c || 1;
        }
        c = +(proc.exitCode ?? c) | 0;
        finish(c);
      }
      finish(+(proc.exitCode ?? 0) | 0);
    }
    function describe(e) {
      if (e && typeof e === "object" && typeof e.stack === "string") {
        const err = e;
        let s = err.stack;
        if (err.message && !s.includes(err.message))
          s = `${err.name}: ${err.message}
${s}`;
        const extra = Object.keys(err).filter((k) => k !== "stack" && k !== "message");
        if (extra.length) {
          try {
            const fields = extra.map((k) => `  ${k}: ${rt.require("util").inspect(err[k], { depth: 1 })}`);
            s += ` {
${fields.join(`,
`)}
}`;
          } catch {}
        }
        if (err.cause !== undefined)
          s += `
  [cause]: ${describe(err.cause)}`;
        return s;
      }
      try {
        return rt.require("util").inspect(e);
      } catch {
        return String(e);
      }
    }
    let captureCallback = null;
    function uncaught(error, origin = "uncaughtException") {
      if (exiting)
        return;
      if (captureCallback) {
        captureCallback(error);
        return;
      }
      try {
        proc.emit("uncaughtExceptionMonitor", error, origin);
        if (proc.listenerCount("uncaughtException") > 0) {
          proc.emit("uncaughtException", error, origin);
          return;
        }
      } catch (e) {
        error = e;
      }
      writeFd(2, `${origin === "unhandledRejection" && !(error instanceof Error) ? "Uncaught " : ""}${describe(error)}

Node.js ${version}
`);
      proc.exitCode = proc.exitCode || 1;
      exit(proc.exitCode === 0 ? 1 : proc.exitCode);
    }
    function unhandledRejection(reason, promise) {
      if (exiting)
        return;
      if (proc.listenerCount("unhandledRejection") > 0) {
        loop.call(() => proc.emit("unhandledRejection", reason, promise));
        return;
      }
      if (!(reason instanceof Error)) {
        const e = new Error(`This error originated either by throwing inside of an async function without a catch block, or by rejecting a promise which was not handled with .catch(). The promise rejected with the reason "${safeString(reason)}".`);
        e.name = "UnhandledPromiseRejection";
        e.code = "ERR_UNHANDLED_REJECTION";
        uncaught(e, "unhandledRejection");
      } else
        uncaught(reason, "unhandledRejection");
    }
    function safeString(v) {
      try {
        return rt.require("util").inspect(v);
      } catch {
        return String(v);
      }
    }
    function signal(sig) {
      if (sig === SIGWINCH) {
        for (const t of terminals)
          if (t.refresh())
            loop.call(() => t.stream.emit("resize"));
      }
      const name = SIGNAL_NAMES[sig];
      if (name && proc.listenerCount(name) > 0) {
        loop.call(() => proc.emit(name, name, sig));
        return;
      }
      if (FATAL.has(sig)) {
        exiting = true;
        finish(128 + sig);
      }
    }
    proc.title = "node";
    proc.version = version;
    proc.versions = {
      node: version.slice(1),
      v8: "13.6.233.10-node.28",
      uv: "1.51.0",
      zlib: "1.3.1",
      brotli: "1.1.0",
      ares: "1.34.5",
      modules: "137",
      nghttp2: "1.66.0",
      napi: "10",
      llhttp: "9.3.0",
      openssl: "3.5.2",
      unicode: "16.0",
      bat: "0.1.0"
    };
    proc.arch = "wasm32";
    proc.platform = "linux";
    proc.release = { name: "node", sourceUrl: "", headersUrl: "", lts: "Krypton" };
    proc.config = { target_defaults: {}, variables: { napi_build_version: "10", node_shared: false } };
    proc.features = { inspector: false, debug: false, uv: true, ipv6: false, tls_alpn: false, tls_sni: false, tls_ocsp: false, tls: false, typescript: "strip", require_module: true };
    proc.execPath = rt.config.execPath;
    proc.execArgv = [];
    proc.argv = ["node"];
    proc.argv0 = "node";
    proc.env = {};
    proc.pid = 0;
    proc.ppid = 0;
    proc.exitCode = undefined;
    proc.allowedNodeEnvironmentFlags = new Set;
    proc.report = { getReport: () => ({ header: { glibcVersionRuntime: "2.39" }, sharedObjects: [] }), writeReport: () => "" };
    proc.noDeprecation = false;
    proc.throwDeprecation = false;
    proc.traceDeprecation = false;
    proc.sourceMapsEnabled = false;
    proc.connected = false;
    proc.cwd = () => cwd ??= kernel.getcwd() || "/";
    proc.chdir = (dir) => {
      try {
        kernel.chdir(String(dir));
      } catch (e) {
        throw rt.require("fs")[Symbol.for("bat.fs.error")]?.(e, "chdir", dir) ?? e;
      }
      cwd = undefined;
    };
    proc.umask = (mask) => mask === undefined ? 18 : 18;
    proc.getuid = proc.geteuid = () => 1000;
    proc.getgid = proc.getegid = () => 1000;
    proc.getgroups = () => [1000];
    proc.uptime = () => (performance.now() - startMs) / 1000;
    const hrtime = (prev) => {
      const t = performance.timeOrigin + performance.now();
      let s = Math.floor(t / 1000);
      let ns = Math.floor((t - s * 1000) * 1e6);
      if (prev) {
        s -= prev[0];
        ns -= prev[1];
        if (ns < 0) {
          s--;
          ns += 1e9;
        }
      }
      return [s, ns];
    };
    hrtime.bigint = () => BigInt(Math.round((performance.timeOrigin + performance.now()) * 1e6));
    proc.hrtime = hrtime;
    proc.memoryUsage = Object.assign(() => {
      const m = performance.memory;
      const heapUsed = m?.usedJSHeapSize ?? 32 << 20;
      const heapTotal = m?.totalJSHeapSize ?? 64 << 20;
      return { rss: heapTotal + (16 << 20), heapTotal, heapUsed, external: 1 << 20, arrayBuffers: 1 << 16 };
    }, { rss: () => (performance.memory?.totalJSHeapSize ?? 64 << 20) + (16 << 20) });
    proc.constrainedMemory = () => 0;
    proc.availableMemory = () => 2 ** 31;
    proc.cpuUsage = (prev) => {
      const user = Math.round((performance.now() - startMs) * 1000);
      return prev ? { user: user - prev.user, system: 0 } : { user, system: 0 };
    };
    proc.resourceUsage = () => ({ userCPUTime: proc.cpuUsage().user, systemCPUTime: 0, maxRSS: 65536, sharedMemorySize: 0, unsharedDataSize: 0, unsharedStackSize: 0, minorPageFault: 0, majorPageFault: 0, swappedOut: 0, fsRead: 0, fsWrite: 0, ipcSent: 0, ipcReceived: 0, signalsCount: 0, voluntaryContextSwitches: 0, involuntaryContextSwitches: 0 });
    proc.nextTick = loop.nextTick;
    proc.exit = exit;
    proc.reallyExit = (code) => finish(code | 0);
    proc.abort = () => finish(134);
    proc.kill = (pid, sig = "SIGTERM") => {
      const n = typeof sig === "number" ? sig : SIGNALS[sig];
      if (n === undefined)
        throw Object.assign(new TypeError(`Unknown signal: ${sig}`), { code: "ERR_UNKNOWN_SIGNAL" });
      if (pid === proc.pid || pid === 0) {
        if (n !== 0)
          loop.nextTick(signal, n);
        return true;
      }
      if (pid < 0) {
        const all = kernel.procList();
        const targets = [-pid];
        for (let i = 0;i < targets.length; i++)
          for (const p of all)
            if (p.ppid === targets[i] && p.state !== 2)
              targets.push(p.pid);
        let found = false;
        for (const target of targets) {
          try {
            kernel.kill(target, n);
            found = true;
          } catch {}
        }
        if (!found)
          throw Object.assign(new Error("kill ESRCH"), { code: "ESRCH", errno: -3, syscall: "kill" });
        return true;
      }
      try {
        kernel.kill(pid, n);
      } catch (e) {
        throw Object.assign(new Error(`kill ${e.code}`), { code: e.code, errno: -e.errno, syscall: "kill" });
      }
      return true;
    };
    proc.emitWarning = (warning, type, code) => {
      let detail;
      if (type && typeof type === "object") {
        detail = type.detail;
        code = type.code;
        type = type.type;
      }
      if (typeof warning === "string") {
        const w = new Error(warning);
        w.name = String(type || "Warning");
        if (code)
          w.code = code;
        if (detail)
          w.detail = detail;
        warning = w;
      }
      if (warning.name === "DeprecationWarning") {
        if (proc.noDeprecation)
          return;
        if (proc.throwDeprecation)
          throw warning;
      }
      loop.nextTick(() => {
        if (proc.listenerCount("warning") > 0)
          proc.emit("warning", warning);
        if (proc.env.NODE_NO_WARNINGS === "1")
          return;
        if (warning.name === "ExperimentalWarning")
          return;
        writeFd(2, `(node:${proc.pid}) ${warning.code ? `[${warning.code}] ` : ""}${warning.name}: ${warning.message}
`);
      });
    };
    proc.binding = (name) => {
      if (name === "natives")
        return {};
      if (name === "constants")
        return rt.require("constants");
      if (name === "util")
        return rt.require("util").types;
      throw new Error(`No such module: ${name}`);
    };
    proc.setUncaughtExceptionCaptureCallback = (fn) => {
      captureCallback = fn;
    };
    proc.hasUncaughtExceptionCaptureCallback = () => captureCallback !== null;
    proc.setSourceMapsEnabled = (v) => {
      proc.sourceMapsEnabled = !!v;
    };
    proc.getBuiltinModule = (id) => {
      try {
        return rt.require(id);
      } catch {
        return;
      }
    };
    proc.getActiveResourcesInfo = () => [];
    proc._getActiveHandles = () => [];
    proc._getActiveRequests = () => [];
    proc.openStdin = () => {
      proc.stdin.resume();
      return proc.stdin;
    };
    proc.loadEnvFile = (path = ".env") => {
      const text = rt.require("fs").readFileSync(path, "utf8");
      for (const [k, v] of Object.entries(rt.require("util").parseEnv(text)))
        if (!(k in proc.env))
          proc.env[k] = v;
    };
    proc._rawDebug = (...args) => writeFd(2, `${rt.require("util").format(...args)}
`);
    proc._tickCallback = () => loop.drainTicks();
    const EventEmitter = rt.require("events");
    Object.setPrototypeOf(proc, EventEmitter.prototype);
    EventEmitter.call(proc);
    proc.setMaxListeners(0);
    const streams = {};
    function outStream(fd) {
      const { Writable } = rt.require("stream");
      const s = new Writable({
        decodeStrings: false,
        write(chunk, encoding, cb) {
          try {
            const bytes = typeof chunk === "string" ? encoding && encoding !== "utf8" && encoding !== "utf-8" ? rt.require("buffer").Buffer.from(chunk, encoding) : encoder2.encode(chunk) : chunk;
            let off = 0;
            while (off < bytes.length)
              off += kernel.write(fd, off ? bytes.subarray(off) : bytes);
            cb();
          } catch (e) {
            cb(Object.assign(new Error(`write ${e.code ?? e}`), { code: e.code, errno: -(e.errno ?? 0), syscall: "write" }));
          }
        },
        final(cb) {
          cb();
        },
        destroy(err, cb) {
          cb(err);
        }
      });
      s.fd = fd;
      s._type = "pipe";
      s._isStdio = true;
      s.isTTY = false;
      s.destroySoon = s.destroy;
      s._handle = { fd, setBlocking() {}, getAsyncId: () => 0, ref() {}, unref() {} };
      if (isTty(fd))
        asTerminalOutput(s, fd);
      s.on("error", (e) => {
        if (e?.code !== "EPIPE")
          uncaught(e);
      });
      return s;
    }
    function inStream(fd = 0) {
      const { Readable } = rt.require("stream");
      const Buffer = rt.require("buffer").Buffer;
      let waiting = false;
      const buf = new Uint8Array(65536);
      const stop = () => {
        if (waiting) {
          waiting = false;
          loop.offFd(fd);
          loop.unref();
        }
      };
      const pump = () => {
        while (waiting) {
          let ready;
          try {
            ready = kernel.pollFd(fd);
          } catch {
            ready = POLLHUP;
          }
          if (!(ready & (POLLIN | POLLHUP)))
            return;
          const n = kernel.readRaw(fd, buf);
          if (n > 0) {
            if (!s.push(Buffer.from(buf.slice(0, n))))
              stop();
          } else if (n === 0 || n !== -11) {
            stop();
            s.push(null);
          } else
            return;
        }
      };
      const s = new Readable({
        highWaterMark: 65536,
        read() {
          if (!waiting) {
            waiting = true;
            loop.ref();
            loop.onFd(fd, POLLIN | POLLHUP, pump);
          }
        },
        destroy(err, cb) {
          stop();
          cb(err);
        }
      });
      s.fd = fd;
      s.isTTY = isTty(fd);
      s.isRaw = false;
      s.setRawMode = (raw) => {
        if (s.isTTY) {
          setRawMode(fd, !!raw);
          s.isRaw = !!raw;
        }
        return s;
      };
      s.on("pause", stop);
      s.ref = () => s;
      s.unref = () => {
        stop();
        return s;
      };
      return s;
    }
    for (const [name, fd] of [["stdout", 1], ["stderr", 2]]) {
      Object.defineProperty(proc, name, {
        configurable: true,
        enumerable: true,
        get: () => streams[fd] ??= outStream(fd),
        set(v) {
          Object.defineProperty(proc, name, { value: v, writable: true, configurable: true, enumerable: true });
          streams[fd] = v;
        }
      });
    }
    Object.defineProperty(proc, "stdin", { configurable: true, enumerable: true, get: () => streams[0] ??= inStream() });
    return {
      process: proc,
      adopt(pid, info, argv, execArgv) {
        proc.pid = pid;
        proc.ppid = kernel.getppid();
        proc.env = info.env;
        proc.argv = argv;
        proc.argv0 = info.argv[0] ?? "node";
        proc.execArgv = execArgv;
        proc.title = "node";
        if (info.env.NODE_NO_WARNINGS === "1")
          proc.noDeprecation = true;
        cwd = undefined;
      },
      exit,
      uncaught,
      unhandledRejection,
      rejectionHandled(promise) {
        if (proc.listenerCount("rejectionHandled") > 0)
          proc.emit("rejectionHandled", promise);
      },
      signal,
      beforeExit() {
        if (!exiting) {
          try {
            proc.emit("beforeExit", +(proc.exitCode ?? 0) | 0);
          } catch (e) {
            uncaught(e);
          }
        }
      },
      mainSettled() {
        mainPending = false;
      },
      drained() {
        if (mainPending && proc.exitCode === undefined) {
          writeFd(2, `Warning: Detected unsettled top-level await
`);
          exit(13);
        }
        exit();
      },
      writeFd,
      streamFor: (fd) => streams[fd],
      ttyStream: (fd, direction) => direction === "in" ? inStream(fd) : outStream(fd)
    };
  }

  // runtime/src/node/child_process.ts
  function create2(rt) {
    const k = rt.kernel;
    const loop = rt.loop;
    const EventEmitter = rt.require("events");
    const Buffer = rt.require("buffer").Buffer;
    const proc = rt.process;
    const decoder2 = new TextDecoder;
    let shell;
    const enoent = (file, args, syscall = "spawn") => Object.assign(new Error(`${syscall} ${file} ENOENT`), { errno: -2, code: "ENOENT", syscall: `${syscall} ${file}`, path: file, spawnargs: args });
    const isNode = (file) => file === proc.execPath || file === "node" || file === "nodejs" || file.endsWith("/node");
    function resolveCommand(file, args, env, cwd) {
      if (isNode(file))
        return { exec: "node", argv: ["node", ...args] };
      const shell2 = shellArgv(file, args);
      if (shell2)
        return { exec: SHELL_EXEC, argv: shell2, shell: true };
      const candidates = [];
      if (file.includes("/"))
        candidates.push(file.startsWith("/") ? file : `${cwd}/${file}`);
      else
        for (const dir of (env.PATH ?? "/usr/local/bin:/usr/bin:/bin").split(":"))
          if (dir)
            candidates.push(`${dir.startsWith("/") ? dir : `${cwd}/${dir}`}/${file}`);
      for (const path of candidates) {
        if (k.kindOf(path) !== 0)
          continue;
        let real;
        try {
          real = k.realpath(path);
        } catch {
          continue;
        }
        if (/\.[cm]?js$/.test(real))
          return { exec: real, argv: [file, ...args] };
        let head = "";
        try {
          const fd = k.open(real);
          const buf = new Uint8Array(256);
          const n = k.read(fd, buf, 0);
          k.close(fd);
          head = decoder2.decode(buf.subarray(0, n));
        } catch {
          continue;
        }
        const m = /^#!\s*(\S+)(?:\s+(.*))?/.exec(head.split(`
`, 1)[0]);
        if (m) {
          const interp = m[1].endsWith("/env") ? (m[2] ?? "").trim().split(/\s+/).filter((w) => !w.startsWith("-"))[0] ?? "" : m[1];
          if (isNode(interp) || interp === "bun")
            return { exec: real, argv: [file, ...args] };
          if (SHELL_NAMES.includes(interp.slice(interp.lastIndexOf("/") + 1)))
            return { exec: SHELL_EXEC, argv: ["sh", real, ...args], shell: true };
        }
        return;
      }
      return;
    }
    function normalizeStdio(stdio) {
      const list = typeof stdio === "string" ? [stdio, stdio, stdio] : Array.isArray(stdio) ? stdio.slice() : ["pipe", "pipe", "pipe"];
      let ipc = false;
      const specs = [0, 1, 2].map((i) => {
        const s = list[i] ?? "pipe";
        if (s === "pipe" || s === "overlapped")
          return "pipe";
        if (s === "ignore")
          return "null";
        if (s === "inherit")
          return "inherit";
        if (typeof s === "number")
          return s === i ? "inherit" : { fd: s };
        if (s && typeof s.fd === "number")
          return s.fd === i ? "inherit" : { fd: s.fd };
        if (s && typeof s._handle?.fd === "number")
          return { fd: s._handle.fd };
        return "pipe";
      });
      if (list.includes("ipc"))
        ipc = true;
      return { specs, ipc };
    }
    function envOf(options, extra) {
      const out = {};
      for (const [key, v] of Object.entries(options?.env ?? proc.env))
        if (v !== undefined)
          out[key] = String(v);
      return extra ? { ...out, ...extra } : out;
    }
    const cwdOf = (options) => {
      const c = options?.cwd;
      if (c === undefined || c === null)
        return proc.cwd();
      const s = c instanceof URL ? decodeURIComponent(c.pathname) : String(c);
      return s.startsWith("/") ? s : `${proc.cwd()}/${s}`;
    };
    function attachIpc(target, fd, onClose) {
      const { Buffer: B } = rt.require("buffer");
      let pending2 = "";
      const buf = new Uint8Array(65536);
      const utf8 = new TextDecoder;
      let open = true;
      k.setNonblock(fd, true);
      let refed = false;
      const ref = () => {
        if (!refed && open) {
          refed = true;
          loop.ref();
        }
      };
      const unref = () => {
        if (refed) {
          refed = false;
          loop.unref();
        }
      };
      const close = () => {
        if (!open)
          return;
        open = false;
        loop.offFd(fd);
        unref();
        try {
          k.close(fd);
        } catch {}
        target.connected = false;
        onClose();
        target.emit("disconnect");
      };
      loop.onFd(fd, POLLIN | POLLHUP, () => {
        for (;; ) {
          const n = k.readRaw(fd, buf);
          if (n === -11)
            return;
          if (n <= 0)
            return close();
          pending2 += utf8.decode(buf.subarray(0, n), { stream: true });
          let i;
          while ((i = pending2.indexOf(`
`)) >= 0) {
            const line = pending2.slice(0, i);
            pending2 = pending2.slice(i + 1);
            let message;
            try {
              message = JSON.parse(line);
            } catch {
              continue;
            }
            target.emit("message", message, undefined);
          }
        }
      });
      target.connected = true;
      target.send = (message, _handle, options, cb) => {
        const done = [_handle, options, cb].find((x) => typeof x === "function");
        if (!open) {
          const e = Object.assign(new Error("Channel closed"), { code: "ERR_IPC_CHANNEL_CLOSED" });
          if (done)
            loop.nextTick(done, e);
          else
            target.emit("error", e);
          return false;
        }
        const bytes = B.from(`${JSON.stringify(message)}
`);
        k.setNonblock(fd, false);
        try {
          let off = 0;
          while (off < bytes.length)
            off += k.write(fd, off ? bytes.subarray(off) : bytes);
        } catch (e) {
          close();
          if (done)
            loop.nextTick(done, e);
          return false;
        } finally {
          if (open)
            k.setNonblock(fd, true);
        }
        if (done)
          loop.nextTick(done, null);
        return true;
      };
      target.disconnect = close;
      return { ref, unref, close };
    }

    class ChildProcess extends EventEmitter {
      pid;
      stdin = null;
      stdout = null;
      stderr = null;
      stdio = [null, null, null];
      exitCode = null;
      signalCode = null;
      killed = false;
      connected = false;
      spawnfile = "";
      spawnargs = [];
      #refed = false;
      #open = 0;
      #exited = false;
      _spawn(file, args, options) {
        this.spawnfile = file;
        this.spawnargs = [file, ...args];
        const env = envOf(options);
        const cwd = cwdOf(options);
        const { specs, ipc } = normalizeStdio(options?.stdio);
        const command = resolveCommand(file, args, env, cwd);
        if (!command || k.kindOf(cwd) !== 1) {
          loop.nextTick(() => this.emit("error", enoent(file, args)));
          return this;
        }
        let listener = -1;
        const childEnv = { ...env, ...command.env };
        if (ipc) {
          listener = k.listen(0);
          childEnv.NODE_CHANNEL_FD = String(k.sockPorts(listener).local);
          childEnv.NODE_CHANNEL_SERIALIZATION_MODE = "json";
        } else
          delete childEnv.NODE_CHANNEL_FD;
        let r;
        try {
          r = k.spawn({ exec: command.exec, argv: command.argv, env: childEnv, cwd, stdio: specs });
        } catch (e) {
          if (listener >= 0)
            k.close(listener);
          loop.nextTick(() => this.emit("error", Object.assign(new Error(`spawn ${file} ${e.code}`), { code: e.code, errno: -e.errno, syscall: `spawn ${file}`, path: file, spawnargs: args })));
          return this;
        }
        this.pid = r.pid;
        this.#refed = true;
        loop.ref();
        const { Readable, Writable } = rt.require("stream");
        if (r.stdio[0] >= 0) {
          const fd = r.stdio[0];
          k.setNonblock(fd, true);
          let closed = false;
          const closeFd = () => {
            if (!closed) {
              closed = true;
              loop.offFd(fd);
              try {
                k.close(fd);
              } catch {}
            }
          };
          this.stdin = new Writable({
            write(chunk, encoding, cb) {
              const bytes = typeof chunk === "string" ? Buffer.from(chunk, encoding) : chunk;
              let off = 0;
              const pump = () => {
                while (off < bytes.length) {
                  const n = k.writeRaw(fd, off ? bytes.subarray(off) : bytes);
                  if (n === -11) {
                    loop.onFd(fd, POLLOUT | 8 | POLLHUP, () => {
                      loop.offFd(fd);
                      pump();
                    });
                    return;
                  }
                  if (n < 0)
                    return cb(Object.assign(new Error("write EPIPE"), { code: "EPIPE", errno: -32, syscall: "write" }));
                  off += n;
                }
                cb();
              };
              pump();
            },
            final(cb) {
              closeFd();
              cb();
            },
            destroy(err, cb) {
              closeFd();
              cb(err);
            }
          });
          this.stdin.on("error", () => {});
        }
        const reader = (fd) => {
          k.setNonblock(fd, true);
          const buf = new Uint8Array(65536);
          let reading = false;
          let ended = false;
          this.#open++;
          const end = () => {
            if (ended)
              return;
            ended = true;
            loop.offFd(fd);
            try {
              k.close(fd);
            } catch {}
            this.#open--;
            this.#maybeClose();
          };
          const s = new Readable({
            highWaterMark: 65536,
            read() {
              if (reading || ended)
                return;
              reading = true;
              loop.onFd(fd, POLLIN | POLLHUP, () => {
                for (;; ) {
                  const n = k.readRaw(fd, buf);
                  if (n === -11)
                    return;
                  if (n <= 0) {
                    end();
                    s.push(null);
                    return;
                  }
                  if (!s.push(Buffer.from(buf.slice(0, n)))) {
                    reading = false;
                    loop.offFd(fd);
                    return;
                  }
                }
              });
            },
            destroy(err, cb) {
              end();
              cb(err);
            }
          });
          return s;
        };
        if (r.stdio[1] >= 0)
          this.stdout = reader(r.stdio[1]);
        if (r.stdio[2] >= 0)
          this.stderr = reader(r.stdio[2]);
        this.stdio = [this.stdin, this.stdout, this.stderr];
        loop.nextTick(() => {
          for (const s of [this.stdout, this.stderr])
            if (s && s.listenerCount("data") === 0 && s.listenerCount("readable") === 0 && !s.readableFlowing && s._readableState.pipes.length === 0)
              s._bat_idle = true;
        });
        let channel;
        if (listener >= 0) {
          k.setNonblock(listener, true);
          this.#open++;
          const queued = [];
          this.connected = true;
          this.send = (...args2) => {
            queued.push(args2);
            return true;
          };
          this.disconnect = () => {
            this.connected = false;
          };
          loop.onFd(listener, POLLIN, () => {
            const fd = k.accept(listener);
            if (fd === undefined)
              return;
            loop.offFd(listener);
            k.close(listener);
            listener = -1;
            const wasConnected = this.connected;
            channel = attachIpc(this, fd, () => {
              this.#open--;
              this.#maybeClose();
            });
            for (const args2 of queued)
              this.send(...args2);
            if (!wasConnected)
              this.disconnect();
          });
        }
        loop.onChild(r.pid, (status) => {
          try {
            k.waitpid(r.pid, true);
          } catch {}
          if (listener >= 0) {
            loop.offFd(listener);
            k.close(listener);
            this.#open--;
          }
          this.#exited = true;
          if (status > 128 && (this.killed || SIGNAL_NAMES[status - 128] === "SIGKILL"))
            this.signalCode = SIGNAL_NAMES[status - 128] ?? null;
          else
            this.exitCode = status;
          if (this.#refed) {
            this.#refed = false;
            loop.unref();
          }
          this.stdin?.destroy();
          this.emit("exit", this.exitCode, this.signalCode);
          for (const s of [this.stdout, this.stderr])
            if (s && s._bat_idle && !s.readableFlowing && s.listenerCount("data") === 0 && s.listenerCount("readable") === 0)
              s.resume();
          this.#maybeClose();
        });
        loop.nextTick(() => this.emit("spawn"));
        if (options?.signal) {
          const onAbort = () => {
            this.kill(options.killSignal ?? "SIGTERM");
            this.emit("error", Object.assign(new Error("The operation was aborted"), { name: "AbortError", code: "ABORT_ERR", cause: options.signal.reason }));
          };
          if (options.signal.aborted)
            loop.nextTick(onAbort);
          else
            options.signal.addEventListener("abort", onAbort, { once: true });
        }
        if (options?.timeout > 0) {
          const t = loop.setTimeout(() => this.kill(options.killSignal ?? "SIGTERM"), options.timeout);
          t.unref();
          this.once("exit", () => rt.loop.clearTimeout(t));
        }
        return this;
      }
      #maybeClose() {
        if (this.#exited && this.#open <= 0) {
          this.#open = 1 << 30;
          loop.nextTick(() => this.emit("close", this.exitCode, this.signalCode));
        }
      }
      kill(sig = "SIGTERM") {
        const n = typeof sig === "number" ? sig : SIGNALS[sig];
        if (n === undefined)
          throw Object.assign(new TypeError(`Unknown signal: ${sig}`), { code: "ERR_UNKNOWN_SIGNAL" });
        if (this.pid === undefined || this.#exited)
          return false;
        try {
          k.kill(this.pid, n);
        } catch {
          return false;
        }
        if (n !== 0)
          this.killed = true;
        return true;
      }
      ref() {
        if (!this.#refed && !this.#exited && this.pid !== undefined) {
          this.#refed = true;
          loop.ref();
        }
      }
      unref() {
        if (this.#refed) {
          this.#refed = false;
          loop.unref();
        }
      }
      [Symbol.dispose]() {
        this.kill();
      }
    }
    function normalizeSpawn(file, args, options) {
      if (typeof file !== "string" || !file)
        throw Object.assign(new TypeError(`The "file" argument must be of type string. Received ${typeof file}`), { code: "ERR_INVALID_ARG_TYPE" });
      if (!Array.isArray(args)) {
        options = args;
        args = [];
      }
      options = options ?? {};
      if (options.shell) {
        const line = [file, ...args].join(" ");
        return ["/bin/sh", ["-c", line], { ...options, shell: false }];
      }
      return [file, args.map(String), options];
    }
    function spawn(file, args, options) {
      const [f, a, o] = normalizeSpawn(file, args, options);
      return new ChildProcess()._spawn(f, a, o);
    }
    function spawnSync(file, args, options) {
      const [f, a, o] = normalizeSpawn(file, args, options);
      const env = envOf(o);
      const cwd = cwdOf(o);
      const result = { pid: 0, output: [null, null, null], stdout: null, stderr: null, status: null, signal: null };
      const encode = (bytes) => o.encoding && o.encoding !== "buffer" ? Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString(o.encoding) : Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      const command = resolveCommand(f, a, env, cwd);
      if (!command || k.kindOf(cwd) !== 1) {
        result.error = enoent(f, a, "spawnSync");
        result.stdout = encode(new Uint8Array(0));
        result.stderr = encode(new Uint8Array(0));
        result.output = [null, result.stdout, result.stderr];
        return result;
      }
      const { specs } = normalizeStdio(o.stdio);
      const childEnv = { ...env, ...command.env };
      delete childEnv.NODE_CHANNEL_FD;
      const input = o.input !== undefined && o.input !== null ? typeof o.input === "string" ? Buffer.from(o.input, o.encoding && o.encoding !== "buffer" ? o.encoding : "utf8") : new Uint8Array(o.input.buffer ?? o.input, o.input.byteOffset ?? 0, o.input.byteLength) : undefined;
      if (command.shell) {
        const io = (i) => {
          const spec = specs[i];
          if (spec === "pipe")
            return i === 0 && !input?.length ? "null" : "memory";
          return spec === "null" ? "null" : spec === "inherit" ? i : spec.fd;
        };
        const run = (shell ??= createShell(rt)).run({ argv: command.argv, env: childEnv, cwd, stdio: [io(0), io(1), io(2)], input, timeoutMs: o.timeout });
        result.pid = k.getpid();
        if (specs[1] === "pipe")
          result.stdout = encode(run.stdout);
        if (specs[2] === "pipe")
          result.stderr = encode(run.stderr);
        result.output = [null, result.stdout, result.stderr];
        if (run.timedOut) {
          result.error = Object.assign(new Error(`spawnSync ${f} ETIMEDOUT`), { code: "ETIMEDOUT", errno: -110, syscall: `spawnSync ${f}`, path: f, spawnargs: a });
          result.signal = typeof o.killSignal === "string" ? o.killSignal : "SIGTERM";
        } else if (run.stdout.length + run.stderr.length > (o.maxBuffer ?? Infinity)) {
          result.error = Object.assign(new Error(`spawnSync ${f} ENOBUFS`), { code: "ENOBUFS", errno: -105, syscall: `spawnSync ${f}` });
        } else
          result.status = run.status;
        return result;
      }
      let r;
      try {
        r = k.spawn({ exec: command.exec, argv: command.argv, env: childEnv, cwd, stdio: specs });
      } catch (e) {
        result.error = Object.assign(new Error(`spawnSync ${f} ${e.code}`), { code: e.code, errno: -e.errno, syscall: `spawnSync ${f}`, path: f, spawnargs: a });
        return result;
      }
      result.pid = r.pid;
      const deadline = o.timeout > 0 ? performance.now() + o.timeout : Infinity;
      const maxBuffer = o.maxBuffer ?? 1024 * 1024 * 1024;
      const chunks = [[], [], []];
      const open = new Set;
      for (const i of [1, 2])
        if (r.stdio[i] >= 0)
          open.add(i);
      let stdin = r.stdio[0];
      let inOff = 0;
      if (stdin >= 0) {
        if (!input || input.length === 0) {
          k.close(stdin);
          stdin = -1;
        } else
          k.setNonblock(stdin, true);
      }
      const buf = new Uint8Array(65536);
      let total = 0;
      let timedOut = false;
      while (open.size || stdin >= 0) {
        const fds = [];
        const which = [];
        for (const i of open) {
          fds.push({ fd: r.stdio[i], events: POLLIN | POLLHUP });
          which.push(i);
        }
        if (stdin >= 0) {
          fds.push({ fd: stdin, events: POLLOUT | 8 | POLLHUP });
          which.push(0);
        }
        const left = deadline - performance.now();
        if (left <= 0) {
          timedOut = true;
          break;
        }
        const revents = k.poll(fds, deadline === Infinity ? -1 : Math.ceil(left));
        for (let j = 0;j < fds.length; j++) {
          if (!revents[j])
            continue;
          const i = which[j];
          if (i === 0) {
            const n = k.writeRaw(stdin, input.subarray(inOff));
            if (n >= 0)
              inOff += n;
            if (n < 0 ? n !== -11 : inOff >= input.length) {
              k.close(stdin);
              stdin = -1;
            }
          } else {
            const n = k.read(fds[j].fd, buf);
            if (n === 0) {
              k.close(fds[j].fd);
              open.delete(i);
            } else {
              chunks[i].push(buf.slice(0, n));
              total += n;
              if (total > maxBuffer) {
                result.error = Object.assign(new Error(`spawnSync ${f} ENOBUFS`), { code: "ENOBUFS", errno: -105, syscall: `spawnSync ${f}` });
                open.clear();
                timedOut = true;
                break;
              }
            }
          }
        }
      }
      if (timedOut) {
        try {
          k.kill(r.pid, SIGNALS[o.killSignal] ?? 15);
        } catch {}
        for (const i of open)
          k.close(r.stdio[i]);
        if (stdin >= 0)
          k.close(stdin);
        result.error ??= Object.assign(new Error(`spawnSync ${f} ETIMEDOUT`), { code: "ETIMEDOUT", errno: -110, syscall: `spawnSync ${f}`, path: f, spawnargs: a });
      }
      let status;
      if (deadline === Infinity || !timedOut)
        status = k.waitpid(r.pid);
      else {
        const until = performance.now() + 2000;
        while ((status = k.waitpid(r.pid, true)) === undefined && performance.now() < until)
          k.poll([], 5);
        if (status === undefined) {
          try {
            k.kill(r.pid, 9);
          } catch {}
          status = k.waitpid(r.pid);
        }
      }
      const join = (list) => {
        const out = new Uint8Array(list.reduce((n, c) => n + c.length, 0));
        let off = 0;
        for (const c of list) {
          out.set(c, off);
          off += c.length;
        }
        return out;
      };
      if (r.stdio[1] >= 0)
        result.stdout = encode(join(chunks[1]));
      if (r.stdio[2] >= 0)
        result.stderr = encode(join(chunks[2]));
      result.output = [null, result.stdout, result.stderr];
      if (status !== undefined && status > 128 && timedOut)
        result.signal = SIGNAL_NAMES[status - 128] ?? null;
      else
        result.status = status ?? null;
      return result;
    }
    function execFile(file, ...rest) {
      const cb = typeof rest[rest.length - 1] === "function" ? rest.pop() : undefined;
      const args = Array.isArray(rest[0]) ? rest.shift() : [];
      const options = rest[0] ?? {};
      const encoding = options.encoding === undefined ? "utf8" : options.encoding;
      const child = spawn(file, args, { ...options, stdio: ["pipe", "pipe", "pipe"] });
      const out = [];
      const err = [];
      let done = false;
      let size = 0;
      const maxBuffer = options.maxBuffer ?? 1024 * 1024;
      const text = (list) => encoding && encoding !== "buffer" ? Buffer.concat(list).toString(encoding) : Buffer.concat(list);
      const finish = (error) => {
        if (done)
          return;
        done = true;
        if (error) {
          error.stdout = text(out);
          error.stderr = text(err);
          error.cmd = [file, ...args].join(" ");
        }
        cb?.(error, text(out), text(err));
      };
      const collect = (list) => (chunk) => {
        list.push(chunk);
        size += chunk.length;
        if (size > maxBuffer) {
          child.kill();
          finish(Object.assign(new RangeError("stdout maxBuffer length exceeded"), { code: "ERR_CHILD_PROCESS_STDIO_MAXBUFFER" }));
        }
      };
      child.stdout?.on("data", collect(out));
      child.stderr?.on("data", collect(err));
      child.on("error", finish);
      child.on("close", (code, signal) => {
        if (code === 0 && signal === null)
          return finish(null);
        const e = new Error(`Command failed: ${[file, ...args].join(" ")}
${text(err)}`);
        e.code = code;
        e.killed = child.killed;
        e.signal = signal;
        finish(e);
      });
      if (options.input !== undefined)
        child.stdin?.end(options.input);
      else
        child.stdin?.end();
      return child;
    }
    function exec(command, ...rest) {
      const cb = typeof rest[rest.length - 1] === "function" ? rest.pop() : undefined;
      return execFile("/bin/sh", ["-c", command], { ...rest[0], shell: false }, cb);
    }
    const promisifyCustom = Symbol.for("nodejs.util.promisify.custom");
    for (const fn of [exec, execFile]) {
      fn[promisifyCustom] = (...args) => {
        let child;
        const promise = new Promise((resolve, reject) => {
          child = fn(...args, (e, stdout, stderr) => e ? reject(e) : resolve({ stdout, stderr }));
        });
        promise.child = child;
        return promise;
      };
    }
    function checkSync(r, file, args, options) {
      if (r.error)
        throw r.error;
      if (r.status !== 0) {
        const stderr = r.stderr ? String(r.stderr) : "";
        const e = new Error(`Command failed: ${[file, ...args].join(" ")}${stderr ? `
${stderr}` : ""}`);
        Object.assign(e, r);
        throw e;
      }
      if (r.stderr?.length && (options?.stdio === undefined || options.stdio === "pipe"))
        rt.ctl.writeFd(2, String(r.stderr));
      return r.stdout;
    }
    function execFileSync(file, args, options) {
      if (!Array.isArray(args)) {
        options = args;
        args = [];
      }
      return checkSync(spawnSync(file, args, options), file, args, options);
    }
    function execSync(command, options) {
      return checkSync(spawnSync("/bin/sh", ["-c", command], { ...options, shell: false }), command, [], options);
    }
    function fork(modulePath, args, options) {
      if (!Array.isArray(args)) {
        options = args;
        args = [];
      }
      options = options ?? {};
      const stdio = options.stdio ?? (options.silent ? ["pipe", "pipe", "pipe", "ipc"] : ["inherit", "inherit", "inherit", "ipc"]);
      const file = modulePath instanceof URL ? decodeURIComponent(modulePath.pathname) : String(modulePath);
      return spawn(options.execPath ?? proc.execPath, [...options.execArgv ?? proc.execArgv, file, ...args], { ...options, stdio: Array.isArray(stdio) && !stdio.includes("ipc") ? [...stdio, "ipc"] : stdio });
    }
    if (proc.env.NODE_CHANNEL_FD && !proc.connected) {
      const port = Number(proc.env.NODE_CHANNEL_FD);
      delete proc.env.NODE_CHANNEL_FD;
      try {
        const fd = k.connect(port);
        const channel = attachIpc(proc, fd, () => {});
        proc.channel = { ref: channel.ref, unref: channel.unref };
        const sync = () => proc.listenerCount("message") > 0 || proc.listenerCount("disconnect") > 0 ? channel.ref() : channel.unref();
        proc.on("newListener", () => loop.nextTick(sync));
        proc.on("removeListener", () => loop.nextTick(sync));
      } catch {}
    }
    return { ChildProcess, spawn, spawnSync, exec, execSync, execFile, execFileSync, fork, _forkChild() {} };
  }
  registerBuiltin("child_process", create2);

  // runtime/src/node/fs.ts
  var MESSAGES = {
    ENOENT: "no such file or directory",
    EEXIST: "file already exists",
    ENOTDIR: "not a directory",
    EISDIR: "illegal operation on a directory",
    ENOTEMPTY: "directory not empty",
    EACCES: "permission denied",
    EPERM: "operation not permitted",
    EBADF: "bad file descriptor",
    EINVAL: "invalid argument",
    EXDEV: "cross-device link not permitted",
    ELOOP: "too many symbolic links encountered",
    EMFILE: "too many open files",
    ENAMETOOLONG: "name too long",
    EROFS: "read-only file system",
    ENOSPC: "no space left on device",
    ESPIPE: "invalid seek",
    EPIPE: "broken pipe",
    EAGAIN: "resource temporarily unavailable",
    ENOSYS: "function not implemented",
    ENOMEM: "not enough memory",
    EIO: "i/o error",
    ERANGE: "result too large",
    ENOTSUP: "operation not supported"
  };
  var S_IFMT = 61440;
  var S_IFREG = 32768;
  var S_IFDIR = 16384;
  var S_IFLNK = 40960;
  var S_IFIFO = 4096;
  var S_IFSOCK = 49152;
  var S_IFCHR = 8192;
  var KIND_MODE = [S_IFREG, S_IFDIR, S_IFLNK, S_IFIFO, S_IFSOCK, S_IFCHR];
  var UV_DIRENT = { [K_FILE]: 1, [K_DIR]: 2, [K_SYMLINK]: 3, [K_FIFO]: 4, [K_SOCKET]: 5, [K_CHAR]: 6 };
  var constants = {
    UV_FS_SYMLINK_DIR: 1,
    UV_FS_SYMLINK_JUNCTION: 2,
    O_RDONLY,
    O_WRONLY,
    O_RDWR,
    UV_DIRENT_UNKNOWN: 0,
    UV_DIRENT_FILE: 1,
    UV_DIRENT_DIR: 2,
    UV_DIRENT_LINK: 3,
    UV_DIRENT_FIFO: 4,
    UV_DIRENT_SOCKET: 5,
    UV_DIRENT_CHAR: 6,
    UV_DIRENT_BLOCK: 7,
    EXTENSIONLESS_FORMAT_JAVASCRIPT: 0,
    EXTENSIONLESS_FORMAT_WASM: 1,
    S_IFMT,
    S_IFREG,
    S_IFDIR,
    S_IFCHR,
    S_IFBLK: 24576,
    S_IFIFO,
    S_IFLNK,
    S_IFSOCK,
    O_CREAT,
    O_EXCL,
    UV_FS_O_FILEMAP: 0,
    O_NOCTTY: 256,
    O_TRUNC,
    O_APPEND,
    O_DIRECTORY,
    O_NOATIME: 262144,
    O_NOFOLLOW,
    O_SYNC: 1052672,
    O_DSYNC: 4096,
    O_DIRECT: 16384,
    O_NONBLOCK,
    S_IRWXU: 448,
    S_IRUSR: 256,
    S_IWUSR: 128,
    S_IXUSR: 64,
    S_IRWXG: 56,
    S_IRGRP: 32,
    S_IWGRP: 16,
    S_IXGRP: 8,
    S_IRWXO: 7,
    S_IROTH: 4,
    S_IWOTH: 2,
    S_IXOTH: 1,
    F_OK: 0,
    R_OK: 4,
    W_OK: 2,
    X_OK: 1,
    UV_FS_COPYFILE_EXCL: 1,
    COPYFILE_EXCL: 1,
    UV_FS_COPYFILE_FICLONE: 2,
    COPYFILE_FICLONE: 2,
    UV_FS_COPYFILE_FICLONE_FORCE: 4,
    COPYFILE_FICLONE_FORCE: 4
  };
  function createFs(rt) {
    const k = rt.kernel;
    const loop = rt.loop;
    const Buffer = rt.require("buffer").Buffer;
    const utf8 = new TextDecoder("utf-8", { ignoreBOM: true });
    const encoder3 = new TextEncoder;
    function fsError(e, syscall, path, dest) {
      if (!e || typeof e.errno !== "number" || typeof e.code !== "string" || e.bat)
        return e;
      const call = syscall ?? e.syscall;
      const p = path !== undefined ? String(path) : e.path;
      let message = `${e.code}: ${MESSAGES[e.code] ?? "unknown error"}, ${call}`;
      if (p !== undefined)
        message += ` '${p}'`;
      if (dest !== undefined)
        message += ` -> '${dest}'`;
      const err = new Error(message);
      err.errno = -e.errno;
      err.code = e.code;
      err.syscall = call;
      if (p !== undefined)
        err.path = p;
      if (dest !== undefined)
        err.dest = String(dest);
      err.bat = true;
      Object.defineProperty(err, "bat", { enumerable: false });
      Error.captureStackTrace?.(err, fsError);
      return err;
    }
    const errnoError = (code, errno, syscall, path) => fsError({ code, errno, syscall, path }, syscall, path);
    const argError = (name, expected, value) => Object.assign(new TypeError(`The "${name}" argument must be ${expected}. Received ${value === null ? "null" : typeof value === "object" ? `an instance of ${value.constructor?.name}` : `type ${typeof value} (${String(value)})`}`), { code: "ERR_INVALID_ARG_TYPE" });
    function toPath(p, name = "path") {
      if (typeof p === "string") {
        if (p.indexOf("\x00") !== -1)
          throw Object.assign(new TypeError(`The argument '${name}' must be a string, Uint8Array, or URL without null bytes. Received ${JSON.stringify(p)}`), { code: "ERR_INVALID_ARG_VALUE" });
        return p;
      }
      if (p instanceof URL) {
        if (p.protocol !== "file:")
          throw Object.assign(new TypeError("The URL must be of scheme file"), { code: "ERR_INVALID_URL_SCHEME" });
        return decodeURIComponent(p.pathname);
      }
      if (p instanceof Uint8Array)
        return utf8.decode(p);
      throw argError(name, "of type string or an instance of Buffer or URL", p);
    }
    function toBytes(data, encoding) {
      if (typeof data === "string")
        return !encoding || encoding === "utf8" || encoding === "utf-8" ? encoder3.encode(data) : Buffer.from(data, encoding);
      if (ArrayBuffer.isView(data))
        return data instanceof Uint8Array ? data : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
      if (data instanceof ArrayBuffer || data instanceof SharedArrayBuffer)
        return new Uint8Array(data);
      throw argError("data", "of type string or an instance of Buffer, TypedArray, or DataView", data);
    }
    function decode(bytes, encoding) {
      if (!encoding || encoding === "buffer")
        return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      if (encoding === "utf8" || encoding === "utf-8")
        return utf8.decode(bytes);
      return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString(encoding);
    }
    const encodingOf = (opts) => typeof opts === "string" ? opts : opts?.encoding ?? undefined;
    function parseFlags(flags) {
      if (flags === undefined || flags === null)
        return O_RDONLY;
      if (typeof flags === "number")
        return flags;
      switch (flags) {
        case "r":
        case "rs":
        case "sr":
          return O_RDONLY;
        case "r+":
        case "rs+":
        case "sr+":
          return O_RDWR;
        case "w":
          return O_TRUNC | O_CREAT | O_WRONLY;
        case "wx":
        case "xw":
          return O_TRUNC | O_CREAT | O_WRONLY | O_EXCL;
        case "w+":
          return O_TRUNC | O_CREAT | O_RDWR;
        case "wx+":
        case "xw+":
          return O_TRUNC | O_CREAT | O_RDWR | O_EXCL;
        case "a":
        case "as":
        case "sa":
          return O_APPEND | O_CREAT | O_WRONLY;
        case "ax":
        case "xa":
          return O_APPEND | O_CREAT | O_WRONLY | O_EXCL;
        case "a+":
        case "as+":
        case "sa+":
          return O_APPEND | O_CREAT | O_RDWR;
        case "ax+":
        case "xa+":
          return O_APPEND | O_CREAT | O_RDWR | O_EXCL;
      }
      throw Object.assign(new TypeError(`The argument 'flags' is invalid. Received ${JSON.stringify(flags)}`), { code: "ERR_INVALID_ARG_VALUE" });
    }
    const parseMode = (mode, def) => mode === undefined || mode === null ? def : typeof mode === "string" ? parseInt(mode, 8) : mode;
    const toMs = (t) => {
      if (t instanceof Date)
        return t.getTime();
      if (typeof t === "bigint")
        return Number(t) * 1000;
      const n = Number(t);
      return Number.isFinite(n) ? n * 1000 : Date.now();
    };

    class Stats {
      dev = 0;
      mode = 0;
      nlink = 0;
      uid = 1000;
      gid = 1000;
      rdev = 0;
      blksize = 4096;
      ino = 0;
      size = 0;
      blocks = 0;
      atimeMs = 0;
      mtimeMs = 0;
      ctimeMs = 0;
      birthtimeMs = 0;
      isFile() {
        return (this.mode & S_IFMT) === S_IFREG;
      }
      isDirectory() {
        return (this.mode & S_IFMT) === S_IFDIR;
      }
      isSymbolicLink() {
        return (this.mode & S_IFMT) === S_IFLNK;
      }
      isFIFO() {
        return (this.mode & S_IFMT) === S_IFIFO;
      }
      isSocket() {
        return (this.mode & S_IFMT) === S_IFSOCK;
      }
      isCharacterDevice() {
        return (this.mode & S_IFMT) === S_IFCHR;
      }
      isBlockDevice() {
        return false;
      }
      get atime() {
        return new Date(this.atimeMs);
      }
      get mtime() {
        return new Date(this.mtimeMs);
      }
      get ctime() {
        return new Date(this.ctimeMs);
      }
      get birthtime() {
        return new Date(this.birthtimeMs);
      }
    }
    for (const key of ["atime", "mtime", "ctime", "birthtime"]) {
      const d = Object.getOwnPropertyDescriptor(Stats.prototype, key);
      Object.defineProperty(Stats.prototype, key, { ...d, enumerable: true, set(v) {
        Object.defineProperty(this, key, { value: v, writable: true, enumerable: true, configurable: true });
      } });
    }
    function takeStat(bigint) {
      const st = k.st;
      const s = new Stats;
      s.dev = st.dev;
      s.mode = KIND_MODE[st.kind] | st.mode;
      s.nlink = st.nlink;
      s.ino = st.ino;
      s.size = st.size;
      s.blocks = Math.ceil(st.size / 512);
      s.atimeMs = s.mtimeMs = st.mtimeMs;
      s.ctimeMs = st.ctimeMs;
      s.birthtimeMs = st.birthtimeMs;
      return bigint ? toBigStats(s) : s;
    }
    function toBigStats(s) {
      const b = Object.create(Stats.prototype);
      for (const key of ["dev", "mode", "nlink", "uid", "gid", "rdev", "blksize", "ino", "size", "blocks"])
        b[key] = BigInt(Math.trunc(s[key]));
      for (const key of ["atime", "mtime", "ctime", "birthtime"]) {
        b[`${key}Ms`] = BigInt(Math.trunc(s[`${key}Ms`]));
        b[`${key}Ns`] = BigInt(Math.trunc(s[`${key}Ms`])) * 1000000n;
        Object.defineProperty(b, key, { value: new Date(s[`${key}Ms`]), enumerable: true, writable: true, configurable: true });
      }
      b.isFile = () => s.isFile();
      b.isDirectory = () => s.isDirectory();
      b.isSymbolicLink = () => s.isSymbolicLink();
      return b;
    }
    const kType = Symbol("type");

    class Dirent {
      name;
      parentPath;
      path;
      [kType];
      constructor(name, type, parentPath) {
        this.name = name;
        this.parentPath = parentPath;
        this.path = parentPath;
        this[kType] = type;
      }
      isFile() {
        return this[kType] === 1;
      }
      isDirectory() {
        return this[kType] === 2;
      }
      isSymbolicLink() {
        return this[kType] === 3;
      }
      isFIFO() {
        return this[kType] === 4;
      }
      isSocket() {
        return this[kType] === 5;
      }
      isCharacterDevice() {
        return this[kType] === 6;
      }
      isBlockDevice() {
        return false;
      }
    }
    function statSync(path, options) {
      const p = toPath(path);
      const rc = k.statRaw(p, false);
      if (rc === 0)
        return takeStat(options?.bigint);
      if ((rc === -2 || rc === -20) && options?.throwIfNoEntry === false)
        return;
      throw errnoError(rc === -2 ? "ENOENT" : codeOf(rc), -rc, "stat", p);
    }
    function lstatSync(path, options) {
      const p = toPath(path);
      const rc = k.statRaw(p, true);
      if (rc === 0)
        return takeStat(options?.bigint);
      if ((rc === -2 || rc === -20) && options?.throwIfNoEntry === false)
        return;
      throw errnoError(codeOf(rc), -rc, "lstat", p);
    }
    const CODES = { 1: "EPERM", 2: "ENOENT", 5: "EIO", 9: "EBADF", 11: "EAGAIN", 12: "ENOMEM", 13: "EACCES", 17: "EEXIST", 18: "EXDEV", 20: "ENOTDIR", 21: "EISDIR", 22: "EINVAL", 24: "EMFILE", 28: "ENOSPC", 29: "ESPIPE", 30: "EROFS", 32: "EPIPE", 34: "ERANGE", 36: "ENAMETOOLONG", 38: "ENOSYS", 39: "ENOTEMPTY", 40: "ELOOP" };
    const codeOf = (rc) => CODES[-rc] ?? `E${-rc}`;
    function sys(syscall, path, fn, dest) {
      try {
        return fn();
      } catch (e) {
        throw fsError(e, syscall, path, dest);
      }
    }
    function existsSync(path) {
      try {
        return k.kindOf(toPath(path)) !== -1;
      } catch {
        return false;
      }
    }
    function accessSync(path, mode = 0) {
      const p = toPath(path);
      const rc = k.statRaw(p, false);
      if (rc !== 0)
        throw errnoError(codeOf(rc), -rc, "access", p);
    }
    function readFileSync(path, options) {
      const encoding = encodingOf(options);
      if (typeof path === "number") {
        const chunks = [];
        let total = 0;
        for (;; ) {
          const buf = new Uint8Array(65536);
          const n = sys("read", undefined, () => k.read(path, buf));
          if (n === 0)
            break;
          chunks.push(n === buf.length ? buf : buf.subarray(0, n));
          total += n;
        }
        const all = new Uint8Array(total);
        let off = 0;
        for (const c of chunks) {
          all.set(c, off);
          off += c.length;
        }
        return decode(all, encoding);
      }
      const p = toPath(path);
      return decode(sys("open", p, () => k.readFile(p)), encoding);
    }
    function writeFileSync(path, data, options) {
      const o = typeof options === "string" ? { encoding: options } : options ?? {};
      const bytes = toBytes(data, o.encoding);
      if (typeof path === "number") {
        let off = 0;
        while (off < bytes.length)
          off += sys("write", undefined, () => k.write(path, off ? bytes.subarray(off) : bytes));
        return;
      }
      const p = toPath(path);
      const flags = parseFlags(o.flag ?? "w");
      if (flags & O_APPEND)
        sys("open", p, () => k.writeFile(p, bytes, { mode: parseMode(o.mode, 438) & ~18, append: true, excl: !!(flags & O_EXCL) }));
      else if (flags & O_TRUNC || !(flags & 3))
        sys("open", p, () => k.writeFile(p, bytes, { mode: parseMode(o.mode, 438) & ~18, excl: !!(flags & O_EXCL) }));
      else {
        const fd = openSync(p, flags, o.mode);
        try {
          writeSync(fd, bytes, 0, bytes.length, 0);
        } finally {
          closeSync(fd);
        }
      }
    }
    function appendFileSync(path, data, options) {
      const o = typeof options === "string" ? { encoding: options } : options ?? {};
      writeFileSync(path, data, { ...o, flag: o.flag ?? "a" });
    }
    function readdirSync(path, options) {
      const p = toPath(path);
      const o = typeof options === "string" ? { encoding: options } : options ?? {};
      const asBuffer = o.encoding === "buffer";
      const name = (n) => asBuffer ? Buffer.from(n) : n;
      if (!o.recursive) {
        const entries = sys("scandir", p, () => k.readdir(p));
        if (o.withFileTypes)
          return entries.map((e) => new Dirent(name(e.name), UV_DIRENT[e.kind] ?? 0, p));
        return entries.map((e) => name(e.name));
      }
      const out = [];
      const queue = [[p, ""]];
      for (let i = 0;i < queue.length; i++) {
        const [dir, rel] = queue[i];
        const entries = sys("scandir", dir, () => k.readdir(dir));
        for (const e of entries) {
          const r = rel ? `${rel}/${e.name}` : e.name;
          out.push(o.withFileTypes ? new Dirent(name(e.name), UV_DIRENT[e.kind] ?? 0, dir) : name(r));
          if (e.kind === K_DIR)
            queue.push([`${dir}/${e.name}`, r]);
        }
      }
      return out;
    }
    function mkdirSync(path, options) {
      const p = toPath(path);
      const o = typeof options === "number" || typeof options === "string" ? { mode: options } : options ?? {};
      const mode = parseMode(o.mode, 511) & ~18;
      if (!o.recursive) {
        sys("mkdir", p, () => k.mkdir(p, { mode }));
        return;
      }
      let first;
      let probe = normalize(p);
      while (probe && k.kindOf(probe) === -1) {
        first = probe;
        const i = probe.lastIndexOf("/");
        if (i <= 0)
          break;
        probe = probe.slice(0, i);
      }
      sys("mkdir", p, () => k.mkdir(p, { mode, recursive: true }));
      return first;
    }
    function normalize(p) {
      if (!p.startsWith("/"))
        p = `${k.getcwd()}/${p}`;
      const out = [];
      for (const part of p.split("/")) {
        if (part === "" || part === ".")
          continue;
        if (part === "..")
          out.pop();
        else
          out.push(part);
      }
      return `/${out.join("/")}`;
    }
    function rmdirSync(path, options) {
      const p = toPath(path);
      if (options?.recursive)
        return rmSync(p, { recursive: true, force: false });
      sys("rmdir", p, () => k.rmdir(p));
    }
    function unlinkSync(path) {
      const p = toPath(path);
      sys("unlink", p, () => k.unlink(p));
    }
    function removeTree(p) {
      for (const e of k.readdir(p)) {
        const child = `${p}/${e.name}`;
        if (e.kind === K_DIR)
          removeTree(child);
        else
          k.unlink(child);
      }
      k.rmdir(p);
    }
    function rmSync(path, options) {
      const p = toPath(path);
      const rc = k.statRaw(p, true);
      if (rc !== 0) {
        if (options?.force && (rc === -2 || rc === -20))
          return;
        throw errnoError(codeOf(rc), -rc, "rm", p);
      }
      if (k.st.kind !== K_DIR)
        return sys("rm", p, () => k.unlink(p));
      if (!options?.recursive) {
        throw Object.assign(new Error(`Path is a directory: rm returned EISDIR (is a directory) ${p}`), { code: "ERR_FS_EISDIR", errno: 21, syscall: "rm", path: p });
      }
      sys("rm", p, () => removeTree(p));
    }
    function copyTree(src, dest, o) {
      const rc = k.statRaw(src, !o.dereference);
      if (rc !== 0)
        throw errnoError(codeOf(rc), -rc, "cp", src);
      const kind = k.st.kind;
      const mode = k.st.mode;
      if (o.filter && !o.filter(src, dest))
        return;
      if (kind === K_DIR) {
        if (!o.recursive)
          throw Object.assign(new Error(`Recursive option not enabled, cannot copy a directory: cp returned EISDIR (${src} is a directory (not copied))`), { code: "ERR_FS_EISDIR" });
        k.mkdir(dest, { recursive: true, mode: mode || 493 });
        for (const e of k.readdir(src))
          copyTree(`${src}/${e.name}`, `${dest}/${e.name}`, o);
      } else if (kind === K_SYMLINK) {
        if (k.kindOf(dest) !== -1)
          k.unlink(dest);
        k.symlink(k.readlink(src), dest);
      } else {
        const exists = k.kindOf(dest) !== -1;
        if (exists && o.errorOnExist && !o.force)
          throw Object.assign(new Error(`Target already exists: cp returned EEXIST (${dest} already exists)`), { code: "ERR_FS_CP_EEXIST" });
        if (exists && o.force === false)
          return;
        k.writeFile(dest, k.readFile(src), { mode });
      }
    }
    function cpSync(src, dest, options) {
      const s = toPath(src, "src");
      const d = toPath(dest, "dest");
      sys("cp", s, () => copyTree(s, d, { force: true, ...options }), d);
    }
    function renameSync(from, to) {
      const a = toPath(from, "oldPath");
      const b = toPath(to, "newPath");
      try {
        k.rename(a, b);
      } catch (e) {
        if (e.code !== "EXDEV")
          throw fsError(e, "rename", a, b);
        sys("rename", a, () => {
          copyTree(a, b, { recursive: true, force: true });
          removeTree(a);
        }, b);
      }
    }
    function copyFileSync(src, dest, mode = 0) {
      const s = toPath(src, "src");
      const d = toPath(dest, "dest");
      sys("copyfile", s, () => {
        const data = k.readFile(s);
        const perm = k.st.mode;
        k.writeFile(d, data, { mode: perm || 420, excl: !!(mode & 1) });
      }, d);
    }
    function symlinkSync(target, path) {
      const t = toPath(target, "target");
      const p = toPath(path);
      sys("symlink", t, () => k.symlink(t, p), p);
    }
    function linkSync(existing, path) {
      const a = toPath(existing, "existingPath");
      const b = toPath(path, "newPath");
      sys("link", a, () => k.link(a, b), b);
    }
    function readlinkSync(path, options) {
      const p = toPath(path);
      const t = sys("readlink", p, () => k.readlink(p));
      return encodingOf(options) === "buffer" ? Buffer.from(t) : t;
    }
    const realpathSync = (path, options) => {
      const p = toPath(path);
      const r = sys("realpath", p, () => k.realpath(p));
      return encodingOf(options) === "buffer" ? Buffer.from(r) : r;
    };
    realpathSync.native = realpathSync;
    function chmodSync(path, mode) {
      const p = toPath(path);
      sys("chmod", p, () => k.chmod(p, parseMode(mode, 420)));
    }
    function lchmodSync(path, mode) {
      const p = toPath(path);
      sys("lchmod", p, () => k.chmod(p, parseMode(mode, 420), true));
    }
    function chownSync(path) {
      accessSync(path);
    }
    function utimesSync(path, _atime, mtime) {
      const p = toPath(path);
      sys("utime", p, () => k.utimes(p, toMs(mtime)));
    }
    function lutimesSync(path, _atime, mtime) {
      const p = toPath(path);
      sys("lutime", p, () => k.utimes(p, toMs(mtime), true));
    }
    function truncateSync(path, len = 0) {
      const p = toPath(path);
      sys("truncate", p, () => k.truncate(p, len));
    }
    function mkdtempSync(prefix, options) {
      const base = toPath(prefix, "prefix");
      for (let attempt = 0;attempt < 100; attempt++) {
        let suffix = "";
        for (let i = 0;i < 6; i++)
          suffix += "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[Math.floor(Math.random() * 62)];
        const p = base + suffix;
        try {
          k.mkdir(p, { mode: 448 });
          return encodingOf(options) === "buffer" ? Buffer.from(p) : p;
        } catch (e) {
          if (e.code !== "EEXIST")
            throw fsError(e, "mkdtemp", `${base}XXXXXX`);
        }
      }
      throw errnoError("EEXIST", 17, "mkdtemp", `${base}XXXXXX`);
    }
    function statfsSync(_path, options) {
      const v = { type: 2240043254, bsize: 4096, blocks: 1 << 20, bfree: 1 << 19, bavail: 1 << 19, files: 1 << 20, ffree: 1 << 19 };
      return options?.bigint ? Object.fromEntries(Object.entries(v).map(([key, n]) => [key, BigInt(n)])) : v;
    }
    function openSync(path, flags, mode) {
      const p = toPath(path);
      return sys("open", p, () => k.open(p, parseFlags(flags), parseMode(mode, 438) & ~18));
    }
    function closeSync(fd) {
      sys("close", undefined, () => k.close(fd));
    }
    function readSync(fd, buffer, offsetOrOptions, length, position) {
      let offset = 0;
      if (offsetOrOptions !== null && typeof offsetOrOptions === "object") {
        ({ offset = 0, length = buffer.byteLength - offset, position = null } = offsetOrOptions);
      } else if (offsetOrOptions !== undefined)
        offset = offsetOrOptions;
      length ??= buffer.byteLength - offset;
      if (length === 0)
        return 0;
      const view = new Uint8Array(buffer.buffer, buffer.byteOffset + offset, length);
      const pos = position === null || position === undefined || position === -1 ? undefined : Number(position);
      return sys("read", undefined, () => k.read(fd, view, pos));
    }
    function writeSync(fd, data, a, b, c) {
      let bytes;
      let position;
      if (typeof data === "string") {
        bytes = toBytes(data, typeof b === "string" ? b : undefined);
        position = typeof a === "number" ? a : undefined;
      } else {
        let offset = 0;
        let length;
        if (a !== null && typeof a === "object")
          ({ offset = 0, length, position } = a);
        else {
          offset = a ?? 0;
          length = b;
          position = typeof c === "number" ? c : undefined;
        }
        const all = toBytes(data);
        bytes = all.subarray(offset, offset + (length ?? all.length - offset));
      }
      if (bytes.length === 0)
        return 0;
      const pos = position === null || position === undefined || position < 0 ? undefined : position;
      return sys("write", undefined, () => k.write(fd, bytes, pos));
    }
    function fstatViaWrapper(fd, options) {
      const st = sys("fstat", undefined, () => k.fstat(fd));
      const s = new Stats;
      s.dev = st.dev;
      s.mode = KIND_MODE[st.kind] | st.mode;
      s.nlink = st.nlink;
      s.ino = st.ino;
      s.size = st.size;
      s.blocks = Math.ceil(st.size / 512);
      s.atimeMs = s.mtimeMs = st.mtimeMs;
      s.ctimeMs = st.ctimeMs;
      s.birthtimeMs = st.birthtimeMs;
      return options?.bigint ? toBigStats(s) : s;
    }
    function ftruncateSync(fd, len = 0) {
      sys("ftruncate", undefined, () => k.ftruncate(fd, len));
    }
    function fsyncSync(_fd) {}
    function futimesSync(fd, _atime, mtime) {
      sys("futime", undefined, () => k.fsetmeta(fd, undefined, toMs(mtime)));
    }
    function fchmodSync(fd, mode) {
      sys("fchmod", undefined, () => k.fsetmeta(fd, parseMode(mode, 420), undefined));
    }
    function readvSync(fd, buffers, position) {
      let total = 0;
      for (const b of buffers) {
        const n = readSync(fd, b, 0, b.byteLength, position === null || position === undefined ? null : position + total);
        total += n;
        if (n < b.byteLength)
          break;
      }
      return total;
    }
    function writevSync(fd, buffers, position) {
      let total = 0;
      for (const b of buffers)
        total += writeSync(fd, b, 0, b.byteLength, position === null || position === undefined ? undefined : position + total);
      return total;
    }

    class Dir {
      path;
      #entries;
      #i = 0;
      #closed = false;
      constructor(path) {
        this.path = path;
      }
      #load() {
        this.#entries ??= readdirSync(this.path, { withFileTypes: true });
        return this.#entries;
      }
      readSync() {
        if (this.#closed)
          throw Object.assign(new Error("Directory handle was closed"), { code: "ERR_DIR_CLOSED" });
        const e = this.#load();
        return this.#i < e.length ? e[this.#i++] : null;
      }
      read(cb) {
        if (typeof cb === "function") {
          let r;
          try {
            r = this.readSync();
          } catch (e) {
            loop.nextTick(cb, e);
            return;
          }
          loop.nextTick(cb, null, r);
          return;
        }
        return new Promise((resolve, reject) => {
          try {
            resolve(this.readSync());
          } catch (e) {
            reject(e);
          }
        });
      }
      closeSync() {
        this.#closed = true;
      }
      close(cb) {
        this.#closed = true;
        if (typeof cb === "function")
          loop.nextTick(cb, null);
        else
          return Promise.resolve();
      }
      async* entries() {
        try {
          for (;; ) {
            const e = this.readSync();
            if (e === null)
              break;
            yield e;
          }
        } finally {
          this.#closed = true;
        }
      }
      [Symbol.asyncIterator]() {
        return this.entries();
      }
      [Symbol.asyncDispose]() {
        return this.close();
      }
      [Symbol.dispose]() {
        this.closeSync();
      }
    }
    function opendirSync(path) {
      const p = toPath(path);
      const rc = k.statRaw(p, false);
      if (rc !== 0)
        throw errnoError(codeOf(rc), -rc, "opendir", p);
      if (k.st.kind !== K_DIR)
        throw errnoError("ENOTDIR", 20, "opendir", p);
      return new Dir(p);
    }
    const EventEmitter = rt.require("events");

    class FSWatcher extends EventEmitter {
      #id = -1;
      #persistent = false;
      #closed = false;
      constructor() {
        super();
      }
      _start(path, options, listener) {
        const p = normalize(path);
        const rc = k.statRaw(p, false);
        if (rc !== 0)
          throw errnoError(codeOf(rc), -rc, "watch", path);
        const isDir = k.st.kind === K_DIR;
        const base = p.slice(p.lastIndexOf("/") + 1);
        const asBuffer = options.encoding === "buffer";
        this.#id = sys("watch", path, () => k.watchAdd(p, !!options.recursive));
        this.#persistent = options.persistent !== false;
        if (this.#persistent)
          loop.ref();
        if (listener)
          this.on("change", listener);
        loop.onWatch(this.#id, (kind, rel) => {
          if (this.#closed)
            return;
          const name = isDir ? rel || base : base;
          this.emit("change", kind === 1 ? "rename" : "change", asBuffer ? Buffer.from(name) : name);
        });
        options.signal?.addEventListener("abort", () => this.close(), { once: true });
      }
      close() {
        if (this.#closed)
          return;
        this.#closed = true;
        loop.offWatch(this.#id);
        k.watchRemove(this.#id);
        if (this.#persistent)
          loop.unref();
        loop.nextTick(() => this.emit("close"));
      }
      ref() {
        if (!this.#persistent && !this.#closed) {
          this.#persistent = true;
          loop.ref();
        }
        return this;
      }
      unref() {
        if (this.#persistent && !this.#closed) {
          this.#persistent = false;
          loop.unref();
        }
        return this;
      }
    }
    function watch(path, options, listener) {
      if (typeof options === "function") {
        listener = options;
        options = {};
      } else if (typeof options === "string")
        options = { encoding: options };
      const w = new FSWatcher;
      w._start(toPath(path), options ?? {}, listener);
      return w;
    }
    const statWatchers = new Map;
    const zeroStats = () => new Stats;
    function watchFile(path, options, listener) {
      if (typeof options === "function") {
        listener = options;
        options = {};
      }
      const p = normalize(toPath(path));
      let w = statWatchers.get(p);
      if (!w) {
        const probe = () => statSync(p, { throwIfNoEntry: false }) ?? zeroStats();
        const state = { timer: undefined, listeners: new Set, prev: probe() };
        state.timer = rt.host.global.setInterval(() => {
          const cur = probe();
          if (cur.mtimeMs !== state.prev.mtimeMs || cur.size !== state.prev.size || cur.ino !== state.prev.ino) {
            const prev = state.prev;
            state.prev = cur;
            for (const l of state.listeners)
              l(cur, prev);
          }
        }, options?.interval ?? 5007);
        if (options?.persistent === false)
          state.timer.unref();
        statWatchers.set(p, w = state);
      }
      w.listeners.add(listener);
      return w;
    }
    function unwatchFile(path, listener) {
      const p = normalize(toPath(path));
      const w = statWatchers.get(p);
      if (!w)
        return;
      if (listener)
        w.listeners.delete(listener);
      else
        w.listeners.clear();
      if (w.listeners.size === 0) {
        rt.host.global.clearInterval(w.timer);
        statWatchers.delete(p);
      }
    }
    const { Readable, Writable } = rt.require("stream");

    class ReadStream extends Readable {
      fd;
      path;
      flags;
      mode;
      start;
      end;
      pos;
      bytesRead = 0;
      autoClose;
      pending = true;
      constructor(path, options) {
        const o = typeof options === "string" ? { encoding: options } : options ?? {};
        super({ highWaterMark: o.highWaterMark ?? 65536, encoding: o.encoding, emitClose: o.emitClose ?? true, autoDestroy: o.autoClose ?? true, signal: o.signal });
        this.path = path !== undefined && path !== null && typeof o.fd !== "number" ? toPath(path) : undefined;
        this.fd = typeof o.fd === "number" ? o.fd : o.fd?.fd ?? null;
        this.flags = o.flags ?? "r";
        this.mode = o.mode ?? 438;
        this.start = o.start;
        this.end = o.end ?? Infinity;
        this.pos = o.start;
        this.autoClose = o.autoClose ?? true;
        if (this.fd !== null)
          this.pending = false;
      }
      _construct(cb) {
        if (this.fd !== null)
          return cb();
        try {
          this.fd = openSync(this.path, this.flags, this.mode);
          this.pending = false;
        } catch (e) {
          return cb(e);
        }
        cb();
        this.emit("open", this.fd);
        this.emit("ready");
      }
      _read(n) {
        let want = n;
        if (this.end !== Infinity)
          want = Math.min(want, this.end - (this.pos ?? this.bytesRead + (this.start ?? 0)) + 1);
        if (want <= 0)
          return void this.push(null);
        const buf = Buffer.allocUnsafeSlow(want);
        let got;
        try {
          got = readSync(this.fd, buf, 0, want, this.pos ?? null);
        } catch (e) {
          return void this.destroy(e);
        }
        if (got === 0)
          return void this.push(null);
        if (this.pos !== undefined)
          this.pos += got;
        this.bytesRead += got;
        this.push(got === want ? buf : buf.subarray(0, got));
      }
      _destroy(err, cb) {
        if (this.fd !== null && this.autoClose) {
          try {
            k.close(this.fd);
          } catch {}
          this.fd = null;
        }
        cb(err);
      }
      close(cb) {
        if (typeof cb === "function")
          this.once("close", cb);
        this.destroy();
      }
    }

    class WriteStream extends Writable {
      fd;
      path;
      flags;
      mode;
      start;
      pos;
      bytesWritten = 0;
      autoClose;
      pending = true;
      constructor(path, options) {
        const o = typeof options === "string" ? { encoding: options } : options ?? {};
        super({ highWaterMark: o.highWaterMark, decodeStrings: true, defaultEncoding: o.encoding ?? "utf8", emitClose: o.emitClose ?? true, autoDestroy: o.autoClose ?? true, signal: o.signal });
        this.path = path !== undefined && path !== null && typeof o.fd !== "number" ? toPath(path) : undefined;
        this.fd = typeof o.fd === "number" ? o.fd : o.fd?.fd ?? null;
        this.flags = o.flags ?? "w";
        this.mode = o.mode ?? 438;
        this.start = o.start;
        this.pos = o.start;
        this.autoClose = o.autoClose ?? true;
        if (this.fd !== null)
          this.pending = false;
      }
      _construct(cb) {
        if (this.fd !== null)
          return cb();
        try {
          this.fd = openSync(this.path, this.flags, this.mode);
          this.pending = false;
        } catch (e) {
          return cb(e);
        }
        cb();
        this.emit("open", this.fd);
        this.emit("ready");
      }
      _write(chunk, _enc, cb) {
        try {
          let off = 0;
          while (off < chunk.length) {
            const n = writeSync(this.fd, chunk, off, chunk.length - off, this.pos);
            off += n;
            if (this.pos !== undefined)
              this.pos += n;
            this.bytesWritten += n;
          }
        } catch (e) {
          return cb(e);
        }
        cb();
      }
      _destroy(err, cb) {
        if (this.fd !== null && this.autoClose) {
          try {
            k.close(this.fd);
          } catch {}
          this.fd = null;
        }
        cb(err);
      }
      close(cb) {
        if (typeof cb === "function") {
          if (this.closed)
            return void loop.nextTick(cb);
          this.once("close", cb);
        }
        if (!this.writableFinished && !this.destroyed)
          this.end(() => this.destroy());
        else
          this.destroy();
      }
      destroySoon() {
        this.end();
      }
    }
    const createReadStream = (path, options) => new ReadStream(path, options);
    const createWriteStream = (path, options) => new WriteStream(path, options);
    const sync = {
      access: accessSync,
      appendFile: appendFileSync,
      chmod: chmodSync,
      chown: chownSync,
      close: closeSync,
      copyFile: copyFileSync,
      cp: cpSync,
      fchmod: fchmodSync,
      fchown: () => {},
      fdatasync: fsyncSync,
      fstat: fstatViaWrapper,
      fsync: fsyncSync,
      ftruncate: ftruncateSync,
      futimes: futimesSync,
      lchmod: lchmodSync,
      lchown: chownSync,
      link: linkSync,
      lstat: lstatSync,
      lutimes: lutimesSync,
      mkdir: mkdirSync,
      mkdtemp: mkdtempSync,
      open: openSync,
      opendir: opendirSync,
      read: readSync,
      readdir: readdirSync,
      readFile: readFileSync,
      readlink: readlinkSync,
      readv: readvSync,
      realpath: realpathSync,
      rename: renameSync,
      rm: rmSync,
      rmdir: rmdirSync,
      stat: statSync,
      statfs: statfsSync,
      symlink: symlinkSync,
      truncate: truncateSync,
      unlink: unlinkSync,
      utimes: utimesSync,
      write: writeSync,
      writeFile: writeFileSync,
      writev: writevSync
    };
    const fs = {
      constants,
      Stats,
      Dirent,
      Dir,
      FSWatcher,
      ReadStream,
      WriteStream,
      FileReadStream: ReadStream,
      FileWriteStream: WriteStream,
      existsSync,
      watch,
      watchFile,
      unwatchFile,
      createReadStream,
      createWriteStream,
      F_OK: 0,
      R_OK: 4,
      W_OK: 2,
      X_OK: 1,
      [Symbol.for("bat.fs.error")]: fsError
    };
    for (const [name, fn] of Object.entries(sync)) {
      fs[`${name}Sync`] = fn;
      fs[name] = function(...args) {
        const cb = args.length && typeof args[args.length - 1] === "function" ? args.pop() : undefined;
        if (cb === undefined)
          throw Object.assign(new TypeError(`The "cb" argument must be of type function. Received undefined`), { code: "ERR_INVALID_ARG_TYPE" });
        let result;
        try {
          result = fn(...args);
        } catch (e) {
          loop.nextTick(cb, e);
          return;
        }
        loop.nextTick(cb, null, result);
      };
    }
    fs.realpath.native = fs.realpath;
    fs.exists = (path, cb) => loop.nextTick(cb, existsSync(path));
    fs.read = (fd, ...args) => {
      const cb = args.pop();
      let buffer = args[0];
      if (buffer === undefined || typeof buffer === "object" && !ArrayBuffer.isView(buffer)) {
        const o = buffer ?? {};
        buffer = o.buffer ?? Buffer.alloc(16384);
        args = [buffer, o];
      }
      const finish = () => {
        let n;
        try {
          n = readSync(fd, args[0], args[1], args[2], args[3]);
        } catch (e) {
          return loop.nextTick(cb, e);
        }
        loop.nextTick(cb, null, n, buffer);
      };
      let ready = 1;
      try {
        ready = k.pollFd(fd);
      } catch {}
      if (ready & (1 | 8 | 16))
        return finish();
      loop.ref();
      loop.onFd(fd, 1 | 16, () => {
        loop.offFd(fd);
        loop.unref();
        finish();
      });
    };
    fs.write = (fd, data, ...args) => {
      const cb = typeof args[args.length - 1] === "function" ? args.pop() : () => {};
      let n;
      try {
        n = writeSync(fd, data, args[0], args[1], args[2]);
      } catch (e) {
        return loop.nextTick(cb, e);
      }
      loop.nextTick(cb, null, n, data);
    };
    fs.readv = (fd, buffers, ...args) => {
      const cb = args.pop();
      let n;
      try {
        n = readvSync(fd, buffers, args[0]);
      } catch (e) {
        return loop.nextTick(cb, e);
      }
      loop.nextTick(cb, null, n, buffers);
    };
    fs.writev = (fd, buffers, ...args) => {
      const cb = args.pop();
      let n;
      try {
        n = writevSync(fd, buffers, args[0]);
      } catch (e) {
        return loop.nextTick(cb, e);
      }
      loop.nextTick(cb, null, n, buffers);
    };
    fs.glob = fs.globSync = () => {
      throw Object.assign(new Error("fs.glob is not implemented in this runtime"), { code: "ERR_METHOD_NOT_IMPLEMENTED" });
    };
    fs.openAsBlob = async (path, options) => new Blob([readFileSync(path)], { type: options?.type ?? "" });

    class FileHandle extends EventEmitter {
      fd;
      #closed = false;
      constructor(fd) {
        super();
        this.fd = fd;
      }
      async read(buffer, offset, length, position) {
        if (buffer === undefined || typeof buffer === "object" && !ArrayBuffer.isView(buffer)) {
          const o = buffer ?? {};
          buffer = o.buffer ?? Buffer.alloc(16384);
          offset = o;
        }
        return { bytesRead: readSync(this.fd, buffer, offset, length, position), buffer };
      }
      async write(data, a, b, c) {
        const bytesWritten = writeSync(this.fd, data, a, b, c);
        return { bytesWritten, buffer: data };
      }
      async readFile(options) {
        return readFileSync(this.fd, options);
      }
      async writeFile(data, options) {
        writeFileSync(this.fd, data, options);
      }
      async appendFile(data, options) {
        writeFileSync(this.fd, data, options);
      }
      async stat(options) {
        return fstatViaWrapper(this.fd, options);
      }
      async truncate(len = 0) {
        ftruncateSync(this.fd, len);
      }
      async sync() {}
      async datasync() {}
      async chmod(mode) {
        fchmodSync(this.fd, mode);
      }
      async chown() {}
      async utimes(atime, mtime) {
        futimesSync(this.fd, atime, mtime);
      }
      async readv(buffers, position) {
        return { bytesRead: readvSync(this.fd, buffers, position), buffers };
      }
      async writev(buffers, position) {
        return { bytesWritten: writevSync(this.fd, buffers, position), buffers };
      }
      createReadStream(options) {
        return new ReadStream(undefined, { ...options, fd: this.fd });
      }
      createWriteStream(options) {
        return new WriteStream(undefined, { ...options, fd: this.fd });
      }
      readLines(options) {
        return rt.require("readline").createInterface({ input: this.createReadStream(options), crlfDelay: Infinity });
      }
      async close() {
        if (this.#closed)
          return;
        this.#closed = true;
        closeSync(this.fd);
        this.fd = -1;
        this.emit("close");
      }
      [Symbol.asyncDispose]() {
        return this.close();
      }
    }
    const promises = { constants };
    for (const name of ["access", "appendFile", "chmod", "chown", "copyFile", "cp", "lchmod", "lchown", "link", "lstat", "lutimes", "mkdir", "mkdtemp", "opendir", "readdir", "readFile", "readlink", "realpath", "rename", "rm", "rmdir", "stat", "statfs", "symlink", "truncate", "unlink", "utimes", "writeFile"]) {
      const fn = sync[name];
      promises[name] = async (...args) => fn(...args);
    }
    promises.readFile = async (path, options) => readFileSync(path instanceof FileHandle ? path.fd : path, options);
    promises.writeFile = async (path, data, options) => {
      if (data !== null && typeof data === "object" && !ArrayBuffer.isView(data) && ((Symbol.asyncIterator in data) || (Symbol.iterator in data))) {
        const parts = [];
        for await (const chunk of data)
          parts.push(toBytes(chunk, encodingOf(options)));
        data = Buffer.concat(parts);
      }
      writeFileSync(path instanceof FileHandle ? path.fd : path, data, options);
    };
    promises.open = async (path, flags, mode) => new FileHandle(openSync(path, flags, mode));
    promises.watch = (path, options = {}) => {
      const events = [];
      let wake;
      let done = false;
      const w = watch(path, options, (eventType, filename) => {
        events.push({ eventType, filename });
        wake?.();
      });
      options.signal?.addEventListener("abort", () => {
        done = true;
        wake?.();
      }, { once: true });
      return {
        async* [Symbol.asyncIterator]() {
          try {
            while (!done) {
              while (events.length)
                yield events.shift();
              if (done)
                break;
              await new Promise((r) => wake = r);
            }
            if (options.signal?.aborted)
              throw Object.assign(new Error("The operation was aborted"), { name: "AbortError", code: "ABORT_ERR", cause: options.signal.reason });
          } finally {
            w.close();
          }
        }
      };
    };
    promises.FileHandle = FileHandle;
    Object.defineProperty(fs, "promises", { value: promises, enumerable: true, configurable: true, writable: true });
    return fs;
  }
  registerBuiltin("fs", createFs);
  registerBuiltin("fs/promises", (rt) => rt.require("fs").promises);

  // runtime/src/process/globals.ts
  var HIDDEN = [
    "self",
    "postMessage",
    "importScripts",
    "close",
    "name",
    "location",
    "origin",
    "isSecureContext",
    "crossOriginIsolated",
    "onmessage",
    "onmessageerror",
    "onerror",
    "onlanguagechange",
    "onoffline",
    "ononline",
    "onrejectionhandled",
    "onunhandledrejection",
    "WorkerGlobalScope",
    "DedicatedWorkerGlobalScope",
    "WorkerNavigator",
    "WorkerLocation",
    "Worker",
    "SharedWorker",
    "XMLHttpRequest",
    "XMLHttpRequestEventTarget",
    "XMLHttpRequestUpload",
    "FileReader",
    "FileReaderSync",
    "EventSource",
    "caches",
    "CacheStorage",
    "Cache",
    "indexedDB",
    "IDBFactory",
    "requestAnimationFrame",
    "cancelAnimationFrame",
    "createImageBitmap",
    "OffscreenCanvas",
    "reportError",
    "fonts",
    "webkitRequestFileSystem",
    "webkitRequestFileSystemSync",
    "webkitResolveLocalFileSystemURL",
    "webkitResolveLocalFileSystemSyncURL",
    "TEMPORARY",
    "PERSISTENT",
    "trustedTypes",
    "ServiceWorkerRegistration",
    "Notification",
    "cookieStore",
    "onstorage"
  ];
  function installGlobals(rt, loop, ctl) {
    const g = rt.host.global;
    for (const name of HIDDEN) {
      try {
        delete g[name];
        if (name in g)
          Object.defineProperty(g, name, { value: undefined, configurable: true, writable: true, enumerable: false });
      } catch {}
    }
    const define = (name, value) => Object.defineProperty(g, name, { value, writable: true, configurable: true, enumerable: false });
    const lazy = (name, get) => Object.defineProperty(g, name, {
      configurable: true,
      enumerable: false,
      get() {
        const value = get();
        define(name, value);
        return value;
      },
      set(value) {
        define(name, value);
      }
    });
    define("global", g);
    define("__bat_w", awaitWrap);
    define("__bat_u", awaitUnwrap);
    define("process", rt.process);
    define("setTimeout", loop.setTimeout);
    define("setInterval", loop.setInterval);
    define("clearTimeout", loop.clearTimeout);
    define("clearInterval", loop.clearTimeout);
    define("setImmediate", loop.setImmediate);
    define("clearImmediate", loop.clearImmediate);
    lazy("Buffer", () => rt.require("buffer").Buffer);
    const realNavigator = g.navigator;
    const nav = { hardwareConcurrency: 1, language: "en-US", languages: ["en-US"], platform: "linux", userAgent: `Node.js/${rt.config.version.slice(1, 3)}` };
    Object.defineProperty(nav, "storage", { value: realNavigator?.storage, enumerable: false });
    Object.defineProperty(nav, "locks", { value: realNavigator?.locks, enumerable: false });
    define("navigator", Object.freeze(nav));
    const wa = g.WebAssembly;
    for (const name of ["compile", "instantiate", "compileStreaming", "instantiateStreaming"]) {
      const native = wa?.[name];
      if (typeof native !== "function")
        continue;
      const wrapped = function(...args) {
        loop.ref();
        const done = () => loop.defer(() => loop.unref());
        let promise;
        try {
          promise = native.apply(wa, args);
        } catch (e) {
          done();
          throw e;
        }
        promise.then(done, done);
        return promise;
      };
      Object.defineProperty(wrapped, "name", { value: name });
      Object.defineProperty(wa, name, { value: wrapped, writable: true, configurable: true, enumerable: true });
    }
    define("console", createConsole(rt, ctl));
    const perf = g.performance;
    if (perf && !perf.eventLoopUtilization) {
      perf.eventLoopUtilization = () => ({ idle: 0, active: 0, utilization: 0 });
      perf.nodeTiming = { name: "node", entryType: "node", startTime: 0, duration: 0, nodeStart: 0, v8Start: 0, bootstrapComplete: 0, environment: 0, loopStart: 0, loopExit: -1, idleTime: 0 };
      perf.timerify = (fn) => fn;
    }
  }
  function createConsole(rt, ctl, streams) {
    let util;
    const counts = new Map;
    const timers = new Map;
    let indent = "";
    const format = (args) => {
      let text;
      if (args.length === 1 && typeof args[0] === "string")
        text = args[0];
      else
        text = (util ??= rt.require("util")).format(...args);
      return indent ? indent + text.replace(/\n/g, `
${indent}`) : text;
    };
    const write = (fd, text) => {
      const stream = streams ? fd === 1 ? streams.stdout : streams.stderr : ctl.streamFor(fd);
      if (stream)
        stream.write(`${text}
`);
      else
        ctl.writeFd(fd, `${text}
`);
    };
    const out = (...args) => write(1, format(args));
    const err = (...args) => write(2, format(args));
    const console2 = {
      log: out,
      info: out,
      debug: out,
      warn: err,
      error: err,
      trace(...args) {
        const e = new Error(format(args));
        e.name = "Trace";
        write(2, String(e.stack));
      },
      dir(value, options) {
        write(1, (util ??= rt.require("util")).inspect(value, { customInspect: false, ...options }));
      },
      dirxml: out,
      assert(ok, ...args) {
        if (!ok)
          err(`Assertion failed${args.length ? ": " : ""}${args.length ? format(args) : ""}`);
      },
      count(label = "default") {
        const n = (counts.get(label) ?? 0) + 1;
        counts.set(label, n);
        out(`${label}: ${n}`);
      },
      countReset(label = "default") {
        counts.delete(label);
      },
      time(label = "default") {
        timers.set(label, performance.now());
      },
      timeEnd(label = "default") {
        const t = timers.get(label);
        if (t !== undefined) {
          out(`${label}: ${(performance.now() - t).toFixed(3)}ms`);
          timers.delete(label);
        }
      },
      timeLog(label = "default", ...args) {
        const t = timers.get(label);
        if (t !== undefined)
          out(`${label}: ${(performance.now() - t).toFixed(3)}ms`, ...args);
      },
      group(...args) {
        if (args.length)
          out(...args);
        indent += "  ";
      },
      groupEnd() {
        indent = indent.slice(2);
      },
      table(data) {
        out(data);
      },
      clear() {},
      timeStamp() {},
      profile() {},
      profileEnd() {}
    };
    console2.groupCollapsed = console2.group;
    Object.defineProperty(console2, "Console", {
      configurable: true,
      enumerable: false,
      get: () => rt.require("console").Console
    });
    return console2;
  }

  // runtime/src/node/misc.ts
  registerBuiltin("process", (rt) => rt.process);
  registerBuiltin("timers", (rt) => {
    const l = rt.loop;
    const timers = {
      setTimeout: l.setTimeout,
      setInterval: l.setInterval,
      setImmediate: l.setImmediate,
      clearTimeout: l.clearTimeout,
      clearInterval: l.clearTimeout,
      clearImmediate: l.clearImmediate,
      active: (t) => t?.refresh?.(),
      unenroll: (t) => l.clearTimeout(t),
      enroll() {}
    };
    Object.defineProperty(timers, "promises", { enumerable: true, configurable: true, get: () => rt.require("timers/promises") });
    return timers;
  });
  registerBuiltin("tty", (rt) => {
    const isatty = (fd) => {
      try {
        return typeof fd === "number" && rt.kernel.isatty(fd);
      } catch {
        return false;
      }
    };
    const open = (fd, direction) => {
      if (!isatty(fd))
        throw Object.assign(new Error("TTY initialization failed: the descriptor is not a terminal"), { code: "ERR_TTY_INIT_FAILED" });
      return rt.ctl.ttyStream(fd, direction);
    };
    return {
      isatty,
      ReadStream: function ReadStream(fd) {
        return open(fd, "in");
      },
      WriteStream: function WriteStream(fd) {
        return open(fd, "out");
      }
    };
  });
  registerBuiltin("console", (rt) => {
    const c = createConsole(rt, rt.ctl);
    function Console(stdout, stderr) {
      const o = stdout && typeof stdout.write !== "function" ? stdout : { stdout, stderr };
      const inst = createConsole(rt, rt.ctl, { stdout: o.stdout, stderr: o.stderr ?? o.stdout });
      if (!new.target)
        return inst;
      Object.assign(this, inst);
    }
    const out = Object.assign(Object.create(null), rt.host.global.console, c);
    Object.defineProperty(out, "Console", { value: Console, enumerable: true, configurable: true, writable: true });
    return out;
  });
  registerBuiltin("constants", (rt) => ({ ...rt.require("os").constants.errno, ...SIGNALS, ...constants }));
  registerBuiltin("perf_hooks", (rt) => {
    const g = rt.host.global;

    class PerformanceObserver {
      static supportedEntryTypes = [];
      observe() {}
      disconnect() {}
      takeRecords() {
        return [];
      }
    }
    const histogram = () => ({ min: 0, max: 0, mean: 0, stddev: 0, exceeds: 0, percentiles: new Map, percentile: () => 0, reset() {}, enable: () => true, disable: () => true, record() {}, recordDelta() {} });
    return {
      performance: g.performance,
      PerformanceObserver: g.PerformanceObserver ?? PerformanceObserver,
      PerformanceEntry: g.PerformanceEntry,
      PerformanceMark: g.PerformanceMark,
      PerformanceMeasure: g.PerformanceMeasure,
      monitorEventLoopDelay: histogram,
      createHistogram: histogram,
      constants: { NODE_PERFORMANCE_GC_MAJOR: 4, NODE_PERFORMANCE_GC_MINOR: 1, NODE_PERFORMANCE_GC_INCREMENTAL: 8, NODE_PERFORMANCE_GC_WEAKCB: 16 }
    };
  });
  registerBuiltin("dns", (rt) => {
    const local = (host) => host === "localhost" || host === "" || host.endsWith(".localhost") || /^127\./.test(host) || host === "0.0.0.0" || host === "::1" || host === "host.internal";
    const isIp = (h) => /^\d+\.\d+\.\d+\.\d+$/.test(h) || h.includes(":");
    const notFound = (host, syscall) => Object.assign(new Error(`${syscall} ENOTFOUND ${host}`), { code: "ENOTFOUND", errno: -3008, syscall, hostname: host });
    function lookupSync(host, options) {
      const o = typeof options === "number" ? { family: options } : options ?? {};
      if (!local(host) && !isIp(host))
        throw notFound(host, "getaddrinfo");
      const address = isIp(host) && host !== "::1" ? host : o.family === 6 ? "::1" : "127.0.0.1";
      const family = address.includes(":") ? 6 : 4;
      return o.all ? [{ address, family }] : { address, family };
    }
    function lookup(host, options, cb) {
      if (typeof options === "function") {
        cb = options;
        options = {};
      }
      let r;
      try {
        r = lookupSync(host, options);
      } catch (e) {
        return void rt.loop.nextTick(cb, e);
      }
      if (Array.isArray(r))
        rt.loop.nextTick(cb, null, r);
      else
        rt.loop.nextTick(cb, null, r.address, r.family);
    }
    const resolve4 = (host, cb) => local(host) ? rt.loop.nextTick(cb, null, ["127.0.0.1"]) : rt.loop.nextTick(cb, notFound(host, "queryA"));
    const promises = {
      lookup: async (host, options) => lookupSync(host, options),
      resolve: async (host) => {
        if (!local(host))
          throw notFound(host, "queryA");
        return ["127.0.0.1"];
      },
      resolve4: async (host) => {
        if (!local(host))
          throw notFound(host, "queryA");
        return ["127.0.0.1"];
      },
      resolve6: async (host) => {
        if (!local(host))
          throw notFound(host, "queryAaaa");
        return ["::1"];
      },
      setServers() {},
      getServers: () => ["127.0.0.1"],
      setDefaultResultOrder() {},
      getDefaultResultOrder: () => "verbatim",
      Resolver: class {
        setServers() {}
        getServers() {
          return ["127.0.0.1"];
        }
        cancel() {}
      }
    };
    return {
      lookup,
      resolve: resolve4,
      resolve4,
      resolve6: (host, cb) => local(host) ? rt.loop.nextTick(cb, null, ["::1"]) : rt.loop.nextTick(cb, notFound(host, "queryAaaa")),
      reverse: (_ip, cb) => rt.loop.nextTick(cb, null, ["localhost"]),
      lookupService: (_a, _p, cb) => rt.loop.nextTick(cb, null, "localhost", "http"),
      setServers() {},
      getServers: () => ["127.0.0.1"],
      setDefaultResultOrder() {},
      getDefaultResultOrder: () => "verbatim",
      Resolver: promises.Resolver,
      promises,
      ADDRCONFIG: 1024,
      V4MAPPED: 2048,
      ALL: 256,
      NODATA: "ENODATA",
      NOTFOUND: "ENOTFOUND",
      SERVFAIL: "ESERVFAIL",
      TIMEOUT: "ETIMEOUT",
      CONNREFUSED: "ECONNREFUSED"
    };
  });
  registerBuiltin("dns/promises", (rt) => rt.require("dns").promises);
  registerBuiltin("sea", () => ({
    isSea: () => false,
    getAsset: () => unsupported("node:sea", "getAsset"),
    getAssetAsBlob: () => unsupported("node:sea", "getAssetAsBlob"),
    getRawAsset: () => unsupported("node:sea", "getRawAsset"),
    getAssetKeys: () => []
  }), { schemeOnly: true });
  registerBuiltin("v8", (rt) => ({
    getHeapStatistics: () => {
      const m = rt.process.memoryUsage();
      return { total_heap_size: m.heapTotal, total_heap_size_executable: 0, total_physical_size: m.heapTotal, total_available_size: 2 ** 31, used_heap_size: m.heapUsed, heap_size_limit: 2 ** 32, malloced_memory: 0, peak_malloced_memory: 0, does_zap_garbage: 0, number_of_native_contexts: 1, number_of_detached_contexts: 0, total_global_handles_size: 0, used_global_handles_size: 0, external_memory: 0 };
    },
    getHeapSpaceStatistics: () => [],
    getHeapSnapshot: () => unsupported("v8", "getHeapSnapshot"),
    writeHeapSnapshot: () => unsupported("v8", "writeHeapSnapshot"),
    setFlagsFromString() {},
    cachedDataVersionTag: () => 0,
    serialize: (v) => rt.require("buffer").Buffer.from(JSON.stringify(v)),
    deserialize: (b) => JSON.parse(new TextDecoder().decode(b)),
    setHeapSnapshotNearHeapLimit() {},
    startupSnapshot: { isBuildingSnapshot: () => false, addSerializeCallback() {}, addDeserializeCallback() {}, setDeserializeMainFunction() {} },
    isStringOneByteRepresentation: (s) => !/[^\x00-\xff]/.test(s)
  }));
  function inspector(rt) {
    const EventEmitter = rt.require("events");

    class Session extends EventEmitter {
      connect() {}
      connectToMainThread() {}
      disconnect() {}
      post(_method, params, cb) {
        const done = typeof params === "function" ? params : cb;
        const err = Object.assign(new Error("The inspector is not available in this runtime"), { code: "ERR_INSPECTOR_NOT_AVAILABLE" });
        if (typeof done === "function")
          rt.loop.nextTick(done, err);
        else
          return Promise.reject(err);
      }
    }
    return { Session, open() {}, close() {}, url: () => {
      return;
    }, waitForDebugger: () => unsupported("inspector", "waitForDebugger"), console: rt.host.global.console, Network: {} };
  }
  registerBuiltin("inspector", inspector);
  registerBuiltin("inspector/promises", inspector);
  registerBuiltin("http2", () => {
    const no = (what) => () => unsupported("http2", what);
    return {
      constants: { HTTP2_HEADER_STATUS: ":status", HTTP2_HEADER_METHOD: ":method", HTTP2_HEADER_PATH: ":path", HTTP2_HEADER_AUTHORITY: ":authority", HTTP2_HEADER_SCHEME: ":scheme", HTTP2_HEADER_CONTENT_TYPE: "content-type", HTTP2_HEADER_CONTENT_LENGTH: "content-length", NGHTTP2_CANCEL: 8, NGHTTP2_NO_ERROR: 0 },
      connect: no("connect"),
      createServer: no("createServer"),
      createSecureServer: no("createSecureServer"),
      getDefaultSettings: () => ({}),
      getPackedSettings: no("getPackedSettings"),
      getUnpackedSettings: no("getUnpackedSettings"),
      sensitiveHeaders: Symbol("nodejs.http2.sensitiveHeaders"),
      Http2ServerRequest: class Http2ServerRequest {
      },
      Http2ServerResponse: class Http2ServerResponse {
      }
    };
  });
  registerBuiltin("tls", () => {
    const no = (what) => () => unsupported("tls", what);
    return {
      connect: no("connect"),
      createServer: no("createServer"),
      createSecureContext: no("createSecureContext"),
      TLSSocket: class TLSSocket {
        constructor() {
          unsupported("tls", "TLSSocket");
        }
      },
      Server: class Server {
        constructor() {
          unsupported("tls", "Server");
        }
      },
      SecureContext: class SecureContext {
      },
      checkServerIdentity: () => {
        return;
      },
      getCiphers: () => [],
      rootCertificates: [],
      getCACertificates: () => [],
      DEFAULT_ECDH_CURVE: "auto",
      DEFAULT_MAX_VERSION: "TLSv1.3",
      DEFAULT_MIN_VERSION: "TLSv1.2",
      DEFAULT_CIPHERS: "",
      CLIENT_RENEG_LIMIT: 3,
      CLIENT_RENEG_WINDOW: 600
    };
  });
  registerBuiltin("cluster", (rt) => {
    const EventEmitter = rt.require("events");
    const c = new EventEmitter;
    return Object.assign(c, { isPrimary: true, isMaster: true, isWorker: false, workers: {}, settings: {}, fork: () => unsupported("cluster", "fork"), setupPrimary() {}, setupMaster() {}, disconnect() {}, SCHED_NONE: 1, SCHED_RR: 2 });
  });
  registerBuiltin("domain", (rt) => {
    const EventEmitter = rt.require("events");

    class Domain extends EventEmitter {
      members = [];
      add() {}
      remove() {}
      bind(fn) {
        return fn;
      }
      intercept(fn) {
        return fn;
      }
      run(fn, ...args) {
        return fn(...args);
      }
      enter() {}
      exit() {}
      dispose() {}
    }
    return { Domain, create: () => new Domain, createDomain: () => new Domain, active: null };
  });
  registerBuiltin("wasi", () => ({
    WASI: class WASI {
      constructor() {
        unsupported("wasi", "WASI");
      }
    }
  }));
  registerBuiltin("repl", () => ({ start: () => unsupported("repl", "start"), builtinModules: [] }));
  registerBuiltin("trace_events", () => ({ createTracing: () => ({ enable() {}, disable() {}, enabled: false, categories: "" }), getEnabledCategories: () => {
    return;
  } }));
  registerBuiltin("dgram", () => ({ createSocket: () => unsupported("dgram", "createSocket"), Socket: class Socket {
  } }));
  registerBuiltin("vm", (rt) => {
    const g = rt.host.global;
    const indirectEval = g.eval;
    const contexts = new WeakSet;
    const sourceUrl = (o) => {
      const name = typeof o === "string" ? o : o?.filename;
      return name ? `
//# sourceURL=${name}` : "";
    };
    const prepare = (code) => {
      if (!/\bimport\s*\(/.test(code))
        return code;
      Object.defineProperty(g, "__bat_import", { value: (s) => rt.loader.import(String(s), `${rt.kernel.getcwd()}/`), configurable: true, writable: true });
      try {
        return rt.loader.transformer.transform(code, "vm.cjs", { forceKind: "cjs", dynamicImport: "__bat_import" }).code;
      } catch {
        return code;
      }
    };
    function runInThisContext(code, options) {
      return indirectEval(prepare(String(code)) + sourceUrl(options));
    }
    function runInContext(code, context, options) {
      if (context === g || context === undefined)
        return runInThisContext(code, options);
      const fn = new g.Function("__bat_ctx", `with (__bat_ctx) { return eval(${JSON.stringify(prepare(String(code)) + sourceUrl(options))}) }`);
      const scope = new Proxy(context, {
        has: () => true,
        get: (t, key) => key === Symbol.unscopables ? undefined : (key in t) ? t[key] : g[key],
        set: (t, key, value) => {
          t[key] = value;
          return true;
        }
      });
      return fn.call(context, scope);
    }

    class Script {
      #code;
      #options;
      constructor(code, options) {
        this.#code = String(code);
        this.#options = options;
        new g.Function(this.#code.includes("import") || this.#code.includes("await") ? "" : this.#code);
      }
      runInThisContext(options) {
        return runInThisContext(this.#code, { ...asOptions(this.#options), ...asOptions(options) });
      }
      runInContext(context, options) {
        return runInContext(this.#code, context, { ...asOptions(this.#options), ...asOptions(options) });
      }
      runInNewContext(context = {}, options) {
        return runInContext(this.#code, context, { ...asOptions(this.#options), ...asOptions(options) });
      }
      createCachedData() {
        return rt.require("buffer").Buffer.alloc(0);
      }
      get cachedDataRejected() {
        return false;
      }
    }
    const asOptions = (o) => typeof o === "string" ? { filename: o } : o ?? {};
    return {
      Script,
      runInThisContext,
      runInContext,
      runInNewContext: (code, context = {}, options) => runInContext(code, context, options),
      createContext: (o = {}) => {
        contexts.add(o);
        return o;
      },
      isContext: (o) => contexts.has(o),
      compileFunction: (code, params = [], options) => new g.Function(...params, prepare(String(code)) + sourceUrl(options)),
      measureMemory: async () => ({ total: { jsMemoryEstimate: 0, jsMemoryRange: [0, 0] } }),
      constants: { USE_MAIN_CONTEXT_DEFAULT_LOADER: Symbol("USE_MAIN_CONTEXT_DEFAULT_LOADER"), DONT_CONTEXTIFY: Symbol("DONT_CONTEXTIFY") },
      SourceTextModule: class SourceTextModule {
        constructor() {
          unsupported("vm", "SourceTextModule");
        }
      },
      SyntheticModule: class SyntheticModule {
        constructor() {
          unsupported("vm", "SyntheticModule");
        }
      }
    };
  });
  function readline(rt) {
    const EventEmitter = rt.require("events");

    class Interface extends EventEmitter {
      input;
      output;
      terminal = false;
      line = "";
      cursor = 0;
      closed = false;
      history = [];
      #prompt = "> ";
      #buffer = "";
      #question;
      #decoder;
      #onData;
      #onEnd;
      constructor(input, output) {
        super();
        const o = input && typeof input.on !== "function" ? input : { input, output };
        this.input = o.input;
        this.output = o.output;
        this.#prompt = o.prompt ?? "> ";
        const { StringDecoder } = rt.require("string_decoder");
        this.#decoder = new StringDecoder("utf8");
        this.#onData = (chunk) => {
          this.#buffer += typeof chunk === "string" ? chunk : this.#decoder.write(chunk);
          let i;
          while ((i = this.#buffer.search(/\r?\n|\r(?!\n)/)) >= 0 && !(this.#buffer[i] === "\r" && i === this.#buffer.length - 1)) {
            const line = this.#buffer.slice(0, i);
            this.#buffer = this.#buffer.slice(i + (this.#buffer[i] === "\r" && this.#buffer[i + 1] === `
` ? 2 : 1));
            this.#line(line);
            if (this.closed)
              return;
          }
        };
        this.#onEnd = () => {
          if (this.#buffer) {
            const rest = this.#buffer;
            this.#buffer = "";
            this.#line(rest);
          }
          this.close();
        };
        if (this.input) {
          this.input.on("data", this.#onData);
          this.input.on("end", this.#onEnd);
          this.input.resume?.();
        }
        o.signal?.addEventListener("abort", () => this.close(), { once: true });
      }
      #line(line) {
        const q = this.#question;
        if (q) {
          this.#question = undefined;
          q(line);
        } else
          this.emit("line", line);
      }
      setPrompt(p) {
        this.#prompt = p;
      }
      getPrompt() {
        return this.#prompt;
      }
      prompt() {
        this.output?.write(this.#prompt);
      }
      question(query, options, cb) {
        if (typeof options === "function")
          cb = options;
        if (this.closed)
          throw Object.assign(new Error("readline was closed"), { code: "ERR_USE_AFTER_CLOSE" });
        this.output?.write(query);
        this.#question = cb;
      }
      write(data) {
        if (typeof data === "string")
          this.#onData(data);
      }
      pause() {
        this.input?.pause?.();
        this.emit("pause");
        return this;
      }
      resume() {
        this.input?.resume?.();
        this.emit("resume");
        return this;
      }
      close() {
        if (this.closed)
          return;
        this.closed = true;
        this.input?.removeListener?.("data", this.#onData);
        this.input?.removeListener?.("end", this.#onEnd);
        this.input?.pause?.();
        this.emit("close");
      }
      getCursorPos() {
        return { rows: 0, cols: this.cursor };
      }
      [Symbol.asyncIterator]() {
        const lines = [];
        let wake;
        this.on("line", (l) => {
          lines.push(l);
          wake?.();
        });
        this.on("close", () => wake?.());
        const self = this;
        return async function* () {
          for (;; ) {
            while (lines.length)
              yield lines.shift();
            if (self.closed)
              return;
            await new Promise((r) => wake = r);
          }
        }();
      }
      [Symbol.dispose]() {
        this.close();
      }
    }
    const esc = (stream, s, cb) => {
      stream?.write?.(s);
      cb?.();
      return true;
    };
    const api = {
      Interface,
      createInterface: (input, output) => new Interface(input, output),
      clearLine: (stream, dir, cb) => esc(stream, dir < 0 ? "\x1B[1K" : dir > 0 ? "\x1B[0K" : "\x1B[2K", cb),
      clearScreenDown: (stream, cb) => esc(stream, "\x1B[0J", cb),
      cursorTo: (stream, x, y, cb) => {
        if (typeof y === "function") {
          cb = y;
          y = undefined;
        }
        return esc(stream, typeof y === "number" ? `\x1B[${y + 1};${x + 1}H` : `\x1B[${x + 1}G`, cb);
      },
      moveCursor: (stream, dx, dy, cb) => esc(stream, (dx < 0 ? `\x1B[${-dx}D` : dx > 0 ? `\x1B[${dx}C` : "") + (dy < 0 ? `\x1B[${-dy}A` : dy > 0 ? `\x1B[${dy}B` : ""), cb),
      emitKeypressEvents() {}
    };
    api.promises = {
      Interface,
      createInterface: (input, output) => {
        const rl = new Interface(input, output);
        const question = rl.question.bind(rl);
        rl.question = (query) => new Promise((resolve) => question(query, resolve));
        return rl;
      }
    };
    return api;
  }
  registerBuiltin("readline", readline);
  registerBuiltin("readline/promises", (rt) => rt.require("readline").promises);
  registerBuiltin("assert/strict", (rt) => rt.require("assert").strict ?? rt.require("assert"));
  registerBuiltin("util/types", (rt) => rt.require("util").types);
  registerBuiltin("path/posix", (rt) => rt.require("path").posix);
  registerBuiltin("path/win32", (rt) => rt.require("path").win32);
  registerBuiltin("stream/web", (rt) => {
    const g = rt.host.global;
    const out = {};
    for (const name of ["ReadableStream", "ReadableStreamDefaultReader", "ReadableStreamBYOBReader", "ReadableStreamDefaultController", "ReadableByteStreamController", "ReadableStreamBYOBRequest", "WritableStream", "WritableStreamDefaultWriter", "WritableStreamDefaultController", "TransformStream", "TransformStreamDefaultController", "ByteLengthQueuingStrategy", "CountQueuingStrategy", "TextEncoderStream", "TextDecoderStream", "CompressionStream", "DecompressionStream"]) {
      if (g[name] !== undefined)
        out[name] = g[name];
    }
    return out;
  });
  for (const name of ["net", "http", "https", "sqlite"]) {
    registerBuiltin(name, (rt) => {
      const said = new Set;
      const missing = (what) => () => {
        if (!said.has(what)) {
          said.add(what);
          rt.ctl?.writeFd(2, `[bat] node:${name} is not available in this build: ${what} was called
`);
        }
        throw Object.assign(new Error(`node:${name} is not available in this build of the runtime (${what} was called)`), { code: "ERR_BAT_MODULE_UNAVAILABLE" });
      };
      const EventEmitter = rt.require("events");
      if (name === "sqlite")
        return { DatabaseSync: class DatabaseSync {
          constructor() {
            missing("new DatabaseSync")();
          }
        }, StatementSync: class StatementSync {
        }, constants: {} };
      const base = {
        createServer: missing("createServer"),
        connect: missing("connect"),
        createConnection: missing("createConnection"),
        request: missing("request"),
        get: missing("get"),
        isIP: (s) => /^\d+\.\d+\.\d+\.\d+$/.test(s) ? 4 : s.includes(":") ? 6 : 0,
        isIPv4: (s) => /^\d+\.\d+\.\d+\.\d+$/.test(s),
        isIPv6: (s) => s.includes(":"),
        Socket: class Socket extends EventEmitter {
          constructor() {
            super();
            missing("new Socket")();
          }
        },
        Server: class Server extends EventEmitter {
          constructor() {
            super();
            missing("new Server")();
          }
        },
        Agent: class Agent {
          options;
          constructor(options = {}) {
            this.options = options;
          }
          destroy() {}
        },
        METHODS: ["DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT"],
        STATUS_CODES: { 200: "OK", 404: "Not Found", 500: "Internal Server Error" },
        IncomingMessage: class IncomingMessage {
        },
        ServerResponse: class ServerResponse {
        },
        OutgoingMessage: class OutgoingMessage {
        },
        ClientRequest: class ClientRequest {
        },
        maxHeaderSize: 16384,
        validateHeaderName() {},
        validateHeaderValue() {}
      };
      base.globalAgent = new base.Agent;
      return base;
    }, name === "sqlite" ? { schemeOnly: true } : {});
  }

  // crates/bat-modules/js/facts.ts
  var FLAG_ASYNC = 1 << 3;
  var FLAG_IMPORT_META = 1 << 4;
  var FLAG_DYNAMIC_IMPORT = 1 << 5;
  var FLAG_USES_REQUIRE = 1 << 6;
  var FLAG_USES_MODULE = 1 << 7;
  var FLAG_USES_EXPORTS = 1 << 8;
  var FLAG_USES_FILENAME = 1 << 9;
  var FLAG_USES_DIRNAME = 1 << 10;
  var FLAG_ES_MODULE_MARKER = 1 << 11;
  var FLAG_HAS_DEFAULT = 1 << 12;
  var FLAG_HAS_REEXPORTS = 1 << 13;
  var FLAG_CODE_IS_SOURCE = 1 << 14;
  var FLAG_HAS_BLOB = 1 << 15;
  var FLAG_LOWERED = 1 << 16;
  var KINDS = ["unknown", "cjs", "esm", "json"];
  var decoder2 = new TextDecoder;
  function kindOf(word) {
    return KINDS[word & 7] ?? "unknown";
  }
  function decodeFacts(word, blob) {
    const lists = [[], [], [], [], []];
    if (word & FLAG_HAS_BLOB && blob && blob.length > 0) {
      let pos = 0;
      const varint = () => {
        let value = 0;
        let shift = 0;
        for (;; ) {
          const byte = blob[pos++];
          value |= (byte & 127) << shift;
          if (!(byte & 128))
            return value >>> 0;
          shift += 7;
        }
      };
      for (const list of lists) {
        const count = varint();
        for (let i = 0;i < count; i++) {
          const length = varint();
          list.push(decoder2.decode(blob.subarray(pos, pos + length)));
          pos += length;
        }
      }
    }
    return {
      word,
      kind: kindOf(word),
      async: (word & FLAG_ASYNC) !== 0,
      imports: lists[0],
      dynamicImports: lists[1],
      requires: lists[2],
      exports: lists[3],
      reexports: lists[4]
    };
  }

  // runtime/src/loader/resolve.ts
  var RESOLVE_IMPORT = 1;
  var RESOLVE_DIR = 2;
  var TYPES = [undefined, "commonjs", "module"];
  var SCRATCH2 = 3 * 8192 + 256;
  function createResolver(kernel) {
    const x = kernel.x;
    const inst = kernel.inst;
    const base = x.bat_alloc(SCRATCH2) >>> 0;
    const specP = base;
    const impP = base + 8192;
    const outP = base + 16384;
    const condP = base + 24576;
    const encoder3 = new TextEncoder;
    const decoder3 = new TextDecoder;
    let condKey = "module-sync";
    let condLen = 0;
    const cache = new Map;
    let cacheGen = kernel.overlayGeneration();
    const stats = { calls: 0, hits: 0, ms: 0, failures: 0 };
    const priv = new Uint8Array(8192);
    let condsWritten = false;
    const put = (s, at, cap) => {
      const u8 = inst.u8();
      const n = s.length;
      if (n <= cap) {
        let i = 0;
        for (;i < n; i++) {
          const c = s.charCodeAt(i);
          if (c > 127)
            break;
          u8[at + i] = c;
        }
        if (i === n)
          return n;
      }
      const bytes = encoder3.encode(s);
      if (bytes.length > cap)
        throw Object.assign(new Error(`ENAMETOOLONG: ${s.slice(0, 80)}\u2026`), { code: "ENAMETOOLONG" });
      u8.set(bytes, at);
      return bytes.length;
    };
    const text = (ptr, len) => {
      const u8 = inst.u8();
      priv.set(u8.subarray(ptr, ptr + len));
      return decoder3.decode(priv.subarray(0, len));
    };
    function notFound(specifier, importer, flags, rc) {
      const esm = (flags & RESOLVE_IMPORT) !== 0;
      let e;
      if (rc === -13) {
        e = new Error(specifier.startsWith("#") ? `Package import specifier "${specifier}" is not defined imported from ${importer}` : `Package subpath '${specifier}' is not defined by "exports" (imported from ${importer})`);
        e.code = specifier.startsWith("#") ? "ERR_PACKAGE_IMPORT_NOT_DEFINED" : "ERR_PACKAGE_PATH_NOT_EXPORTED";
      } else if (rc === -22) {
        e = new TypeError(`Invalid module "${specifier}" imported from ${importer}`);
        e.code = "ERR_INVALID_MODULE_SPECIFIER";
      } else if (esm) {
        const bare = !/^[./]|^file:/.test(specifier);
        e = new Error(`Cannot find ${bare ? "package" : "module"} '${specifier}' imported from ${importer}`);
        e.code = "ERR_MODULE_NOT_FOUND";
      } else {
        e = new Error(`Cannot find module '${specifier}'
Require stack:
- ${importer}`);
        e.code = "MODULE_NOT_FOUND";
        e.requireStack = [importer];
      }
      return e;
    }
    function resolve(specifier, importer, flags) {
      stats.calls++;
      const gen = kernel.overlayGeneration();
      if (gen !== cacheGen) {
        cache.clear();
        cacheGen = gen;
      }
      const dir = flags & RESOLVE_DIR ? importer : importer.slice(0, importer.lastIndexOf("/") + 1);
      const key = `${flags}${condKey}\x00${dir}\x00${specifier}`;
      const hit = cache.get(key);
      if (hit !== undefined) {
        stats.hits++;
        if (hit instanceof Error)
          throw notFound(specifier, importer, flags, hit.rc);
        return hit;
      }
      const t0 = performance.now();
      if (!condsWritten) {
        condLen = put(condKey, condP, 256);
        condsWritten = true;
      }
      const sl = put(specifier, specP, 8192);
      const il = put(importer, impP, 8192);
      const rc = x.bat_resolve(specP, sl, impP, il, flags, condP, condLen, outP, 8192);
      stats.ms += performance.now() - t0;
      if (rc < 0) {
        stats.failures++;
        cache.set(key, Object.assign(new Error("unresolved"), { rc }));
        throw notFound(specifier, importer, flags, rc);
      }
      const u8 = inst.u8();
      const out = { type: TYPES[u8[outP]], path: text(outP + 1, rc - 1) };
      cache.set(key, out);
      return out;
    }
    function packageScope(path) {
      const rc = x.bat_package_scope(specP, put(path, specP, 8192), outP, 8192);
      if (rc < 0)
        return;
      const u8 = inst.u8();
      return { type: TYPES[u8[outP]], path: text(outP + 1, rc - 1) };
    }
    return {
      resolve,
      packageScope,
      setConditions(extra) {
        condKey = ["module-sync", ...extra].join(",");
        condLen = put(condKey, condP, 256);
        cache.clear();
      },
      stats,
      kernelStats() {
        if (!x.bat_resolve_stats)
          return;
        x.bat_resolve_stats(outP);
        const f = new Float64Array(8);
        const dv = inst.dv();
        for (let i = 0;i < 8; i++)
          f[i] = dv.getFloat64(outP + i * 8, true);
        return { calls: f[0], cacheHits: f[1], stats: f[2], packageReads: f[3], packageCacheHits: f[4], ns: f[5], resultEntries: f[6], packageEntries: f[7] };
      }
    };
  }

  // runtime/src/loader/transform.ts
  var encoder3 = new TextEncoder;
  var decoder3 = new TextDecoder;
  function hash(bytes, seed) {
    let h1 = 3735928559 ^ seed;
    let h2 = 1103547991 ^ seed;
    for (let i = 0;i < bytes.length; i++) {
      const c = bytes[i];
      h1 = Math.imul(h1 ^ c, 2654435761);
      h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return (h2 >>> 0).toString(16).padStart(8, "0") + (h1 >>> 0).toString(16).padStart(8, "0");
  }
  function createTransformer(rt) {
    const kernel = rt.kernel;
    const stats = { transforms: 0, cacheHits: 0, ms: 0, bytes: 0, instantiateMs: 0 };
    let wasm;
    let cacheReady = false;
    const cacheDir = `${rt.config.cacheDir}/modules-a1`;
    function instance() {
      if (!wasm) {
        const t0 = performance.now();
        wasm = new WebAssembly.Instance(rt.wasmModule("modules"), {}).exports;
        stats.instantiateMs = performance.now() - t0;
      }
      return wasm;
    }
    function encodeOptions(o) {
      let flags = 1 << 11;
      if (o.packageType === "commonjs")
        flags |= 1;
      if (o.packageType === "module")
        flags |= 2;
      if (o.forceKind)
        flags |= (o.forceKind === "cjs" ? 1 : 2) << 2;
      const dyn = encoder3.encode(o.dynamicImport ?? "");
      const bytes = new Uint8Array(4 + 4 * 4 + dyn.length);
      const view = new DataView(bytes.buffer);
      view.setUint32(0, flags, true);
      view.setUint32(16, dyn.length, true);
      bytes.set(dyn, 20);
      return bytes;
    }
    function run(src, filename, options) {
      const w = instance();
      const put = (bytes) => {
        const p = w.bat_alloc(bytes.length || 1);
        new Uint8Array(w.memory.buffer, p, bytes.length).set(bytes);
        return p;
      };
      const name = encoder3.encode(filename);
      const opts = encodeOptions(options);
      const srcP = put(src);
      const nameP = put(name);
      const optsP = put(opts);
      let result = 0;
      try {
        result = w.bat_transform(srcP, src.length, nameP, name.length, optsP, opts.length);
        const buffer = w.memory.buffer;
        const h = new Uint32Array(buffer, result, 10);
        if (h[0] !== 1) {
          const lines = decoder3.decode(new Uint8Array(buffer, h[8], h[9])).split(`
`);
          const first = lines.find((l) => l.startsWith("E")) ?? lines[0] ?? "E\t0\t0\ttransform failed";
          const [, line, column, ...message] = first.split("\t");
          const e = new SyntaxError(`${message.join("\t")}
    at ${filename}:${line}:${column}`);
          throw e;
        }
        return {
          word: h[1],
          code: new Uint8Array(buffer, h[2], h[3]).slice(),
          blob: new Uint8Array(buffer, h[4], h[5]).slice()
        };
      } catch (e) {
        if (e instanceof WebAssembly.RuntimeError)
          wasm = undefined;
        throw e;
      } finally {
        if (wasm === w) {
          if (result)
            w.bat_result_free(result);
          w.bat_free(srcP, src.length || 1);
          w.bat_free(nameP, name.length || 1);
          w.bat_free(optsP, opts.length || 1);
        }
      }
    }
    function transform(source, filename, options = {}) {
      const src = typeof source === "string" ? encoder3.encode(source) : source;
      const dot = filename.lastIndexOf(".");
      const ext = dot > filename.lastIndexOf("/") ? filename.slice(dot + 1) : "";
      const seed = (options.packageType === "module" ? 1 : options.packageType === "commonjs" ? 2 : 0) | (options.forceKind === "cjs" ? 4 : options.forceKind === "esm" ? 8 : 0);
      const key = `${cacheDir}/${hash(src, seed)}-${src.length.toString(36)}${options.dynamicImport ? "d" : ""}.${ext || "js"}`;
      const cached = src.length >= 256 ? kernel.tryReadFile(key) : undefined;
      if (cached && cached.length >= 8) {
        const dv = new DataView(cached.buffer, cached.byteOffset, cached.byteLength);
        const word = dv.getUint32(0, true);
        const blobLen = dv.getUint32(4, true);
        stats.cacheHits++;
        return { facts: decodeFacts(word, cached.subarray(8, 8 + blobLen)), code: decoder3.decode(cached.subarray(8 + blobLen)) };
      }
      const t0 = performance.now();
      const out = run(src, filename, options);
      stats.ms += performance.now() - t0;
      stats.transforms++;
      stats.bytes += src.length;
      if (src.length >= 256) {
        try {
          if (!cacheReady) {
            kernel.mkdir(cacheDir, { recursive: true });
            cacheReady = true;
          }
          const file = new Uint8Array(8 + out.blob.length + out.code.length);
          const dv = new DataView(file.buffer);
          dv.setUint32(0, out.word, true);
          dv.setUint32(4, out.blob.length, true);
          file.set(out.blob, 8);
          file.set(out.code, 8 + out.blob.length);
          kernel.writeFile(key, file);
        } catch {}
      }
      return { facts: decodeFacts(out.word, out.blob), code: decoder3.decode(out.code) };
    }
    return { transform, stats };
  }

  // runtime/src/loader/loader.ts
  var NEW = 0;
  var LINKING = 1;
  var LINKED = 2;
  var EVALUATING = 3;
  var EVALUATED = 4;
  var FAILED = 5;
  var FACT_FAILED = 1 << 30;
  var FACT_IN_PROGRAM = 2147483648;
  var WRAP_CJS = "(function (exports, require, module, __filename, __dirname, __bat) {";
  var WRAP_ESM = "(function* (__bat) {";
  var WRAP_ESM_ASYNC = "(async function* (__bat) {";
  var dirname = (p) => {
    const i = p.lastIndexOf("/");
    return i <= 0 ? "/" : p.slice(0, i);
  };
  var extname = (p) => {
    const slash = p.lastIndexOf("/");
    const dot = p.lastIndexOf(".");
    return dot > slash + 1 ? p.slice(dot) : "";
  };
  var pathToFileURL = (path) => {
    const q = path.indexOf("?");
    const file = q < 0 ? path : path.slice(0, q);
    return `file://${encodeURI(file).replace(/[?#]/g, encodeURIComponent)}${q < 0 ? "" : path.slice(q)}`;
  };
  var fileURLToPath = (url) => {
    const u = url.slice(url.startsWith("file:///") ? 7 : url.startsWith("file://localhost/") ? 16 : 5);
    const cut = u.search(/[?#]/);
    return decodeURIComponent(cut < 0 ? u : u.slice(0, cut));
  };
  function createLoader(rt, builtins) {
    const kernel = rt.kernel;
    const g = rt.host.global;
    const records = new Map;
    const resolver = createResolver(kernel);
    const transformer = createTransformer(rt);
    const decoder4 = new TextDecoder;
    const indirectEval = g.eval;
    let main;
    const scopeTypes = new Map;
    const stats = {
      modules: 0,
      cjs: 0,
      esm: 0,
      json: 0,
      builtin: 0,
      compiled: 0,
      sourceAsCode: 0,
      transformed: 0,
      fromProgram: 0,
      readMs: 0,
      compileMs: 0,
      programMs: 0,
      programs: 0,
      bytes: 0
    };
    const defined = new Map;
    const started = new Map;
    let loadingForUse = 0;
    Object.defineProperty(g, "__bat_define", {
      value: (path, fn, startable) => {
        defined.set(path, fn);
        if (startable !== 1 || loadingForUse)
          return;
        try {
          const entry = { generator: fn.call(undefined, undefined), ready: false };
          const first = entry.generator.next();
          if (typeof first?.then === "function") {
            first.then(() => {
              entry.ready = true;
            }, () => {});
          } else
            entry.ready = true;
          started.set(fn, entry);
        } catch {}
      },
      writable: true,
      configurable: true
    });
    let programOf;
    const programLoaded = new Set;
    function programName(path) {
      if (!programOf) {
        programOf = new Map;
        const names = kernel.imageNames();
        for (let id = 0;id < names.length; id++) {
          if (names[id] === undefined)
            continue;
          const section = kernel.imageSection(id, 2);
          if (!section)
            continue;
          try {
            for (const p of JSON.parse(decoder4.decode(section))) {
              for (const m of p.modules)
                programOf.set(m, p.name);
            }
          } catch {}
        }
      }
      return programOf.get(path);
    }
    function programFunction(path) {
      const have = defined.get(path);
      if (have)
        return have;
      const name = programName(path);
      if (name === undefined || programLoaded.has(name))
        return;
      programLoaded.add(name);
      const url = rt.config.programs[name];
      if (!url)
        return;
      const t0 = performance.now();
      loadingForUse++;
      try {
        rt.host.importScripts(url);
      } catch (e) {
        loadingForUse--;
        rt.process?.emitWarning?.(`program script ${name} failed to load (${e.message}); falling back to the image`);
        return;
      }
      loadingForUse--;
      stats.programMs += performance.now() - t0;
      stats.programs++;
      rt.mark(`program ${name}`);
      return defined.get(path);
    }

    class Module {
      id;
      filename;
      path;
      exports = {};
      loaded = false;
      children = [];
      paths;
      parent;
      constructor(id = "", parent) {
        this.id = id;
        this.filename = id || null;
        this.path = id ? dirname(id) : "";
        this.parent = parent;
        this.paths = id ? nodeModulePaths(this.path) : [];
      }
      require(specifier) {
        return requireFrom(this.id, specifier);
      }
      _compile(source2, filename) {
        return compileCjs(source2, filename, this);
      }
      get isPreloading() {
        return false;
      }
    }
    function nodeModulePaths(from) {
      const out = [];
      let dir = from;
      for (;; ) {
        if (!dir.endsWith("/node_modules"))
          out.push(dir === "/" ? "/node_modules" : `${dir}/node_modules`);
        if (dir === "/")
          break;
        dir = dirname(dir);
      }
      return out;
    }
    function newNamespace() {
      const namespace = Object.create(null);
      Object.defineProperty(namespace, Symbol.toStringTag, { value: "Module" });
      return namespace;
    }
    function resolve(specifier, parentId, mode, options) {
      const builtin = builtins.canonical(specifier);
      if (builtin !== undefined)
        return `node:${builtin}`;
      if (specifier.startsWith("node:")) {
        throw Object.assign(new Error(`No such built-in module: ${specifier}`), { code: "ERR_UNKNOWN_BUILTIN_MODULE" });
      }
      let query = "";
      const c = specifier.charCodeAt(0);
      if (c === 46 || c === 47 || specifier.startsWith("file:")) {
        const q2 = specifier.search(/[?#]/);
        if (q2 >= 0) {
          query = specifier.slice(q2);
          specifier = specifier.slice(0, q2);
        }
      } else if (mode === "import" && /^(https?|data|blob):/.test(specifier)) {
        throw Object.assign(new Error(`Only URLs with a scheme in: file, data, and node are supported by the default ESM loader. Received protocol '${specifier.slice(0, specifier.indexOf(":") + 1)}'`), { code: "ERR_UNSUPPORTED_ESM_URL_SCHEME" });
      }
      const flags = mode === "import" ? RESOLVE_IMPORT : 0;
      const q = parentId.indexOf("?");
      const parent = q < 0 ? parentId : parentId.slice(0, q);
      if (options?.paths) {
        let last;
        for (const p of options.paths) {
          try {
            const r2 = resolver.resolve(specifier, p.startsWith("/") ? p : `${kernel.getcwd()}/${p}`, flags | RESOLVE_DIR);
            scopeTypes.set(r2.path, r2.type);
            return r2.path;
          } catch (e) {
            last = e;
          }
        }
        throw last ?? Object.assign(new Error(`Cannot find module '${specifier}'`), { code: "MODULE_NOT_FOUND" });
      }
      const r = resolver.resolve(specifier, parent, parent.endsWith("/") ? flags | RESOLVE_DIR : flags);
      scopeTypes.set(r.path, r.type);
      return r.path + query;
    }
    function packageTypeOf(path) {
      if (scopeTypes.has(path))
        return scopeTypes.get(path);
      const type = resolver.packageScope(path)?.type;
      scopeTypes.set(path, type);
      return type;
    }
    function compile(wrapper, code, id) {
      const t0 = performance.now();
      try {
        return indirectEval(`${wrapper}${code}
})
//# sourceURL=${id.startsWith("/") ? pathToFileURL(id).slice(7) : id}`);
      } finally {
        stats.compileMs += performance.now() - t0;
      }
    }
    function source(record) {
      const path = record.path;
      const t0 = performance.now();
      const rc = kernel.statRaw(path);
      if (rc < 0) {
        throw Object.assign(new Error(`Cannot find module '${path}'`), { code: "MODULE_NOT_FOUND" });
      }
      const word = kernel.st.facts;
      const overlay = kernel.st.dev === 0;
      let code;
      let facts;
      if (!overlay && word !== 0 && !(word & FACT_FAILED)) {
        const ready = defined.get(path);
        if (ready && !(word & FACT_IN_PROGRAM)) {
          record.facts = factsOf(path, word);
          record.kind = record.facts.kind === "esm" ? "esm" : "cjs";
          record.fn = ready;
          stats.fromProgram++;
          return;
        }
        if (word & FACT_IN_PROGRAM) {
          const fn = programFunction(path);
          if (fn) {
            record.facts = factsOf(path, word);
            record.kind = record.facts.kind === "esm" ? "esm" : "cjs";
            record.fn = fn;
            stats.fromProgram++;
            return;
          }
        } else {
          const r = kernel.readModule(path);
          stats.bytes += r.data.length;
          if (r.compiled) {
            code = decoder4.decode(r.data);
            stats.compiled++;
          } else if (word & FLAG_CODE_IS_SOURCE) {
            code = decoder4.decode(r.data);
            if (code.charCodeAt(0) === 65279)
              code = code.slice(1);
            stats.sourceAsCode++;
          } else {
            const out = transformer.transform(r.data, path, { packageType: packageTypeOf(path) });
            code = out.code;
            facts = out.facts;
            stats.transformed++;
          }
          facts ??= factsOf(path, word);
        }
      }
      if (code === undefined) {
        const data = kernel.readFile(path);
        stats.bytes += data.length;
        const out = transformer.transform(data, path, { packageType: packageTypeOf(path) });
        code = out.code;
        facts = out.facts;
        stats.transformed++;
      }
      stats.readMs += performance.now() - t0;
      record.facts = facts;
      record.kind = facts.kind === "esm" ? "esm" : "cjs";
      record.fn = compile(record.kind === "cjs" ? WRAP_CJS : facts.async ? WRAP_ESM_ASYNC : WRAP_ESM, code, record.id);
    }
    function factsOf(path, word) {
      const facts = decodeFacts(word);
      if (facts.kind !== "cjs")
        return facts;
      let lists;
      const load2 = () => lists ??= decodeFacts(word, readFactsBlob(path));
      Object.defineProperty(facts, "exports", { get: () => load2().exports, configurable: true });
      Object.defineProperty(facts, "reexports", { get: () => load2().reexports, configurable: true });
      return facts;
    }
    let blobBuf = 0;
    function readFactsBlob(path) {
      const x = kernel.x;
      if (!x.bat_module_facts)
        return;
      const u8 = () => kernel.inst.u8();
      const bytes = new TextEncoder().encode(path);
      blobBuf ||= x.bat_alloc(8192 + 65536) >>> 0;
      u8().set(bytes, blobBuf);
      let rc = x.bat_module_facts(blobBuf, bytes.length, blobBuf + 8192, 65536);
      if (rc === -34) {
        const need = new DataView(u8().buffer).getUint32(blobBuf + 8192, true);
        const p = x.bat_alloc(need) >>> 0;
        try {
          rc = x.bat_module_facts(blobBuf, bytes.length, p, need);
          return rc > 0 ? u8().slice(p, p + rc) : undefined;
        } finally {
          x.bat_free(p, need);
        }
      }
      return rc > 0 ? u8().slice(blobBuf + 8192, blobBuf + 8192 + rc) : undefined;
    }
    function load(id, parent) {
      let record = records.get(id);
      if (record)
        return record;
      const q = id.indexOf("?");
      const hash2 = id.indexOf("#");
      const cut = q < 0 ? hash2 : hash2 < 0 ? q : Math.min(q, hash2);
      const path = id.startsWith("/") && cut >= 0 ? id.slice(0, cut) : id;
      record = {
        id,
        path,
        kind: "",
        state: NEW,
        facts: undefined,
        fn: undefined,
        module: undefined,
        namespace: undefined,
        generator: undefined,
        deps: [],
        stars: [],
        pending: undefined,
        error: undefined,
        facade: undefined,
        synced: false
      };
      stats.modules++;
      if (id.startsWith("node:")) {
        record.kind = "builtin";
        record.module = { exports: builtins.require(id) };
        record.state = EVALUATED;
        stats.builtin++;
        records.set(id, record);
        return record;
      }
      records.set(id, record);
      try {
        record.module = new Module(path, parent?.module ?? null);
        if (id !== path)
          record.module.id = id;
        const ext = extname(path);
        if (ext === ".json") {
          record.kind = "json";
          stats.json++;
          return record;
        }
        if (ext === ".node") {
          throw Object.assign(new Error(`Native addons are not supported in this runtime: cannot load '${path}'. Use a WebAssembly or JavaScript build of the package.`), { code: "ERR_DLOPEN_FAILED" });
        }
        if (ext === ".wasm") {
          throw Object.assign(new TypeError(`Unknown file extension ".wasm" for ${path}`), { code: "ERR_UNKNOWN_FILE_EXTENSION" });
        }
        const hook = extensions[ext];
        if (hook && !defaultExtensions.has(hook)) {
          record.kind = "cjs";
          record.fn = () => hook(record.module, path);
          record.facts = decodeFacts(1);
          return record;
        }
        source(record);
        stats[record.kind]++;
        if (record.kind === "esm")
          record.namespace = newNamespace();
        return record;
      } catch (error) {
        records.delete(id);
        throw error;
      }
    }

    class Context {
      record;
      _meta;
      constructor(record) {
        this.record = record;
      }
      exports(getters) {
        const namespace = this.record.namespace;
        for (const name in getters)
          Object.defineProperty(namespace, name, { get: getters[name], enumerable: true });
      }
      link(specifier) {
        const record = this.record;
        try {
          const dep = load(resolve(specifier, record.id, "import"), record);
          record.deps.push(dep);
          return namespaceOf(dep);
        } catch (error) {
          record.error ??= error;
          return newNamespace();
        }
      }
      star(namespace) {
        this.record.stars.push(namespace);
      }
      import(specifier) {
        return importFrom(this.record.id, String(specifier));
      }
      get meta() {
        const record = this.record;
        return this._meta ??= {
          __proto__: null,
          dirname: dirname(record.path),
          filename: record.path,
          main: record === main,
          resolve: (specifier) => {
            const id = resolve(String(specifier), record.id, "import");
            return id.startsWith("/") ? pathToFileURL(id) : id;
          },
          url: pathToFileURL(record.id)
        };
      }
    }
    function namespaceOf(record) {
      if (record.namespace)
        return record.namespace;
      const namespace = record.namespace = newNamespace();
      const whole = { get: () => record.module.exports, enumerable: true };
      Object.defineProperty(namespace, "default", whole);
      Object.defineProperty(namespace, "module.exports", whole);
      for (const name of cjsExportNames(record, new Set))
        defineInterop(namespace, record, name);
      if (record.state === EVALUATED)
        syncNamespace(record);
      return namespace;
    }
    function defineInterop(namespace, record, name) {
      if (name in namespace)
        return;
      Object.defineProperty(namespace, name, { get: () => record.module.exports?.[name], enumerable: true, configurable: true });
    }
    function syncNamespace(record) {
      const namespace = record.namespace;
      if (!namespace || record.synced || record.kind === "esm")
        return;
      record.synced = true;
      const exports = record.module.exports;
      if (exports === null || typeof exports !== "object" && typeof exports !== "function")
        return;
      for (const name of Object.keys(exports))
        defineInterop(namespace, record, name);
    }
    function cjsExportNames(record, seen) {
      if (seen.has(record))
        return [];
      seen.add(record);
      if (record.kind === "builtin")
        return Object.keys(Object(record.module.exports));
      if (record.kind !== "cjs" || !record.facts)
        return [];
      const names = [...record.facts.exports];
      for (const specifier of record.facts.reexports) {
        try {
          names.push(...cjsExportNames(load(resolve(specifier, record.id, "require"), record), seen));
        } catch {}
      }
      return names;
    }
    function requireView(record) {
      const namespace = record.namespace;
      if ("module.exports" in namespace)
        return namespace["module.exports"];
      if (!("default" in namespace) || "__esModule" in namespace)
        return namespace;
      if (!record.facade) {
        record.facade = newNamespace();
        for (const name of Object.keys(namespace)) {
          Object.defineProperty(record.facade, name, { get: () => namespace[name], enumerable: true });
        }
        Object.defineProperty(record.facade, "__esModule", { value: true });
      }
      return record.facade;
    }
    function link(record) {
      if (record.kind !== "esm" || record.state !== NEW)
        return;
      record.state = LINKING;
      const early = started.get(record.fn);
      if (early)
        started.delete(record.fn);
      let prelude;
      if (early?.ready) {
        record.generator = early.generator;
        prelude = record.generator.next(new Context(record));
      } else {
        record.generator = record.fn.call(undefined, new Context(record));
        prelude = record.generator.next();
      }
      if (record.facts.async)
        prelude.catch(() => {});
      if (record.error) {
        record.state = FAILED;
        records.delete(record.id);
        throw record.error;
      }
      for (const dep of record.deps)
        link(dep);
      for (const from of record.stars) {
        for (const name of Object.keys(from)) {
          if (name === "default" || name === "module.exports" || name in record.namespace)
            continue;
          Object.defineProperty(record.namespace, name, { get: () => from[name], enumerable: true });
        }
      }
      record.state = LINKED;
    }
    function evaluate(record) {
      if (record.kind !== "esm")
        return void runCjs(record);
      if (record.state === FAILED)
        throw record.error;
      if (record.state >= EVALUATING)
        return record.pending;
      record.state = EVALUATING;
      const fail = (error) => {
        record.state = FAILED;
        record.error = error;
        record.pending = undefined;
        throw error;
      };
      try {
        let waits;
        for (const dep of record.deps) {
          const wait = evaluate(dep);
          if (wait)
            (waits ??= []).push(wait);
        }
        const body = () => record.facts.async ? record.generator.next() : void record.generator.next();
        const running = waits ? Promise.all(waits).then(body) : body();
        if (!running) {
          record.state = EVALUATED;
          record.generator = undefined;
          return;
        }
        record.pending = running.then(() => {
          record.state = EVALUATED;
          record.pending = undefined;
          record.generator = undefined;
        }, fail);
        record.pending.catch(() => {});
        return record.pending;
      } catch (error) {
        return fail(error);
      }
    }
    function hasAsync(record, seen = new Set) {
      if (record.kind !== "esm" || seen.has(record))
        return false;
      seen.add(record);
      if (record.state === EVALUATED)
        return false;
      return record.facts.async || record.pending !== undefined || record.deps.some((dep) => hasAsync(dep, seen));
    }
    function runCjs(record) {
      if (record.state !== NEW)
        return;
      record.state = EVALUATING;
      const module = record.module;
      try {
        if (record.kind === "json") {
          let text = kernel.readText(record.path);
          if (text.charCodeAt(0) === 65279)
            text = text.slice(1);
          try {
            module.exports = JSON.parse(text);
          } catch (e) {
            e.message = `${record.path}: ${e.message}`;
            throw e;
          }
        } else {
          const require2 = makeRequire(record.id, module);
          record.fn.call(module.exports, module.exports, require2, module, record.path, module.path, new Context(record));
        }
        module.loaded = true;
        record.state = EVALUATED;
        record.fn = undefined;
        if (record.namespace)
          syncNamespace(record);
      } catch (error) {
        records.delete(record.id);
        throw error;
      }
    }
    const defaultExtensions = new Set;
    const extensions = Object.create(null);
    for (const ext of [".js", ".json", ".node"]) {
      const fn = (module, filename) => {
        module.exports = requireFrom(filename, filename);
      };
      defaultExtensions.add(fn);
      extensions[ext] = fn;
    }
    const cache = new Proxy(Object.create(null), {
      get: (_, id) => typeof id === "string" ? records.get(id)?.module : undefined,
      set: (_, id, module) => {
        if (typeof id !== "string")
          return false;
        records.set(id, {
          id,
          path: id,
          kind: "cjs",
          state: EVALUATED,
          facts: decodeFacts(1),
          fn: undefined,
          module,
          namespace: undefined,
          generator: undefined,
          deps: [],
          stars: [],
          pending: undefined,
          error: undefined,
          facade: undefined,
          synced: false
        });
        return true;
      },
      has: (_, id) => typeof id === "string" && records.has(id),
      deleteProperty: (_, id) => typeof id === "string" && records.delete(id) || true,
      ownKeys: () => [...records.keys()].filter((k) => !k.startsWith("node:")),
      getOwnPropertyDescriptor: (_, id) => typeof id === "string" && records.has(id) ? { value: records.get(id).module, enumerable: true, configurable: true, writable: true } : undefined
    });
    function makeRequire(parentId, module) {
      const require2 = (specifier) => {
        if (typeof specifier !== "string") {
          throw Object.assign(new TypeError(`The "id" argument must be of type string. Received ${specifier === null ? "null" : typeof specifier}`), { code: "ERR_INVALID_ARG_TYPE" });
        }
        return requireFrom(parentId, specifier, module);
      };
      require2.resolve = (specifier, options) => {
        const id = resolve(String(specifier), parentId, "require", options);
        return id.startsWith("node:") && !String(specifier).startsWith("node:") ? id.slice(5) : id;
      };
      require2.resolve.paths = (specifier) => builtins.canonical(specifier) !== undefined ? null : /^\.\.?\//.test(specifier) ? [dirname(parentId)] : nodeModulePaths(dirname(parentId));
      require2.cache = cache;
      require2.extensions = extensions;
      Object.defineProperty(require2, "main", { get: () => main?.module, enumerable: true, configurable: true });
      return require2;
    }
    function requireFrom(parentId, specifier, parentModule) {
      const id = resolve(specifier, parentId, "require");
      let record = records.get(id);
      if (!record) {
        record = load(id, parentModule ? { module: parentModule } : undefined);
        if (parentModule && record.module instanceof Module)
          parentModule.children.push(record.module);
      }
      if (record.kind !== "esm") {
        if (record.state === NEW)
          runCjs(record);
        return record.module.exports;
      }
      link(record);
      if (hasAsync(record)) {
        throw Object.assign(new Error(`require() cannot be used on an ESM graph with top-level await. Use import() instead. To see where the top-level await comes from, use --experimental-print-required-tla.
  From ${parentId} 
  Requiring ${record.id}`), { code: "ERR_REQUIRE_ASYNC_MODULE" });
      }
      evaluate(record);
      return requireView(record);
    }
    async function importFrom(parentId, specifier) {
      await null;
      return importNow(parentId, specifier);
    }
    function importNow(parentId, specifier) {
      const record = load(resolve(specifier, parentId, "import"));
      if (record.kind === "esm") {
        link(record);
        const wait = evaluate(record);
        if (wait)
          return wait.then(() => record.namespace);
        return record.namespace;
      }
      runCjs(record);
      return namespaceOf(record);
    }
    function compileCjs(sourceText, filename, module) {
      const out = transformer.transform(sourceText, /\.[cm]?[jt]sx?$/.test(filename) ? filename : `${filename}.js`, { forceKind: "cjs" });
      const fn = compile(WRAP_CJS, out.code, filename);
      const record = records.get(filename) ?? { id: filename, path: filename, module };
      const require2 = makeRequire(filename, module);
      return fn.call(module.exports, module.exports, require2, module, filename, dirname(filename), new Context(record));
    }
    function start(record) {
      main = record;
      if (record.kind === "esm") {
        link(record);
        return evaluate(record);
      }
      runCjs(record);
      return;
    }
    const loader = {
      records,
      resolver,
      transformer,
      Module,
      stats,
      runMain(path) {
        const cwd = kernel.getcwd();
        const id = resolver.resolve(path.startsWith("/") ? path : `./${path}`, `${cwd === "/" ? "" : cwd}/`, RESOLVE_DIR);
        scopeTypes.set(id.path, id.type);
        return start(load(id.path));
      },
      runSource(sourceText, name, kind) {
        const cwd = kernel.getcwd();
        const id = `${cwd === "/" ? "" : cwd}/${name}`;
        const out = transformer.transform(sourceText, `${id}.${kind === "esm" ? "mjs" : "js"}`, kind ? { forceKind: kind } : {});
        const record = {
          id,
          path: id,
          kind: out.facts.kind === "esm" ? "esm" : "cjs",
          state: NEW,
          facts: out.facts,
          fn: undefined,
          module: new Module(id, null),
          namespace: undefined,
          generator: undefined,
          deps: [],
          stars: [],
          pending: undefined,
          error: undefined,
          facade: undefined,
          synced: false
        };
        record.fn = compile(record.kind === "cjs" ? WRAP_CJS : out.facts.async ? WRAP_ESM_ASYNC : WRAP_ESM, out.code, name);
        if (record.kind === "esm")
          record.namespace = newNamespace();
        records.set(id, record);
        return start(record);
      },
      import: (specifier, parentId) => importFrom(parentId, specifier),
      require: (specifier, parentId) => requireFrom(parentId, specifier),
      createRequire: (parentId) => makeRequire(parentId),
      resolve,
      compileCjs,
      main: () => main?.module,
      programUrls(names) {
        const urls = [];
        for (const name of names) {
          const url = rt.config.programs[name];
          if (!url || programLoaded.has(name))
            continue;
          programLoaded.add(name);
          stats.programs++;
          urls.push(url);
        }
        return urls;
      },
      programUrl(path) {
        let real = path;
        try {
          real = kernel.realpath(path);
        } catch {
          return;
        }
        const name = programName(real);
        if (name === undefined || programLoaded.has(name) || defined.has(real))
          return;
        programLoaded.add(name);
        stats.programs++;
        return rt.config.programs[name];
      }
    };
    Module._extensions = extensions;
    Module._cache = cache;
    Module._nodeModulePaths = nodeModulePaths;
    return loader;
  }

  // runtime/src/node/module.ts
  function createModule(rt) {
    const loader = rt.loader;
    const Module = loader.Module;
    const builtins = () => rt.builtins;
    const toFilename = (from) => {
      const s = from instanceof URL ? from.href : String(from);
      if (s.startsWith("file:"))
        return fileURLToPath(s);
      if (!s.startsWith("/")) {
        throw Object.assign(new TypeError(`The argument 'filename' must be a file URL object, file URL string, or absolute path string. Received '${s}'`), { code: "ERR_INVALID_ARG_VALUE" });
      }
      return s;
    };
    const cwdFile = () => {
      const cwd = rt.kernel.getcwd();
      return `${cwd === "/" ? "" : cwd}/`;
    };
    Module.Module = Module;
    Module.createRequire = (from) => loader.createRequire(toFilename(from));
    Module.builtinModules = builtins().names();
    Module.isBuiltin = (id) => typeof id === "string" && builtins().canonical(id) !== undefined;
    Module.register = () => {};
    Module.registerHooks = () => ({ deregister() {} });
    Module.syncBuiltinESMExports = () => {};
    Module.findSourceMap = () => {
      return;
    };
    Module.SourceMap = class SourceMap {
      payload;
      constructor(payload) {
        this.payload = payload;
      }
      findEntry() {
        return {};
      }
      findOrigin() {
        return {};
      }
    };
    Module.globalPaths = [];
    Module.wrapper = ["(function (exports, require, module, __filename, __dirname) { ", `
});`];
    Module.wrap = (code) => Module.wrapper[0] + code + Module.wrapper[1];
    Module._resolveFilename = (request, parent, _isMain, options) => {
      const id = loader.resolve(String(request), parent?.filename ?? parent?.id ?? cwdFile(), "require", options);
      return id.startsWith("node:") && !String(request).startsWith("node:") ? id.slice(5) : id;
    };
    Module._load = (request, parent) => loader.require(String(request), parent?.filename ?? parent?.id ?? cwdFile());
    Module._findPath = (request, paths) => {
      try {
        return loader.resolve(request, cwdFile(), "require", { paths });
      } catch {
        return false;
      }
    };
    Module._resolveLookupPaths = (request, parent) => /^\.\.?\//.test(request) ? [parent?.path ?? "."] : Module._nodeModulePaths(parent?.path ?? rt.kernel.getcwd());
    Module._initPaths = () => {};
    Module._preloadModules = () => {};
    Module._pathCache = Object.create(null);
    Module.runMain = (main = rt.process.argv[1]) => loader.runMain(main);
    Module.findPackageJSON = (specifier, base) => {
      const from = base === undefined ? undefined : toFilename(base);
      let target;
      const s = specifier instanceof URL ? specifier.href : String(specifier);
      if (s.startsWith("file:"))
        target = fileURLToPath(s);
      else if (s.startsWith("/"))
        target = s;
      else {
        try {
          target = loader.resolve(s, from ?? cwdFile(), "import");
        } catch {
          return;
        }
      }
      return loader.resolver.packageScope(target)?.path;
    };
    Module.enableCompileCache = () => ({ status: 3, message: "Compile cache is managed by the host runtime" });
    Module.getCompileCacheDir = () => {
      return;
    };
    Module.flushCompileCache = () => {};
    Module.constants = { compileCacheStatus: { FAILED: 0, ENABLED: 1, ALREADY_ENABLED: 2, DISABLED: 3 } };
    Module.stripTypeScriptTypes = () => {
      throw Object.assign(new Error("module.stripTypeScriptTypes is not implemented in this runtime"), { code: "ERR_METHOD_NOT_IMPLEMENTED" });
    };
    Module.getSourceMapsSupport = () => ({ enabled: false, nodeModules: false, generatedCode: false });
    Module.setSourceMapsSupport = () => {};
    return Module;
  }
  registerBuiltin("module", createModule);

  // runtime/src/node/os.ts
  registerBuiltin("os", (rt) => {
    const env = () => rt.process.env;
    const cpu = { model: "WebAssembly", speed: 0, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } };
    const errno = { E2BIG: 7, EACCES: 13, EADDRINUSE: 98, EADDRNOTAVAIL: 99, EAGAIN: 11, EBADF: 9, EBUSY: 16, ECONNABORTED: 103, ECONNREFUSED: 111, ECONNRESET: 104, EEXIST: 17, EINTR: 4, EINVAL: 22, EIO: 5, EISDIR: 21, EMFILE: 24, ENOENT: 2, ENOMEM: 12, ENOSPC: 28, ENOSYS: 38, ENOTDIR: 20, ENOTEMPTY: 39, ENOTSUP: 95, EPERM: 1, EPIPE: 32, ERANGE: 34, EROFS: 30, ETIMEDOUT: 110, EXDEV: 18 };
    const os = {
      EOL: `
`,
      devNull: "/dev/null",
      arch: () => rt.process.arch,
      machine: () => "wasm32",
      platform: () => "linux",
      type: () => "Linux",
      release: () => "6.8.0-bat",
      version: () => "#1 SMP bat-kernel",
      hostname: () => "localhost",
      homedir: () => env().HOME || "/home/user",
      tmpdir: () => {
        const t = env().TMPDIR || env().TMP || env().TEMP || "/tmp";
        return t.length > 1 && t.endsWith("/") ? t.slice(0, -1) : t;
      },
      endianness: () => "LE",
      cpus: () => [{ ...cpu }],
      availableParallelism: () => 1,
      totalmem: () => 4 * 2 ** 30,
      freemem: () => 2 * 2 ** 30,
      uptime: () => performance.now() / 1000,
      loadavg: () => [0, 0, 0],
      networkInterfaces: () => ({ lo: [{ address: "127.0.0.1", netmask: "255.0.0.0", family: "IPv4", mac: "00:00:00:00:00:00", internal: true, cidr: "127.0.0.1/8" }] }),
      userInfo: (options) => {
        return { uid: 1000, gid: 1000, username: env().USER || "user", homedir: os.homedir(), shell: "/bin/sh" };
      },
      getPriority: () => 0,
      setPriority: () => {},
      constants: { signals: SIGNALS, errno, priority: { PRIORITY_LOW: 19, PRIORITY_BELOW_NORMAL: 10, PRIORITY_NORMAL: 0, PRIORITY_ABOVE_NORMAL: -7, PRIORITY_HIGH: -14, PRIORITY_HIGHEST: -20 }, dlopen: {}, UV_UDP_REUSEADDR: 4 }
    };
    return os;
  });

  // runtime/src/node/worker_threads.ts
  function create3(rt) {
    const EventEmitter = rt.require("events");
    const loop = rt.loop;
    const g = rt.host.global;
    const env = new Map;
    const untransferable = new WeakSet;

    class MessagePort extends EventEmitter {
      _other;
      _queue = [];
      _started = false;
      _closed = false;
      _refed = false;
      _scheduled = false;
      _onmessage = null;
      _wrapped = new Map;
      constructor() {
        super();
        this.on("newListener", (name) => {
          if (name === "message") {
            this.start();
            this.ref();
          }
        });
        this.on("removeListener", (name) => {
          if (name === "message" && this.listenerCount("message") === 0)
            this.unref();
        });
      }
      postMessage(value, transfer) {
        const other = this._other;
        if (this._closed || !other || other._closed)
          return;
        const list = (Array.isArray(transfer) ? transfer : transfer?.transfer ?? []).filter((t) => !(t instanceof MessagePort));
        other._queue.push(g.structuredClone(value, list.length ? { transfer: list } : undefined));
        other._schedule();
      }
      _schedule() {
        if (!this._started || this._scheduled || this._closed)
          return;
        this._scheduled = true;
        loop.setImmediate(() => {
          this._scheduled = false;
          while (this._queue.length && this._started && !this._closed)
            this.emit("message", this._queue.shift());
        });
      }
      start() {
        if (!this._started) {
          this._started = true;
          this._schedule();
        }
      }
      close(cb) {
        if (this._closed)
          return;
        this._closed = true;
        this.unref();
        const other = this._other;
        if (typeof cb === "function")
          this.once("close", cb);
        loop.setImmediate(() => this.emit("close"));
        if (other && !other._closed)
          other.close();
      }
      ref() {
        if (!this._refed && !this._closed) {
          this._refed = true;
          loop.ref();
        }
      }
      unref() {
        if (this._refed) {
          this._refed = false;
          loop.unref();
        }
      }
      hasRef() {
        return this._refed;
      }
      get onmessage() {
        return this._onmessage;
      }
      set onmessage(fn) {
        if (this._onmessage)
          this.removeEventListener("message", this._onmessage);
        this._onmessage = typeof fn === "function" ? fn : null;
        if (this._onmessage)
          this.addEventListener("message", this._onmessage);
      }
      addEventListener(type, fn) {
        if (typeof fn !== "function" && typeof fn?.handleEvent !== "function")
          return;
        if (this._wrapped.has(fn))
          return;
        const wrapped = (data) => {
          const ev = type === "message" ? new g.MessageEvent("message", { data }) : new g.Event(type);
          if (typeof fn === "function")
            fn.call(this, ev);
          else
            fn.handleEvent(ev);
        };
        this._wrapped.set(fn, wrapped);
        this.on(type, wrapped);
      }
      removeEventListener(type, fn) {
        const wrapped = this._wrapped.get(fn);
        if (wrapped) {
          this._wrapped.delete(fn);
          this.off(type, wrapped);
        }
      }
      dispatchEvent(ev) {
        this.emit(ev.type, ev.data);
        return true;
      }
      [Symbol.dispose]() {
        this.close();
      }
    }

    class MessageChannel {
      port1 = new MessagePort;
      port2 = new MessagePort;
      constructor() {
        this.port1._other = this.port2;
        this.port2._other = this.port1;
      }
    }
    function receiveMessageOnPort(port) {
      if (!(port instanceof MessagePort))
        throw Object.assign(new TypeError('The "port" argument must be a MessagePort instance'), { code: "ERR_INVALID_ARG_TYPE" });
      return port._queue.length ? { message: port._queue.shift() } : undefined;
    }
    const proc = rt.process;
    let thread;
    if (proc.env.BAT_WORKER_THREAD) {
      try {
        thread = JSON.parse(proc.env.BAT_WORKER_THREAD);
      } catch {}
      delete proc.env.BAT_WORKER_THREAD;
    }
    let parentPort = null;
    if (thread) {
      rt.require("child_process");
      parentPort = new EventEmitter;
      parentPort.postMessage = (value) => void proc.send?.(value === undefined ? null : value);
      parentPort.close = () => proc.disconnect?.();
      parentPort.ref = parentPort.unref = () => parentPort;
      parentPort.start = () => {};
      const deliver = (message) => parentPort.emit("message", message);
      parentPort.on("newListener", (name) => {
        if (name === "message" && parentPort.listenerCount("message") === 0)
          proc.on("message", deliver);
      });
      parentPort.on("removeListener", (name) => {
        if (name === "message" && parentPort.listenerCount("message") === 0)
          proc.off("message", deliver);
      });
      proc.on("disconnect", () => proc.exit());
    }
    let nextThread = 1;

    class Worker extends EventEmitter {
      threadId;
      _child;
      _code;
      constructor(filename, options = {}) {
        super();
        const fs = rt.require("fs");
        this.threadId = nextThread++;
        let file = filename instanceof g.URL ? rt.require("url").fileURLToPath(filename) : String(filename);
        let scratch;
        if (options.eval) {
          scratch = file = `/tmp/.worker-${proc.pid}-${this.threadId}.${options.type === "module" ? "mjs" : "cjs"}`;
          fs.writeFileSync(file, String(filename));
        }
        const env2 = options.env && typeof options.env === "object" ? options.env : proc.env;
        this._child = rt.require("child_process").fork(file, options.argv ?? [], {
          env: { ...env2, BAT_WORKER_THREAD: JSON.stringify({ threadId: this.threadId, workerData: options.workerData ?? null }) },
          execArgv: options.execArgv ?? [],
          stdio: ["ignore", "inherit", "inherit", "ipc"]
        });
        this._child.on("spawn", () => this.emit("online"));
        this._child.on("message", (message) => this.emit("message", message));
        this._child.on("error", (e) => this.emit("error", e));
        this._child.on("exit", (code) => {
          this._code = code ?? 1;
          if (scratch)
            fs.rmSync(scratch, { force: true });
          this.emit("exit", this._code);
        });
      }
      postMessage(value) {
        if (this._code === undefined && this._child.connected)
          this._child.send(value === undefined ? null : value);
      }
      terminate() {
        return new Promise((resolve) => {
          if (this._code !== undefined)
            return resolve(this._code);
          this.once("exit", resolve);
          this._child.kill("SIGKILL");
        });
      }
      ref() {
        this._child.ref();
      }
      unref() {
        this._child.unref();
      }
    }
    return {
      isMainThread: !thread,
      isInternalThread: false,
      parentPort,
      workerData: thread?.workerData ?? null,
      threadId: thread?.threadId ?? 0,
      resourceLimits: {},
      SHARE_ENV: Symbol.for("nodejs.worker_threads.SHARE_ENV"),
      Worker,
      MessageChannel,
      MessagePort,
      BroadcastChannel: g.BroadcastChannel,
      receiveMessageOnPort,
      markAsUntransferable: (o) => void untransferable.add(o),
      isMarkedAsUntransferable: (o) => untransferable.has(o),
      markAsUncloneable() {},
      moveMessagePortToContext: (port) => port,
      getEnvironmentData: (key) => env.get(key),
      setEnvironmentData: (key, value) => void (value === undefined ? env.delete(key) : env.set(key, value)),
      postMessageToThread: () => unsupported("worker_threads", "postMessageToThread")
    };
  }
  registerBuiltin("worker_threads", create3);

  // runtime/src/node/crypto.ts
  var natives = new WeakMap;
  function nativeOf(rt) {
    let native = natives.get(rt);
    if (native)
      return native;
    const x = new WebAssembly.Instance(rt.wasmModule("native"), {}).exports;
    let bytes = new Uint8Array(x.memory.buffer);
    const mem = () => bytes.byteLength === 0 ? bytes = new Uint8Array(x.memory.buffer) : bytes;
    const registry = typeof FinalizationRegistry === "function" ? new FinalizationRegistry((free) => free()) : undefined;
    native = {
      x,
      mem,
      call(inputs, outLength, fn) {
        let total = outLength;
        for (const input of inputs)
          total += input.length;
        const base = x.bat_alloc(total);
        try {
          const pointers = [];
          let at = base;
          const view = mem();
          for (const input of inputs) {
            view.set(input, at);
            pointers.push(at);
            at += input.length;
          }
          fn(pointers, at);
          return mem().slice(at, at + outLength);
        } finally {
          x.bat_free(base, total);
        }
      },
      track: (owner, free) => registry?.register(owner, free, owner),
      untrack: (owner) => void registry?.unregister(owner)
    };
    natives.set(rt, native);
    return native;
  }
  var HASHES = ["md5", "sha1", "sha224", "sha256", "sha384", "sha512", "sha512-256"];
  var DIGEST_SIZE = [16, 20, 28, 32, 48, 64, 32];
  var SCRATCH_LIMIT = 1 << 20;
  var CBC = 0;
  var CTR = 1;
  var GCM = 2;
  var CIPHERS = {};
  for (const bits of [128, 192, 256]) {
    CIPHERS[`aes-${bits}-cbc`] = { mode: CBC, key: bits / 8, iv: 16 };
    CIPHERS[`aes-${bits}-ctr`] = { mode: CTR, key: bits / 8, iv: 16 };
    CIPHERS[`aes-${bits}-gcm`] = { mode: GCM, key: bits / 8, iv: 12 };
  }
  var UNAVAILABLE = [
    "createSign",
    "createVerify",
    "sign",
    "verify",
    "Sign",
    "Verify",
    "generateKeyPair",
    "generateKeyPairSync",
    "generateKey",
    "generateKeySync",
    "publicEncrypt",
    "publicDecrypt",
    "privateEncrypt",
    "privateDecrypt",
    "createPublicKey",
    "createPrivateKey",
    "createECDH",
    "ECDH",
    "createDiffieHellman",
    "createDiffieHellmanGroup",
    "getDiffieHellman",
    "DiffieHellman",
    "DiffieHellmanGroup",
    "diffieHellman",
    "X509Certificate",
    "Certificate",
    "generatePrime",
    "generatePrimeSync",
    "checkPrime",
    "checkPrimeSync",
    "argon2",
    "argon2Sync",
    "encapsulate",
    "decapsulate",
    "setEngine",
    "setFips",
    "secureHeapUsed"
  ];
  var HEX = [];
  for (let i = 0;i < 256; i++)
    HEX.push((i < 16 ? "0" : "") + i.toString(16));
  function coded(error, code) {
    error.code = code;
    return error;
  }
  function argType(name, expected, value) {
    const got = value === null ? "null" : typeof value === "object" ? `an instance of ${value.constructor?.name ?? "Object"}` : `type ${typeof value} (${String(value)})`;
    return coded(new TypeError(`The "${name}" argument must be ${expected}. Received ${got}`), "ERR_INVALID_ARG_TYPE");
  }
  function createCrypto(rt) {
    const { Buffer } = rt.require("buffer");
    const stream = rt.require("stream");
    const webcrypto = rt.host?.global?.crypto ?? globalThis.crypto;
    const encoder4 = new TextEncoder;
    let cached;
    const native = () => cached ?? (cached = nativeOf(rt));
    const kState = Symbol("kState");
    const asBytes = (value, name, encoding) => {
      if (typeof value === "string")
        return Buffer.from(value, encoding === "buffer" ? "utf8" : encoding);
      if (value instanceof Uint8Array)
        return value;
      if (ArrayBuffer.isView(value))
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      if (value instanceof ArrayBuffer || typeof SharedArrayBuffer === "function" && value instanceof SharedArrayBuffer)
        return new Uint8Array(value);
      throw argType(name, "of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView", value);
    };
    const keyBytes = (key, name = "key", encoding) => key instanceof KeyObject ? key[kState] : asBytes(key, name, encoding);
    const algIds = new Map;
    const lookupAlg = (name) => {
      let id = algIds.get(name);
      if (id !== undefined)
        return id;
      if (typeof name !== "string")
        throw argType("algorithm", "of type string", name);
      const plain = name.toLowerCase().replace(/^rsa-/, "").replace(/^sha-/, "sha").replace("sha512/256", "sha512-256");
      id = HASHES.indexOf(plain);
      if (id >= 0)
        algIds.set(name, id);
      return id;
    };
    const algId = (name) => {
      const id = lookupAlg(name);
      if (id < 0)
        throw coded(new Error("Digest method not supported"), "ERR_OSSL_EVP_UNSUPPORTED");
      return id;
    };
    const digestId = (name) => {
      const id = lookupAlg(name);
      if (id < 0)
        throw coded(new TypeError(`Invalid digest: ${name}`), "ERR_CRYPTO_INVALID_DIGEST");
      return id;
    };
    const uint = (value, name, min, max) => {
      if (typeof value !== "number")
        throw argType(name, "of type number", value);
      if (!Number.isInteger(value) || value < min || value > max) {
        throw coded(new RangeError(`The value of "${name}" is out of range. It must be >= ${min} && <= ${max}. Received ${value}`), "ERR_OUT_OF_RANGE");
      }
      return value;
    };
    const callback = (cb, name = "callback") => {
      if (typeof cb !== "function")
        throw argType(name, "of type function", cb);
      return cb;
    };
    const later = (cb, work) => {
      rt.loop.defer(() => {
        let value;
        try {
          value = work();
        } catch (error) {
          return cb(error);
        }
        cb(null, value);
      });
    };
    const encoded = (bytes, encoding) => encoding && encoding !== "buffer" ? bytes.toString(encoding) : bytes;
    let scratchPointer = 0;
    let scratchCapacity = 0;
    let scratchOwner = null;
    let outPointer = 0;
    const reserve = (need) => {
      if (need <= scratchCapacity)
        return;
      const { x, mem } = native();
      const capacity = Math.max(need, scratchCapacity * 2, 1 << 16);
      const pointer = x.bat_alloc(capacity);
      if (scratchCapacity) {
        if (scratchOwner?.used)
          mem().copyWithin(pointer, scratchPointer, scratchPointer + scratchOwner.used);
        x.bat_free(scratchPointer, scratchCapacity);
      }
      scratchPointer = pointer;
      scratchCapacity = capacity;
    };
    const spill = (state) => {
      const n = native();
      if (!state.handle) {
        if (state.key) {
          const key = state.key;
          n.call([key], 0, ([pointer]) => state.handle = n.x.bat_hmac_new(state.alg, pointer, key.length));
          state.key = null;
        } else {
          state.handle = n.x.bat_hash_new(state.alg);
        }
        const handle = state.handle;
        n.track(state, () => n.x.bat_hash_free(handle));
      }
      if (state.used) {
        n.x.bat_hash_update(state.handle, scratchPointer, state.used);
        state.used = 0;
      }
    };
    const own = (state) => {
      if (scratchOwner === state)
        return;
      if (scratchOwner?.used)
        spill(scratchOwner);
      scratchOwner = state;
    };
    const feed = (state, data) => {
      const length = data.length;
      if (length === 0)
        return;
      own(state);
      if (state.used + length > SCRATCH_LIMIT) {
        spill(state);
        if (length > SCRATCH_LIMIT) {
          const { x, mem } = native();
          reserve(SCRATCH_LIMIT);
          for (let at = 0;at < length; at += SCRATCH_LIMIT) {
            const part = data.subarray(at, Math.min(at + SCRATCH_LIMIT, length));
            mem().set(part, scratchPointer);
            x.bat_hash_update(state.handle, scratchPointer, part.length);
          }
          return;
        }
      }
      reserve(state.used + length);
      native().mem().set(data, scratchPointer + state.used);
      state.used += length;
    };
    const feedText = (state, text) => {
      const room = text.length * 3;
      const used = scratchOwner === state ? state.used : 0;
      if (used + room > SCRATCH_LIMIT)
        return feed(state, Buffer.from(text, "utf8"));
      if (room === 0)
        return;
      own(state);
      reserve(used + room);
      const at = scratchPointer + used;
      state.used = used + encoder4.encodeInto(text, native().mem().subarray(at, at + room)).written;
    };
    const update = (state, data, encoding) => {
      if (state.done)
        throw coded(new Error("Digest already called"), "ERR_CRYPTO_HASH_FINALIZED");
      if (typeof data === "string") {
        if (encoding === undefined || encoding === "utf8" || encoding === "utf-8" || encoding === "buffer")
          feedText(state, data);
        else
          feed(state, Buffer.from(data, encoding));
      } else if (data instanceof Uint8Array) {
        feed(state, data);
      } else if (ArrayBuffer.isView(data)) {
        feed(state, new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
      } else {
        throw argType("data", "of type string or an instance of Buffer, TypedArray, or DataView", data);
      }
    };
    const finish = (state) => {
      const { x, mem, untrack } = native();
      if (!outPointer)
        outPointer = x.bat_alloc(64);
      let length;
      if (state.handle) {
        spill(state);
        length = x.bat_hash_final(state.handle, outPointer);
        untrack(state);
        state.handle = 0;
      } else if (state.key) {
        const key = state.key;
        own(state);
        reserve(state.used + key.length);
        mem().set(key, scratchPointer + state.used);
        length = x.bat_hmac_oneshot(state.alg, scratchPointer + state.used, key.length, scratchPointer, state.used, outPointer);
      } else {
        length = x.bat_hash_oneshot(state.alg, scratchPointer, scratchOwner === state ? state.used : 0, outPointer);
      }
      if (scratchOwner === state)
        scratchOwner = null;
      state.used = 0;
      state.done = true;
      return length;
    };
    const output = (length, encoding) => {
      const view = native().mem();
      if (encoding === "hex") {
        let text = "";
        for (let i = outPointer, end = outPointer + length;i < end; i++)
          text += HEX[view[i]];
        return text;
      }
      return encoded(Buffer.from(view.subarray(outPointer, outPointer + length)), encoding);
    };
    const newState = (alg, key) => ({ alg, key, handle: 0, used: 0, done: false });
    function LazyTransform(options) {
      this._options = options;
    }
    Object.setPrototypeOf(LazyTransform.prototype, stream.Transform.prototype);
    Object.setPrototypeOf(LazyTransform, stream.Transform);
    for (const name of ["_readableState", "_writableState"]) {
      Object.defineProperty(LazyTransform.prototype, name, {
        configurable: true,
        enumerable: true,
        get() {
          stream.Transform.call(this, this._options);
          this._writableState.decodeStrings = false;
          return this[name];
        },
        set(value) {
          Object.defineProperty(this, name, { value, enumerable: true, configurable: true, writable: true });
        }
      });
    }
    function Hash(algorithm, options) {
      if (!(this instanceof Hash))
        return new Hash(algorithm, options);
      this[kState] = newState(algId(algorithm), null);
      LazyTransform.call(this, options);
    }
    Object.setPrototypeOf(Hash.prototype, LazyTransform.prototype);
    Object.setPrototypeOf(Hash, LazyTransform);
    Hash.prototype.update = function(data, encoding) {
      update(this[kState], data, encoding);
      return this;
    };
    Hash.prototype.digest = function(encoding) {
      const state = this[kState];
      if (state.done)
        throw coded(new Error("Digest already called"), "ERR_CRYPTO_HASH_FINALIZED");
      return output(finish(state), encoding);
    };
    Hash.prototype.copy = function(options) {
      const state = this[kState];
      if (state.done)
        throw coded(new Error("Digest already called"), "ERR_CRYPTO_HASH_FINALIZED");
      const copy = Object.create(Hash.prototype);
      const next = newState(state.alg, null);
      if (state.handle || state.used) {
        spill(state);
        const n = native();
        const handle = next.handle = n.x.bat_hash_copy(state.handle);
        n.track(next, () => n.x.bat_hash_free(handle));
      }
      copy[kState] = next;
      LazyTransform.call(copy, options);
      return copy;
    };
    Hash.prototype._transform = function(chunk, encoding, done) {
      update(this[kState], chunk, encoding);
      done();
    };
    Hash.prototype._flush = function(done) {
      this.push(this.digest());
      done();
    };
    function Hmac(algorithm, key, options) {
      if (!(this instanceof Hmac))
        return new Hmac(algorithm, key, options);
      const id = algId(algorithm);
      this[kState] = newState(id, Uint8Array.from(keyBytes(key, "key", options?.encoding)));
      LazyTransform.call(this, options);
    }
    Object.setPrototypeOf(Hmac.prototype, LazyTransform.prototype);
    Object.setPrototypeOf(Hmac, LazyTransform);
    Hmac.prototype.update = Hash.prototype.update;
    Hmac.prototype.digest = function(encoding) {
      const state = this[kState];
      if (state.done)
        return encoded(Buffer.alloc(0), encoding);
      return output(finish(state), encoding);
    };
    Hmac.prototype._transform = Hash.prototype._transform;
    Hmac.prototype._flush = Hash.prototype._flush;
    const hash2 = (algorithm, data, outputEncoding = "hex") => {
      const state = newState(algId(algorithm), null);
      update(state, data);
      return output(finish(state), outputEncoding);
    };
    const fillRandom = (bytes) => {
      for (let at = 0;at < bytes.length; at += 65536)
        webcrypto.getRandomValues(bytes.subarray(at, at + 65536));
    };
    const randomBytes = (size, cb) => {
      const bytes = Buffer.alloc(uint(size, "size", 0, 2 ** 31 - 1));
      if (cb === undefined) {
        fillRandom(bytes);
        return bytes;
      }
      later(callback(cb), () => (fillRandom(bytes), bytes));
    };
    const randomRange = (buffer, offset = 0, size) => {
      if (!ArrayBuffer.isView(buffer) && !(buffer instanceof ArrayBuffer))
        throw argType("buf", "an instance of ArrayBuffer, Buffer, TypedArray, or DataView", buffer);
      const all = asBytes(buffer, "buf");
      const start = uint(offset, "offset", 0, all.length);
      return all.subarray(start, start + (size === undefined ? all.length - start : uint(size, "size", 0, all.length - start)));
    };
    const randomFillSync = (buffer, offset, size) => {
      fillRandom(randomRange(buffer, offset, size));
      return buffer;
    };
    const randomFill = (buffer, ...rest) => {
      const cb = callback(rest.pop());
      const range = randomRange(buffer, rest[0], rest[1]);
      later(cb, () => (fillRandom(range), buffer));
    };
    const randomInt = (...args) => {
      const cb = typeof args[args.length - 1] === "function" ? callback(args.pop()) : undefined;
      const max = args.pop();
      const min = args.length ? args[0] : 0;
      if (!Number.isSafeInteger(min))
        throw argType("min", "a safe integer", min);
      if (!Number.isSafeInteger(max))
        throw argType("max", "a safe integer", max);
      const range = max - min;
      if (!(range > 0)) {
        throw coded(new RangeError(`The value of "max" is out of range. It must be greater than the value of "min" (${min}). Received ${max}`), "ERR_OUT_OF_RANGE");
      }
      if (range > 2 ** 48 - 1) {
        throw coded(new RangeError(`The value of "max - min" is out of range. It must be <= ${2 ** 48 - 1}. Received ${range}`), "ERR_OUT_OF_RANGE");
      }
      const limit = 2 ** 48 - 2 ** 48 % range;
      const draw = () => {
        const bytes = new Uint8Array(6);
        for (;; ) {
          webcrypto.getRandomValues(bytes);
          const value = (bytes[0] << 8 | bytes[1]) * 2 ** 32 + ((bytes[2] << 24 | bytes[3] << 16 | bytes[4] << 8 | bytes[5]) >>> 0);
          if (value < limit)
            return value % range + min;
        }
      };
      if (!cb)
        return draw();
      later(cb, draw);
    };
    const randomUUID = () => {
      if (typeof webcrypto.randomUUID === "function")
        return webcrypto.randomUUID();
      const b = webcrypto.getRandomValues(new Uint8Array(16));
      b[6] = b[6] & 15 | 64;
      b[8] = b[8] & 63 | 128;
      let s = "";
      for (let i = 0;i < 16; i++)
        s += (i === 4 || i === 6 || i === 8 || i === 10 ? "-" : "") + HEX[b[i]];
      return s;
    };
    const timingSafeEqual = (a, b) => {
      const x = asBytes(typeof a === "string" ? undefined : a, "buf1");
      const y = asBytes(typeof b === "string" ? undefined : b, "buf2");
      if (x.length !== y.length)
        throw coded(new RangeError("Input buffers must have the same byte length"), "ERR_CRYPTO_TIMING_SAFE_EQUAL_LENGTH");
      let diff = 0;
      for (let i = 0;i < x.length; i++)
        diff |= x[i] ^ y[i];
      return diff === 0;
    };
    const derive = (inputs, length, fn) => {
      const n = native();
      let status = 0;
      const bytes = n.call(inputs, length, (pointers, out) => status = fn(n.x, pointers, out));
      if (status !== 0)
        throw coded(new Error("Key derivation failed"), "ERR_CRYPTO_OPERATION_FAILED");
      return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    };
    const pbkdf2Job = (password, salt, iterations, keylen, digest) => {
      if (typeof digest !== "string")
        throw argType("digest", "of type string", digest);
      const alg = digestId(digest);
      const pw = Uint8Array.from(keyBytes(password, "password"));
      const s = Uint8Array.from(asBytes(salt, "salt"));
      const rounds = uint(iterations, "iterations", 1, 2 ** 31 - 1);
      const length = uint(keylen, "keylen", 0, 2 ** 31 - 1);
      return () => derive([pw, s], length, (x, [p, q], out) => x.bat_pbkdf2(alg, p, pw.length, q, s.length, rounds, out, length));
    };
    const pbkdf2Sync = (password, salt, iterations, keylen, digest) => pbkdf2Job(password, salt, iterations, keylen, digest)();
    const pbkdf2 = (password, salt, iterations, keylen, digest, cb) => {
      if (typeof digest === "function")
        throw argType("digest", "of type string", digest);
      later(callback(cb), pbkdf2Job(password, salt, iterations, keylen, digest));
    };
    const scryptJob = (password, salt, keylen, options = {}) => {
      const pw = Uint8Array.from(keyBytes(password, "password"));
      const s = Uint8Array.from(asBytes(salt, "salt"));
      const length = uint(keylen, "keylen", 0, 2 ** 31 - 1);
      const N = options.N ?? options.cost ?? 16384;
      const r = options.r ?? options.blockSize ?? 8;
      const p = options.p ?? options.parallelization ?? 1;
      const maxmem = options.maxmem ?? 32 * 1024 * 1024;
      const logN = Math.log2(N);
      const bad = (why) => coded(new RangeError(`Invalid scrypt params: ${why}`), "ERR_CRYPTO_INVALID_SCRYPT_PARAMS");
      if (!Number.isInteger(logN) || logN < 1 || !Number.isInteger(r) || r < 1 || !Number.isInteger(p) || p < 1)
        throw bad("N must be a power of two above 1, r and p positive integers");
      if (128 * N * r > maxmem)
        throw bad("memory limit exceeded");
      return () => length === 0 ? Buffer.alloc(0) : derive([pw, s], length, (x, [a, b], out) => x.bat_scrypt(a, pw.length, b, s.length, logN, r, p, out, length));
    };
    const scryptSync = (password, salt, keylen, options) => scryptJob(password, salt, keylen, options)();
    const scrypt = (password, salt, keylen, options, cb) => {
      if (typeof options === "function")
        [options, cb] = [undefined, options];
      later(callback(cb), scryptJob(password, salt, keylen, options));
    };
    const hkdfJob = (digest, ikm, salt, info, keylen) => {
      if (typeof digest !== "string")
        throw argType("digest", "of type string", digest);
      const alg = digestId(digest);
      const key = Uint8Array.from(keyBytes(ikm, "ikm"));
      const s = Uint8Array.from(asBytes(salt, "salt"));
      const i = Uint8Array.from(asBytes(info, "info"));
      const length = uint(keylen, "length", 0, 2 ** 31 - 1);
      if (length > 255 * DIGEST_SIZE[alg])
        throw coded(new RangeError("Invalid key length"), "ERR_CRYPTO_INVALID_KEYLEN");
      return () => {
        const out = derive([key, s, i], length, (x, [a, b, c], o) => x.bat_hkdf(alg, a, key.length, b, s.length, c, i.length, o, length));
        return out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength);
      };
    };
    const hkdfSync = (digest, ikm, salt, info, keylen) => hkdfJob(digest, ikm, salt, info, keylen)();
    const hkdf = (digest, ikm, salt, info, keylen, cb) => {
      later(callback(cb), hkdfJob(digest, ikm, salt, info, keylen));
    };
    function KeyObject(type, bytes) {
      if (type !== "secret")
        throw coded(new Error("crypto.KeyObject: only secret keys are available in this runtime"), "ERR_FEATURE_UNAVAILABLE_ON_PLATFORM");
      this[kState] = bytes;
    }
    Object.defineProperties(KeyObject.prototype, {
      type: { get: () => "secret", enumerable: true, configurable: true },
      symmetricKeySize: {
        get() {
          return this[kState].length;
        },
        enumerable: true,
        configurable: true
      }
    });
    KeyObject.prototype.export = function(options) {
      const bytes = Buffer.from(this[kState]);
      return options?.format === "jwk" ? { kty: "oct", k: bytes.toString("base64url") } : bytes;
    };
    KeyObject.prototype.equals = function(other) {
      if (!(other instanceof KeyObject))
        throw argType("otherKeyObject", "an instance of KeyObject", other);
      const a = this[kState];
      const b = other[kState];
      return a.length === b.length && timingSafeEqual(a, b);
    };
    const createSecretKey = (key, encoding) => new KeyObject("secret", Uint8Array.from(asBytes(key, "key", encoding)));
    const cipherInfo = (name) => {
      const info = typeof name === "string" ? CIPHERS[name.toLowerCase()] : undefined;
      if (!info)
        throw coded(new TypeError(typeof name === "string" ? "Unknown cipher" : 'The "cipher" argument must be of type string'), typeof name === "string" ? "ERR_CRYPTO_UNKNOWN_CIPHER" : "ERR_INVALID_ARG_TYPE");
      return info;
    };
    const openCipher = (self, encrypt, name, key, iv, options) => {
      const info = cipherInfo(name);
      const k = keyBytes(key);
      if (k.length !== info.key)
        throw coded(new RangeError("Invalid key length"), "ERR_CRYPTO_INVALID_KEYLEN");
      const v = iv === null ? new Uint8Array(0) : asBytes(iv, "iv");
      if (info.mode === GCM ? v.length === 0 : v.length !== info.iv)
        throw coded(new TypeError("Invalid initialization vector"), "ERR_CRYPTO_INVALID_IV");
      const tagLength = options?.authTagLength ?? 16;
      if (info.mode === GCM && !(Number.isInteger(tagLength) && tagLength >= 4 && tagLength <= 16)) {
        throw coded(new TypeError(`Invalid authentication tag length: ${tagLength}`), "ERR_CRYPTO_INVALID_AUTH_TAG");
      }
      const n = native();
      let handle = 0;
      n.call([k, v], 0, ([kp, vp]) => handle = n.x.bat_cipher_new(info.mode, encrypt ? 1 : 0, kp, k.length, vp, v.length));
      const state = { handle, mode: info.mode, encrypt, tag: null, tagLength, decoder: null };
      n.track(state, () => n.x.bat_cipher_free(handle));
      self[kState] = state;
      LazyTransform.call(self, options);
    };
    const live = (self, what) => {
      const state = self[kState];
      if (!state.handle)
        throw coded(new Error(`Invalid state for operation ${what}`), "ERR_CRYPTO_INVALID_STATE");
      return state;
    };
    const cipherOutput = (state, bytes, encoding, last) => {
      const buffer = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      if (!encoding || encoding === "buffer")
        return buffer;
      state.decoder ??= new (rt.require("string_decoder")).StringDecoder(encoding);
      return last ? state.decoder.end(buffer) : state.decoder.write(buffer);
    };
    const cipherMethods = {
      update(data, inputEncoding, outputEncoding) {
        const state = live(this, "update");
        const input = asBytes(data, "data", inputEncoding);
        const n = native();
        let written = 0;
        const out = n.call([input], input.length + 16, ([pointer], o) => written = n.x.bat_cipher_update(state.handle, pointer, input.length, o));
        return cipherOutput(state, out.subarray(0, written), outputEncoding, false);
      },
      final(outputEncoding) {
        const state = live(this, "final");
        const n = native();
        const gcm = state.mode === GCM;
        if (gcm && !state.encrypt && !state.tag)
          throw coded(new Error("Unsupported state or unable to authenticate data"), "ERR_CRYPTO_INVALID_STATE");
        const tag = gcm && !state.encrypt ? state.tag : new Uint8Array(16);
        let status = 0;
        const out = n.call([tag], 16, ([tagPointer], o) => {
          status = n.x.bat_cipher_final(state.handle, o, tagPointer, tag.length);
          if (gcm && state.encrypt)
            state.tag = n.mem().slice(tagPointer, tagPointer + state.tagLength);
        });
        n.x.bat_cipher_free(state.handle);
        n.untrack(state);
        state.handle = 0;
        if (status === -2)
          throw coded(new Error("error:1C80006B:Provider routines::wrong final block length"), "ERR_OSSL_WRONG_FINAL_BLOCK_LENGTH");
        if (status < 0) {
          throw gcm ? new Error("Unsupported state or unable to authenticate data") : coded(new Error("error:1C800064:Provider routines::bad decrypt"), "ERR_OSSL_BAD_DECRYPT");
        }
        return cipherOutput(state, out.subarray(0, status), outputEncoding, true);
      },
      setAAD(data, _options) {
        const state = live(this, "setAAD");
        const aad = asBytes(data, "buffer");
        const n = native();
        n.call([aad], 0, ([pointer]) => n.x.bat_cipher_aad(state.handle, pointer, aad.length));
        return this;
      },
      getAuthTag() {
        const state = this[kState];
        if (!state.encrypt || state.handle || !state.tag)
          throw coded(new Error("Invalid state for operation getAuthTag"), "ERR_CRYPTO_INVALID_STATE");
        return Buffer.from(state.tag);
      },
      setAuthTag(tag, encoding) {
        const state = live(this, "setAuthTag");
        const bytes = Uint8Array.from(asBytes(tag, "buffer", encoding));
        if (state.encrypt || state.mode !== GCM)
          throw coded(new Error("Invalid state for operation setAuthTag"), "ERR_CRYPTO_INVALID_STATE");
        if (bytes.length < 4 || bytes.length > 16)
          throw coded(new TypeError(`Invalid authentication tag length: ${bytes.length}`), "ERR_CRYPTO_INVALID_AUTH_TAG");
        state.tag = bytes;
        return this;
      },
      setAutoPadding(on = true) {
        const state = live(this, "setAutoPadding");
        native().x.bat_cipher_padding(state.handle, on ? 1 : 0);
        return this;
      },
      _transform(chunk, encoding, done) {
        this.push(this.update(chunk, encoding));
        done();
      },
      _flush(done) {
        try {
          this.push(this.final());
        } catch (error) {
          return done(error);
        }
        done();
      }
    };
    function Cipheriv(cipher, key, iv, options) {
      if (!(this instanceof Cipheriv))
        return new Cipheriv(cipher, key, iv, options);
      openCipher(this, true, cipher, key, iv, options);
    }
    function Decipheriv(cipher, key, iv, options) {
      if (!(this instanceof Decipheriv))
        return new Decipheriv(cipher, key, iv, options);
      openCipher(this, false, cipher, key, iv, options);
    }
    for (const ctor of [Cipheriv, Decipheriv]) {
      Object.setPrototypeOf(ctor.prototype, LazyTransform.prototype);
      Object.setPrototypeOf(ctor, LazyTransform);
      for (const [name, value] of Object.entries(cipherMethods)) {
        Object.defineProperty(ctor.prototype, name, { value, writable: true, configurable: true });
      }
    }
    const getCipherInfo = (name) => {
      const info = typeof name === "string" ? CIPHERS[name.toLowerCase()] : undefined;
      if (!info)
        return;
      const mode = ["cbc", "ctr", "gcm"][info.mode];
      return { name: name.toLowerCase(), mode, keyLength: info.key, ivLength: info.iv, ...info.mode === CBC ? { blockSize: 16 } : {} };
    };
    const exports = {
      createHash: (algorithm, options) => new Hash(algorithm, options),
      createHmac: (algorithm, key, options) => new Hmac(algorithm, key, options),
      hash: hash2,
      getHashes: () => [...HASHES.map((name) => `RSA-${name.toUpperCase().replace("SHA512-256", "SHA512/256")}`), ...HASHES],
      Hash,
      Hmac,
      randomBytes,
      pseudoRandomBytes: randomBytes,
      randomFillSync,
      randomFill,
      randomInt,
      randomUUID,
      getRandomValues: (array) => webcrypto.getRandomValues(array),
      timingSafeEqual,
      pbkdf2,
      pbkdf2Sync,
      scrypt,
      scryptSync,
      hkdf,
      hkdfSync,
      createCipheriv: (cipher, key, iv, options) => new Cipheriv(cipher, key, iv, options),
      createDecipheriv: (cipher, key, iv, options) => new Decipheriv(cipher, key, iv, options),
      Cipheriv,
      Decipheriv,
      getCiphers: () => Object.keys(CIPHERS),
      getCipherInfo,
      KeyObject,
      createSecretKey,
      getCurves: () => [],
      getFips: () => 0,
      constants: {}
    };
    Object.defineProperties(exports, {
      webcrypto: { get: () => webcrypto, enumerable: true, configurable: true },
      subtle: { get: () => webcrypto.subtle, enumerable: true, configurable: true }
    });
    for (const name of UNAVAILABLE) {
      const stub = function() {
        unsupported("crypto", name);
      };
      Object.defineProperty(stub, "name", { value: name });
      exports[name] = stub;
    }
    return exports;
  }
  registerBuiltin("crypto", createCrypto);

  // runtime/src/node/zlib.ts
  var DEFLATE = 0;
  var INFLATE = 1;
  var GZIP = 2;
  var GUNZIP = 3;
  var DEFLATE_RAW = 4;
  var INFLATE_RAW = 5;
  var UNZIP = 6;
  var BROTLI_ENCODE = 7;
  var BROTLI_DECODE = 8;
  var isBrotli = (mode) => mode >= BROTLI_ENCODE;
  var isEncoder = (mode) => mode === DEFLATE || mode === GZIP || mode === DEFLATE_RAW || mode === BROTLI_ENCODE;
  var ONE_SHOT_CHUNK = 128 * 1024;
  var constants2 = {
    Z_NO_FLUSH: 0,
    Z_PARTIAL_FLUSH: 1,
    Z_SYNC_FLUSH: 2,
    Z_FULL_FLUSH: 3,
    Z_FINISH: 4,
    Z_BLOCK: 5,
    Z_OK: 0,
    Z_STREAM_END: 1,
    Z_NEED_DICT: 2,
    Z_ERRNO: -1,
    Z_STREAM_ERROR: -2,
    Z_DATA_ERROR: -3,
    Z_MEM_ERROR: -4,
    Z_BUF_ERROR: -5,
    Z_VERSION_ERROR: -6,
    Z_NO_COMPRESSION: 0,
    Z_BEST_SPEED: 1,
    Z_BEST_COMPRESSION: 9,
    Z_DEFAULT_COMPRESSION: -1,
    Z_FILTERED: 1,
    Z_HUFFMAN_ONLY: 2,
    Z_RLE: 3,
    Z_FIXED: 4,
    Z_DEFAULT_STRATEGY: 0,
    ZLIB_VERNUM: 4880,
    DEFLATE: 1,
    INFLATE: 2,
    GZIP: 3,
    GUNZIP: 4,
    DEFLATERAW: 5,
    INFLATERAW: 6,
    UNZIP: 7,
    BROTLI_DECODE: 8,
    BROTLI_ENCODE: 9,
    Z_MIN_WINDOWBITS: 8,
    Z_MAX_WINDOWBITS: 15,
    Z_DEFAULT_WINDOWBITS: 15,
    Z_MIN_CHUNK: 64,
    Z_MAX_CHUNK: Infinity,
    Z_DEFAULT_CHUNK: 16384,
    Z_MIN_MEMLEVEL: 1,
    Z_MAX_MEMLEVEL: 9,
    Z_DEFAULT_MEMLEVEL: 8,
    Z_MIN_LEVEL: -1,
    Z_MAX_LEVEL: 9,
    Z_DEFAULT_LEVEL: -1,
    BROTLI_OPERATION_PROCESS: 0,
    BROTLI_OPERATION_FLUSH: 1,
    BROTLI_OPERATION_FINISH: 2,
    BROTLI_OPERATION_EMIT_METADATA: 3,
    BROTLI_PARAM_MODE: 0,
    BROTLI_MODE_GENERIC: 0,
    BROTLI_MODE_TEXT: 1,
    BROTLI_MODE_FONT: 2,
    BROTLI_DEFAULT_MODE: 0,
    BROTLI_PARAM_QUALITY: 1,
    BROTLI_MIN_QUALITY: 0,
    BROTLI_MAX_QUALITY: 11,
    BROTLI_DEFAULT_QUALITY: 11,
    BROTLI_PARAM_LGWIN: 2,
    BROTLI_MIN_WINDOW_BITS: 10,
    BROTLI_MAX_WINDOW_BITS: 24,
    BROTLI_LARGE_MAX_WINDOW_BITS: 30,
    BROTLI_DEFAULT_WINDOW: 22,
    BROTLI_PARAM_LGBLOCK: 3,
    BROTLI_MIN_INPUT_BLOCK_BITS: 16,
    BROTLI_MAX_INPUT_BLOCK_BITS: 24,
    BROTLI_PARAM_DISABLE_LITERAL_CONTEXT_MODELING: 4,
    BROTLI_PARAM_SIZE_HINT: 5,
    BROTLI_PARAM_LARGE_WINDOW: 6,
    BROTLI_PARAM_NPOSTFIX: 7,
    BROTLI_PARAM_NDIRECT: 8,
    BROTLI_DECODER_RESULT_ERROR: 0,
    BROTLI_DECODER_RESULT_SUCCESS: 1,
    BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT: 2,
    BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT: 3,
    BROTLI_DECODER_PARAM_DISABLE_RING_BUFFER_REALLOCATION: 0,
    BROTLI_DECODER_PARAM_LARGE_WINDOW: 1,
    BROTLI_DECODER_NO_ERROR: 0,
    BROTLI_DECODER_SUCCESS: 1,
    BROTLI_DECODER_NEEDS_MORE_INPUT: 2,
    BROTLI_DECODER_NEEDS_MORE_OUTPUT: 3,
    BROTLI_DECODER_ERROR_FORMAT_EXUBERANT_NIBBLE: -1,
    BROTLI_DECODER_ERROR_FORMAT_RESERVED: -2,
    BROTLI_DECODER_ERROR_FORMAT_EXUBERANT_META_NIBBLE: -3,
    BROTLI_DECODER_ERROR_FORMAT_SIMPLE_HUFFMAN_ALPHABET: -4,
    BROTLI_DECODER_ERROR_FORMAT_SIMPLE_HUFFMAN_SAME: -5,
    BROTLI_DECODER_ERROR_FORMAT_CL_SPACE: -6,
    BROTLI_DECODER_ERROR_FORMAT_HUFFMAN_SPACE: -7,
    BROTLI_DECODER_ERROR_FORMAT_CONTEXT_MAP_REPEAT: -8,
    BROTLI_DECODER_ERROR_FORMAT_BLOCK_LENGTH_1: -9,
    BROTLI_DECODER_ERROR_FORMAT_BLOCK_LENGTH_2: -10,
    BROTLI_DECODER_ERROR_FORMAT_TRANSFORM: -11,
    BROTLI_DECODER_ERROR_FORMAT_DICTIONARY: -12,
    BROTLI_DECODER_ERROR_FORMAT_WINDOW_BITS: -13,
    BROTLI_DECODER_ERROR_FORMAT_PADDING_1: -14,
    BROTLI_DECODER_ERROR_FORMAT_PADDING_2: -15,
    BROTLI_DECODER_ERROR_FORMAT_DISTANCE: -16,
    BROTLI_DECODER_ERROR_DICTIONARY_NOT_SET: -19,
    BROTLI_DECODER_ERROR_INVALID_ARGUMENTS: -20,
    BROTLI_DECODER_ERROR_ALLOC_CONTEXT_MODES: -21,
    BROTLI_DECODER_ERROR_ALLOC_TREE_GROUPS: -22,
    BROTLI_DECODER_ERROR_ALLOC_CONTEXT_MAP: -25,
    BROTLI_DECODER_ERROR_ALLOC_RING_BUFFER_1: -26,
    BROTLI_DECODER_ERROR_ALLOC_RING_BUFFER_2: -27,
    BROTLI_DECODER_ERROR_ALLOC_BLOCK_TYPE_TREES: -30,
    BROTLI_DECODER_ERROR_UNREACHABLE: -31
  };
  var CODE_NAMES = ["Z_OK", "Z_STREAM_END", "Z_NEED_DICT", "Z_ERRNO", "Z_STREAM_ERROR", "Z_DATA_ERROR", "Z_MEM_ERROR", "Z_BUF_ERROR", "Z_VERSION_ERROR"];
  function coded2(error, code, errno) {
    error.code = code;
    if (errno !== undefined)
      error.errno = errno;
    return error;
  }
  function outOfRange(name, range, value) {
    return coded2(new RangeError(`The value of "${name}" is out of range. It must be ${range}. Received ${value}`), "ERR_OUT_OF_RANGE");
  }
  function createZlib(rt) {
    const { Buffer, kMaxLength } = rt.require("buffer");
    const stream = rt.require("stream");
    const { Transform } = stream;
    const C = constants2;
    let cached;
    const native = () => cached ?? (cached = nativeOf(rt));
    const toBytes = (value) => {
      if (typeof value === "string")
        return Buffer.from(value);
      if (value instanceof Uint8Array)
        return value;
      if (ArrayBuffer.isView(value))
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      if (value instanceof ArrayBuffer)
        return new Uint8Array(value);
      const got = value === null ? "null" : typeof value === "object" ? `an instance of ${value.constructor?.name ?? "Object"}` : `type ${typeof value} (${String(value)})`;
      throw coded2(new TypeError(`The "buffer" argument must be of type string or an instance of Buffer, TypedArray, DataView, or ArrayBuffer. Received ${got}`), "ERR_INVALID_ARG_TYPE");
    };
    const integer = (value, name, min, max, fallback) => {
      if (value === undefined || value === null)
        return fallback;
      if (typeof value !== "number" || Number.isNaN(value)) {
        throw coded2(new TypeError(`The "${name}" property must be of type number. Received ${typeof value}`), "ERR_INVALID_ARG_TYPE");
      }
      if (value < min || value > max)
        throw outOfRange(name, `>= ${min} and <= ${max}`, value);
      return Math.floor(value);
    };
    const configure = (mode, options) => {
      const o = options ?? {};
      const chunkSize = integer(o.chunkSize, "options.chunkSize", C.Z_MIN_CHUNK, Infinity, C.Z_DEFAULT_CHUNK);
      const maxOutputLength = integer(o.maxOutputLength, "options.maxOutputLength", 1, kMaxLength ?? 2 ** 32, kMaxLength ?? 2 ** 32);
      if (isBrotli(mode)) {
        const params = o.params ?? {};
        return {
          level: 0,
          chunkSize,
          flush: integer(o.flush, "options.flush", 0, 3, C.BROTLI_OPERATION_PROCESS),
          finishFlush: integer(o.finishFlush, "options.finishFlush", 0, 3, C.BROTLI_OPERATION_FINISH),
          fullFlush: C.BROTLI_OPERATION_FLUSH,
          finish: C.BROTLI_OPERATION_FINISH,
          maxOutputLength,
          brotli: [
            integer(params[C.BROTLI_PARAM_QUALITY], "options.params[BROTLI_PARAM_QUALITY]", 0, 11, C.BROTLI_DEFAULT_QUALITY),
            integer(params[C.BROTLI_PARAM_LGWIN], "options.params[BROTLI_PARAM_LGWIN]", 10, 24, C.BROTLI_DEFAULT_WINDOW),
            integer(params[C.BROTLI_PARAM_MODE], "options.params[BROTLI_PARAM_MODE]", 0, 2, C.BROTLI_DEFAULT_MODE),
            integer(params[C.BROTLI_PARAM_SIZE_HINT], "options.params[BROTLI_PARAM_SIZE_HINT]", 0, 2 ** 32 - 1, 0)
          ]
        };
      }
      const level = integer(o.level, "options.level", C.Z_MIN_LEVEL, C.Z_MAX_LEVEL, C.Z_DEFAULT_LEVEL);
      return {
        level: level === C.Z_DEFAULT_COMPRESSION ? 6 : level,
        chunkSize,
        flush: integer(o.flush, "options.flush", C.Z_NO_FLUSH, C.Z_BLOCK, C.Z_NO_FLUSH),
        finishFlush: integer(o.finishFlush, "options.finishFlush", C.Z_NO_FLUSH, C.Z_BLOCK, C.Z_FINISH),
        fullFlush: C.Z_FULL_FLUSH,
        finish: C.Z_FINISH,
        maxOutputLength,
        brotli: [0, 0, 0, 0]
      };
    };
    const open = (mode, config, outCap) => {
      const { x } = native();
      const [a, b, c, d] = isBrotli(mode) ? config.brotli : [config.level, 0, 0, 0];
      return { mode, handle: x.bat_z_new(mode, a, b, c, d), out: x.bat_alloc(outCap), outCap, finish: config.finish, bytesWritten: 0, ended: false };
    };
    const close = (engine) => {
      if (!engine.handle)
        return;
      const { x } = native();
      x.bat_z_free(engine.handle);
      x.bat_free(engine.out, engine.outCap);
      engine.handle = 0;
    };
    const failure = (engine, detail, brotliCode) => {
      if (engine.mode === BROTLI_ENCODE)
        return coded2(new Error("Compression failed"), "ERR_BROTLI_COMPRESS_FAILED", -1);
      if (engine.mode === BROTLI_DECODE) {
        const name = Object.keys(C).find((key) => key.startsWith("BROTLI_DECODER_ERROR_") && C[key] === brotliCode);
        return coded2(new Error("Decompression failed"), name ? `ERR_${name.slice("BROTLI_DECODER".length)}` : "ERR_BROTLI_DECOMPRESSION_FAILED", brotliCode);
      }
      const message = ["", "incorrect header check", "invalid compressed data", "incorrect data check", "incorrect length check"][detail] ?? "invalid compressed data";
      return coded2(new Error(message), "Z_DATA_ERROR", C.Z_DATA_ERROR);
    };
    const truncated = () => coded2(new Error("unexpected end of file"), "Z_BUF_ERROR", C.Z_BUF_ERROR);
    const pump = (engine, input, flush, sink) => {
      const n = native();
      const { x } = n;
      const length = input.length;
      const base = length ? x.bat_alloc(length) : 0;
      try {
        if (length)
          n.mem().set(input, base);
        const finishing = isEncoder(engine.mode) && flush === engine.finish;
        let at = 0;
        let stalled = 0;
        for (;; ) {
          const status = x.bat_z_write(engine.handle, base + at, length - at, engine.out, engine.outCap, flush);
          const view = n.mem();
          const result = new Int32Array(view.buffer, x.bat_z_result(), 4);
          const consumed = result[0];
          const produced = result[1];
          if (status < 0)
            throw failure(engine, result[2], result[3]);
          at += consumed;
          engine.bytesWritten += consumed;
          engine.ended = status === 1;
          if (produced)
            sink(Buffer.from(view.subarray(engine.out, engine.out + produced)));
          if (at < length) {
            if (!consumed && !produced)
              break;
            continue;
          }
          if (produced === engine.outCap)
            continue;
          if (finishing && status !== 1 && (produced || ++stalled < 3))
            continue;
          break;
        }
      } finally {
        if (length)
          x.bat_free(base, length);
      }
    };
    const runSync = (mode, data, options) => {
      const input = toBytes(data);
      const config = configure(mode, options);
      const engine = open(mode, config, Math.max(config.chunkSize, ONE_SHOT_CHUNK));
      const chunks = [];
      let total = 0;
      try {
        pump(engine, input, config.finishFlush, (chunk) => {
          total += chunk.length;
          if (total > config.maxOutputLength) {
            throw coded2(new RangeError(`Cannot create a Buffer larger than ${config.maxOutputLength} bytes`), "ERR_BUFFER_TOO_LARGE");
          }
          chunks.push(chunk);
        });
        if (!isEncoder(mode) && config.finishFlush === config.finish && !engine.ended)
          throw truncated();
      } finally {
        close(engine);
      }
      const buffer = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks, total);
      return options?.info ? { buffer, engine: undefined } : buffer;
    };
    const runAsync = (mode, data, options, cb) => {
      if (typeof options === "function")
        [options, cb] = [undefined, options];
      if (typeof cb !== "function")
        throw coded2(new TypeError('The "callback" argument must be of type function'), "ERR_INVALID_ARG_TYPE");
      const input = toBytes(data);
      rt.loop.defer(() => {
        let result;
        try {
          result = runSync(mode, input, options);
        } catch (error) {
          return cb(error);
        }
        cb(null, result);
      });
    };
    const kConfig = Symbol("kConfig");
    const kEngine = Symbol("kEngine");
    const flushMarks = new WeakMap;
    const flushChunks = new Map;
    const flushChunk = (kind) => {
      let chunk = flushChunks.get(kind);
      if (!chunk) {
        chunk = Buffer.alloc(0);
        flushMarks.set(chunk, kind);
        flushChunks.set(kind, chunk);
      }
      return chunk;
    };
    function ZlibBase(mode, options) {
      const config = configure(mode, options);
      Transform.call(this, { autoDestroy: true, ...options });
      this[kConfig] = config;
      this[kEngine] = { mode, handle: 0, out: 0, outCap: config.chunkSize, finish: config.finish, bytesWritten: 0, ended: false };
      this.bytesWritten = 0;
      this._closed = false;
    }
    Object.setPrototypeOf(ZlibBase.prototype, Transform.prototype);
    Object.setPrototypeOf(ZlibBase, Transform);
    const engineOf = (self) => {
      const engine = self[kEngine];
      if (!engine.handle) {
        Object.assign(engine, open(engine.mode, self[kConfig], engine.outCap), { bytesWritten: engine.bytesWritten });
        const n = native();
        const { handle, out, outCap } = engine;
        n.track(self, () => (n.x.bat_z_free(handle), n.x.bat_free(out, outCap)));
      }
      return engine;
    };
    const release = (self) => {
      self._closed = true;
      const engine = self[kEngine];
      if (!engine.handle)
        return;
      native().untrack(self);
      close(engine);
    };
    const streamWrite = (self, chunk, flush, last) => {
      const engine = engineOf(self);
      try {
        pump(engine, chunk, flush, (piece) => self.push(piece));
      } finally {
        self.bytesWritten = engine.bytesWritten;
      }
      if (last && !isEncoder(engine.mode) && flush === engine.finish && !engine.ended)
        throw truncated();
    };
    Object.defineProperty(ZlibBase.prototype, "bytesRead", {
      configurable: true,
      enumerable: true,
      get() {
        return this.bytesWritten;
      },
      set(value) {
        this.bytesWritten = value;
      }
    });
    ZlibBase.prototype._transform = function(chunk, _encoding, done) {
      if (this._closed)
        return done();
      const mark = flushMarks.get(chunk);
      try {
        streamWrite(this, toBytes(chunk), mark ?? this[kConfig].flush, false);
      } catch (error) {
        return done(error);
      }
      done();
    };
    ZlibBase.prototype._flush = function(done) {
      if (this._closed)
        return done();
      try {
        streamWrite(this, new Uint8Array(0), this[kConfig].finishFlush, true);
      } catch (error) {
        return done(error);
      }
      done();
    };
    ZlibBase.prototype.flush = function(kind, cb) {
      if (typeof kind === "function" || kind === undefined && !cb)
        [kind, cb] = [this[kConfig].fullFlush, kind];
      if (this.writableFinished) {
        if (cb)
          rt.loop.nextTick(cb);
      } else if (this.writableEnded) {
        if (cb)
          this.once("end", cb);
      } else {
        this.write(flushChunk(kind), "", cb);
      }
    };
    ZlibBase.prototype.close = function(cb) {
      if (cb)
        stream.finished(this, cb);
      this.destroy();
    };
    ZlibBase.prototype._destroy = function(error, done) {
      release(this);
      done(error);
    };
    ZlibBase.prototype.reset = function() {
      const engine = this[kEngine];
      if (engine.handle)
        native().x.bat_z_reset(engine.handle);
      engine.ended = false;
    };
    ZlibBase.prototype.params = function(_level, _strategy, cb) {
      if (cb)
        rt.loop.nextTick(cb);
    };
    const streamClass = (name, mode) => {
      const ctor = function(options) {
        if (!(this instanceof ctor))
          return new ctor(options);
        ZlibBase.call(this, mode, options);
      };
      Object.defineProperty(ctor, "name", { value: name });
      Object.setPrototypeOf(ctor.prototype, ZlibBase.prototype);
      Object.setPrototypeOf(ctor, ZlibBase);
      return ctor;
    };
    const crc32 = (data, value = 0) => {
      const input = toBytes(data);
      const n = native();
      let crc = 0;
      n.call([input], 0, ([pointer]) => crc = n.x.bat_crc32(pointer, input.length, value >>> 0));
      return crc >>> 0;
    };
    const codes = {};
    for (const name of CODE_NAMES) {
      codes[name] = constants2[name];
      codes[constants2[name]] = name;
    }
    const exports = { crc32, constants: Object.freeze({ ...constants2 }), codes: Object.freeze(codes) };
    const kinds = [
      ["Deflate", DEFLATE],
      ["Inflate", INFLATE],
      ["Gzip", GZIP],
      ["Gunzip", GUNZIP],
      ["DeflateRaw", DEFLATE_RAW],
      ["InflateRaw", INFLATE_RAW],
      ["Unzip", UNZIP],
      ["BrotliCompress", BROTLI_ENCODE],
      ["BrotliDecompress", BROTLI_DECODE]
    ];
    for (const [name, mode] of kinds) {
      const ctor = streamClass(name, mode);
      const lower = name[0].toLowerCase() + name.slice(1);
      exports[name] = ctor;
      exports[`create${name}`] = (options) => new ctor(options);
      exports[lower] = (data, options, cb) => runAsync(mode, data, options, cb);
      exports[`${lower}Sync`] = (data, options) => runSync(mode, data, options);
    }
    for (const [name, value] of Object.entries(constants2)) {
      if (!name.startsWith("BROTLI"))
        Object.defineProperty(exports, name, { value, enumerable: false, writable: false, configurable: false });
    }
    return exports;
  }
  registerBuiltin("zlib", createZlib);

  // runtime/src/net/codec.ts
  var EV_HEAD = 1;
  var EV_BODY = 2;
  var EV_END = 3;
  var EV_EOF = 4;
  var EV_WS_FRAME = 6;
  var EV_WS_DATA = 7;
  var EV_WS_END = 8;
  var F_KEEPALIVE = 1;
  var F_UPGRADE = 4;
  var F_EXPECT_CONTINUE = 16;
  var F_HTTP10 = 64;
  var WS_FIN = 256;
  var WS_MASK = 512;
  var EAGAIN2 = 11;
  var EPIPE = 32;
  var EV_WORDS = 2048;
  var latin1 = new TextDecoder("latin1");
  function getCodec(kernel) {
    const k = kernel;
    return k.__codec ??= createCodec(kernel);
  }
  function createCodec(kernel) {
    const inst = kernel.inst;
    const evP = kernel.x.bat_alloc(EV_WORDS * 4 + 64) >>> 0;
    if (!evP)
      throw new Error("kernel: out of memory");
    const outP = evP + EV_WORDS * 4;
    const ev = new Uint32Array(EV_WORDS);
    const take = (n) => {
      const u32 = new Uint32Array(inst.u8().buffer, evP, n);
      ev.set(u32);
    };
    const copy = (ptr, len, alloc) => {
      const out = alloc ? alloc(len) : new Uint8Array(len);
      out.set(inst.u8().subarray(ptr, ptr + len));
      return out;
    };
    function httpParser(kind, alloc) {
      let h = kernel.x.bat_http_parser_new(kind === "response" ? 1 : 0) >>> 0;
      let busy = false;
      return {
        recv(fd, sink, more) {
          if (!h || busy)
            return false;
          busy = true;
          try {
            for (;; ) {
              const n = kernel.x.bat_http_recv(h, fd, evP, EV_WORDS);
              if (n <= 0) {
                if (n < 0)
                  sink.error(-n);
                return false;
              }
              take(n);
              const chunks = [];
              for (let i = 0;i < n; ) {
                const kindWord = ev[i];
                if (kindWord === EV_BODY) {
                  chunks.push(copy(ev[i + 1], ev[i + 2], alloc));
                  i += 3;
                } else if (kindWord === EV_HEAD) {
                  chunks.push(copy(ev[i + 4], ev[i + 5]));
                  i += ev[i + 1];
                } else
                  i += 2;
              }
              let c = 0;
              for (let i = 0;i < n; ) {
                switch (ev[i]) {
                  case EV_HEAD: {
                    const text = latin1.decode(chunks[c++]);
                    const count = ev[i + 12];
                    const raw = new Array(count * 2);
                    for (let j = 0, w = i + 13;j < count; j++, w += 4) {
                      raw[j * 2] = text.substring(ev[w], ev[w] + ev[w + 1]);
                      raw[j * 2 + 1] = text.substring(ev[w + 2], ev[w + 2] + ev[w + 3]);
                    }
                    const status = ev[i + 3];
                    const a = text.substring(ev[i + 6], ev[i + 6] + ev[i + 7]);
                    const head = {
                      flags: ev[i + 2],
                      status,
                      method: kind === "request" ? a : "",
                      target: kind === "request" ? text.substring(ev[i + 8], ev[i + 8] + ev[i + 9]) : "",
                      reason: kind === "response" ? a : "",
                      raw,
                      contentLength: ev[i + 10] + ev[i + 11] * 4294967296
                    };
                    i += ev[i + 1];
                    sink.head(head);
                    break;
                  }
                  case EV_BODY:
                    i += 3;
                    sink.body(chunks[c++]);
                    break;
                  case EV_END:
                    i += 2;
                    sink.end();
                    break;
                  case EV_EOF:
                    sink.eof(ev[i + 1] === 1);
                    i += 2;
                    break;
                  default:
                    sink.error(ev[i + 1]);
                    i += 2;
                }
              }
              if (!h)
                return false;
              if (more && !more())
                return true;
            }
          } finally {
            busy = false;
          }
        },
        expectNoBody() {
          if (h)
            kernel.x.bat_http_expect_no_body(h);
        },
        resume(fd, raw) {
          if (h)
            kernel.x.bat_http_resume(h, fd, raw ? 1 : 0);
        },
        free() {
          if (h)
            kernel.x.bat_http_parser_free(h);
          h = 0;
        }
      };
    }
    function wsParser() {
      let h = kernel.x.bat_ws_new() >>> 0;
      let busy = false;
      return {
        recv(fd, sink, more) {
          if (!h || busy)
            return false;
          busy = true;
          try {
            for (;; ) {
              const n = kernel.x.bat_ws_recv(h, fd, evP, EV_WORDS);
              if (n <= 0) {
                if (n < 0)
                  sink.error(-n);
                return false;
              }
              take(n);
              const chunks = [];
              for (let i = 0;i < n; ) {
                const w = ev[i];
                if (w === EV_WS_DATA) {
                  chunks.push(copy(ev[i + 1], ev[i + 2]));
                  i += 3;
                } else
                  i += w === EV_WS_FRAME ? 4 : w === EV_WS_END ? 1 : 2;
              }
              let c = 0;
              for (let i = 0;i < n; ) {
                switch (ev[i]) {
                  case EV_WS_FRAME:
                    sink.frame(ev[i + 1] & 15, (ev[i + 1] & WS_FIN) !== 0, ev[i + 2] + ev[i + 3] * 4294967296);
                    i += 4;
                    break;
                  case EV_WS_DATA:
                    i += 3;
                    sink.data(chunks[c++]);
                    break;
                  case EV_WS_END:
                    i += 1;
                    sink.frameEnd();
                    break;
                  case EV_EOF:
                    sink.eof(ev[i + 1] === 1);
                    i += 2;
                    break;
                  default:
                    sink.error(ev[i + 1]);
                    i += 2;
                }
              }
              if (!h)
                return false;
              if (more && !more())
                return true;
            }
          } finally {
            busy = false;
          }
        },
        free() {
          if (h)
            kernel.x.bat_ws_free(h);
          h = 0;
        }
      };
    }
    function send(fd, bytes, from = 0, chunked = false) {
      const flags = chunked ? 1 : 0;
      let done = from;
      const end = bytes.length;
      while (done < end) {
        const cap = kernel.x.bat_http_reserve(fd, flags, outP);
        if (cap <= 0) {
          if (cap === -EAGAIN2 || cap === 0)
            break;
          return cap;
        }
        const u8 = inst.u8();
        const u32 = new Uint32Array(u8.buffer, outP, 5);
        const n = Math.min(cap, end - done);
        const l1 = Math.min(n, u32[2]);
        u8.set(bytes.subarray(done, done + l1), u32[1]);
        if (n > l1)
          u8.set(bytes.subarray(done + l1, done + n), u32[3]);
        const rc = kernel.x.bat_http_commit(fd, flags, n);
        if (rc < 0)
          return rc;
        done += n;
      }
      return done - from;
    }
    function sendText(fd, text, from = 0) {
      let done = from;
      const end = text.length;
      while (done < end) {
        const cap = kernel.x.bat_http_reserve(fd, 0, outP);
        if (cap <= 0) {
          if (cap === -EAGAIN2 || cap === 0)
            break;
          return cap;
        }
        const u8 = inst.u8();
        const u32 = new Uint32Array(u8.buffer, outP, 5);
        const n = Math.min(cap, end - done);
        const l1 = Math.min(n, u32[2]);
        let p = u32[1];
        for (let i = 0;i < l1; i++)
          u8[p++] = text.charCodeAt(done + i);
        p = u32[3];
        for (let i = l1;i < n; i++)
          u8[p++] = text.charCodeAt(done + i);
        const rc = kernel.x.bat_http_commit(fd, 0, n);
        if (rc < 0)
          return rc;
        done += n;
      }
      return done - from;
    }
    function wsSend(fd, opcode, payload, from, first, mask) {
      const left = payload.length - from;
      const flags = (first ? opcode : 0) | WS_FIN | (mask ? WS_MASK : 0);
      const n = kernel.x.bat_ws_reserve(fd, flags, left, outP);
      if (n < 0)
        return n;
      const u8 = inst.u8();
      const u32 = new Uint32Array(u8.buffer, outP, 6);
      const l1 = Math.min(n, u32[3]);
      if (l1)
        u8.set(payload.subarray(from, from + l1), u32[2]);
      if (n > l1)
        u8.set(payload.subarray(from + l1, from + n), u32[4]);
      const rc = kernel.x.bat_ws_commit(fd, u32[0] + n);
      return rc < 0 ? rc : n;
    }
    function wsAcceptKey(key) {
      const u8 = inst.u8();
      for (let i = 0;i < key.length; i++)
        u8[evP + i] = key.charCodeAt(i);
      kernel.x.bat_ws_accept_key(evP, key.length, evP + 256);
      let out = "";
      for (let i = 0;i < 28; i++)
        out += String.fromCharCode(u8[evP + 256 + i]);
      return out;
    }
    const READ_CAP = 64 * 1024;
    let readP = 0;
    function read(fd, alloc) {
      if (!readP)
        readP = kernel.x.bat_alloc(READ_CAP) >>> 0;
      const n = kernel.x.bat_read(fd, readP, READ_CAP);
      if (n <= 0)
        return n;
      return copy(readP, n, alloc);
    }
    const portListener = (port) => kernel.x.bat_port_listener(port) >>> 0;
    async function waitForListener(port, signal) {
      const word = kernel.x.BAT_PORTS_WORD.value >>> 2;
      for (;; ) {
        signal?.throwIfAborted();
        const i32 = inst.i32();
        const seen = Atomics.load(i32, word);
        const id = portListener(port);
        if (id)
          return id;
        const woke = waitWord(i32, word, seen, 1000);
        if (signal) {
          let onAbort;
          const aborted = new Promise((resolve) => {
            onAbort = resolve;
            signal.addEventListener("abort", onAbort, { once: true });
          });
          await Promise.race([woke, aborted]);
          signal.removeEventListener("abort", onAbort);
        } else
          await woke;
      }
    }
    return { httpParser, wsParser, send, sendText, read, wsSend, wsAcceptKey, portListener, waitForListener };
  }

  // runtime/src/net/client.ts
  var POLLIN2 = 1;
  var POLLOUT2 = 4;
  var POLLERR = 8;
  var POLLHUP2 = 16;
  function netError(code, message) {
    const e = new Error(message);
    e.code = code;
    return e;
  }
  var MAX_PER_PORT = 48;
  var IDLE_MAX = 8;
  var HIGH_WATER = 1 << 20;
  var encoder4 = new TextEncoder;
  function createOutbox(codec, fd, wantWrite) {
    const queue = [];
    let failed;
    let queued = 0;
    let blocked = false;
    const drains = [];
    function flush() {
      while (queue.length) {
        const item = queue[0];
        const len = item.data.length;
        const n = typeof item.data === "string" ? codec.sendText(fd, item.data, item.at) : codec.send(fd, item.data, item.at, item.chunked);
        if (n < 0) {
          fail(netError(n === -EPIPE ? "EPIPE" : "ECONNRESET", "socket closed by the peer"));
          return;
        }
        item.at += n;
        queued -= n;
        if (item.at < len) {
          if (!blocked) {
            blocked = true;
            wantWrite(true);
          }
          return;
        }
        queue.shift();
        item.done?.();
      }
      if (blocked) {
        blocked = false;
        wantWrite(false);
      }
      while (drains.length)
        drains.shift()();
    }
    function fail(err) {
      if (failed)
        return;
      failed = err;
      for (const item of queue.splice(0))
        item.done?.(err);
      queued = 0;
      while (drains.length)
        drains.shift()();
    }
    return {
      write(data, chunked = false, done) {
        if (failed) {
          done?.(failed);
          return false;
        }
        if (data.length === 0) {
          if (queue.length)
            queue.push({ data, at: 0, chunked, done });
          else
            done?.();
          return queue.length === 0;
        }
        queue.push({ data, at: 0, chunked, done });
        queued += data.length;
        if (queue.length === 1)
          flush();
        return queue.length === 0;
      },
      flush,
      fail,
      get failed() {
        return failed;
      },
      get queued() {
        return queued;
      },
      drained() {
        if (queue.length === 0 || failed)
          return Promise.resolve();
        return new Promise((resolve) => drains.push(resolve));
      }
    };
  }
  function createHttpClient(ctx2) {
    const { kernel, io } = ctx2;
    const codec = getCodec(kernel);
    const pools = new Map;
    let closed = false;
    const live = new Set;
    const poolOf = (port) => {
      let p = pools.get(port);
      if (!p)
        pools.set(port, p = { idle: [], active: 0, waiters: [] });
      return p;
    };
    function destroy(conn) {
      if (conn.dead)
        return;
      conn.dead = true;
      live.delete(conn);
      io.off(conn.fd);
      conn.parser.free();
      try {
        kernel.close(conn.fd);
      } catch {}
    }
    function connect(port) {
      const fd = kernel.x.bat_connect(port);
      if (fd < 0)
        throw netError(fd === -111 ? "ECONNREFUSED" : `E${-fd}`, `connect ECONNREFUSED 127.0.0.1:${port}`);
      kernel.setNonblock(fd, true);
      const conn = { fd, parser: codec.httpParser("response"), port, reused: false, dead: false };
      live.add(conn);
      return conn;
    }
    async function acquire(port, signal) {
      const pool = poolOf(port);
      while (pool.active >= MAX_PER_PORT) {
        await new Promise((resolve, reject) => {
          const wake = () => {
            signal?.removeEventListener("abort", onAbort);
            resolve();
          };
          const onAbort = () => {
            const i = pool.waiters.indexOf(wake);
            if (i >= 0)
              pool.waiters.splice(i, 1);
            reject(signal.reason);
          };
          signal?.addEventListener("abort", onAbort, { once: true });
          pool.waiters.push(wake);
        });
        if (closed)
          throw netError("ECONNRESET", "runtime closed");
      }
      let conn;
      while (conn = pool.idle.pop()) {
        if (!conn.dead) {
          io.off(conn.fd);
          conn.reused = true;
          break;
        }
      }
      conn ??= connect(port);
      pool.active++;
      return conn;
    }
    function release(conn, reusable) {
      const pool = poolOf(conn.port);
      pool.active--;
      if (reusable && !conn.dead && !closed && pool.idle.length < IDLE_MAX) {
        pool.idle.push(conn);
        io.on(conn.fd, POLLIN2 | POLLHUP2 | POLLERR, () => {
          const i = pool.idle.indexOf(conn);
          if (i >= 0)
            pool.idle.splice(i, 1);
          destroy(conn);
        });
      } else
        destroy(conn);
      pool.waiters.shift()?.();
    }
    function exchange(conn, req) {
      return new Promise((resolve, reject) => {
        const { fd, parser } = conn;
        const method = req.method.toUpperCase();
        let settled = false;
        let finished = false;
        let controller;
        let keepAlive = false;
        let requestSent = false;
        let responseDone = false;
        let interim = false;
        let wantOut = false;
        let paused = false;
        const arm = () => io.on(fd, POLLIN2 | POLLHUP2 | POLLERR | (wantOut ? POLLOUT2 : 0), onReady);
        const outbox = createOutbox(codec, fd, (on) => {
          wantOut = on;
          if (!finished)
            arm();
        });
        const finish = (reusable) => {
          if (finished)
            return;
          finished = true;
          req.signal?.removeEventListener("abort", onAbort);
          release(conn, reusable);
        };
        const fail = (err) => {
          if (finished)
            return;
          outbox.fail(err instanceof Error ? err : new Error(String(err)));
          finish(false);
          if (!settled) {
            settled = true;
            reject(err);
          } else {
            try {
              controller?.error(err);
            } catch {}
          }
        };
        const onAbort = () => fail(req.signal.reason ?? new DOMException("The operation was aborted.", "AbortError"));
        const maybeDone = () => {
          if (responseDone && requestSent)
            finish(keepAlive);
        };
        const sink = {
          head(head2) {
            if (head2.status >= 100 && head2.status < 200 && !(head2.flags & F_UPGRADE)) {
              interim = true;
              return;
            }
            interim = false;
            keepAlive = (head2.flags & F_KEEPALIVE) !== 0 && !(head2.flags & F_UPGRADE);
            const headers = [];
            for (let i = 0;i < head2.raw.length; i += 2)
              headers.push([head2.raw[i], head2.raw[i + 1]]);
            const noBody = method === "HEAD" || head2.status === 204 || head2.status === 205 || head2.status === 304;
            const body2 = new ReadableStream({
              start(c) {
                controller = c;
              },
              pull() {
                if (paused) {
                  paused = false;
                  pump();
                }
              },
              cancel() {
                fail(netError("ECONNRESET", "response body cancelled"));
              }
            }, new ByteLengthQueuingStrategy({ highWaterMark: HIGH_WATER }));
            settled = true;
            resolve({ status: head2.status, statusText: head2.reason, headers, body: noBody ? null : body2 });
          },
          body(chunk) {
            if (finished)
              return;
            try {
              controller?.enqueue(chunk);
            } catch {}
          },
          end() {
            if (interim) {
              interim = false;
              return;
            }
            responseDone = true;
            try {
              controller?.close();
            } catch {}
            maybeDone();
            if (!finished && !requestSent)
              finish(false);
          },
          eof(clean) {
            if (finished)
              return;
            if (responseDone)
              return finish(false);
            if (!settled) {
              const e = netError("ECONNRESET", "socket hang up");
              e.beforeResponse = clean;
              return fail(e);
            }
            fail(new TypeError("terminated"));
          },
          error(errno) {
            fail(netError("HPE_INVALID", `invalid HTTP response from the guest (errno ${errno})`));
          }
        };
        const more = () => !finished && (!controller || (controller.desiredSize ?? 1) > 0);
        const pump = () => {
          if (finished)
            return;
          if (parser.recv(fd, sink, more))
            paused = true;
        };
        const onReady = (mask) => {
          if (finished)
            return;
          if (mask & POLLOUT2)
            outbox.flush();
          if (mask & (POLLIN2 | POLLHUP2) && !paused)
            pump();
          if (mask & POLLERR && !requestSent && !finished)
            outbox.flush();
        };
        if (req.signal?.aborted)
          return onAbort();
        req.signal?.addEventListener("abort", onAbort, { once: true });
        if (method === "HEAD")
          parser.expectNoBody();
        let head = `${method} ${req.path} HTTP/1.1\r
`;
        let hasHost = false;
        for (const [name, value] of req.headers) {
          const lower = name.toLowerCase();
          if (lower === "content-length" || lower === "transfer-encoding" || lower === "connection" || lower === "keep-alive")
            continue;
          if (lower === "host")
            hasHost = true;
          head += `${name}: ${value}\r
`;
        }
        if (!hasHost)
          head += `host: localhost:${conn.port}\r
`;
        const body = req.body;
        if (body instanceof Uint8Array) {
          head += `content-length: ${body.length}\r
\r
`;
          outbox.write(head);
          outbox.write(body, false, (err) => {
            if (err)
              return;
            requestSent = true;
            maybeDone();
          });
        } else if (body) {
          head += `transfer-encoding: chunked\r
\r
`;
          outbox.write(head);
          const reader = body.getReader();
          (async () => {
            try {
              for (;; ) {
                const { done, value } = await reader.read();
                if (finished)
                  return void reader.cancel().catch(() => {});
                if (done)
                  break;
                if (value?.length) {
                  outbox.write(value, true);
                  await outbox.drained();
                  if (outbox.failed)
                    throw outbox.failed;
                }
              }
              outbox.write(`0\r
\r
`, false, (err) => {
                if (err)
                  return;
                requestSent = true;
                maybeDone();
              });
            } catch (e) {
              fail(e);
            }
          })();
        } else {
          if (method !== "GET" && method !== "HEAD")
            head += `content-length: 0\r
`;
          head += `\r
`;
          outbox.write(head, false, (err) => {
            if (err)
              return;
            requestSent = true;
            maybeDone();
          });
        }
        if (!finished) {
          arm();
          pump();
        }
      });
    }
    async function request(port, req) {
      if (closed)
        throw netError("ECONNRESET", "runtime closed");
      req.signal?.throwIfAborted();
      for (;; ) {
        const conn = await acquire(port, req.signal);
        const reused = conn.reused;
        try {
          return await exchange(conn, req);
        } catch (e) {
          const stale = reused && e?.beforeResponse === true && !(req.body instanceof ReadableStream);
          if (!stale || req.signal?.aborted)
            throw e;
        }
      }
    }
    function close() {
      closed = true;
      for (const conn of [...live])
        destroy(conn);
      for (const pool of pools.values())
        for (const wake of pool.waiters.splice(0))
          wake();
    }
    return { request, close, codec };
  }
  function headerPairs(init) {
    if (!init)
      return [];
    const out = [];
    new Headers(init).forEach((value, name) => out.push([name, value]));
    return out;
  }
  async function wireBody(body) {
    if (body == null)
      return { body: null };
    if (typeof body === "string")
      return { body: encoder4.encode(body), type: "text/plain;charset=UTF-8" };
    if (body instanceof Uint8Array)
      return { body };
    if (body instanceof ArrayBuffer)
      return { body: new Uint8Array(body) };
    if (ArrayBuffer.isView(body))
      return { body: new Uint8Array(body.buffer, body.byteOffset, body.byteLength) };
    if (body instanceof ReadableStream)
      return { body };
    const r = new Response(body);
    return { body: new Uint8Array(await r.arrayBuffer()), type: r.headers.get("content-type") ?? undefined };
  }
  function toResponse(res) {
    const headers = new Headers;
    for (const [name, value] of res.headers) {
      try {
        headers.append(name, value);
      } catch {}
    }
    const status = res.status >= 200 && res.status <= 599 ? res.status : 502;
    const nullBody = status === 204 || status === 205 || status === 304;
    return new Response(nullBody ? null : res.body, { status, statusText: /^[\t\x20-\x7e\x80-\xff]*$/.test(res.statusText) ? res.statusText : "", headers });
  }

  // runtime/src/trace.ts
  var TRACE_CHANNEL = "bat-trace";
  var channel;
  var source = "";
  function traceEnable(src) {
    source = src;
    channel ??= new BroadcastChannel(TRACE_CHANNEL);
  }
  var tracing = () => channel !== undefined;
  function trace(name, data, at) {
    if (channel)
      channel.postMessage({ src: source, name, t: performance.timeOrigin + (at ?? performance.now()), data });
  }
  function traceCommand(cmd, answer) {
    if (!channel)
      return;
    const listener = new BroadcastChannel(TRACE_CHANNEL);
    listener.onmessage = (e) => {
      if (e.data?.cmd === cmd)
        answer();
    };
  }

  // runtime/src/net/net.ts
  var LOOPBACK = new Set(["", "localhost", "127.0.0.1", "::1", "[::1]", "0.0.0.0", "::", "[::]", "ip6-localhost"]);
  var V4 = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var V6 = /^(?:(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,7}:|(?:[0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,5}(?::[0-9a-f]{1,4}){1,2}|(?:[0-9a-f]{1,4}:){1,4}(?::[0-9a-f]{1,4}){1,3}|(?:[0-9a-f]{1,4}:){1,3}(?::[0-9a-f]{1,4}){1,4}|(?:[0-9a-f]{1,4}:){1,2}(?::[0-9a-f]{1,4}){1,5}|[0-9a-f]{1,4}:(?::[0-9a-f]{1,4}){1,6}|:(?:(?::[0-9a-f]{1,4}){1,7}|:)|(?:[0-9a-f]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}|::(?:ffff(?::0{1,4})?:)?(?:\d{1,3}\.){3}\d{1,3})(?:%.+)?$/i;
  var isIPv4 = (s) => typeof s === "string" && V4.test(s);
  var isIPv6 = (s) => typeof s === "string" && V6.test(s);
  var isIP = (s) => isIPv4(s) ? 4 : isIPv6(s) ? 6 : 0;
  var isLoopback = (host) => host === undefined || LOOPBACK.has(host.toLowerCase()) || /^127\.\d+\.\d+\.\d+$/.test(host) || host.toLowerCase().endsWith(".localhost");
  function pathPort(path) {
    let h = 2166136261;
    for (let i = 0;i < path.length; i++) {
      h ^= path.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return 20000 + (h >>> 0) % 20000;
  }
  var kInternals = Symbol.for("bat.net.internals");
  function getNet(rt) {
    const r = rt;
    return r[kInternals] ??= createNet(rt);
  }
  function createNet(rt) {
    const kernel = rt.kernel;
    const loop = rt.loop;
    const codec = getCodec(kernel);
    const { Duplex } = rt.require("stream");
    const EventEmitter = rt.require("events");
    const { Buffer } = rt.require("buffer");
    const io = { on: (fd, mask, cb) => loop.onFd(fd, mask, cb), off: (fd) => loop.offFd(fd) };
    const alloc = (n) => Buffer.allocUnsafe(n);
    const sysError = (code, syscall, extra = {}) => {
      const address = extra.address !== undefined ? ` ${extra.address}${extra.port !== undefined ? `:${extra.port}` : ""}` : "";
      return Object.assign(new Error(`${syscall} ${code}${address}`), { code, syscall, errno: -{ ECONNREFUSED: 111, EADDRINUSE: 98, EPIPE: 32, ECONNRESET: 104, ENETUNREACH: 101, ENOTFOUND: 3008 }[code] || -1, ...extra });
    };

    class Socket extends Duplex {
      _fd = -1;
      _out;
      _wantOut = false;
      _reading = false;
      _consumer = null;
      _refed = true;
      _held = false;
      _timer;
      _timeoutMs = 0;
      _pendingWrites = [];
      connecting = false;
      server = null;
      bytesRead = 0;
      bytesWritten = 0;
      remoteAddress;
      remoteFamily;
      remotePort;
      localAddress;
      localPort;
      _path;
      constructor(options = {}) {
        super({ allowHalfOpen: options.allowHalfOpen ?? false, emitClose: true, autoDestroy: true, highWaterMark: options.highWaterMark });
        if (typeof options.fd === "number")
          this._attach(options.fd);
        if (options.signal) {
          const onAbort = () => this.destroy(Object.assign(new Error("The operation was aborted"), { name: "AbortError", code: "ABORT_ERR" }));
          if (options.signal.aborted)
            loop.nextTick(onAbort);
          else
            options.signal.addEventListener("abort", onAbort, { once: true });
        }
      }
      _attach(fd) {
        this._fd = fd;
        kernel.setNonblock(fd, true);
        this._out = createOutbox(codec, fd, (on) => {
          this._wantOut = on;
          this._arm();
        });
        const ports = kernel.sockPorts(fd);
        this.localAddress = "127.0.0.1";
        this.localPort = ports.local;
        this.remoteAddress = "127.0.0.1";
        this.remoteFamily = "IPv4";
        this.remotePort = ports.peer;
        this._hold();
        this._arm();
      }
      _hold() {
        const want = this._refed && this._fd >= 0;
        if (want !== this._held) {
          this._held = want;
          if (want)
            loop.ref();
          else
            loop.unref();
        }
      }
      _arm() {
        if (this._fd < 0)
          return;
        const mask = POLLHUP2 | POLLERR | (this._reading || this._consumer ? POLLIN2 : 0) | (this._wantOut ? POLLOUT2 : 0);
        io.on(this._fd, mask, this._onReady);
      }
      _onReady = (mask) => {
        if (this._fd < 0)
          return;
        if (mask & (POLLOUT2 | POLLERR))
          this._out.flush();
        if (this._fd < 0)
          return;
        if (mask & (POLLIN2 | POLLHUP2)) {
          if (this._consumer)
            this._consumer(mask);
          else if (this._reading)
            this._doRead();
        }
      };
      _doRead() {
        while (this._reading && this._fd >= 0 && !this._consumer) {
          const r = codec.read(this._fd, alloc);
          if (typeof r === "number") {
            if (r === -EAGAIN2)
              return;
            this._reading = false;
            this._arm();
            if (r === 0)
              this.push(null);
            else
              this.destroy(sysError("ECONNRESET", "read"));
            return;
          }
          this.bytesRead += r.length;
          this._active();
          if (!this.push(r)) {
            this._reading = false;
            this._arm();
            return;
          }
        }
      }
      _read() {
        if (this._fd < 0 || this._consumer) {
          this._reading = true;
          return;
        }
        if (!this._reading) {
          this._reading = true;
          this._arm();
        }
        this._doRead();
      }
      _release() {
        this._consumer = null;
        if (this._fd >= 0) {
          this._arm();
          if (this._reading)
            this._doRead();
        }
      }
      _write(chunk, _encoding, cb) {
        if (this.connecting)
          return void this._pendingWrites.push({ chunk, cb });
        if (this._fd < 0 || !this._out)
          return cb(sysError("EPIPE", "write"));
        this.bytesWritten += chunk.length;
        this._active();
        this._out.write(chunk, false, (err) => cb(err ? sysError("EPIPE", "write") : null));
      }
      _writev(chunks, cb) {
        if (this.connecting)
          return void this._pendingWrites.push({ chunk: Buffer.concat(chunks.map((c) => c.chunk)), cb });
        if (this._fd < 0 || !this._out)
          return cb(sysError("EPIPE", "write"));
        this._active();
        for (let i = 0;i < chunks.length; i++) {
          const last = i === chunks.length - 1;
          this.bytesWritten += chunks[i].chunk.length;
          this._out.write(chunks[i].chunk, false, last ? (err) => cb(err ? sysError("EPIPE", "write") : null) : undefined);
        }
      }
      _final(cb) {
        if (this.connecting)
          return void this.once("connect", () => this._final(cb));
        if (this._fd < 0 || !this._out)
          return cb();
        const fd = this._fd;
        this._out.write("", false, () => {
          if (this._fd === fd) {
            try {
              kernel.shutdown(fd);
            } catch {}
          }
          cb();
        });
      }
      _destroy(err, cb) {
        this.connecting = false;
        if (this._timer)
          this._timer.close?.();
        this._timer = undefined;
        const fd = this._fd;
        if (fd >= 0) {
          this._fd = -1;
          io.off(fd);
          this._out?.fail(sysError("EPIPE", "write"));
          try {
            kernel.close(fd);
          } catch {}
          this._hold();
        }
        for (const w of this._pendingWrites.splice(0))
          w.cb(err ?? sysError("EPIPE", "write"));
        const server = this.server;
        if (server) {
          this.server = null;
          server._connectionClosed(this);
        }
        cb(err);
      }
      _active() {
        if (this._timer)
          this._timer.refresh();
      }
      connect(...args) {
        const { options, cb } = normalizeConnectArgs(args);
        if (cb)
          this.once("connect", cb);
        if (this._fd >= 0 || this.connecting)
          throw Object.assign(new Error("Socket is already connected"), { code: "ERR_SOCKET_ALREADY_CONNECTED" });
        this.connecting = true;
        this._path = options.path;
        const host = options.host ?? "localhost";
        const port = options.path !== undefined ? pathPort(String(options.path)) : Number(options.port);
        loop.ref();
        loop.nextTick(() => {
          loop.unref();
          if (!this.connecting || this.destroyed)
            return;
          if (options.path === undefined && !isLoopback(host)) {
            return this.destroy(sysError(isIP(host) ? "ENETUNREACH" : "ENOTFOUND", isIP(host) ? "connect" : "getaddrinfo", { address: host, port, hostname: host }));
          }
          if (options.lookup || !isIP(host))
            this.emit("lookup", null, "127.0.0.1", 4, host);
          const fd = kernel.x.bat_connect(port);
          if (fd < 0) {
            return this.destroy(sysError("ECONNREFUSED", "connect", options.path !== undefined ? { address: options.path } : { address: "127.0.0.1", port }));
          }
          this.connecting = false;
          const wasReading = this._reading;
          this._reading = false;
          this._attach(fd);
          this.emit("connect");
          this.emit("ready");
          for (const w of this._pendingWrites.splice(0))
            this._write(w.chunk, "buffer", w.cb);
          if (wasReading || this.readableFlowing)
            this._read();
        });
        return this;
      }
      setTimeout(ms, cb) {
        if (this._timer)
          this._timer.close?.();
        this._timer = undefined;
        this._timeoutMs = ms;
        if (ms > 0) {
          this._timer = loop.setTimeout(() => {
            this._timer = undefined;
            this.emit("timeout");
          }, ms);
          this._timer.unref?.();
          if (cb)
            this.once("timeout", cb);
        } else if (cb)
          this.removeListener("timeout", cb);
        return this;
      }
      get timeout() {
        return this._timeoutMs || undefined;
      }
      setNoDelay() {
        return this;
      }
      setKeepAlive() {
        return this;
      }
      ref() {
        this._refed = true;
        this._hold();
        return this;
      }
      unref() {
        this._refed = false;
        this._hold();
        return this;
      }
      address() {
        if (this._fd < 0)
          return {};
        return { address: this.localAddress, family: "IPv4", port: this.localPort };
      }
      get pending() {
        return this._fd < 0 && !this.destroyed;
      }
      get readyState() {
        if (this.connecting)
          return "opening";
        if (this.readable && this.writable)
          return "open";
        if (this.readable && !this.writable)
          return "readOnly";
        if (!this.readable && this.writable)
          return "writeOnly";
        return "closed";
      }
      get bufferSize() {
        return this.writableLength;
      }
      get remoteFamilyName() {
        return this.remoteFamily;
      }
      destroySoon() {
        if (this.writable)
          this.end();
        if (this.writableFinished)
          this.destroy();
        else
          this.once("finish", this.destroy);
      }
      resetAndDestroy() {
        return this.destroy();
      }
    }
    function normalizeConnectArgs(args) {
      if (Array.isArray(args[0]))
        args = args[0];
      let options = {};
      const first = args[0];
      if (typeof first === "object" && first !== null)
        options = { ...first };
      else if (typeof first === "string" && !/^\d+$/.test(first))
        options = { path: first };
      else {
        options = { port: Number(first) };
        if (typeof args[1] === "string")
          options.host = args[1];
      }
      const cb = typeof args[args.length - 1] === "function" ? args[args.length - 1] : undefined;
      return { options, cb };
    }

    class Server extends EventEmitter {
      _fd = -1;
      _refed = true;
      _held = false;
      _connections = new Set;
      _address = null;
      listening = false;
      allowHalfOpen;
      pauseOnConnect;
      maxConnections;
      _options;
      constructor(options, listener) {
        super();
        if (typeof options === "function") {
          listener = options;
          options = {};
        }
        this._options = options ?? {};
        this.allowHalfOpen = !!this._options.allowHalfOpen;
        this.pauseOnConnect = !!this._options.pauseOnConnect;
        if (listener)
          this.on("connection", listener);
      }
      _hold() {
        const want = this._refed && this._fd >= 0;
        if (want !== this._held) {
          this._held = want;
          if (want)
            loop.ref();
          else
            loop.unref();
        }
      }
      listen(...args) {
        const cb = typeof args[args.length - 1] === "function" ? args.pop() : undefined;
        let port = 0;
        let host;
        let path;
        const first = args[0];
        if (typeof first === "object" && first !== null) {
          port = Number(first.port ?? 0);
          host = first.host;
          path = first.path;
          if (first.signal)
            first.signal.addEventListener("abort", () => this.close(), { once: true });
        } else if (typeof first === "string" && !/^\d+$/.test(first))
          path = first;
        else {
          port = Number(first ?? 0);
          if (typeof args[1] === "string")
            host = args[1];
        }
        if (this._fd >= 0)
          throw Object.assign(new Error("Listen method has been called more than once without closing."), { code: "ERR_SERVER_ALREADY_LISTEN" });
        if (cb)
          this.once("listening", cb);
        const want = path !== undefined ? pathPort(path) : port;
        const fd = kernel.x.bat_listen(want);
        if (fd < 0) {
          const err = sysError(fd === -98 ? "EADDRINUSE" : "EACCES", "listen", path !== undefined ? { address: path } : { address: host ?? "::", port });
          loop.ref();
          loop.nextTick(() => {
            loop.unref();
            this.emit("error", err);
          });
          return this;
        }
        this._fd = fd;
        kernel.setNonblock(fd, true);
        const bound = kernel.sockPorts(fd).local;
        if (tracing())
          trace(`listen ${bound}`, { pid: rt.process?.pid, loader: { ...rt.loader?.stats }, resolveMs: rt.loader?.resolver.stats.ms });
        const address = host === undefined ? "::" : host === "localhost" ? "127.0.0.1" : host;
        this._address = path !== undefined ? path : { address, family: isIPv6(address) ? "IPv6" : "IPv4", port: bound };
        this.listening = true;
        this._hold();
        io.on(fd, POLLIN2, () => this._accept());
        loop.nextTick(() => {
          if (this._fd === fd)
            this.emit("listening");
        });
        return this;
      }
      _accept() {
        while (this._fd >= 0) {
          const fd = kernel.accept(this._fd);
          if (fd === undefined)
            return;
          if (this.maxConnections !== undefined && this._connections.size >= this.maxConnections) {
            kernel.close(fd);
            this.emit("drop", {});
            continue;
          }
          const socket = new Socket({ allowHalfOpen: this.allowHalfOpen, highWaterMark: this._options.highWaterMark });
          socket.server = this;
          this._connections.add(socket);
          socket._attach(fd);
          if (this.pauseOnConnect)
            socket.pause();
          this.emit("connection", socket);
        }
      }
      _connectionClosed(socket) {
        this._connections.delete(socket);
        if (this._fd < 0 && this._connections.size === 0 && this._closing) {
          this._closing = false;
          loop.nextTick(() => this.emit("close"));
        }
      }
      _closing = false;
      close(cb) {
        if (this._fd < 0) {
          const err = Object.assign(new Error("Server is not running."), { code: "ERR_SERVER_NOT_RUNNING" });
          if (cb)
            loop.nextTick(cb, err);
          return this;
        }
        if (cb)
          this.once("close", cb);
        const fd = this._fd;
        this._fd = -1;
        this.listening = false;
        io.off(fd);
        kernel.close(fd);
        this._hold();
        if (this._connections.size === 0)
          loop.nextTick(() => this.emit("close"));
        else
          this._closing = true;
        return this;
      }
      address() {
        return this._fd >= 0 ? this._address : null;
      }
      getConnections(cb) {
        loop.nextTick(cb, null, this._connections.size);
        return this;
      }
      get connections() {
        return this._connections.size;
      }
      ref() {
        this._refed = true;
        this._hold();
        return this;
      }
      unref() {
        this._refed = false;
        this._hold();
        return this;
      }
      [Symbol.asyncDispose]() {
        return new Promise((resolve) => this._fd >= 0 ? this.close(() => resolve()) : resolve());
      }
    }
    const connect = (...args) => {
      const { options } = normalizeConnectArgs(args);
      const socket = new Socket(options);
      if (options.timeout)
        socket.setTimeout(options.timeout);
      return socket.connect(...args);
    };
    let autoSelectFamily = false;
    let autoSelectTimeout = 250;

    class BlockList {
      addAddress() {}
      addRange() {}
      addSubnet() {}
      check() {
        return false;
      }
      get rules() {
        return [];
      }
    }

    class SocketAddress {
      address;
      family;
      port;
      flowlabel = 0;
      constructor(o = {}) {
        this.address = o.address ?? "127.0.0.1";
        this.family = o.family ?? "ipv4";
        this.port = o.port ?? 0;
      }
    }
    const net = {
      Socket,
      Stream: Socket,
      Server,
      BlockList,
      SocketAddress,
      createServer: (options, listener) => new Server(options, listener),
      connect,
      createConnection: connect,
      isIP,
      isIPv4,
      isIPv6,
      getDefaultAutoSelectFamily: () => autoSelectFamily,
      setDefaultAutoSelectFamily: (v) => void (autoSelectFamily = !!v),
      getDefaultAutoSelectFamilyAttemptTimeout: () => autoSelectTimeout,
      setDefaultAutoSelectFamilyAttemptTimeout: (v) => void (autoSelectTimeout = v)
    };
    return { net, io, codec, isLoopback };
  }

  // runtime/src/net/tunnel.ts
  var WINDOW = 256 * 1024;
  var SCRATCH3 = 64 * 1024;
  var HEAD_MAX = 256 * 1024;
  var HIGH_WATER2 = 1 << 20;
  var WISP_STREAM = 1;
  function wispPacket(type, payload) {
    const packet = new Uint8Array(5 + payload.length);
    packet[0] = type;
    new DataView(packet.buffer).setUint32(1, WISP_STREAM, true);
    packet.set(payload, 5);
    return packet;
  }
  var wispRefusals = {
    65: ["EINVAL", "invalid destination"],
    66: ["EHOSTUNREACH", "unreachable"],
    67: ["ETIMEDOUT", "the destination did not answer"],
    68: ["ECONNREFUSED", "the destination refused the connection"],
    71: ["ETIMEDOUT", "the transfer timed out"],
    72: ["EACCES", "the relay blocks this destination"],
    73: ["EACCES", "throttled by the relay"]
  };
  var latin12 = new TextDecoder("latin1");
  var utf8 = new TextDecoder;
  var encoder5 = new TextEncoder;
  function instantiateTls(module, random = (bytes) => void crypto.getRandomValues(bytes)) {
    let memory;
    const view = () => new DataView(memory.buffer);
    const wasi = {
      random_get(ptr, len) {
        for (let at = 0;at < len; at += 65536)
          random(new Uint8Array(memory.buffer, ptr + at, Math.min(65536, len - at)));
        return 0;
      },
      clock_time_get(_id, _precision, out) {
        view().setBigUint64(out, BigInt(Date.now()) * 1000000n, true);
        return 0;
      },
      fd_write(_fd, iovs, count, written) {
        let total = 0;
        let text = "";
        for (let i = 0;i < count; i++) {
          const ptr = view().getUint32(iovs + i * 8, true);
          const len = view().getUint32(iovs + i * 8 + 4, true);
          text += utf8.decode(new Uint8Array(memory.buffer, ptr, len).slice());
          total += len;
        }
        if (text.trim())
          console.warn(`[bat tls] ${text.trimEnd()}`);
        view().setUint32(written, total, true);
        return 0;
      },
      environ_sizes_get(count, size) {
        view().setUint32(count, 0, true);
        view().setUint32(size, 0, true);
        return 0;
      },
      environ_get: () => 0,
      proc_exit(code) {
        throw new Error(`bat_tls.wasm stopped (exit ${code})`);
      }
    };
    const imports = {};
    for (const entry of WebAssembly.Module.imports(module)) {
      if (entry.kind !== "function")
        continue;
      (imports[entry.module] ??= {})[entry.name] = entry.module === "wasi_snapshot_preview1" && wasi[entry.name] || (() => 52);
    }
    const x = new WebAssembly.Instance(module, imports).exports;
    memory = x.memory;
    x._initialize?.();
    return { x, scratch: x.bat_alloc(SCRATCH3), testBuild: x.tls_test_build() === 1 };
  }
  function find(data, at, pattern) {
    outer:
      for (let i = at;i <= data.length - pattern.length; i++) {
        for (let j = 0;j < pattern.length; j++)
          if (data[i + j] !== pattern[j])
            continue outer;
        return i;
      }
    return -1;
  }
  function createResponseParser(headRequest, sink) {
    let state = "head";
    let held = new Uint8Array(0);
    let remaining = 0;
    const bad = (message) => {
      state = "done";
      sink.error(message);
    };
    const hold = (data, at, limit) => {
      if (data.length - at > limit)
        return false;
      held = data.slice(at);
      return true;
    };
    function push(chunk) {
      let data = chunk;
      if (held.length) {
        data = new Uint8Array(held.length + chunk.length);
        data.set(held);
        data.set(chunk, held.length);
        held = new Uint8Array(0);
      }
      let at = 0;
      for (;; ) {
        switch (state) {
          case "done":
            return;
          case "head": {
            const end = find(data, at, [13, 10, 13, 10]);
            if (end < 0) {
              if (!hold(data, at, HEAD_MAX))
                bad("the response head is too large");
              return;
            }
            const lines = latin12.decode(data.subarray(at, end)).split(`\r
`);
            at = end + 4;
            const status = /^HTTP\/1\.[01] (\d{3})(?: (.*))?$/.exec(lines[0]);
            if (!status)
              return bad("not an HTTP/1.1 response");
            const code = Number(status[1]);
            const headers = [];
            for (const line of lines.slice(1)) {
              const colon = line.indexOf(":");
              if (colon <= 0 || /[\s]/.test(line.slice(0, colon)))
                return bad("a malformed response header");
              headers.push([line.slice(0, colon), line.slice(colon + 1).trim()]);
            }
            if (code < 200)
              continue;
            const all = (name) => headers.filter(([n]) => n.toLowerCase() === name).map(([, v]) => v);
            const bodyless = headRequest || code === 204 || code === 304;
            if (bodyless)
              state = "done";
            else if (all("transfer-encoding").some((v) => /(^|,)\s*chunked\s*$/i.test(v)))
              state = "chunk-size";
            else {
              const lengths = [...new Set(all("content-length"))];
              if (lengths.length > 1 || lengths.length && !/^\d+$/.test(lengths[0]))
                return bad("an invalid content-length");
              if (lengths.length) {
                remaining = Number(lengths[0]);
                state = remaining ? "length" : "done";
              } else
                state = "close";
            }
            sink.head(code, status[2] ?? "", headers, bodyless);
            if (state === "done")
              return sink.end();
            continue;
          }
          case "close":
            if (at < data.length)
              sink.body(data.subarray(at));
            return;
          case "length":
          case "chunk-data": {
            const n = Math.min(remaining, data.length - at);
            if (n)
              sink.body(data.subarray(at, at + n));
            at += n;
            remaining -= n;
            if (remaining)
              return;
            if (state === "length") {
              state = "done";
              return sink.end();
            }
            state = "chunk-end";
            continue;
          }
          case "chunk-end":
            if (data.length - at < 2)
              return void hold(data, at, 2);
            if (data[at] !== 13 || data[at + 1] !== 10)
              return bad("a malformed chunk");
            at += 2;
            state = "chunk-size";
            continue;
          case "chunk-size": {
            const end = find(data, at, [13, 10]);
            if (end < 0) {
              if (!hold(data, at, 1024))
                bad("a malformed chunk size");
              return;
            }
            const size = latin12.decode(data.subarray(at, end)).split(";")[0].trim();
            if (!/^[0-9a-fA-F]{1,12}$/.test(size))
              return bad("a malformed chunk size");
            at = end + 2;
            remaining = parseInt(size, 16);
            state = remaining ? "chunk-data" : "trailers";
            continue;
          }
          case "trailers": {
            const end = find(data, at, [13, 10]);
            if (end < 0) {
              if (!hold(data, at, HEAD_MAX))
                bad("the response trailers are too large");
              return;
            }
            const empty = end === at;
            at = end + 2;
            if (!empty)
              continue;
            state = "done";
            return sink.end();
          }
        }
      }
    }
    return {
      push,
      eof(clean) {
        if (state === "done")
          return;
        if (state === "close" && clean) {
          state = "done";
          return sink.end();
        }
        bad(state === "head" ? "the connection closed before a response" : "the connection closed in the middle of the response");
      },
      get done() {
        return state === "done";
      }
    };
  }
  var HOP = /^(host|connection|keep-alive|proxy-connection|transfer-encoding|content-length|upgrade|te|trailer|expect)$/i;
  function requestHead(req, framing) {
    const method = req.method.toUpperCase();
    if (!/^[A-Z]+$/.test(method))
      throw new TypeError(`fetch failed: invalid method ${JSON.stringify(req.method)}`);
    let head = `${method} ${req.url.pathname}${req.url.search} HTTP/1.1\r
host: ${req.url.host}\r
`;
    for (const [name, value] of req.headers) {
      if (HOP.test(name))
        continue;
      if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name) || /[\r\n\0]/.test(value))
        throw new TypeError(`fetch failed: invalid header ${JSON.stringify(name)}`);
      head += `${name}: ${value}\r
`;
    }
    return `${head}${framing}connection: close\r
\r
`;
  }
  function tunnelRequest(deps, req) {
    return new Promise((resolve, reject) => {
      const host = req.url.hostname;
      const port = Number(req.url.port) || 443;
      let ws;
      let engine;
      let conn = 0;
      let over = false;
      let settled = false;
      let controller;
      let relayOpen = false;
      const outQueue = [];
      let outQueued = 0;
      let unacked = 0;
      const wisp = deps.protocol === "wisp";
      let credit = 0;
      const inQueue = [];
      let inEnded = false;
      let eofFed = false;
      let pumping = false;
      const waiters = [];
      const wake = () => {
        for (const waiter of waiters.splice(0))
          waiter();
      };
      const cleanup = () => {
        req.signal?.removeEventListener("abort", onAbort);
        if (conn && engine)
          engine.x.tls_free(conn);
        conn = 0;
        try {
          if (wisp && relayOpen && ws?.readyState === 1)
            ws.send(wispPacket(4, new Uint8Array([2])));
          ws?.close(1000);
        } catch {}
        wake();
      };
      const fail = (error) => {
        if (over)
          return;
        over = true;
        cleanup();
        if (!settled) {
          settled = true;
          reject(error);
        } else {
          try {
            controller?.error(error);
          } catch {}
        }
      };
      const onAbort = () => fail(req.signal.reason ?? new DOMException("The operation was aborted.", "AbortError"));
      const tlsError = () => {
        const { x, scratch } = engine;
        const n = x.tls_error(conn, scratch, 1024);
        return utf8.decode(new Uint8Array(x.memory.buffer, scratch, n).slice());
      };
      const send = () => {
        while (outQueue.length && relayOpen && ws?.readyState === 1) {
          const chunk = outQueue[0];
          if (wisp) {
            if (!credit)
              return;
            credit--;
            ws.send(wispPacket(2, chunk));
          } else {
            if (unacked && unacked + chunk.length > WINDOW)
              return;
            ws.send(chunk);
            unacked += chunk.length;
          }
          outQueued -= chunk.length;
          outQueue.shift();
        }
      };
      const flush = () => {
        const { x, scratch } = engine;
        for (let n;conn && (n = x.tls_out(conn, scratch, SCRATCH3)) > 0; ) {
          outQueue.push(new Uint8Array(x.memory.buffer, scratch, n).slice());
          outQueued += n;
        }
        send();
      };
      async function write(bytes) {
        const { x, scratch } = engine;
        for (let at = 0;at < bytes.length; ) {
          if (over)
            throw netError("ECONNRESET", "the connection is closed");
          const n = Math.min(bytes.length - at, SCRATCH3);
          new Uint8Array(x.memory.buffer, scratch, n).set(bytes.subarray(at, at + n));
          const took = x.tls_write(conn, scratch, n);
          if (took < 0)
            throw netError("EPROTO", `TLS: ${tlsError()}`);
          at += took;
          flush();
          if (took === 0 || outQueued > WINDOW)
            await new Promise((next) => waiters.push(next));
        }
      }
      const finish = () => {
        if (over)
          return;
        over = true;
        engine.x.tls_close(conn);
        flush();
        cleanup();
        try {
          controller?.close();
        } catch {}
      };
      const parser = createResponseParser(req.method.toUpperCase() === "HEAD", {
        head(status, reason, headers, bodyless) {
          const { x, scratch } = engine;
          const tls = utf8.decode(new Uint8Array(x.memory.buffer, scratch, x.tls_info(conn, scratch, 256)).slice());
          const body = new ReadableStream({
            start(c) {
              controller = c;
            },
            pull() {
              pump();
            },
            cancel() {
              fail(netError("ECONNRESET", "response body cancelled"));
            }
          }, new ByteLengthQueuingStrategy({ highWaterMark: HIGH_WATER2 }));
          settled = true;
          resolve({ status, statusText: reason, headers, body: bodyless ? null : body, tls });
        },
        body(chunk) {
          try {
            controller?.enqueue(chunk);
          } catch {}
        },
        end: finish,
        error: (message) => fail(netError("HPE_INVALID", `HTTP over the tunnel to ${host}: ${message}`))
      });
      const wantMore = () => !controller || (controller.desiredSize ?? 1) > 0;
      function pump() {
        if (over || !conn || pumping)
          return;
        pumping = true;
        const { x, scratch } = engine;
        let taken = 0;
        try {
          for (let progressed = true;progressed && !over; ) {
            progressed = false;
            while (inQueue.length) {
              const chunk = inQueue[0];
              const n = Math.min(chunk.length, SCRATCH3);
              new Uint8Array(x.memory.buffer, scratch, n).set(chunk.subarray(0, n));
              const took = x.tls_in(conn, scratch, n);
              if (took < 0) {
                const message = tlsError();
                flush();
                return fail(netError("EPROTO", `TLS with ${host}: ${message}`));
              }
              if (took === 0)
                break;
              progressed = true;
              taken += took;
              if (took === chunk.length)
                inQueue.shift();
              else
                inQueue[0] = chunk.subarray(took);
              if (took < n)
                break;
            }
            if (inEnded && !inQueue.length && !eofFed) {
              eofFed = true;
              x.tls_in_eof(conn);
              progressed = true;
            }
            flush();
            while (wantMore() && !over) {
              const n = x.tls_read(conn, scratch, SCRATCH3);
              if (n === 0)
                break;
              if (n < 0) {
                const detail = n === -2 ? tlsError() : "";
                parser.eof(n === -1);
                if (!over)
                  fail(netError("ECONNRESET", `TLS with ${host}: ${detail || "closed"}`));
                return;
              }
              progressed = true;
              parser.push(new Uint8Array(x.memory.buffer, scratch, n).slice());
            }
            if (!wantMore())
              break;
          }
        } finally {
          pumping = false;
          if (taken && !wisp && relayOpen && ws?.readyState === 1)
            ws.send(JSON.stringify({ t: "ack", bytes: taken }));
          wake();
        }
      }
      async function sendRequest() {
        const method = req.method.toUpperCase();
        const body = req.body;
        if (body instanceof Uint8Array) {
          await write(encoder5.encode(requestHead(req, `content-length: ${body.length}\r
`)));
          await write(body);
        } else if (body) {
          await write(encoder5.encode(requestHead(req, `transfer-encoding: chunked\r
`)));
          const reader = body.getReader();
          try {
            for (;; ) {
              const { done, value } = await reader.read();
              if (over)
                return;
              if (done)
                break;
              if (!value?.length)
                continue;
              await write(encoder5.encode(`${value.length.toString(16)}\r
`));
              await write(value);
              await write(encoder5.encode(`\r
`));
            }
            await write(encoder5.encode(`0\r
\r
`));
          } finally {
            if (over)
              reader.cancel().catch(() => {});
          }
        } else {
          await write(encoder5.encode(requestHead(req, method === "GET" || method === "HEAD" ? "" : `content-length: 0\r
`)));
        }
      }
      function start() {
        const { x, scratch } = engine;
        const name = encoder5.encode(host);
        new Uint8Array(x.memory.buffer, scratch, name.length).set(name);
        conn = x.tls_new(scratch, name.length);
        if (!conn) {
          const n = x.tls_error(0, scratch, 1024);
          return fail(netError("EPROTO", `TLS with ${host}: ${utf8.decode(new Uint8Array(x.memory.buffer, scratch, n).slice())}`));
        }
        flush();
        sendRequest().catch((error) => {
          if (!over)
            fail(error);
        });
      }
      function onWisp(packet) {
        if (packet.length < 5)
          return;
        const type = packet[0];
        const stream = new DataView(packet.buffer, packet.byteOffset).getUint32(1, true);
        if (!relayOpen) {
          relayOpen = true;
          const name = encoder5.encode(host);
          const connect = new Uint8Array(3 + name.length);
          connect[0] = 1;
          new DataView(connect.buffer).setUint16(1, port, true);
          connect.set(name, 3);
          ws.send(wispPacket(1, connect));
          start();
          if (over)
            return;
        }
        if (type === 3 && packet.length >= 9 && (stream === 0 || stream === WISP_STREAM)) {
          credit = new DataView(packet.buffer, packet.byteOffset).getUint32(5, true);
          send();
          wake();
        } else if (type === 2 && stream === WISP_STREAM) {
          inQueue.push(packet.subarray(5));
          pump();
        } else if (type === 4 && stream === WISP_STREAM) {
          const refusal = wispRefusals[packet[5] ?? 0];
          if (refusal)
            return fail(netError(refusal[0], `the relay could not carry the connection to ${host}:${port} (${refusal[1]})`));
          inEnded = true;
          pump();
        }
      }
      function onControl(text) {
        let control;
        try {
          control = JSON.parse(text);
        } catch {
          return;
        }
        if (control.t === "open") {
          if (relayOpen)
            return;
          relayOpen = true;
          start();
        } else if (control.t === "ack" && Number.isFinite(control.bytes)) {
          unacked = Math.max(0, unacked - Number(control.bytes));
          send();
          wake();
        } else if (control.t === "end") {
          inEnded = true;
          pump();
        } else if (control.t === "error") {
          const code = String(control.code ?? "reset");
          const what = code === "denied" ? `the relay refused ${host}:${port}` : `the relay could not carry the connection to ${host}:${port}`;
          fail(netError(code === "denied" ? "EACCES" : code === "refused" ? "ECONNREFUSED" : code === "timeout" ? "ETIMEDOUT" : code === "dns" ? "ENOTFOUND" : "ECONNRESET", `${what} (${code}: ${String(control.message ?? "").slice(0, 200)})`));
        }
      }
      if (req.signal?.aborted)
        return onAbort();
      req.signal?.addEventListener("abort", onAbort, { once: true });
      deps.engine().then((loaded) => {
        if (over)
          return;
        engine = loaded;
        const relay = new URL(deps.relayUrl);
        if (!wisp) {
          relay.searchParams.set("host", host);
          relay.searchParams.set("port", String(port));
        }
        ws = new deps.WebSocket(relay.href);
        ws.binaryType = "arraybuffer";
        ws.onmessage = (event) => {
          if (over)
            return;
          if (wisp)
            return typeof event.data === "string" ? undefined : onWisp(new Uint8Array(event.data));
          if (typeof event.data === "string")
            return onControl(event.data);
          inQueue.push(new Uint8Array(event.data));
          pump();
        };
        ws.onclose = () => {
          if (over)
            return;
          if (!relayOpen)
            return fail(netError("ECONNREFUSED", `the relay at ${relay.host} did not accept the WebSocket (it is unreachable, or this page's origin is not one it allows)`));
          inEnded = true;
          pump();
          if (!over && !inQueue.length)
            fail(netError("ECONNRESET", `the relay closed the connection to ${host}:${port}`));
        };
      }, fail);
    });
  }

  // runtime/src/net/fetch.ts
  var HOST_ALIAS = "host.internal";
  var kFetch = Symbol.for("bat.net.fetch");
  var REDIRECTS = new Set([301, 302, 303, 307, 308]);
  function getGuestFetch(rt) {
    const r = rt;
    return r[kFetch] ??= createGuestFetch(rt);
  }
  function createGuestFetch(rt) {
    const { io } = getNet(rt);
    const loop = rt.loop;
    const browserFetch = rt.host.fetch;
    const said = (input, init, result) => {
      const process = rt.process;
      if (process?.env?.BAT_FETCH_DIAG !== "1")
        return;
      let where = "(unparsed URL)";
      try {
        const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
        where = url.origin + url.pathname;
      } catch {}
      const method = (init?.method ?? (typeof input === "object" && !(input instanceof URL) ? input.method : "GET")).toUpperCase();
      try {
        process.stderr?.write(`[bat fetch] ${method} ${where} -> ${result}
`);
      } catch {}
    };
    let mapText, map = {};
    const mapped = (input) => {
      const text = rt.process?.env?.BAT_FETCH_MAP;
      if (!text)
        return;
      if (text !== mapText) {
        mapText = text;
        try {
          map = JSON.parse(text);
        } catch {
          map = {};
        }
      }
      try {
        const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
        const to = map[url.origin + url.pathname];
        return typeof to === "string" ? to : undefined;
      } catch {
        return;
      }
    };
    const native = async (input, init) => {
      let response;
      try {
        const to = mapped(input);
        if (to !== undefined)
          response = await browserFetch(to, { signal: init?.signal ?? (typeof input === "object" && !(input instanceof URL) ? input.signal : undefined) });
        else
          response = await browserFetch(input, init);
      } catch (error) {
        const name = error?.name;
        if (name !== "AbortError" && name !== "TimeoutError")
          said(input, init, `${name ?? "Error"}: ${String(error?.message ?? error).slice(0, 200)}`);
        throw error;
      }
      if (response.status >= 400)
        said(input, init, `HTTP ${response.status}`);
      return response;
    };
    const client = createHttpClient({ kernel: rt.kernel, io });
    const env = (name) => String(rt.process?.env?.[name] ?? "");
    const tunnelFor = (url) => {
      const relay = env("BAT_FETCH_TUNNEL_URL");
      if (!relay || url.protocol !== "https:")
        return;
      const at = url.origin + url.pathname;
      const named = env("BAT_FETCH_TUNNEL").split(/[\s,]+/).some((entry) => entry.includes("/") ? at.startsWith(entry) : entry.toLowerCase() === url.hostname);
      return named ? relay : undefined;
    };
    let engine;
    const tlsEngine = () => engine ??= (async () => {
      const url = rt.config.wasm.tls;
      if (!url)
        throw new Error("this runtime was started without its TLS module (bat_tls.wasm)");
      const response = await browserFetch(url);
      if (!response.ok)
        throw new Error(`${url}: HTTP ${response.status}`);
      const loaded = instantiateTls(await WebAssembly.compile(await response.arrayBuffer()));
      if (loaded.testBuild) {
        try {
          rt.process?.stderr?.write(`[bat fetch] bat_tls.wasm is a TEST build: it trusts a test certificate besides the public roots
`);
        } catch {}
      }
      return loaded;
    })().catch((error) => {
      engine = undefined;
      throw error;
    });
    async function tunnelled(relay, url, req) {
      const via = `tunnel via ${(() => {
        try {
          return new URL(relay).host;
        } catch {
          return "an unreadable relay address";
        }
      })()}`;
      try {
        const res = await tunnelRequest({ relayUrl: relay, protocol: env("BAT_FETCH_TUNNEL_PROTOCOL") === "wisp" ? "wisp" : "relay", WebSocket: rt.host.WebSocket, engine: tlsEngine }, { url, ...req });
        said(url, { method: req.method }, `HTTP ${res.status} (${via}, ${res.tls})`);
        return { status: res.status, statusText: res.statusText, headers: res.headers, body: res.body, url: url.href };
      } catch (error) {
        const name = error?.name;
        if (name !== "AbortError" && name !== "TimeoutError")
          said(url, { method: req.method }, `${via}: ${String(error?.message ?? error).slice(0, 300)}`);
        throw error;
      }
    }
    async function tunnelFetch(relay, url, input, init) {
      const given = typeof input === "object" && !(input instanceof URL) ? input : undefined;
      let method = (init?.method ?? given?.method ?? "GET").toUpperCase();
      const signal = init?.signal ?? given?.signal ?? undefined;
      const redirect = init?.redirect ?? given?.redirect ?? "follow";
      let headers = headerPairs(init?.headers ?? given?.headers);
      const has = (name) => headers.some(([n]) => n.toLowerCase() === name);
      let body = null;
      if (init?.body != null) {
        const wire = await wireBody(init.body);
        body = wire.body;
        if (wire.type && !has("content-type"))
          headers.push(["content-type", wire.type]);
      } else if (given?.body)
        body = new Uint8Array(await given.arrayBuffer());
      if (!has("accept"))
        headers.push(["accept", "*/*"]);
      if (!has("user-agent"))
        headers.push(["user-agent", "node"]);
      if (!has("accept-encoding"))
        headers.push(["accept-encoding", "identity"]);
      let res;
      let redirected = false;
      for (let hops = 0;; hops++) {
        try {
          res = await tunnelled(relay, url, { method, headers, body, signal });
        } catch (e) {
          if (e?.name === "AbortError" || e?.name === "TimeoutError")
            throw e;
          throw new TypeError(`fetch failed: ${String(e?.message ?? e)}`, { cause: e });
        }
        const location = redirect !== "manual" && REDIRECTS.has(res.status) ? res.headers.find(([n]) => n.toLowerCase() === "location")?.[1] : undefined;
        if (location === undefined)
          break;
        await res.body?.cancel().catch(() => {});
        if (redirect === "error")
          throw new TypeError("fetch failed: unexpected redirect");
        if (hops >= 20)
          throw new TypeError("fetch failed: redirect count exceeded");
        if (body instanceof ReadableStream)
          throw new TypeError("fetch failed: a redirect of a request with a streamed body");
        const next = new URL(location, url);
        if (res.status === 303 || (res.status === 301 || res.status === 302) && method === "POST") {
          method = "GET";
          body = null;
          headers = headers.filter(([n]) => !/^content-/i.test(n));
        }
        if (next.origin !== url.origin)
          headers = headers.filter(([n]) => !/^(authorization|cookie|proxy-authorization)$/i.test(n));
        const onward = tunnelFor(next);
        if (!onward)
          return guestFetch(next, { method, headers: headers.filter(([n]) => !/^(accept-encoding|user-agent)$/i.test(n)), body, signal, redirect });
        relay = onward;
        url = next;
        redirected = true;
      }
      let stream = track(res.body);
      const encoding = res.headers.find(([n]) => n.toLowerCase() === "content-encoding")?.[1]?.trim().toLowerCase();
      if (stream && (encoding === "gzip" || encoding === "deflate")) {
        stream = stream.pipeThrough(new DecompressionStream(encoding));
        res.headers = res.headers.filter(([n]) => !/^content-(encoding|length)$/i.test(n));
      }
      const response = toResponse({ ...res, body: stream });
      Object.defineProperty(response, "url", { value: res.url, configurable: true });
      if (redirected)
        Object.defineProperty(response, "redirected", { value: true, configurable: true });
      return response;
    }
    const pageOrigin = new URL(rt.host.location.origin);
    const stripBrackets = (h) => h.startsWith("[") ? h.slice(1, -1) : h;
    const hostPort = (url) => (rt.process?.env?.BAT_HOST_LOOPBACK_PORTS ?? "").split(",").includes(url.port || "80");
    const isLocal = (url) => url.protocol === "http:" && isLoopback(stripBrackets(url.hostname)) && !hostPort(url);
    const isHostAlias = (url) => url.hostname === HOST_ALIAS;
    const toPage = (url) => {
      const out = new URL(url.href);
      out.protocol = pageOrigin.protocol;
      out.hostname = pageOrigin.hostname;
      out.port = pageOrigin.port;
      return out;
    };
    function track(body) {
      if (!body)
        return null;
      const reader = body.getReader();
      return new ReadableStream({
        async pull(controller) {
          loop.ref();
          try {
            const { done, value } = await reader.read();
            if (done)
              controller.close();
            else
              controller.enqueue(value);
          } catch (e) {
            controller.error(e);
          } finally {
            loop.unref();
          }
        },
        cancel(reason) {
          return reader.cancel(reason);
        }
      });
    }
    async function local(url, req, follow) {
      let method = req.method;
      let body = req.body;
      let headers = req.headers;
      for (let hops = 0;; hops++) {
        const port = url.port ? Number(url.port) : 80;
        if (!headers.some(([n]) => n.toLowerCase() === "host"))
          headers = [["host", url.host], ...headers];
        const res = await client.request(port, { method, path: url.pathname + url.search, headers, body, signal: req.signal });
        const location = follow && REDIRECTS.has(res.status) ? res.headers.find(([n]) => n.toLowerCase() === "location")?.[1] : undefined;
        if (location === undefined)
          return { ...res, url: url.href };
        await res.body?.cancel().catch(() => {});
        if (hops >= 20)
          throw new TypeError("fetch failed: redirect count exceeded");
        const next = new URL(location, url);
        if (res.status === 303 || (res.status === 301 || res.status === 302) && method === "POST") {
          method = "GET";
          body = null;
          headers = headers.filter(([n]) => !/^content-/i.test(n));
        }
        headers = headers.filter(([n]) => n.toLowerCase() !== "host");
        if (!isLocal(next)) {
          const out = await native(isHostAlias(next) ? toPage(next) : next, { method, headers, body, signal: req.signal });
          return { status: out.status, statusText: out.statusText, headers: headerPairs(out.headers), body: out.body, url: out.url };
        }
        url = next;
      }
    }
    async function route(url, req) {
      loop.ref();
      try {
        if (isLocal(url)) {
          const res = await local(url, req, false);
          return { ...res, body: track(res.body) };
        }
        const relay = tunnelFor(url);
        if (relay) {
          const res = await tunnelled(relay, url, req);
          return { ...res, body: track(res.body) };
        }
        const headers = req.headers.filter(([n]) => !/^(host|connection|content-length|transfer-encoding|keep-alive|upgrade|expect|user-agent)$/i.test(n));
        const out = await native(isHostAlias(url) ? toPage(url) : url, { method: req.method, headers, body: req.method === "GET" || req.method === "HEAD" ? undefined : req.body, signal: req.signal, redirect: "manual" });
        return { status: out.status, statusText: out.statusText, headers: headerPairs(out.headers), body: track(out.body), url: url.href };
      } finally {
        loop.unref();
      }
    }
    function withoutUserAgent(input, init) {
      if (init?.headers) {
        const headers = new Headers(init.headers);
        if (!headers.has("user-agent"))
          return [input, init];
        headers.delete("user-agent");
        return [input, { ...init, headers }];
      }
      if (typeof input === "object" && !(input instanceof URL) && input.headers.has("user-agent")) {
        const headers = new Headers(input.headers);
        headers.delete("user-agent");
        return [new Request(input, { headers }), init];
      }
      return [input, init];
    }
    async function guestFetch(input, init) {
      let url;
      try {
        url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
      } catch {}
      loop.ref();
      try {
        if (url && isLocal(url)) {
          const request = new Request(input, init);
          const body = request.body ? new Uint8Array(await request.arrayBuffer()) : null;
          let res;
          try {
            res = await local(url, { method: request.method, headers: headerPairs(request.headers), body, signal: request.signal }, request.redirect !== "manual");
          } catch (e) {
            if (e?.name === "AbortError" || e?.name === "TimeoutError")
              throw e;
            throw new TypeError("fetch failed", { cause: e });
          }
          const response2 = toResponse({ ...res, body: track(res.body) });
          Object.defineProperty(response2, "url", { value: res.url, configurable: true });
          return response2;
        }
        const relay = url && tunnelFor(url);
        if (relay)
          return await tunnelFetch(relay, url, input, init);
        [input, init] = withoutUserAgent(input, init);
        let response;
        if (url && isHostAlias(url)) {
          if (typeof input === "object" && !(input instanceof URL))
            response = await native(new Request(toPage(url), input), init);
          else
            response = await native(toPage(url), init);
        } else
          response = await native(input, init);
        if (!response.body || response.status < 200)
          return response;
        const tracked = new Response(track(response.body), { status: response.status, statusText: response.statusText, headers: response.headers });
        for (const key of ["url", "redirected", "type"])
          Object.defineProperty(tracked, key, { value: response[key], configurable: true });
        return tracked;
      } finally {
        loop.unref();
      }
    }
    return { fetch: guestFetch, route, client };
  }
  function installFetch(rt) {
    const g = rt.host.global;
    if (g.fetch?.__bat)
      return;
    const gf = getGuestFetch(rt);
    const fetch2 = (input, init) => gf.fetch(input, init);
    Object.defineProperty(fetch2, "__bat", { value: true });
    Object.defineProperty(g, "fetch", { value: fetch2, writable: true, configurable: true, enumerable: true });
  }

  // runtime/src/net/http.ts
  var STATUS_CODES = {
    100: "Continue",
    101: "Switching Protocols",
    102: "Processing",
    103: "Early Hints",
    200: "OK",
    201: "Created",
    202: "Accepted",
    203: "Non-Authoritative Information",
    204: "No Content",
    205: "Reset Content",
    206: "Partial Content",
    207: "Multi-Status",
    208: "Already Reported",
    226: "IM Used",
    300: "Multiple Choices",
    301: "Moved Permanently",
    302: "Found",
    303: "See Other",
    304: "Not Modified",
    305: "Use Proxy",
    307: "Temporary Redirect",
    308: "Permanent Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Payload Too Large",
    414: "URI Too Long",
    415: "Unsupported Media Type",
    416: "Range Not Satisfiable",
    417: "Expectation Failed",
    418: "I'm a Teapot",
    421: "Misdirected Request",
    422: "Unprocessable Entity",
    423: "Locked",
    424: "Failed Dependency",
    425: "Too Early",
    426: "Upgrade Required",
    428: "Precondition Required",
    429: "Too Many Requests",
    431: "Request Header Fields Too Large",
    451: "Unavailable For Legal Reasons",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported",
    506: "Variant Also Negotiates",
    507: "Insufficient Storage",
    508: "Loop Detected",
    509: "Bandwidth Limit Exceeded",
    510: "Not Extended",
    511: "Network Authentication Required"
  };
  var METHODS = [
    "ACL",
    "BIND",
    "CHECKOUT",
    "CONNECT",
    "COPY",
    "DELETE",
    "GET",
    "HEAD",
    "LINK",
    "LOCK",
    "M-SEARCH",
    "MERGE",
    "MKACTIVITY",
    "MKCALENDAR",
    "MKCOL",
    "MOVE",
    "NOTIFY",
    "OPTIONS",
    "PATCH",
    "POST",
    "PROPFIND",
    "PROPPATCH",
    "PURGE",
    "PUT",
    "QUERY",
    "REBIND",
    "REPORT",
    "SEARCH",
    "SOURCE",
    "SUBSCRIBE",
    "TRACE",
    "UNBIND",
    "UNLINK",
    "UNLOCK",
    "UNSUBSCRIBE"
  ];
  var SINGLE = new Set(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "server", "user-agent"]);
  var kHttp = Symbol.for("bat.net.http");
  function getHttp(rt) {
    const r = rt;
    return r[kHttp] ??= createHttp(rt);
  }
  function createHttp(rt) {
    const { net, codec } = getNet(rt);
    const loop = rt.loop;
    const kernel = rt.kernel;
    const { Readable, Writable } = rt.require("stream");
    const EventEmitter = rt.require("events");
    const { Buffer } = rt.require("buffer");
    const alloc = (n) => Buffer.allocUnsafe(n);
    const invalidArg = (code, message) => Object.assign(new TypeError(message), { code });
    let dateCache = "";
    let dateAt = 0;
    const utcDate = () => {
      const now = Date.now();
      if (now - dateAt >= 1000) {
        dateAt = now - now % 1000;
        dateCache = new Date(now).toUTCString();
      }
      return dateCache;
    };
    function headersObject(raw, distinct) {
      const out = Object.create(null);
      for (let i = 0;i < raw.length; i += 2) {
        const name = raw[i].toLowerCase();
        const value = raw[i + 1];
        const have = out[name];
        if (distinct) {
          if (have)
            have.push(value);
          else
            out[name] = [value];
        } else if (have === undefined)
          out[name] = name === "set-cookie" ? [value] : value;
        else if (name === "set-cookie")
          have.push(value);
        else if (SINGLE.has(name))
          continue;
        else
          out[name] = `${have}${name === "cookie" ? "; " : ", "}${value}`;
      }
      return out;
    }
    const heard = (message, err) => err && message.listenerCount("error") === 0 ? null : err;

    class IncomingMessage extends Readable {
      socket;
      httpVersionMajor = 1;
      httpVersionMinor = 1;
      httpVersion = "1.1";
      complete = false;
      aborted = false;
      rawHeaders = [];
      rawTrailers = [];
      trailers = {};
      trailersDistinct = {};
      method = null;
      url = "";
      statusCode = null;
      statusMessage = null;
      upgrade = false;
      _headers;
      _distinct;
      _full = false;
      _resume;
      _dumped = false;
      _keepAlive = true;
      req;
      constructor(socket) {
        super({ autoDestroy: false, emitClose: true });
        this.socket = socket;
      }
      get connection() {
        return this.socket;
      }
      set connection(v) {
        this.socket = v;
      }
      get headers() {
        return this._headers ??= headersObject(this.rawHeaders, false);
      }
      set headers(v) {
        this._headers = v;
      }
      get headersDistinct() {
        return this._distinct ??= headersObject(this.rawHeaders, true);
      }
      _read() {
        if (this._full) {
          this._full = false;
          this._resume?.();
        }
      }
      _destroy(err, cb) {
        if (!this.complete)
          this.aborted = true;
        this._full = false;
        this._resume?.();
        cb(heard(this, err));
      }
      setTimeout(ms, cb) {
        if (cb)
          this.on("timeout", cb);
        this.socket?.setTimeout?.(ms);
        return this;
      }
      _dump() {
        if (this._dumped)
          return;
        this._dumped = true;
        this.removeAllListeners("data");
        this._full = false;
        this._resume?.();
      }
    }
    const tokenRe = /^[\^_`a-zA-Z\-0-9!#$%&'*+.|~]+$/;
    function checkName(name) {
      if (typeof name !== "string" || !name || !tokenRe.test(name))
        throw invalidArg("ERR_INVALID_HTTP_TOKEN", `Header name must be a valid HTTP token ["${name}"]`);
      return name;
    }
    function checkValue(name, value) {
      if (value === undefined)
        throw invalidArg("ERR_HTTP_INVALID_HEADER_VALUE", `Invalid value "undefined" for header "${name}"`);
      const bad = (v) => /[^\t\x20-\x7e\x80-\xff]/.test(String(v));
      if (Array.isArray(value) ? value.some(bad) : bad(value))
        throw invalidArg("ERR_INVALID_CHAR", `Invalid character in header content ["${name}"]`);
    }
    function headerStore() {
      const map = new Map;
      return {
        map,
        set(name, value) {
          checkName(name);
          checkValue(name, value);
          map.set(name.toLowerCase(), [name, Array.isArray(value) ? value.map(String) : typeof value === "string" ? value : String(value)]);
        },
        append(name, value) {
          checkName(name);
          checkValue(name, value);
          const have = map.get(name.toLowerCase());
          if (!have)
            return this.set(name, value);
          const list = Array.isArray(have[1]) ? have[1] : [have[1]];
          have[1] = list.concat(Array.isArray(value) ? value.map(String) : String(value));
        },
        get: (name) => map.get(String(name).toLowerCase())?.[1],
        has: (name) => map.has(String(name).toLowerCase()),
        remove: (name) => void map.delete(String(name).toLowerCase()),
        names: () => [...map.keys()],
        rawNames: () => [...map.values()].map((v) => v[0]),
        object() {
          const out = Object.create(null);
          for (const [key, [, value]] of map)
            out[key] = value;
          return out;
        },
        assign(headers, append = false) {
          if (!headers)
            return;
          const put = (k, v) => append ? this.append(k, v) : this.set(k, v);
          if (Array.isArray(headers)) {
            if (headers.length && Array.isArray(headers[0]))
              for (const [k, v] of headers)
                this.append(k, v);
            else {
              const seen = new Set;
              for (let i = 0;i + 1 < headers.length; i += 2) {
                const k = String(headers[i]).toLowerCase();
                if (seen.has(k))
                  this.append(headers[i], headers[i + 1]);
                else {
                  seen.add(k);
                  this.set(headers[i], headers[i + 1]);
                }
              }
            }
          } else if (typeof headers.forEach === "function" && typeof headers.get === "function")
            headers.forEach((v, k) => put(k, v));
          else
            for (const k of Object.keys(headers))
              if (headers[k] !== undefined)
                put(k, headers[k]);
        }
      };
    }

    class ServerResponse extends Writable {
      statusCode = 200;
      statusMessage;
      headersSent = false;
      sendDate = true;
      finished = false;
      shouldKeepAlive = true;
      chunkedEncoding = false;
      useChunkedEncodingByDefault = true;
      strictContentLength = false;
      req;
      socket;
      _h = headerStore();
      _conn;
      _hasBody = true;
      _knownLength;
      _closedEarly = false;
      constructor(req, options) {
        super({ highWaterMark: options?.highWaterMark, emitClose: true, autoDestroy: true });
        this.req = req;
        this.socket = req.socket;
        this.shouldKeepAlive = req._keepAlive !== false;
      }
      get connection() {
        return this.socket;
      }
      get _header() {
        return this.headersSent ? "sent" : null;
      }
      get writableFinishedCompat() {
        return this.writableFinished;
      }
      setHeader(name, value) {
        if (this.headersSent)
          throw Object.assign(new Error("Cannot set headers after they are sent to the client"), { code: "ERR_HTTP_HEADERS_SENT" });
        this._h.set(name, value);
        return this;
      }
      appendHeader(name, value) {
        if (this.headersSent)
          throw Object.assign(new Error("Cannot append headers after they are sent to the client"), { code: "ERR_HTTP_HEADERS_SENT" });
        this._h.append(name, value);
        return this;
      }
      setHeaders(headers) {
        if (this.headersSent)
          throw Object.assign(new Error("Cannot set headers after they are sent to the client"), { code: "ERR_HTTP_HEADERS_SENT" });
        this._h.assign(headers);
        return this;
      }
      getHeader(name) {
        return this._h.get(name);
      }
      getHeaders() {
        return this._h.object();
      }
      getHeaderNames() {
        return this._h.names();
      }
      getRawHeaderNames() {
        return this._h.rawNames();
      }
      hasHeader(name) {
        return this._h.has(name);
      }
      removeHeader(name) {
        if (this.headersSent)
          throw Object.assign(new Error("Cannot remove headers after they are sent to the client"), { code: "ERR_HTTP_HEADERS_SENT" });
        this._h.remove(name);
      }
      writeHead(statusCode, reason, headers) {
        if (this.headersSent)
          throw Object.assign(new Error("Cannot write headers after they are sent to the client"), { code: "ERR_HTTP_HEADERS_SENT" });
        if (typeof reason !== "string") {
          headers = reason;
          reason = undefined;
        }
        statusCode |= 0;
        if (statusCode < 100 || statusCode > 999)
          throw Object.assign(new RangeError(`Invalid status code: ${statusCode}`), { code: "ERR_HTTP_INVALID_STATUS_CODE" });
        this.statusCode = statusCode;
        if (reason !== undefined)
          this.statusMessage = reason;
        this._h.assign(headers);
        return this;
      }
      writeContinue(cb) {
        this.socket?._out?.write(`HTTP/1.1 100 Continue\r
\r
`, false, () => cb?.());
      }
      writeProcessing() {
        this.socket?._out?.write(`HTTP/1.1 102 Processing\r
\r
`);
      }
      writeEarlyHints(hints, cb) {
        let head = `HTTP/1.1 103 Early Hints\r
`;
        for (const [k, v] of Object.entries(hints))
          for (const one of Array.isArray(v) ? v : [v])
            head += `${k}: ${one}\r
`;
        this.socket?._out?.write(`${head}\r
`, false, () => cb?.());
      }
      addTrailers() {}
      flushHeaders() {
        if (!this.headersSent)
          this._sendHead();
      }
      setTimeout(ms, cb) {
        if (cb)
          this.on("timeout", cb);
        this.socket?.setTimeout?.(ms);
        return this;
      }
      assignSocket() {}
      detachSocket() {}
      _sendHead() {
        const req = this.req;
        const code = this.statusCode;
        const h = this._h;
        this.headersSent = true;
        this._hasBody = !(req.method === "HEAD" || code === 204 || code === 304 || code >= 100 && code < 200);
        let head = `HTTP/1.1 ${code} ${this.statusMessage ?? STATUS_CODES[code] ?? "unknown"}\r
`;
        this.statusMessage ??= STATUS_CODES[code] ?? "unknown";
        for (const [name, value] of h.map.values()) {
          if (Array.isArray(value))
            for (const v of value)
              head += `${name}: ${v}\r
`;
          else
            head += `${name}: ${value}\r
`;
        }
        if (this.sendDate && !h.has("date"))
          head += `Date: ${utcDate()}\r
`;
        const connection = h.get("connection");
        if (typeof connection === "string" && /\bclose\b/i.test(connection))
          this.shouldKeepAlive = false;
        if (this._hasBody) {
          const te = h.get("transfer-encoding");
          if (h.has("content-length"))
            this.chunkedEncoding = false;
          else if (typeof te === "string" && /\bchunked\b/i.test(te))
            this.chunkedEncoding = true;
          else if (this._knownLength !== undefined) {
            head += `Content-Length: ${this._knownLength}\r
`;
            this.chunkedEncoding = false;
          } else if (req.httpVersionMinor >= 1 && this.useChunkedEncodingByDefault) {
            head += `Transfer-Encoding: chunked\r
`;
            this.chunkedEncoding = true;
          } else {
            this.shouldKeepAlive = false;
            this.chunkedEncoding = false;
          }
        } else
          this.chunkedEncoding = false;
        if (connection === undefined) {
          const timeout = req.socket?.server?.keepAliveTimeout ?? 5000;
          if (this.shouldKeepAlive)
            head += `Connection: keep-alive\r
Keep-Alive: timeout=${Math.max(1, Math.floor(timeout / 1000))}\r
`;
          else
            head += `Connection: close\r
`;
        }
        const out = this.socket?._out;
        if (out)
          out.write(`${head}\r
`);
      }
      end(chunk, encoding, cb) {
        if (typeof chunk === "function") {
          cb = chunk;
          chunk = undefined;
        } else if (typeof encoding === "function") {
          cb = encoding;
          encoding = undefined;
        }
        if (!this.headersSent && this.writableLength === 0 && !this.writableEnded) {
          if (typeof chunk === "string")
            chunk = Buffer.from(chunk, encoding);
          else if (chunk != null && !Buffer.isBuffer(chunk) && ArrayBuffer.isView(chunk))
            chunk = Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength);
          this._knownLength = chunk == null ? 0 : chunk.length;
          if (chunk != null && chunk.length === 0)
            chunk = undefined;
        }
        this.finished = true;
        if (tracing())
          trace(`res ${this.statusCode} ${String(this.req?.url).slice(0, 80)}`, { pid: rt.process?.pid, loader: rt.loader?.stats.modules, compileMs: rt.loader?.stats.compileMs });
        return super.end(chunk, encoding, cb);
      }
      _write(chunk, _encoding, cb) {
        if (!this.headersSent)
          this._sendHead();
        const out = this.socket?._out;
        if (!out || this.socket.destroyed)
          return cb();
        if (!this._hasBody || chunk.length === 0)
          return cb();
        this.socket.bytesWritten += chunk.length;
        out.write(chunk, this.chunkedEncoding, () => cb());
      }
      _final(cb) {
        if (!this.headersSent) {
          this._knownLength ??= 0;
          this._sendHead();
        }
        const out = this.socket?._out;
        const done = () => {
          this.finished = true;
          cb();
          const conn = this._conn;
          this._conn = undefined;
          conn?.responseDone(this);
        };
        if (!out || this.socket.destroyed)
          return done();
        out.write(this.chunkedEncoding && this._hasBody ? `0\r
\r
` : "", false, done);
      }
      _destroy(err, cb) {
        const conn = this._conn;
        this._conn = undefined;
        if (conn && !this.finished)
          conn.socket.destroy();
        cb(err);
      }
    }
    function serveConnection(server, socket) {
      const fd = socket._fd;
      const parser = codec.httpParser("request", alloc);
      let req;
      let res;
      let reqDone = false;
      let responding = false;
      let upgraded = false;
      let closed = false;
      let idle;
      const clearIdle = () => {
        if (idle)
          idle.close?.();
        idle = undefined;
        socket._httpIdle = false;
      };
      const armIdle = () => {
        clearIdle();
        socket._httpIdle = true;
        if (server._fd < 0)
          return void socket.destroy();
        const ms = server.keepAliveTimeout;
        if (ms > 0) {
          idle = loop.setTimeout(() => {
            idle = undefined;
            if (!responding && !closed)
              socket.destroy();
          }, ms);
          idle.unref?.();
        }
      };
      const conn = {
        socket,
        pump,
        responseDone(done) {
          if (done !== res)
            return;
          const keep = res.shouldKeepAlive && !closed;
          const finishedReq = req;
          responding = false;
          res = undefined;
          req = undefined;
          if (finishedReq && !finishedReq.complete) {
            finishedReq._dump();
            req = finishedReq;
          } else {
            reqDone = false;
            if (finishedReq && !finishedReq.destroyed)
              finishedReq.destroy();
          }
          if (!keep)
            return void socket.destroySoon();
          if (!req) {
            armIdle();
            pump();
          }
        }
      };
      const sink = {
        head(head) {
          clearIdle();
          const message = new IncomingMessage(socket);
          message.rawHeaders = head.raw;
          message.method = head.method;
          message.url = head.target;
          if (head.flags & F_HTTP10) {
            message.httpVersionMinor = 0;
            message.httpVersion = "1.0";
          }
          message._keepAlive = (head.flags & F_KEEPALIVE) !== 0;
          message._resume = pump;
          if (head.flags & F_UPGRADE) {
            if (server.listenerCount("upgrade") > 0) {
              upgraded = true;
              message.upgrade = true;
              message.complete = true;
              message.push(null);
              parser.resume(fd, true);
              parser.free();
              socket._release();
              server.emit("upgrade", message, socket, Buffer.alloc(0));
              return;
            }
            parser.resume(fd, false);
          }
          req = message;
          reqDone = false;
          responding = true;
          res = new server._ServerResponse(message);
          res._conn = conn;
          if (head.flags & F_EXPECT_CONTINUE) {
            if (server.listenerCount("checkContinue") > 0)
              return void server.emit("checkContinue", req, res);
            res.writeContinue();
          }
          if (tracing())
            trace(`req ${message.method} ${String(message.url).slice(0, 80)}`, { pid: rt.process?.pid });
          server.emit("request", req, res);
        },
        body(chunk) {
          if (!req || req._dumped || req.destroyed)
            return;
          socket.bytesRead += chunk.length;
          if (!req.push(chunk))
            req._full = true;
        },
        end() {
          if (!req)
            return;
          const message = req;
          message.complete = true;
          reqDone = true;
          if (!responding) {
            req = undefined;
            reqDone = false;
            if (!message.destroyed)
              message.destroy();
            armIdle();
          } else if (!message._dumped && !message.destroyed)
            message.push(null);
        },
        eof() {
          if (!closed)
            socket.destroy();
        },
        error() {
          if (closed)
            return;
          if (server.listenerCount("clientError") > 0)
            return void server.emit("clientError", Object.assign(new Error("Parse Error"), { code: "HPE_INVALID" }), socket);
          socket._out?.write(`HTTP/1.1 400 Bad Request\r
Connection: close\r
\r
`, false, () => socket.destroy());
        }
      };
      const more = () => !closed && !upgraded && !(req && req._full) && !(reqDone && responding);
      function pump() {
        if (closed || upgraded)
          return;
        parser.recv(fd, sink, more);
      }
      socket._consumer = () => {
        if (reqDone && responding) {
          if (kernel.pollFd(fd) & POLLHUP2)
            socket.destroy();
          return;
        }
        pump();
      };
      socket.on("close", () => {
        closed = true;
        clearIdle();
        if (!upgraded)
          parser.free();
        const message = req;
        const response = res;
        req = undefined;
        res = undefined;
        if (message && !message.destroyed) {
          if (!message.complete) {
            message.aborted = true;
            message.emit("aborted");
            message.destroy(Object.assign(new Error("aborted"), { code: "ECONNRESET" }));
          } else
            message.destroy();
        }
        if (response && !response.destroyed) {
          response._conn = undefined;
          response.destroy();
        }
      });
      socket.on("timeout", () => {
        if (req?.listenerCount("timeout") || res?.listenerCount("timeout") || server.listenerCount("timeout")) {
          req?.emit("timeout", socket);
          res?.emit("timeout", socket);
          server.emit("timeout", socket);
        } else
          socket.destroy();
      });
      socket.on("error", () => {});
      if (server.timeout > 0)
        socket.setTimeout(server.timeout);
      armIdle();
      socket._arm();
      pump();
    }

    class Server extends net.Server {
      timeout = 0;
      keepAliveTimeout = 5000;
      headersTimeout = 60000;
      requestTimeout = 300000;
      maxHeadersCount = null;
      maxRequestsPerSocket = 0;
      httpAllowHalfOpen = false;
      _ServerResponse;
      _IncomingMessage;
      constructor(options, listener) {
        if (typeof options === "function") {
          listener = options;
          options = {};
        }
        super({ ...options, allowHalfOpen: true });
        this._ServerResponse = options?.ServerResponse ?? ServerResponse;
        this._IncomingMessage = options?.IncomingMessage ?? IncomingMessage;
        if (options?.keepAliveTimeout !== undefined)
          this.keepAliveTimeout = options.keepAliveTimeout;
        if (listener)
          this.on("request", listener);
        this.on("connection", (socket) => serveConnection(this, socket));
      }
      setTimeout(ms, cb) {
        this.timeout = ms;
        if (cb)
          this.on("timeout", cb);
        return this;
      }
      closeAllConnections() {
        for (const socket of [...this._connections])
          socket.destroy();
      }
      closeIdleConnections() {
        for (const socket of [...this._connections])
          if (socket._httpIdle)
            socket.destroy();
      }
      close(cb) {
        super.close(cb);
        this.closeIdleConnections();
        return this;
      }
    }

    class Agent extends EventEmitter {
      options;
      defaultPort = 80;
      protocol = "http:";
      maxSockets = Infinity;
      maxFreeSockets = 256;
      maxTotalSockets = Infinity;
      keepAlive;
      keepAliveMsecs = 1000;
      requests = {};
      sockets = {};
      freeSockets = {};
      constructor(options = {}) {
        super();
        this.options = { ...options };
        this.keepAlive = !!options.keepAlive;
        if (options.maxSockets !== undefined)
          this.maxSockets = options.maxSockets;
      }
      destroy() {}
      getName(o = {}) {
        return `${o.host ?? "localhost"}:${o.port ?? ""}:${o.localAddress ?? ""}`;
      }
    }
    function makeClient(defaultProtocol, globalAgent2) {

      class ClientRequest extends Writable {
        method;
        path;
        host;
        protocol;
        agent;
        aborted = false;
        finished = false;
        reusedSocket = false;
        maxHeadersCount = null;
        socket = null;
        res;
        _h = headerStore();
        _chunks = [];
        _url;
        _abort = new AbortController;
        _timer;
        _sent = false;
        _held = false;
        constructor(input, options, cb) {
          super({ emitClose: true, autoDestroy: false });
          let url;
          if (typeof input === "string")
            url = new URL(input);
          else if (input instanceof URL)
            url = input;
          else {
            cb = options;
            options = input;
          }
          if (typeof options === "function") {
            cb = options;
            options = {};
          }
          options = { ...options ?? {} };
          const protocol = options.protocol ?? url?.protocol ?? options.agent?.protocol ?? defaultProtocol;
          const hostname = options.hostname ?? options.host?.replace(/:\d+$/, "") ?? url?.hostname ?? "localhost";
          const port = options.port ?? url?.port ?? options.defaultPort ?? "";
          const path = options.path ?? (url ? url.pathname + url.search : "/");
          if (/[\u0000- ]/.test(path))
            throw invalidArg("ERR_UNESCAPED_CHARACTERS", "Request path contains unescaped characters");
          const host = hostname.includes(":") && !hostname.startsWith("[") ? `[${hostname}]` : hostname;
          this._url = new URL(`${protocol}//${host}${port !== "" && port != null ? `:${port}` : ""}${path.startsWith("/") ? path : `/${path}`}`);
          this.protocol = protocol;
          this.host = hostname;
          this.path = path;
          this.method = String(options.method ?? "GET").toUpperCase();
          this.agent = options.agent === undefined ? globalAgent2 : options.agent;
          this._h.assign(options.headers);
          const auth = options.auth ?? (url?.username ? `${decodeURIComponent(url.username)}:${decodeURIComponent(url.password)}` : undefined);
          if (auth && !this._h.has("authorization"))
            this._h.set("Authorization", `Basic ${Buffer.from(auth).toString("base64")}`);
          if (cb)
            this.once("response", cb);
          if (options.signal) {
            const onAbort = () => this.destroy(Object.assign(new Error("The operation was aborted"), { name: "AbortError", code: "ABORT_ERR" }));
            if (options.signal.aborted)
              loop.nextTick(onAbort);
            else
              options.signal.addEventListener("abort", onAbort, { once: true });
          }
          if (options.timeout)
            this.setTimeout(options.timeout);
          this._hold(true);
          loop.nextTick(() => {
            if (this.destroyed)
              return;
            this.socket = Object.assign(new EventEmitter, {
              setTimeout: () => {},
              setNoDelay: () => {},
              setKeepAlive: () => {},
              ref: () => {},
              unref: () => {},
              destroy: () => this.destroy(),
              remoteAddress: "127.0.0.1",
              connecting: false,
              writable: true,
              readable: true,
              destroyed: false,
              encrypted: this.protocol === "https:"
            });
            this.emit("socket", this.socket);
          });
        }
        _hold(on) {
          if (on !== this._held) {
            this._held = on;
            if (on)
              loop.ref();
            else
              loop.unref();
          }
        }
        get connection() {
          return this.socket;
        }
        get headersSent() {
          return this._sent;
        }
        setHeader(name, value) {
          this._h.set(name, value);
          return this;
        }
        appendHeader(name, value) {
          this._h.append(name, value);
          return this;
        }
        getHeader(name) {
          return this._h.get(name);
        }
        getHeaders() {
          return this._h.object();
        }
        getHeaderNames() {
          return this._h.names();
        }
        getRawHeaderNames() {
          return this._h.rawNames();
        }
        hasHeader(name) {
          return this._h.has(name);
        }
        removeHeader(name) {
          this._h.remove(name);
        }
        flushHeaders() {}
        setNoDelay() {}
        setSocketKeepAlive() {}
        setTimeout(ms, cb) {
          if (cb)
            this.once("timeout", cb);
          if (this._timer)
            this._timer.close?.();
          this._timer = undefined;
          if (ms > 0) {
            this._timer = loop.setTimeout(() => this.emit("timeout"), ms);
            this._timer.unref?.();
          }
          return this;
        }
        abort() {
          this.aborted = true;
          this.destroy();
        }
        _write(chunk, _encoding, cb) {
          this._chunks.push(chunk);
          cb();
        }
        _final(cb) {
          this.finished = true;
          this._send();
          cb();
        }
        _destroy(err, cb) {
          if (this._timer)
            this._timer.close?.();
          this._abort.abort();
          this._hold(false);
          if (this.res && !this.res.complete && !this.res.destroyed) {
            this.res.aborted = true;
            this.res.emit("aborted");
            this.res.destroy(Object.assign(new Error("aborted"), { code: "ECONNRESET" }));
          }
          if (!err && !this.res && !this.aborted && this._sent)
            err = Object.assign(new Error("socket hang up"), { code: "ECONNRESET" });
          cb(err);
        }
        _send() {
          if (this._sent)
            return;
          this._sent = true;
          const headers = [];
          for (const [name, value] of this._h.map.values()) {
            if (Array.isArray(value))
              for (const v of value)
                headers.push([name, v]);
            else
              headers.push([name, value]);
          }
          const total = this._chunks.reduce((n, c) => n + c.length, 0);
          const body = total || this.method !== "GET" && this.method !== "HEAD" ? Buffer.concat(this._chunks, total) : null;
          this._chunks = [];
          getGuestFetch(rt).route(this._url, { method: this.method, headers, body, signal: this._abort.signal }).then((wire) => {
            if (this.destroyed)
              return void wire.body?.cancel().catch(() => {});
            const res = new IncomingMessage(this.socket);
            this.res = res;
            res.req = this;
            res.statusCode = wire.status;
            res.statusMessage = wire.statusText || STATUS_CODES[wire.status] || "";
            res.rawHeaders = wire.headers.flat();
            const finish = () => {
              this._hold(false);
              if (this._timer)
                this._timer.close?.();
              if (!this.destroyed)
                this.destroy();
            };
            const reader = wire.body?.getReader();
            let reading = false;
            res._read = () => {
              if (reading)
                return;
              if (!reader) {
                res.complete = true;
                res.push(null);
                return;
              }
              reading = true;
              reader.read().then(({ done, value }) => {
                reading = false;
                if (res.destroyed)
                  return;
                if (done) {
                  res.complete = true;
                  res.push(null);
                } else if (res.push(Buffer.from(value.buffer, value.byteOffset, value.byteLength)))
                  res._read();
              }, (err) => {
                reading = false;
                if (!res.destroyed)
                  res.destroy(Object.assign(err instanceof Error ? err : new Error(String(err)), { code: "ECONNRESET" }));
              });
            };
            res._destroy = (err, cb) => {
              if (!res.complete)
                reader?.cancel().catch(() => {});
              cb(heard(res, err));
            };
            res.once("end", () => {
              res.destroy();
              finish();
            });
            res.once("close", finish);
            if (!this.emit("response", res))
              res.resume();
          }, (err) => {
            if (this.destroyed)
              return;
            const cause = err?.cause ?? err;
            const code = cause?.code ?? (err?.name === "AbortError" ? "ABORT_ERR" : "ECONNRESET");
            this.destroy(Object.assign(err instanceof Error ? err : new Error(String(err)), { code }));
          });
        }
      }
      const request = (input, options, cb) => new ClientRequest(input, options, cb);
      const get = (input, options, cb) => {
        const req = request(input, options, cb);
        req.end();
        return req;
      };
      return { ClientRequest, request, get };
    }
    const globalAgent = new Agent({ keepAlive: true });
    const client = makeClient("http:", globalAgent);
    const http = {
      METHODS,
      STATUS_CODES,
      Agent,
      globalAgent,
      Server,
      ServerResponse,
      IncomingMessage,
      OutgoingMessage: ServerResponse,
      ClientRequest: client.ClientRequest,
      createServer: (options, listener) => new Server(options, listener),
      request: client.request,
      get: client.get,
      maxHeaderSize: 1 << 20,
      validateHeaderName: (name) => void checkName(name),
      validateHeaderValue: (name, value) => checkValue(name, value),
      setMaxIdleHTTPParsers() {}
    };

    class HttpsAgent extends Agent {
      defaultPort = 443;
      protocol = "https:";
    }
    const httpsAgent = new HttpsAgent({ keepAlive: true });
    const secure = makeClient("https:", httpsAgent);
    const https = {
      Agent: HttpsAgent,
      globalAgent: httpsAgent,
      Server: class Server2 {
        constructor() {
          throw Object.assign(new Error("https.createServer is not supported in this runtime: serve HTTP and let the page origin provide TLS"), { code: "ERR_FEATURE_UNAVAILABLE_ON_PLATFORM" });
        }
      },
      createServer() {
        throw Object.assign(new Error("https.createServer is not supported in this runtime: serve HTTP and let the page origin provide TLS"), { code: "ERR_FEATURE_UNAVAILABLE_ON_PLATFORM" });
      },
      request: secure.request,
      get: secure.get
    };
    return { http, https };
  }

  // runtime/src/net/builtins.ts
  var NET_GLOBALS = "bat:net-globals";
  function globals(rt) {
    installFetch(rt);
  }
  registerBuiltin("net", (rt) => {
    globals(rt);
    return getNet(rt).net;
  });
  registerBuiltin("http", (rt) => {
    globals(rt);
    return getHttp(rt).http;
  });
  registerBuiltin("https", (rt) => {
    globals(rt);
    return getHttp(rt).https;
  });
  registerBuiltin(NET_GLOBALS, (rt) => {
    globals(rt);
    return {};
  }, { hidden: true });

  // runtime/src/sqlite/backend.ts
  var IOCAP_SAFE_APPEND = 512;
  var IOCAP_SEQUENTIAL = 1024;
  var IOCAP_POWERSAFE_OVERWRITE = 4096;
  function resolvePosix(cwd, path) {
    const full = path.startsWith("/") ? path : `${cwd}/${path}`;
    const out = [];
    for (const part of full.split("/")) {
      if (part === "" || part === ".")
        continue;
      if (part === "..")
        out.pop();
      else
        out.push(part);
    }
    return `/${out.join("/")}`;
  }

  // runtime/src/sqlite/backend-kernel.ts
  var O_RDONLY2 = 0;
  var O_RDWR2 = 2;
  var O_CREAT2 = 64;
  var O_EXCL2 = 128;
  function createKernelBackend(kernel, options) {
    const mode = options.sync ?? "request";
    let draining = false;
    let again = false;
    const requestDrain = () => {
      if (draining) {
        again = true;
        return;
      }
      draining = true;
      const done = () => {
        draining = false;
        if (again) {
          again = false;
          requestDrain();
        }
      };
      kernel.flush().then(done, done);
    };
    return {
      deviceCharacteristics: IOCAP_SAFE_APPEND | IOCAP_SEQUENTIAL | IOCAP_POWERSAFE_OVERWRITE,
      open(path, flags) {
        const f = flags.readOnly ? O_RDONLY2 : O_RDWR2 | (flags.create ? O_CREAT2 : 0) | (flags.create && flags.exclusive ? O_EXCL2 : 0);
        return kernel.open(path, f, 420);
      },
      close(fd) {
        kernel.close(fd);
      },
      read(fd, dst, pos) {
        let done = 0;
        while (done < dst.length) {
          const n = kernel.read(fd, done === 0 ? dst : dst.subarray(done), pos + done);
          if (n === 0)
            break;
          done += n;
        }
        return done;
      },
      write(fd, src, pos) {
        let done = 0;
        while (done < src.length)
          done += kernel.write(fd, done === 0 ? src : src.subarray(done), pos + done);
      },
      truncate(fd, size) {
        kernel.ftruncate(fd, size);
      },
      size(fd) {
        return kernel.fstat(fd).size;
      },
      sync() {
        if (mode === "wait")
          kernel.flushSync();
        else if (mode === "request")
          requestDrain();
      },
      delete(path) {
        try {
          kernel.unlink(path);
          return true;
        } catch (e) {
          if (e.code === "ENOENT")
            return false;
          throw e;
        }
      },
      exists(path) {
        return kernel.kindOf(path) >= 0;
      },
      writable(path) {
        return kernel.kindOf(path) >= 0;
      },
      fullPath(path) {
        return resolvePosix(options.cwd(), path);
      }
    };
  }

  // runtime/src/sqlite/engine.ts
  var OPEN_READONLY = 1;
  var OPEN_READWRITE = 2;
  var OPEN_CREATE = 4;
  var OPEN_EXCLUSIVE = 16;
  var OPEN_MAIN_DB = 256;
  var encoder6 = new TextEncoder;
  var decoder4 = new TextDecoder;
  function createEngine(backend, source2) {
    let engine;
    const stats = { compileMs: 0, instantiateMs: 0 };
    return {
      stats,
      get() {
        if (engine)
          return engine;
        let s = typeof source2 === "function" ? source2() : source2;
        if (!(s instanceof WebAssembly.Module)) {
          const t2 = performance.now();
          s = new WebAssembly.Module(s);
          stats.compileMs = performance.now() - t2;
        }
        const t = performance.now();
        engine = instantiate(backend, s);
        stats.instantiateMs = performance.now() - t;
        return engine;
      }
    };
  }
  function instantiate(backend, module) {
    let memory;
    let x;
    let u8 = new Uint8Array(0);
    let u32 = new Uint32Array(0);
    let f64 = new Float64Array(0);
    let dv = new DataView(u8.buffer);
    const RESERVE_FIRST = 32 << 20;
    const RESERVE_MIN = 16 << 20;
    const RESERVE_MAX = 256 << 20;
    let reserving = true;
    const reserve = (bytes) => {
      reserving = true;
      try {
        const p = x.sqlite3_malloc(bytes);
        if (p)
          x.sqlite3_free(p);
      } finally {
        reserving = false;
      }
    };
    const refresh = () => {
      if (u8.byteLength !== 0)
        return;
      if (!reserving)
        reserve(Math.min(RESERVE_MAX, Math.max(RESERVE_MIN, memory.buffer.byteLength)));
      u8 = new Uint8Array(memory.buffer);
      u32 = new Uint32Array(memory.buffer);
      f64 = new Float64Array(memory.buffer);
      dv = new DataView(memory.buffer);
    };
    const cstr = (p) => {
      refresh();
      let end = p;
      while (u8[end] !== 0)
        end++;
      return text(p, end - p);
    };
    const text = (p, n) => {
      if (n <= 24) {
        let s = "";
        let i = 0;
        for (;i < n; i++) {
          const c = u8[p + i];
          if (c > 127)
            break;
          s += String.fromCharCode(c);
        }
        if (i === n)
          return s;
      }
      return decoder4.decode(u8.subarray(p, p + n));
    };
    const functions = new Map;
    let nextFunctionId = 1;
    let pending2;
    const guard = (fn, ctx2) => {
      try {
        fn();
      } catch (error) {
        if (!pending2)
          pending2 = { error };
        x.sqlite3_result_error(ctx2, emptyString, 0);
      }
    };
    const imports = {
      bat: {
        open(zName, flags, pOut) {
          try {
            const path = cstr(zName);
            const want = { readOnly: (flags & OPEN_READONLY) !== 0, create: (flags & OPEN_CREATE) !== 0, exclusive: (flags & OPEN_EXCLUSIVE) !== 0 };
            let fd;
            let out2 = want.readOnly ? OPEN_READONLY : OPEN_READWRITE;
            try {
              fd = backend.open(path, want);
            } catch (e) {
              const code = e.code;
              if (want.readOnly || !(flags & OPEN_MAIN_DB) || code !== "EACCES" && code !== "EROFS" && code !== "EPERM")
                return -1;
              fd = backend.open(path, { readOnly: true, create: false, exclusive: false });
              out2 = OPEN_READONLY;
            }
            refresh();
            dv.setInt32(pOut, out2, true);
            return fd;
          } catch {
            return -1;
          }
        },
        close(fd) {
          try {
            backend.close(fd);
            return 0;
          } catch {
            return -1;
          }
        },
        read(fd, p, n, off) {
          try {
            refresh();
            return backend.read(fd, u8.subarray(p, p + n), off);
          } catch {
            return -1;
          }
        },
        write(fd, p, n, off) {
          try {
            refresh();
            backend.write(fd, u8.subarray(p, p + n), off);
            return 0;
          } catch (e) {
            const code = e.code;
            return code === "ENOSPC" || code === "EDQUOT" || code === "ENOMEM" ? -2 : -1;
          }
        },
        truncate(fd, size) {
          try {
            backend.truncate(fd, size);
            return 0;
          } catch {
            return -1;
          }
        },
        sync(fd, flags) {
          try {
            backend.sync(fd, (flags & 16) !== 0);
            return 0;
          } catch {
            return -1;
          }
        },
        size(fd) {
          try {
            return backend.size(fd);
          } catch {
            return -1;
          }
        },
        delete(zName) {
          try {
            return backend.delete(cstr(zName)) ? 0 : 1;
          } catch {
            return -1;
          }
        },
        access(zName, flags) {
          try {
            const path = cstr(zName);
            return (flags === 1 ? backend.writable(path) : backend.exists(path)) ? 1 : 0;
          } catch {
            return 0;
          }
        },
        fullpath(zName, nOut, zOut) {
          try {
            const bytes = encoder6.encode(backend.fullPath(cstr(zName)));
            if (bytes.length + 1 > nOut)
              return -1;
            refresh();
            u8.set(bytes, zOut);
            u8[zOut + bytes.length] = 0;
            return 0;
          } catch {
            return -1;
          }
        },
        random(n, p) {
          refresh();
          crypto.getRandomValues(u8.subarray(p, p + n));
        },
        now: () => Date.now(),
        devchar: () => backend.deviceCharacteristics,
        func_call(id, ctx2, argc, argv) {
          guard(() => functions.get(id).call(ctx2, argc, argv), ctx2);
        },
        func_destroy(id) {
          functions.delete(id);
        },
        agg_step(id, ctx2, state, argc, argv, inverse) {
          guard(() => functions.get(id).step(ctx2, state, argc, argv, inverse !== 0), ctx2);
        },
        agg_final(id, ctx2, state, isFinal) {
          guard(() => functions.get(id).final(ctx2, state, isFinal !== 0), ctx2);
        },
        authorize(id, action, a, b, c, d) {
          try {
            const s = (p) => p ? cstr(p) : null;
            return functions.get(id).authorize(action, s(a), s(b), s(c), s(d));
          } catch (error) {
            if (!pending2)
              pending2 = { error };
            return 1;
          }
        }
      }
    };
    const instance = new WebAssembly.Instance(module, imports);
    x = instance.exports;
    memory = instance.exports.memory;
    x._initialize();
    reserve(RESERVE_FIRST);
    refresh();
    const out = x.sqlite3_malloc(24);
    const emptyString = out + 16;
    u8[emptyString] = 0;
    let lastLen = 0;
    const allocString = (s) => {
      const n = s.length;
      let cap = n <= 4096 ? n * 3 : n + 64;
      let p = x.sqlite3_malloc(cap + 1);
      if (!p)
        throw new RangeError("SQLite: out of memory");
      refresh();
      let { read, written } = encoder6.encodeInto(s, u8.subarray(p, p + cap));
      if (read < n) {
        const rest = s.slice(read);
        cap = written + rest.length * 3;
        p = x.sqlite3_realloc(p, cap + 1);
        if (!p)
          throw new RangeError("SQLite: out of memory");
        refresh();
        written += encoder6.encodeInto(rest, u8.subarray(p + written, p + cap)).written;
      }
      u8[p + written] = 0;
      lastLen = written;
      return p;
    };
    const allocBytes = (b) => {
      const p = x.sqlite3_malloc(b.length || 1);
      if (!p)
        throw new RangeError("SQLite: out of memory");
      refresh();
      u8.set(b, p);
      return p;
    };
    let rowBuf = 0;
    let rowCap = 0;
    const rowBuffer = (columns) => {
      if (columns > rowCap) {
        if (rowBuf)
          x.sqlite3_free(rowBuf);
        rowCap = Math.max(columns, 32);
        rowBuf = x.sqlite3_malloc(rowCap * 16);
        if (!rowBuf)
          throw new RangeError("SQLite: out of memory");
      }
      return rowBuf;
    };
    return {
      x,
      out,
      refresh,
      cstr,
      text,
      allocString,
      allocBytes,
      rowBuffer,
      get lastLen() {
        return lastLen;
      },
      get u8() {
        refresh();
        return u8;
      },
      get u32() {
        refresh();
        return u32;
      },
      get f64() {
        refresh();
        return f64;
      },
      get dv() {
        refresh();
        return dv;
      },
      addFunction(entry) {
        const id = nextFunctionId++;
        functions.set(id, entry);
        return id;
      },
      removeFunction(id) {
        functions.delete(id);
      },
      takePending() {
        const p = pending2;
        pending2 = undefined;
        return p;
      }
    };
  }

  // runtime/src/sqlite/node-sqlite.ts
  var SQLITE_OK = 0;
  var SQLITE_ROW = 100;
  var SQLITE_DONE = 101;
  var OPEN_READONLY2 = 1;
  var OPEN_READWRITE2 = 2;
  var OPEN_CREATE2 = 4;
  var OPEN_URI = 64;
  var DBCONFIG_ENABLE_FKEY = 1002;
  var DBCONFIG_DEFENSIVE = 1010;
  var DBCONFIG_DQS_DML = 1013;
  var DBCONFIG_DQS_DDL = 1014;
  var SQLITE_UTF8 = 1;
  var SQLITE_DETERMINISTIC = 2048;
  var SQLITE_DIRECTONLY = 524288;
  var DESERIALIZE_FREEONCLOSE = 1;
  var DESERIALIZE_RESIZEABLE = 2;
  var MAX_I64 = 2n ** 63n - 1n;
  var MIN_I64 = -(2n ** 63n);
  var constants3 = Object.freeze({
    SQLITE_CHANGESET_OMIT: 0,
    SQLITE_CHANGESET_REPLACE: 1,
    SQLITE_CHANGESET_ABORT: 2,
    SQLITE_CHANGESET_DATA: 1,
    SQLITE_CHANGESET_NOTFOUND: 2,
    SQLITE_CHANGESET_CONFLICT: 3,
    SQLITE_CHANGESET_CONSTRAINT: 4,
    SQLITE_CHANGESET_FOREIGN_KEY: 5,
    SQLITE_OK: 0,
    SQLITE_DENY: 1,
    SQLITE_IGNORE: 2,
    SQLITE_CREATE_INDEX: 1,
    SQLITE_CREATE_TABLE: 2,
    SQLITE_CREATE_TEMP_INDEX: 3,
    SQLITE_CREATE_TEMP_TABLE: 4,
    SQLITE_CREATE_TEMP_TRIGGER: 5,
    SQLITE_CREATE_TEMP_VIEW: 6,
    SQLITE_CREATE_TRIGGER: 7,
    SQLITE_CREATE_VIEW: 8,
    SQLITE_DELETE: 9,
    SQLITE_DROP_INDEX: 10,
    SQLITE_DROP_TABLE: 11,
    SQLITE_DROP_TEMP_INDEX: 12,
    SQLITE_DROP_TEMP_TABLE: 13,
    SQLITE_DROP_TEMP_TRIGGER: 14,
    SQLITE_DROP_TEMP_VIEW: 15,
    SQLITE_DROP_TRIGGER: 16,
    SQLITE_DROP_VIEW: 17,
    SQLITE_INSERT: 18,
    SQLITE_PRAGMA: 19,
    SQLITE_READ: 20,
    SQLITE_SELECT: 21,
    SQLITE_TRANSACTION: 22,
    SQLITE_UPDATE: 23,
    SQLITE_ATTACH: 24,
    SQLITE_DETACH: 25,
    SQLITE_ALTER_TABLE: 26,
    SQLITE_REINDEX: 27,
    SQLITE_ANALYZE: 28,
    SQLITE_CREATE_VTABLE: 29,
    SQLITE_DROP_VTABLE: 30,
    SQLITE_FUNCTION: 31,
    SQLITE_SAVEPOINT: 32,
    SQLITE_COPY: 0,
    SQLITE_RECURSIVE: 33
  });
  function err(Base, code, message) {
    const e = new Base(message);
    e.code = code;
    return e;
  }
  var invalidType = (message) => err(TypeError, "ERR_INVALID_ARG_TYPE", message);
  var invalidState = (message) => err(Error, "ERR_INVALID_STATE", message);
  var unavailable = (what) => err(Error, "ERR_FEATURE_UNAVAILABLE_ON_PLATFORM", `${what} is not supported in this runtime`);
  function createSqliteModule(backend, options) {
    const holder = createEngine(backend, options.wasm);
    const counters = { open: 0, close: 0, exec: 0, prepare: 0, all: 0, get: 0, run: 0, iterate: 0, ms: 0 };
    let timing = false;
    let E;
    let x;
    const engine = () => {
      if (!E) {
        E = holder.get();
        x = E.x;
      }
      return E;
    };
    const sqliteError = (conn) => {
      const pending2 = E.takePending();
      if (pending2)
        return pending2.error;
      const errcode = x.sqlite3_extended_errcode(conn.db);
      const e = err(Error, "ERR_SQLITE_ERROR", E.cstr(x.sqlite3_errmsg(conn.db)));
      e.errcode = errcode;
      e.errstr = E.cstr(x.sqlite3_errstr(errcode));
      return e;
    };
    const check = (conn, rc) => {
      if (rc !== SQLITE_OK)
        throw sqliteError(conn);
    };
    const registry = new FinalizationRegistry(({ conn, stmt }) => {
      if (conn.stmts.delete(stmt))
        x.sqlite3_finalize(stmt);
    });
    const bindValue = (st, index, value) => {
      const stmt = st.stmt;
      let rc;
      if (typeof value === "number")
        rc = x.sqlite3_bind_double(stmt, index, value);
      else if (typeof value === "string") {
        const p = E.allocString(value);
        rc = x.bat_bind_text(stmt, index, p, E.lastLen);
      } else if (value === null)
        rc = x.sqlite3_bind_null(stmt, index);
      else if (ArrayBuffer.isView(value)) {
        const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
        rc = bytes.length === 0 ? x.sqlite3_bind_zeroblob(stmt, index, 0) : x.bat_bind_blob(stmt, index, E.allocBytes(bytes), bytes.length);
      } else if (typeof value === "bigint") {
        if (value > MAX_I64 || value < MIN_I64)
          throw err(TypeError, "ERR_INVALID_ARG_VALUE", "BigInt value is too large to bind.");
        rc = x.sqlite3_bind_int64(stmt, index, value);
      } else
        throw invalidType(`Provided value cannot be bound to SQLite parameter ${index}.`);
      check(st.conn, rc);
    };
    const bareNames = (st) => {
      if (st.bare)
        return st.bare;
      const map = new Map;
      const n = x.sqlite3_bind_parameter_count(st.stmt);
      for (let i = 1;i <= n; i++) {
        const p = x.sqlite3_bind_parameter_name(st.stmt, i);
        if (!p)
          continue;
        const full = E.cstr(p);
        const bare = full.slice(1);
        const seen = map.get(bare);
        if (seen !== undefined && seen !== full) {
          throw invalidState(`Cannot create bare named parameter '${bare}' because of conflicting names '${seen}' and '${full}'.`);
        }
        map.set(bare, full);
      }
      return st.bare = map;
    };
    const bindParams = (st, args) => {
      const stmt = st.stmt;
      if (st.stepped) {
        st.stepped = false;
        x.sqlite3_reset(stmt);
      }
      const n = args.length;
      if (st.bound) {
        st.bound = false;
        check(st.conn, x.sqlite3_clear_bindings(stmt));
      }
      if (n === 0)
        return;
      st.bound = true;
      let first = 0;
      const named = args[0];
      if (named !== null && (typeof named === "object" || typeof named === "function") && !ArrayBuffer.isView(named)) {
        first = 1;
        const bare = st.bareNamed ? bareNames(st) : undefined;
        for (const key of Object.keys(named)) {
          const z = E.allocString(key);
          let index2 = x.sqlite3_bind_parameter_index(stmt, z);
          x.sqlite3_free(z);
          if (index2 === 0 && bare) {
            const full = bare.get(key);
            if (full !== undefined) {
              const zf = E.allocString(full);
              index2 = x.sqlite3_bind_parameter_index(stmt, zf);
              x.sqlite3_free(zf);
            }
          }
          if (index2 === 0) {
            if (st.unknownNamed)
              continue;
            throw invalidState(`Unknown named parameter '${key}'`);
          }
          bindValue(st, index2, named[key]);
        }
      }
      let index = 1;
      for (let i = first;i < n; i++) {
        for (;; ) {
          const name = x.sqlite3_bind_parameter_name(stmt, index);
          if (!name || E.u8[name] === 63)
            break;
          index++;
        }
        bindValue(st, index++, args[i]);
      }
    };
    const tooLarge = (v) => err(RangeError, "ERR_OUT_OF_RANGE", `Value is too large to be represented as a JavaScript number: ${v}`);
    const columnNames = (stmt, n) => {
      const names = new Array(n);
      for (let i = 0;i < n; i++)
        names[i] = E.cstr(x.sqlite3_column_name(stmt, i));
      return names;
    };
    const readRow = (st, n, names) => {
      const buf = E.rowBuffer(n);
      x.bat_row(st.stmt, n, buf);
      const u32 = E.u32;
      const f64 = E.f64;
      const u8 = E.u8;
      const big = st.readBigInts;
      const arrays = st.returnArrays;
      const row = arrays ? new Array(n) : { __proto__: null };
      let w = buf >>> 2;
      for (let i = 0;i < n; i++, w += 4) {
        let v;
        switch (u32[w]) {
          case 1:
            v = f64[(w >>> 1) + 1];
            if (big)
              v = BigInt(v);
            break;
          case 2:
            v = f64[(w >>> 1) + 1];
            break;
          case 3:
            v = E.text(u32[w + 2], u32[w + 1]);
            break;
          case 4:
            v = u8.slice(u32[w + 2], u32[w + 2] + u32[w + 1]);
            break;
          case 6: {
            const exact = E.dv.getBigInt64(buf + i * 16 + 8, true);
            if (!big)
              throw tooLarge(exact);
            v = exact;
            break;
          }
          default:
            v = null;
        }
        if (arrays)
          row[i] = v;
        else
          row[names[i]] = v;
      }
      return row;
    };
    const valueToJs = (value, big) => {
      switch (x.sqlite3_value_type(value)) {
        case 1: {
          if (big)
            return x.sqlite3_value_int64(value);
          if (!x.bat_value_int_safe(value))
            throw tooLarge(x.sqlite3_value_int64(value));
          return x.sqlite3_value_double(value);
        }
        case 2:
          return x.sqlite3_value_double(value);
        case 3: {
          const p = x.sqlite3_value_text(value);
          const n = x.sqlite3_value_bytes(value);
          E.refresh();
          return E.text(p, n);
        }
        case 4: {
          const p = x.sqlite3_value_blob(value);
          const n = x.sqlite3_value_bytes(value);
          return E.u8.slice(p, p + n);
        }
        default:
          return null;
      }
    };
    const argsToJs = (argc, argv, big) => {
      const args = new Array(argc);
      for (let i = 0;i < argc; i++)
        args[i] = valueToJs(E.u32[(argv >>> 2) + i], big);
      return args;
    };
    const resultFromJs = (ctx2, value) => {
      if (value === null || value === undefined)
        x.sqlite3_result_null(ctx2);
      else if (typeof value === "number")
        x.sqlite3_result_double(ctx2, value);
      else if (typeof value === "string") {
        const p = E.allocString(value);
        x.bat_result_text(ctx2, p, E.lastLen);
      } else if (ArrayBuffer.isView(value)) {
        const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
        x.bat_result_blob(ctx2, E.allocBytes(bytes), bytes.length);
      } else if (typeof value === "bigint") {
        if (value > MAX_I64 || value < MIN_I64)
          throw err(RangeError, "ERR_OUT_OF_RANGE", "BigInt value is too large for SQLite");
        x.sqlite3_result_int64(ctx2, value);
      } else {
        const z = E.allocString(typeof value.then === "function" ? "Asynchronous user-defined functions are not supported" : "Returned JavaScript value cannot be converted to a SQLite value");
        x.sqlite3_result_error(ctx2, z, -1);
        x.sqlite3_free(z);
      }
    };
    let constructing;
    const states = new WeakMap;
    const live = (self) => {
      const st = states.get(self);
      if (!st)
        throw invalidType("Illegal invocation");
      if (!st.conn.stmts.has(st.stmt))
        throw invalidState("statement has been finalized");
      return st;
    };
    const stepError = (st) => sqliteError(st.conn);
    const begin = () => timing ? performance.now() : 0;
    const end = (t) => {
      if (timing)
        counters.ms += performance.now() - t;
    };
    const boolArg = (v, name) => {
      if (typeof v !== "boolean")
        throw invalidType(`The "${name}" argument must be a boolean.`);
      return v;
    };

    class StatementSync {
      constructor() {
        if (!constructing)
          throw err(Error, "ERR_ILLEGAL_CONSTRUCTOR", "Illegal constructor");
        states.set(this, constructing);
        constructing = undefined;
      }
      all() {
        const st = live(this);
        const t = begin();
        counters.all++;
        st.epoch++;
        const stmt = st.stmt;
        try {
          bindParams(st, arguments);
          const rows = [];
          const n = x.sqlite3_column_count(stmt);
          let names;
          let rc;
          while ((rc = x.sqlite3_step(stmt)) === SQLITE_ROW)
            rows.push(readRow(st, n, names ??= st.returnArrays ? [] : columnNames(stmt, n)));
          if (rc !== SQLITE_DONE)
            throw stepError(st);
          return rows;
        } finally {
          x.sqlite3_reset(stmt);
          end(t);
        }
      }
      get() {
        const st = live(this);
        const t = begin();
        counters.get++;
        st.epoch++;
        const stmt = st.stmt;
        try {
          bindParams(st, arguments);
          const rc = x.sqlite3_step(stmt);
          if (rc === SQLITE_DONE)
            return;
          if (rc !== SQLITE_ROW)
            throw stepError(st);
          const n = x.sqlite3_column_count(stmt);
          if (n === 0)
            return;
          return readRow(st, n, st.returnArrays ? [] : columnNames(stmt, n));
        } finally {
          x.sqlite3_reset(stmt);
          end(t);
        }
      }
      run() {
        const st = live(this);
        const t = begin();
        counters.run++;
        st.epoch++;
        const stmt = st.stmt;
        try {
          bindParams(st, arguments);
          let rc;
          while ((rc = x.sqlite3_step(stmt)) === SQLITE_ROW) {}
          if (rc !== SQLITE_DONE)
            throw stepError(st);
        } finally {
          x.sqlite3_reset(stmt);
          end(t);
        }
        const db = st.conn.db;
        const changes = x.bat_changes(db);
        const rowid = x.bat_last_insert_rowid(db);
        if (st.readBigInts)
          return { changes: BigInt(changes), lastInsertRowid: BigInt(rowid) };
        return { changes, lastInsertRowid: rowid };
      }
      iterate() {
        const st = live(this);
        counters.iterate++;
        const epoch = ++st.epoch;
        const stmt = st.stmt;
        bindParams(st, arguments);
        st.stepped = true;
        const n = x.sqlite3_column_count(stmt);
        let names;
        let done = false;
        const it = {
          __proto__: iteratorPrototype,
          next() {
            if (!st.conn.stmts.has(stmt))
              throw invalidState("statement has been finalized");
            if (st.epoch !== epoch)
              throw invalidState("iterator was invalidated");
            if (done)
              return { __proto__: null, done: true, value: null };
            const rc = x.sqlite3_step(stmt);
            if (rc === SQLITE_ROW) {
              return { __proto__: null, done: false, value: readRow(st, n, names ??= st.returnArrays ? [] : columnNames(stmt, n)) };
            }
            const failed = rc !== SQLITE_DONE ? stepError(st) : undefined;
            x.sqlite3_reset(stmt);
            if (failed)
              throw failed;
            return { __proto__: null, done: true, value: null };
          },
          return() {
            if (!st.conn.stmts.has(stmt))
              throw invalidState("statement has been finalized");
            if (st.epoch !== epoch)
              throw invalidState("iterator was invalidated");
            done = true;
            x.sqlite3_reset(stmt);
            return { __proto__: null, done: true, value: null };
          }
        };
        return it;
      }
      columns() {
        const st = live(this);
        const stmt = st.stmt;
        const n = x.sqlite3_column_count(stmt);
        const s = (p) => p ? E.cstr(p) : null;
        const out = new Array(n);
        for (let i = 0;i < n; i++) {
          out[i] = {
            __proto__: null,
            column: s(x.sqlite3_column_origin_name(stmt, i)),
            database: s(x.sqlite3_column_database_name(stmt, i)),
            name: s(x.sqlite3_column_name(stmt, i)),
            table: s(x.sqlite3_column_table_name(stmt, i)),
            type: s(x.sqlite3_column_decltype(stmt, i))
          };
        }
        return out;
      }
      setAllowBareNamedParameters(enabled) {
        const st = live(this);
        st.bareNamed = boolArg(enabled, "allowBareNamedParameters");
      }
      setAllowUnknownNamedParameters(enabled) {
        const st = live(this);
        st.unknownNamed = boolArg(enabled, "enabled");
      }
      setReadBigInts(enabled) {
        const st = live(this);
        st.readBigInts = boolArg(enabled, "readBigInts");
      }
      setReturnArrays(enabled) {
        const st = live(this);
        st.returnArrays = boolArg(enabled, "returnArrays");
      }
      get sourceSQL() {
        const st = live(this);
        return E.cstr(x.sqlite3_sql(st.stmt));
      }
      get expandedSQL() {
        const st = live(this);
        const p = x.sqlite3_expanded_sql(st.stmt);
        if (!p)
          throw err(Error, "ERR_SQLITE_ERROR", "Expanded SQL text would exceed configured limits");
        const sql = E.cstr(p);
        x.sqlite3_free(p);
        return sql;
      }
    }
    const iteratorPrototype = Object.create(Object.getPrototypeOf(Object.getPrototypeOf([][Symbol.iterator]())), {
      [Symbol.toStringTag]: { value: "StatementSyncIterator", configurable: true }
    });
    const dbs = new WeakMap;
    const dbState = (self) => {
      const s = dbs.get(self);
      if (!s)
        throw invalidType("Illegal invocation");
      return s;
    };
    const opened = (self) => {
      const conn = dbState(self).conn;
      if (!conn)
        throw invalidState("database is not open");
      return conn;
    };
    const pathArg = (path) => {
      let location;
      if (typeof path === "string")
        location = path;
      else if (path instanceof Uint8Array)
        location = new TextDecoder().decode(path);
      else if (path !== null && typeof path === "object" && typeof path.href === "string" && path.protocol === "file:") {
        location = decodeURIComponent(path.pathname);
      }
      if (location === undefined || location.includes("\x00")) {
        throw invalidType('The "path" argument must be a string, Uint8Array, or URL without null bytes.');
      }
      return location;
    };
    const openDatabase = (s) => {
      engine();
      const z = E.allocString(s.location);
      const flags = (s.readOnly ? OPEN_READONLY2 : OPEN_READWRITE2 | OPEN_CREATE2) | OPEN_URI;
      const rc = x.sqlite3_open_v2(z, E.out, flags, 0);
      x.sqlite3_free(z);
      const db = E.u32[E.out >>> 2];
      const conn = { db, stmts: new Set, functionIds: [], authorizerId: 0, ignoreNextError: false };
      try {
        if (rc !== SQLITE_OK) {
          if (!db)
            throw err(Error, "ERR_SQLITE_ERROR", "out of memory");
          throw sqliteError(conn);
        }
        x.sqlite3_extended_result_codes(db, 1);
        check(conn, x.bat_db_config(db, DBCONFIG_DQS_DML, s.dqs ? 1 : 0));
        check(conn, x.bat_db_config(db, DBCONFIG_DQS_DDL, s.dqs ? 1 : 0));
        check(conn, x.bat_db_config(db, DBCONFIG_ENABLE_FKEY, s.foreignKeys ? 1 : 0));
        if (s.defensive)
          check(conn, x.bat_db_config(db, DBCONFIG_DEFENSIVE, 1));
        x.sqlite3_busy_timeout(db, s.timeout);
      } catch (e) {
        if (db)
          x.sqlite3_close_v2(db);
        throw e;
      }
      s.conn = conn;
    };
    const closeDatabase = (s) => {
      const conn = s.conn;
      for (const stmt of conn.stmts)
        x.sqlite3_finalize(stmt);
      conn.stmts.clear();
      const rc = x.sqlite3_close_v2(conn.db);
      s.conn = undefined;
      if (conn.authorizerId)
        E.removeFunction(conn.authorizerId);
      if (rc !== SQLITE_OK)
        throw err(Error, "ERR_SQLITE_ERROR", "failed to close the database");
    };
    const prepareStatement = (s, conn, sql) => {
      const z = E.allocString(sql);
      const rc = x.sqlite3_prepare_v2(conn.db, z, E.lastLen + 1, E.out, 0);
      x.sqlite3_free(z);
      if (rc !== SQLITE_OK)
        throw sqliteError(conn);
      const stmt = E.u32[E.out >>> 2];
      if (stmt)
        conn.stmts.add(stmt);
      constructing = {
        conn,
        stmt,
        readBigInts: s.readBigInts,
        returnArrays: s.returnArrays,
        bareNamed: s.bareNamed,
        unknownNamed: s.unknownNamed,
        epoch: 0,
        stepped: false,
        bound: false
      };
      const statement = new StatementSync;
      if (stmt)
        registry.register(statement, { conn, stmt });
      return statement;
    };
    const optionBool = (options2, key, fallback, prefix = "options") => {
      const v = options2[key];
      if (v === undefined)
        return fallback;
      if (typeof v !== "boolean")
        throw invalidType(`The "${prefix}.${key}" argument must be a boolean.`);
      return v;
    };

    class DatabaseSync {
      constructor(path, options2) {
        const location = pathArg(path);
        const s = {
          location,
          readOnly: false,
          foreignKeys: true,
          dqs: false,
          timeout: 0,
          defensive: false,
          readBigInts: false,
          returnArrays: false,
          bareNamed: true,
          unknownNamed: false
        };
        let open = true;
        if (options2 !== undefined) {
          if (options2 === null || typeof options2 !== "object")
            throw invalidType('The "options" argument must be an object.');
          open = optionBool(options2, "open", true);
          s.readOnly = optionBool(options2, "readOnly", false);
          s.foreignKeys = optionBool(options2, "enableForeignKeyConstraints", true);
          s.dqs = optionBool(options2, "enableDoubleQuotedStringLiterals", false);
          if (optionBool(options2, "allowExtension", false))
            throw unavailable("node:sqlite: loading extensions");
          if (options2.timeout !== undefined) {
            if (!Number.isInteger(options2.timeout))
              throw invalidType('The "options.timeout" argument must be an integer.');
            s.timeout = options2.timeout;
          }
          s.readBigInts = optionBool(options2, "readBigInts", false);
          s.returnArrays = optionBool(options2, "returnArrays", false);
          s.bareNamed = optionBool(options2, "allowBareNamedParameters", true);
          s.unknownNamed = optionBool(options2, "allowUnknownNamedParameters", false);
          s.defensive = optionBool(options2, "defensive", false);
        }
        dbs.set(this, s);
        if (open) {
          const t = begin();
          counters.open++;
          openDatabase(s);
          end(t);
        }
      }
      open() {
        const s = dbState(this);
        if (s.conn)
          throw invalidState("database is already open");
        const t = begin();
        counters.open++;
        openDatabase(s);
        end(t);
      }
      close() {
        const s = dbState(this);
        if (!s.conn)
          throw invalidState("database is not open");
        const t = begin();
        counters.close++;
        closeDatabase(s);
        end(t);
      }
      prepare(sql) {
        const s = dbState(this);
        const conn = opened(this);
        if (typeof sql !== "string")
          throw invalidType('The "sql" argument must be a string.');
        const t = begin();
        counters.prepare++;
        try {
          return prepareStatement(s, conn, sql);
        } finally {
          end(t);
        }
      }
      exec(sql) {
        const conn = opened(this);
        if (typeof sql !== "string")
          throw invalidType('The "sql" argument must be a string.');
        const t = begin();
        counters.exec++;
        const z = E.allocString(sql);
        const rc = x.bat_exec(conn.db, z);
        x.sqlite3_free(z);
        end(t);
        if (rc !== SQLITE_OK)
          throw sqliteError(conn);
      }
      function(name, options2, fn) {
        const conn = opened(this);
        if (typeof name !== "string")
          throw invalidType('The "name" argument must be a string.');
        if (arguments.length < 3) {
          fn = options2;
          options2 = undefined;
        }
        let big = false;
        let varargs = false;
        let deterministic = false;
        let directOnly = false;
        if (options2 !== undefined) {
          if (options2 === null || typeof options2 !== "object")
            throw invalidType('The "options" argument must be an object.');
          const o = options2;
          big = optionBool(o, "useBigIntArguments", false);
          varargs = optionBool(o, "varargs", false);
          deterministic = optionBool(o, "deterministic", false);
          directOnly = optionBool(o, "directOnly", false);
        }
        if (typeof fn !== "function")
          throw invalidType('The "function" argument must be a function.');
        const f = fn;
        const id = E.addFunction({
          call(ctx2, argc, argv) {
            resultFromJs(ctx2, f(...argsToJs(argc, argv, big)));
          }
        });
        const z = E.allocString(name);
        const flags = SQLITE_UTF8 | (deterministic ? SQLITE_DETERMINISTIC : 0) | (directOnly ? SQLITE_DIRECTONLY : 0);
        const rc = x.bat_create_function(conn.db, z, varargs ? -1 : f.length, flags, id);
        x.sqlite3_free(z);
        check(conn, rc);
      }
      aggregate(name, options2) {
        const conn = opened(this);
        const start = options2.start;
        if (start === undefined)
          throw invalidType('The "options.start" argument must be a function or a primitive value.');
        const step = options2.step;
        if (typeof step !== "function")
          throw invalidType('The "options.step" argument must be a function.');
        const result = options2.result;
        const inverse = options2.inverse;
        if (inverse !== undefined && typeof inverse !== "function")
          throw invalidType('The "options.inverse" argument must be a function.');
        const big = optionBool(options2, "useBigIntArguments", false);
        const varargs = optionBool(options2, "varargs", false);
        const directOnly = optionBool(options2, "directOnly", false);
        const deterministic = optionBool(options2, "deterministic", false);
        if (typeof name !== "string")
          throw invalidType('The "name" argument must be a string.');
        let argc = -1;
        if (!varargs) {
          argc = Math.max(0, step.length - 1);
          if (inverse)
            argc = Math.max(argc, Math.max(0, inverse.length - 1));
        }
        const accumulators = new Map;
        const initial = () => ({ value: typeof start === "function" ? start() : start });
        const id = E.addFunction({
          step(ctx2, state, argCount, argv, isInverse) {
            let acc = accumulators.get(state);
            if (!acc)
              accumulators.set(state, acc = initial());
            const args = argsToJs(argCount, argv, big);
            acc.value = (isInverse ? inverse : step)(acc.value, ...args);
          },
          final(ctx2, state, isFinal) {
            const acc = (state ? accumulators.get(state) : undefined) ?? initial();
            if (isFinal && state)
              accumulators.delete(state);
            resultFromJs(ctx2, typeof result === "function" ? result(acc.value) : acc.value);
          }
        });
        const z = E.allocString(name);
        const flags = SQLITE_UTF8 | (deterministic ? SQLITE_DETERMINISTIC : 0) | (directOnly ? SQLITE_DIRECTONLY : 0);
        const rc = x.bat_create_aggregate(conn.db, z, argc, flags, id, inverse ? 1 : 0);
        x.sqlite3_free(z);
        check(conn, rc);
      }
      createTagStore(maxSize = 1000) {
        opened(this);
        return createTagStore(this, maxSize);
      }
      location(dbName = "main") {
        const conn = opened(this);
        if (typeof dbName !== "string")
          throw invalidType('The "dbName" argument must be a string.');
        const z = E.allocString(dbName);
        const p = x.sqlite3_db_filename(conn.db, z);
        x.sqlite3_free(z);
        if (!p)
          return null;
        return E.cstr(p) || null;
      }
      createSession() {
        opened(this);
        throw unavailable("node:sqlite: createSession()");
      }
      applyChangeset() {
        opened(this);
        throw unavailable("node:sqlite: applyChangeset()");
      }
      enableLoadExtension() {
        opened(this);
        throw unavailable("node:sqlite: loading extensions");
      }
      loadExtension() {
        opened(this);
        throw unavailable("node:sqlite: loading extensions");
      }
      enableDefensive(active) {
        const conn = opened(this);
        if (typeof active !== "boolean")
          throw invalidType('The "active" argument must be a boolean.');
        check(conn, x.bat_db_config(conn.db, DBCONFIG_DEFENSIVE, active ? 1 : 0));
      }
      serialize(dbName = "main") {
        const conn = opened(this);
        if (typeof dbName !== "string")
          throw invalidType('The "dbName" argument must be a string.');
        const z = E.allocString(dbName);
        const p = x.sqlite3_serialize(conn.db, z, E.out, 0);
        x.sqlite3_free(z);
        const size = Number(E.dv.getBigInt64(E.out, true));
        if (!p) {
          if (size === 0)
            return new Uint8Array(0);
          throw sqliteError(conn);
        }
        const bytes = E.u8.slice(p, p + size);
        x.sqlite3_free(p);
        return bytes;
      }
      deserialize(buffer, options2) {
        const conn = opened(this);
        if (!(buffer instanceof Uint8Array))
          throw invalidType('The "buffer" argument must be a Uint8Array.');
        let dbName = "main";
        if (options2 !== undefined) {
          if (options2 === null || typeof options2 !== "object")
            throw invalidType('The "options" argument must be an object.');
          if (options2.dbName !== undefined) {
            if (typeof options2.dbName !== "string")
              throw invalidType('The "options.dbName" argument must be a string.');
            dbName = options2.dbName;
          }
        }
        if (buffer.length === 0)
          throw err(RangeError, "ERR_INVALID_ARG_VALUE", 'The "buffer" argument must not be empty.');
        for (const stmt of conn.stmts)
          x.sqlite3_finalize(stmt);
        conn.stmts.clear();
        const p = x.sqlite3_malloc(buffer.length);
        if (!p)
          throw err(Error, "ERR_MEMORY_ALLOCATION_FAILED", "Failed to allocate memory for the database");
        E.u8.set(buffer, p);
        const z = E.allocString(dbName);
        const n = BigInt(buffer.length);
        const rc = x.sqlite3_deserialize(conn.db, z, p, n, n, DESERIALIZE_FREEONCLOSE | DESERIALIZE_RESIZEABLE);
        x.sqlite3_free(z);
        check(conn, rc);
      }
      setAuthorizer(callback) {
        const conn = opened(this);
        if (callback !== null && typeof callback !== "function")
          throw invalidType('The "callback" argument must be a function or null.');
        if (conn.authorizerId)
          E.removeFunction(conn.authorizerId);
        conn.authorizerId = 0;
        if (callback) {
          conn.authorizerId = E.addFunction({
            authorize(action, a, b, c, d) {
              const r = callback(action, a, b, c, d);
              if (!Number.isInteger(r))
                throw invalidType("Authorizer callback must return an integer authorization code");
              if (r !== 0 && r !== 1 && r !== 2) {
                throw err(RangeError, "ERR_OUT_OF_RANGE", "Authorizer callback returned a invalid authorization code");
              }
              return r;
            }
          });
        }
        check(conn, x.bat_set_authorizer(conn.db, conn.authorizerId));
      }
      get isOpen() {
        return dbState(this).conn !== undefined;
      }
      get isTransaction() {
        return x.sqlite3_get_autocommit(opened(this).db) === 0;
      }
      [Symbol.dispose]() {
        const s = dbState(this);
        if (s.conn) {
          try {
            closeDatabase(s);
          } catch {}
        }
      }
    }
    function createTagStore(db, capacity) {
      const cache = new Map;
      const statement = (strings) => {
        const sql = strings.join("?");
        let st = cache.get(sql);
        if (st) {
          cache.delete(sql);
          const state = states.get(st);
          if (!state.conn.stmts.has(state.stmt))
            st = undefined;
        }
        if (!st)
          st = db.prepare(sql);
        cache.set(sql, st);
        if (cache.size > capacity)
          cache.delete(cache.keys().next().value);
        return st;
      };
      return {
        all: (strings, ...values) => statement(strings).all(...values),
        get: (strings, ...values) => statement(strings).get(...values),
        run: (strings, ...values) => statement(strings).run(...values),
        iterate: (strings, ...values) => statement(strings).iterate(...values),
        clear: () => cache.clear(),
        get size() {
          return cache.size;
        },
        get capacity() {
          return capacity;
        },
        get db() {
          return db;
        }
      };
    }

    class Session {
      constructor() {
        throw err(Error, "ERR_ILLEGAL_CONSTRUCTOR", "Illegal constructor");
      }
    }
    function backup(sourceDb, path, options2) {
      if (sourceDb === null || typeof sourceDb !== "object" || !dbs.has(sourceDb))
        throw invalidType('The "sourceDb" argument must be an object.');
      const conn = opened(sourceDb);
      const location = pathArg(path);
      let rate = 100;
      let source2 = "main";
      let target = "main";
      let progress;
      if (options2 !== undefined) {
        if (options2 === null || typeof options2 !== "object")
          throw invalidType('The "options" argument must be an object.');
        if (options2.rate !== undefined) {
          if (!Number.isInteger(options2.rate))
            throw invalidType('The "options.rate" argument must be an integer.');
          rate = options2.rate;
        }
        if (options2.source !== undefined) {
          if (typeof options2.source !== "string")
            throw invalidType('The "options.source" argument must be a string.');
          source2 = options2.source;
        }
        if (options2.target !== undefined) {
          if (typeof options2.target !== "string")
            throw invalidType('The "options.target" argument must be a string.');
          target = options2.target;
        }
        if (options2.progress !== undefined) {
          if (typeof options2.progress !== "function")
            throw invalidType('The "options.progress" argument must be a function.');
          progress = options2.progress;
        }
      }
      return new Promise((resolve, reject) => {
        const z = E.allocString(location);
        const rc = x.sqlite3_open_v2(z, E.out, OPEN_READWRITE2 | OPEN_CREATE2 | OPEN_URI, 0);
        x.sqlite3_free(z);
        const dest = { db: E.u32[E.out >>> 2], stmts: new Set, functionIds: [], authorizerId: 0, ignoreNextError: false };
        const fail = (e) => {
          if (dest.db)
            x.sqlite3_close_v2(dest.db);
          reject(e);
        };
        if (rc !== SQLITE_OK)
          return fail(sqliteError(dest));
        const zt = E.allocString(target);
        const zs = E.allocString(source2);
        const handle = x.sqlite3_backup_init(dest.db, zt, conn.db, zs);
        x.sqlite3_free(zt);
        x.sqlite3_free(zs);
        if (!handle)
          return fail(sqliteError(dest));
        const turn = () => {
          try {
            if (!dbs.get(sourceDb)?.conn) {
              x.sqlite3_backup_finish(handle);
              return fail(invalidState("database is not open"));
            }
            const r = x.sqlite3_backup_step(handle, rate);
            const total = x.sqlite3_backup_pagecount(handle);
            const remaining = x.sqlite3_backup_remaining(handle);
            if (r === SQLITE_DONE) {
              x.sqlite3_backup_finish(handle);
              x.sqlite3_close_v2(dest.db);
              return resolve(total);
            }
            if (r !== SQLITE_OK && r !== 5 && r !== 6) {
              x.sqlite3_backup_finish(handle);
              return fail(sqliteError(dest));
            }
            if (progress)
              progress({ totalPages: total, remainingPages: remaining });
            queueMicrotask(turn);
          } catch (e) {
            x.sqlite3_backup_finish(handle);
            fail(e);
          }
        };
        turn();
      });
    }
    for (const C of [DatabaseSync, StatementSync]) {
      for (const key of Object.getOwnPropertyNames(C.prototype)) {
        if (key === "constructor")
          continue;
        const d = Object.getOwnPropertyDescriptor(C.prototype, key);
        if (typeof d.value === "function")
          Object.defineProperty(C.prototype, key, { ...d, enumerable: true });
      }
    }
    const callable = (C, name) => new Proxy(C, {
      apply() {
        throw err(TypeError, "ERR_CONSTRUCT_CALL_REQUIRED", "Cannot call constructor without `new`");
      }
    });
    return {
      DatabaseSync: callable(DatabaseSync, "DatabaseSync"),
      StatementSync,
      Session,
      constants: constants3,
      backup,
      __bat: {
        counters,
        get engine() {
          return holder.stats;
        },
        setTiming(on) {
          timing = on;
        },
        prewarm(scratchFile) {
          const Db = DatabaseSync;
          const db = new Db(scratchFile ?? ":memory:");
          try {
            db.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA cache_size = -2000; PRAGMA foreign_keys = ON");
            db.prepare("SELECT name FROM sqlite_master WHERE type = ? AND name NOT LIKE ?").all("table", "sqlite_%");
            db.exec("BEGIN");
            db.prepare("CREATE TABLE IF NOT EXISTS a(id TEXT PRIMARY KEY, n INTEGER NOT NULL, data TEXT, time_created INTEGER)").run();
            db.prepare("CREATE TABLE b(id INTEGER PRIMARY KEY, a_id TEXT NOT NULL REFERENCES a(id) ON DELETE CASCADE, v REAL, blob BLOB)").run();
            db.prepare("CREATE INDEX b_a ON b(a_id)").run();
            db.prepare("CREATE UNIQUE INDEX a_n ON a(n)").run();
            const ia = db.prepare("INSERT INTO a(id, n, data, time_created) VALUES (?, ?, ?, ?)");
            const ib = db.prepare("INSERT INTO b(a_id, v, blob) VALUES ($a, $v, $blob) RETURNING id");
            for (let i = 0;i < 40; i++) {
              ia.run(`id-${i}`, i, JSON.stringify({ i, text: "x".repeat(200) }), Date.now());
              ib.get({ a: `id-${i}`, v: i / 3, blob: new Uint8Array(64) });
            }
            db.exec("COMMIT");
            db.prepare("SELECT a.id, a.data, count(b.id) AS c FROM a LEFT JOIN b ON b.a_id = a.id WHERE a.n >= ? GROUP BY a.id ORDER BY a.time_created DESC, a.id LIMIT 10").all(5);
            db.prepare("SELECT * FROM a WHERE id = ?").get("id-3");
            db.prepare("SELECT * FROM a WHERE id IN (?, ?, ?) AND data IS NOT NULL").all("id-1", "id-2", "id-3");
            db.prepare("SELECT json_extract(data, '$.i') AS i FROM a WHERE n < ? ORDER BY n").all(3);
            db.prepare("UPDATE a SET data = ?, n = n + 1000 WHERE id = ?").run("{}", "id-7");
            db.prepare("INSERT INTO a(id, n, data) VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET data = excluded.data").run("id-8", 8, "y".repeat(20000));
            db.prepare("DELETE FROM a WHERE id = ?").run("id-9");
            db.prepare("PRAGMA table_info(a)").all();
            db.prepare("PRAGMA wal_checkpoint(PASSIVE)").all();
          } finally {
            db.close();
            if (scratchFile) {
              try {
                backend.delete(scratchFile);
                backend.delete(`${scratchFile}-wal`);
              } catch {}
            }
          }
        }
      }
    };
  }

  // runtime/src/sqlite/builtins.ts
  registerBuiltin("sqlite", (rt) => createSqliteModule(createKernelBackend(rt.kernel, { cwd: () => rt.process.cwd() }), { wasm: () => rt.wasmModule("sqlite") }), { schemeOnly: true });

  // runtime/src/kernel/attach.ts
  var closedExports = new Proxy({}, {
    get() {
      throw new Error("The runtime is closed");
    }
  });
  var declaredMaximum = new WeakMap;
  var decoder5 = new TextDecoder;
  async function attachKernel(opts) {
    const { module, canBlock } = opts;
    let memory = opts.memory;
    let u8 = new Uint8Array(memory.buffer);
    let i32 = new Int32Array(memory.buffer);
    let dv = new DataView(memory.buffer);
    let memGenIdx = -1;
    let memGen = -1;
    const refresh = () => {
      u8 = new Uint8Array(memory.buffer);
      i32 = new Int32Array(memory.buffer);
      dv = new DataView(memory.buffer);
    };
    const fresh = () => {
      if (memGenIdx >= 0) {
        const g = Atomics.load(i32, memGenIdx);
        if (g !== memGen) {
          memGen = g;
          refresh();
        }
      }
    };
    const host = {
      imageRead: () => -11,
      log: (level, message) => level >= 3 ? console.error(message) : console.log(message),
      ...opts.host
    };
    const text = (ptr, len) => {
      fresh();
      return decoder5.decode(u8.slice(ptr, ptr + len));
    };
    const imports = {
      env: { memory },
      bat: {
        host_wait(addr, expect, timeoutMs) {
          fresh();
          const r = Atomics.wait(i32, addr >>> 2, expect | 0, timeoutMs < 0 ? Infinity : timeoutMs);
          return r === "ok" ? 0 : r === "not-equal" ? 1 : 2;
        },
        host_notify(addr, count) {
          fresh();
          return Atomics.notify(i32, addr >>> 2, count >>> 0 === 4294967295 ? Infinity : count);
        },
        host_log(level, ptr, len) {
          host.log(level, text(ptr, len));
        },
        host_now_ms: () => performance.timeOrigin + performance.now(),
        host_image_read(image, offset, ptr, len) {
          fresh();
          return host.imageRead(image, offset, u8.subarray(ptr, ptr + len));
        }
      },
      wasi_snapshot_preview1: {
        environ_get: () => 0,
        environ_sizes_get(countPtr, sizePtr) {
          fresh();
          dv.setUint32(countPtr, 0, true);
          dv.setUint32(sizePtr, 0, true);
          return 0;
        },
        fd_write(_fd, iovs, iovsLen, nwritten) {
          fresh();
          let total = 0;
          let s = "";
          for (let i = 0;i < iovsLen; i++) {
            const p = dv.getUint32(iovs + i * 8, true);
            const l = dv.getUint32(iovs + i * 8 + 4, true);
            s += decoder5.decode(u8.slice(p, p + l));
            total += l;
          }
          if (s)
            host.log(3, s.trimEnd());
          dv.setUint32(nwritten, total, true);
          return 0;
        },
        proc_exit(code) {
          throw new Error(`kernel proc_exit(${code})`);
        },
        sched_yield: () => 0,
        clock_time_get(_id, _prec, out) {
          fresh();
          dv.setBigUint64(out, BigInt(Math.round((performance.timeOrigin + performance.now()) * 1e6)), true);
          return 0;
        },
        random_get(ptr, len) {
          fresh();
          const tmp = new Uint8Array(len);
          crypto.getRandomValues(tmp);
          u8.set(tmp, ptr);
          return 0;
        }
      },
      wasi: { "thread-spawn": () => -1 }
    };
    const instance = await WebAssembly.instantiate(module, imports);
    const x = instance.exports;
    memGenIdx = x.BAT_MEM_GEN.value >>> 2;
    if (opts.first) {
      x.bat_mem_configure(declaredMaximum.get(memory) ?? memory.buffer.byteLength / 65536);
      x._initialize?.();
    }
    const lockIdx = x.BAT_BOOT_LOCK.value >>> 2;
    while (Atomics.compareExchange(i32, lockIdx, 0, 1) !== 0) {
      if (canBlock)
        Atomics.wait(i32, lockIdx, 1, 5);
    }
    let thread = 0;
    try {
      thread = x.bat_thread_alloc(opts.stackSize ?? 1 << 20, x.__tls_size.value, x.__tls_align.value) >>> 0;
      if (!thread)
        throw new Error("kernel: out of memory attaching thread");
      fresh();
      x.__stack_pointer.value = dv.getUint32(thread + 28, true);
      x.__wasm_init_tls(dv.getUint32(thread + 32, true));
    } finally {
      Atomics.store(i32, lockIdx, 0);
      Atomics.notify(i32, lockIdx, 1);
    }
    const tid = x.bat_thread_start(thread, canBlock ? 1 : 0);
    if (opts.first)
      x.bat_kernel_init();
    const inst = {
      x,
      memory,
      module,
      thread,
      tid,
      canBlock,
      host,
      u8: () => (fresh(), u8),
      i32: () => (fresh(), i32),
      dv: () => (fresh(), dv),
      release() {
        memGenIdx = -1;
        const none = new ArrayBuffer(8);
        u8 = new Uint8Array(none);
        i32 = new Int32Array(none);
        dv = new DataView(none);
        memory = undefined;
        inst.x = closedExports;
        inst.memory = undefined;
      }
    };
    return inst;
  }

  // runtime/src/kernel/opfs.ts
  async function opfsDir(namespace, ...parts) {
    let dir = await navigator.storage.getDirectory();
    for (const part of ["bat", namespace, ...parts]) {
      dir = await dir.getDirectoryHandle(part, { create: true });
    }
    return dir;
  }
  var sharedHandles;
  async function openSyncHandle(file, mode) {
    let read = false;
    const options = {
      get mode() {
        read = true;
        return mode;
      }
    };
    try {
      return await file.createSyncAccessHandle(options);
    } finally {
      sharedHandles = read;
    }
  }
  async function openImage(namespace, name, keeper) {
    if (!keeper && sharedHandles === false)
      return;
    const dir = await opfsDir(namespace, "images");
    const h = await dir.getFileHandle(name);
    for (let attempt = 0;; attempt++) {
      try {
        const handle = await openSyncHandle(h, "read-only");
        if (sharedHandles || keeper)
          return handle;
        handle.close();
        return;
      } catch (e) {
        if (sharedHandles) {
          if (e?.name !== "NoModificationAllowedError")
            throw e;
          return openSyncHandle(h, "readwrite-unsafe");
        }
        if (!keeper)
          return;
        if (attempt >= 40) {
          const name2 = e?.name;
          if (name2 !== "InvalidStateError" && name2 !== "NoModificationAllowedError")
            throw e;
          throw Object.assign(new Error("This workspace is already open in another tab or window, and this browser lets only one of them read its files. Close it there, then reload.", { cause: e }), { code: "EBUSY" });
        }
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
    }
  }
  var early = new Map;
  function preopenImage(namespace, name, keeper = false) {
    const key = `${namespace}/${name}`;
    if (early.has(key))
      return;
    const opening = openImage(namespace, name, keeper);
    opening.catch(() => {
      if (early.get(key) === opening)
        early.delete(key);
    });
    early.set(key, opening);
  }
  async function openImageHandle(namespace, name, keeper = false) {
    const key = `${namespace}/${name}`;
    const opening = early.get(key);
    if (opening) {
      early.delete(key);
      try {
        const handle = await opening;
        if (handle || !keeper)
          return handle;
      } catch {}
    }
    return openImage(namespace, name, keeper);
  }

  // runtime/src/node/builtins.ts
  var isInternal = (id) => id.startsWith("internal/");
  var SCHEME_ONLY = new Set(["sqlite", "sea", "test", "test/reporters"]);
  function createBuiltins(rt) {
    const cache = new Map;
    let lib;
    let internalBinding;
    const g = rt.host.global;
    Object.defineProperty(g, "__bat_nodelib", {
      value: (l) => {
        lib = l;
      },
      writable: true,
      configurable: true
    });
    function nodelib() {
      if (!lib) {
        rt.host.importScripts(rt.config.nodelibUrl);
        if (!lib)
          throw new Error(`runtime: ${rt.config.nodelibUrl} did not register the Node lib`);
      }
      return lib;
    }
    function makeInternalBinding(l) {
      const ALL_PROPERTIES = 0;
      const ONLY_ENUMERABLE = 2;
      const isIndex = (k) => /^(?:0|[1-9]\d*)$/.test(k) && Number(k) <= 4294967295;
      const symbols = {
        owner_symbol: Symbol("owner_symbol"),
        async_id_symbol: Symbol("async_id_symbol"),
        trigger_async_id_symbol: Symbol("trigger_async_id_symbol")
      };
      const bindings = {
        util: {
          constants: { ALL_PROPERTIES, ONLY_ENUMERABLE },
          getOwnNonIndexProperties(obj, filter) {
            const out = [];
            for (const k of Object.getOwnPropertyNames(obj)) {
              if (isIndex(k))
                continue;
              if (filter !== ONLY_ENUMERABLE || Object.getOwnPropertyDescriptor(obj, k).enumerable)
                out.push(k);
            }
            for (const s of Object.getOwnPropertySymbols(obj)) {
              if (filter !== ONLY_ENUMERABLE || Object.getOwnPropertyDescriptor(obj, s).enumerable)
                out.push(s);
            }
            return out;
          },
          isInsideNodeModules: () => false,
          getCallSites(frameCount) {
            const target = {};
            const prevPrepare = Error.prepareStackTrace;
            const prevLimit = Error.stackTraceLimit;
            try {
              Error.stackTraceLimit = frameCount;
              Error.prepareStackTrace = (_e, sites) => sites;
              Error.captureStackTrace(target, bindings.util.getCallSites);
              return (target.stack || []).slice(0, frameCount).map((s) => ({
                functionName: s.getFunctionName() || "",
                scriptId: "",
                scriptName: s.getScriptNameOrSourceURL() || s.getFileName() || "",
                lineNumber: s.getLineNumber() || 0,
                columnNumber: s.getColumnNumber() || 0,
                column: s.getColumnNumber() || 0
              }));
            } finally {
              Error.prepareStackTrace = prevPrepare;
              Error.stackTraceLimit = prevLimit;
            }
          },
          privateSymbols: { untransferable_object_private_symbol: Symbol("untransferable_object") }
        },
        config: { hasIntl: false },
        symbols,
        uv: l.uv,
        constants: { ...l.constants, zlib: {} },
        trace_events: { getCategoryEnabledBuffer: () => new Uint8Array(1), trace() {} }
      };
      let buffer;
      return (name) => {
        if (name === "buffer")
          return buffer ??= l.createBufferBinding();
        if (Object.prototype.hasOwnProperty.call(bindings, name))
          return bindings[name];
        throw new Error(`internalBinding('${name}') is not provided by this runtime`);
      };
    }
    function requireBuiltin(spec) {
      const id = spec.startsWith("node:") ? spec.slice(5) : spec;
      const hit = cache.get(id);
      if (hit)
        return hit.exports;
      const module = { exports: {} };
      const reg = factories.get(id);
      if (reg) {
        cache.set(id, module);
        try {
          const out = reg.factory(rt);
          if (out !== undefined)
            module.exports = out;
        } catch (e) {
          cache.delete(id);
          throw e;
        }
        return module.exports;
      }
      const l = nodelib();
      const factory = l.factories[id];
      if (!factory) {
        const e = new Error(`No such built-in module: ${spec}`);
        e.code = "ERR_UNKNOWN_BUILTIN_MODULE";
        throw e;
      }
      cache.set(id, module);
      try {
        factory(module.exports, requireBuiltin, module, rt.process, internalBinding ??= makeInternalBinding(l), l.primordials);
      } catch (e) {
        cache.delete(id);
        throw e;
      }
      return module.exports;
    }
    function has(id) {
      if (factories.has(id))
        return true;
      return !isInternal(id) && Object.prototype.hasOwnProperty.call(nodelib().factories, id);
    }
    return {
      require: requireBuiltin,
      canonical(specifier) {
        if (specifier.startsWith("node:")) {
          const id = specifier.slice(5);
          return has(id) && !factories.get(id)?.opts.hidden ? id : undefined;
        }
        if (specifier.charCodeAt(0) === 46 || specifier.charCodeAt(0) === 47)
          return;
        if (SCHEME_ONLY.has(specifier) || factories.get(specifier)?.opts.schemeOnly || factories.get(specifier)?.opts.hidden)
          return;
        return has(specifier) ? specifier : undefined;
      },
      names() {
        const out = new Set;
        for (const [name, { opts }] of factories)
          if (!opts.hidden)
            out.add(opts.schemeOnly || SCHEME_ONLY.has(name) ? `node:${name}` : name);
        for (const name of Object.keys(nodelib().factories))
          if (!isInternal(name))
            out.add(name);
        return [...out].sort();
      },
      loaded: (id) => cache.has(id)
    };
  }

  // runtime/src/process/runtime.ts
  var DEFAULT_CONFIG = {
    nodelibUrl: "bat-nodelib.js",
    wasm: {},
    programs: {},
    cacheDir: "/.bat/cache",
    execPath: "/usr/local/bin/node",
    version: "v24.11.0",
    prewarm: ["events", "path", "buffer", "util", "fs", "stream", "url", "module", "os"]
  };

  // runtime/src/process/config.ts
  function parseConfig(href) {
    const hash2 = href.indexOf("#");
    let given = {};
    if (hash2 >= 0 && hash2 + 1 < href.length) {
      try {
        given = JSON.parse(decodeURIComponent(href.slice(hash2 + 1)));
      } catch (e) {
        console.warn(`process worker: unreadable configuration in the URL fragment: ${e}`);
      }
    }
    const base = hash2 >= 0 ? href.slice(0, hash2) : href;
    const abs = (u) => new URL(u, base).href;
    const config = { ...DEFAULT_CONFIG, ...given, wasm: { ...DEFAULT_CONFIG.wasm, ...given.wasm }, programs: { ...given.programs } };
    config.nodelibUrl = abs(config.nodelibUrl);
    for (const k of Object.keys(config.wasm))
      if (config.wasm[k])
        config.wasm[k] = abs(config.wasm[k]);
    for (const k of Object.keys(config.programs))
      config.programs[k] = abs(config.programs[k]);
    return config;
  }

  // runtime/src/process/worker.ts
  var g = globalThis;
  var host = {
    global: g,
    importScripts: g.importScripts.bind(g),
    postMessage: g.postMessage.bind(g),
    addEventListener: g.addEventListener.bind(g),
    fetch: g.fetch.bind(g),
    setTimeout: g.setTimeout.bind(g),
    clearTimeout: g.clearTimeout.bind(g),
    queueMicrotask: g.queueMicrotask.bind(g),
    MessageChannel: g.MessageChannel,
    Worker: g.Worker,
    WebSocket: g.WebSocket,
    XMLHttpRequest: g.XMLHttpRequest,
    location: { href: String(g.location.href), origin: String(g.location.origin) }
  };
  var config = parseConfig(host.location.href);
  if (config.trace)
    traceEnable("process");
  traceCommand("modules", () => {
    if (pid && loader)
      trace("modules", { pid, argv: rt.process?.argv, modules: [...loader.records.values()].filter((r) => r.kind === "cjs" || r.kind === "esm").map((r) => r.path) });
  });
  var inst;
  var kernel;
  var namespace = "default";
  var handles = [];
  var rt;
  var loop;
  var ctl;
  var builtins;
  var loader;
  var warm = false;
  var pid = 0;
  var runAt = 0;
  var marks = [];
  async function openImages() {
    const names = kernel.imageNames();
    for (let id = 0;id < names.length; id++) {
      const name = names[id];
      if (name !== undefined && !handles[id]) {
        try {
          handles[id] = await openImageHandle(namespace, name);
        } catch (e) {
          console.warn(`process worker: no handle for image ${name}: ${e}`);
        }
      }
    }
  }
  var wasmModules = new Map;
  function wasmModule(name) {
    let m = wasmModules.get(name);
    if (m)
      return m;
    const url = config.wasm[name];
    if (!url)
      throw new Error(`runtime: no Wasm module configured for '${name}'`);
    const xhr = new host.XMLHttpRequest;
    xhr.open("GET", url, false);
    xhr.responseType = "arraybuffer";
    xhr.send();
    if (xhr.status !== 200)
      throw new Error(`runtime: ${url}: HTTP ${xhr.status}`);
    m = new WebAssembly.Module(xhr.response);
    wasmModules.set(name, m);
    return m;
  }
  function prefetchWasm() {
    for (const [name, url] of Object.entries(config.wasm)) {
      if (!url || name === "tls" || wasmModules.has(name))
        continue;
      WebAssembly.compileStreaming(host.fetch(url)).then((m) => {
        if (!wasmModules.has(name))
          wasmModules.set(name, m);
      }, () => {});
    }
  }
  function finish(code) {
    loop.stop();
    try {
      if (config.trace || rt.process.env?.BAT_TRACE) {
        const report = { pid, marks, loader: loader.stats, resolve: loader.resolver.stats, resolveKernel: loader.resolver.kernelStats(), transform: loader.transformer.stats, loop: loop.stats };
        ctl.writeFd(2, `[bat-trace] ${JSON.stringify(report, (_k, v) => typeof v === "number" ? Math.round(v * 100) / 100 : v)}
`);
      }
    } catch {}
    kernel.exit(code);
    const never = new Int32Array(new SharedArrayBuffer(4));
    for (;; )
      Atomics.wait(never, 0, 0);
  }
  function warmUp() {
    if (warm)
      return;
    loop = createLoop(host);
    rt = {
      kernel,
      config,
      loop,
      process: undefined,
      require: (id) => builtins.require(id),
      wasmModule,
      host: { ...host, global: g },
      mark: (name) => {
        marks.push([name, performance.now() - runAt]);
        trace(name, { pid, loader: loader ? { ...loader.stats } : undefined });
      },
      marks
    };
    builtins = createBuiltins(rt);
    rt.builtins = builtins;
    ctl = createProcess(rt, loop, finish);
    rt.process = ctl.process;
    loader = createLoader(rt, builtins);
    rt.loader = loader;
    rt.ctl = ctl;
    installGlobals(rt, loop, ctl);
    host.addEventListener("unhandledrejection", (ev) => {
      ev.preventDefault();
      ctl.unhandledRejection(ev.reason, ev.promise);
    });
    host.addEventListener("rejectionhandled", (ev) => ctl.rejectionHandled(ev.promise));
    host.addEventListener("error", (ev) => {
      ev.preventDefault();
      ctl.uncaught(ev.error ?? new Error(ev.message));
    });
    for (const id of config.prewarm) {
      try {
        builtins.require(id);
      } catch (e) {
        console.warn(`prewarm ${id}: ${e}`);
      }
    }
    prefetchWasm();
    warm = true;
  }
  function isNode(exec) {
    const base = exec.slice(exec.lastIndexOf("/") + 1);
    return exec === config.execPath || base === "node" || base === "nodejs";
  }
  function parseLaunch(info) {
    const l = { args: [], execArgv: [], preload: [], conditions: [] };
    const opts = (list, fromEnv) => {
      let i = 0;
      for (;i < list.length; i++) {
        const a = list[i];
        if (a === "--") {
          i++;
          break;
        }
        if (!a.startsWith("-") || a === "-")
          break;
        const eq = a.indexOf("=");
        const name = eq < 0 ? a : a.slice(0, eq);
        const value = () => eq >= 0 ? a.slice(eq + 1) : list[++i];
        if (!fromEnv)
          l.execArgv.push(a);
        if (name === "-e" || name === "--eval")
          l.evalSource = value();
        else if (name === "-p" || name === "--print" || name === "-pe") {
          l.evalSource = value();
          l.print = true;
        } else if (name === "-r" || name === "--require")
          l.preload.push({ kind: "require", id: value() });
        else if (name === "--import")
          l.preload.push({ kind: "import", id: value() });
        else if (name === "--input-type")
          l.inputType = value() === "module" ? "esm" : "cjs";
        else if (name === "-C" || name === "--conditions")
          l.conditions.push(value());
        else if (name === "-v" || name === "--version")
          l.version = true;
        else if (["--loader", "--experimental-loader", "--title", "--max-old-space-size", "--stack-trace-limit", "--env-file", "--watch-path", "--inspect-port", "--unhandled-rejections", "--dns-result-order", "--stack-size", "--disable-warning"].includes(name) && eq < 0 && name !== "--max-old-space-size")
          i++;
      }
      return i;
    };
    if (info.env.NODE_OPTIONS)
      opts(info.env.NODE_OPTIONS.split(/\s+/).filter(Boolean), true);
    if (isNode(info.exec)) {
      const rest = info.argv.slice(1);
      const i = opts(rest, false);
      if (l.evalSource === undefined && i < rest.length) {
        l.script = rest[i];
        l.args = rest.slice(i + 1);
      } else
        l.args = rest.slice(i);
    } else {
      l.script = info.exec;
      l.args = info.argv.slice(1);
    }
    return l;
  }
  function runShell(info) {
    rt.mark("shell");
    const r = createShell(rt).run({ argv: info.argv, env: info.env, cwd: info.cwd || kernel.getcwd(), stdio: [0, 1, 2], asProcess: true });
    kernel.exit(r.signal ? 128 + r.signal : r.status);
    const never = new Int32Array(new SharedArrayBuffer(4));
    for (;; )
      Atomics.wait(never, 0, 0);
  }
  function run(info) {
    if (info.exec === SHELL_EXEC)
      runShell(info);
    const startupPrograms = (info.env.BAT_PROGRAMS ?? "").split(",").filter(Boolean);
    delete info.env.BAT_PROGRAMS;
    const launch = parseLaunch(info);
    let script = launch.script;
    if (script !== undefined && script !== "-" && !script.startsWith("/")) {
      const cwd = kernel.getcwd();
      script = `${cwd === "/" ? "" : cwd}/${script}`;
    }
    ctl.adopt(pid, info, [config.execPath, ...script !== undefined ? [script] : [], ...launch.args], launch.execArgv);
    if (launch.conditions.length)
      loader.resolver.setConditions(launch.conditions);
    rt.mark("adopted");
    loop.start(kernel, {
      uncaught: (e) => ctl.uncaught(e),
      beforeExit: () => ctl.beforeExit(),
      drained: () => ctl.drained(),
      signal: (s) => ctl.signal(s)
    });
    loop.ref();
    if (config.programLoad !== "importScripts" && script !== undefined && script !== "-") {
      const own = loader.programUrl(script);
      const urls = [...own ? [own] : [], ...loader.programUrls(startupPrograms)];
      if (urls.length || preloading) {
        rt.mark("entry");
        const label = (url) => `program ${url.slice(url.lastIndexOf("/") + 1, url.lastIndexOf("-"))}`.replace("program program-", "program ");
        Promise.all([
          preloading,
          ...urls.map((url) => importModule(url).then(() => rt.mark(label(url)), (e) => {
            if (url === own)
              throw e;
            ctl.process.emitWarning?.(`start-up program ${label(url)} failed to load (${e?.message}); loading from the image`);
          }))
        ]).then(() => startEntry(launch, script, true), (e) => {
          ctl.mainSettled();
          ctl.uncaught(e);
          loop.unref();
        });
        return;
      }
    }
    startEntry(launch, script, false);
  }
  var preloading;
  function preloadPrograms(names) {
    if (config.programLoad === "importScripts")
      return;
    const urls = loader.programUrls(names);
    if (!urls.length)
      return;
    const t0 = performance.now();
    preloading = Promise.all(urls.map((url) => importModule(url).catch((e) => console.warn(`program script ${url} failed to load: ${e}`)))).then(() => trace("worker.programs", { names, ms: performance.now() - t0 }));
  }
  var importModule = new Function("u", "return import(u)");
  function startEntry(launch, script, marked) {
    try {
      if (launch.version) {
        ctl.writeFd(1, `${config.version}
`);
        ctl.exit(0);
      }
      const cwd = kernel.getcwd();
      const base = `${cwd === "/" ? "" : cwd}/`;
      for (const p of launch.preload) {
        if (p.kind === "require")
          loader.require(p.id, base);
        else
          loader.import(p.id, base);
      }
      let pending2;
      if (!marked)
        rt.mark("entry");
      if (launch.evalSource !== undefined) {
        if (launch.print) {
          pending2 = loader.runSource(`module.exports = eval(${JSON.stringify(launch.evalSource)})`, "[eval]", "cjs");
          g.console.log(loader.main().exports);
        } else
          pending2 = loader.runSource(launch.evalSource, "[eval]", launch.inputType);
      } else if (script === undefined || script === "-") {
        const chunks = [];
        const buf = new Uint8Array(65536);
        for (;; ) {
          const n = kernel.read(0, buf);
          if (n <= 0)
            break;
          chunks.push(buf.slice(0, n));
        }
        const text = chunks.map((c) => new TextDecoder().decode(c)).join("");
        pending2 = text.trim() ? loader.runSource(text, "[stdin]", launch.inputType) : undefined;
      } else {
        pending2 = loader.runMain(script);
      }
      rt.mark("entry-returned");
      if (pending2) {
        pending2.then(() => ctl.mainSettled(), (e) => {
          ctl.mainSettled();
          ctl.uncaught(e);
        });
      } else
        ctl.mainSettled();
    } catch (e) {
      ctl.mainSettled();
      ctl.uncaught(e);
    } finally {
      loop.unref();
    }
    loop.drainTicks();
  }
  host.addEventListener("message", async (e) => {
    const m = e.data;
    if (!m || typeof m.type !== "string")
      return;
    try {
      if (m.type === "attach") {
        e.stopImmediatePropagation();
        const serviceWorker = g.navigator?.serviceWorker;
        if (m.controlled && serviceWorker && !serviceWorker.controller) {
          host.postMessage({ type: "uncontrolled" });
          return;
        }
        namespace = m.namespace;
        for (const name of m.images ?? [])
          preopenImage(namespace, name);
        inst = await attachKernel({
          module: m.module,
          memory: m.memory,
          canBlock: true,
          host: {
            imageRead(image, offset, dst) {
              const h = handles[image];
              return h ? h.read(dst, { at: offset }) : -11;
            }
          }
        });
        kernel = createKernel(inst);
        trace("worker.attached");
        await openImages();
        host.postMessage({ type: "ready", thread: inst.thread, tid: inst.tid });
        try {
          warmUp();
        } catch (err2) {
          console.error("process worker warm-up failed (will retry at spawn):", err2);
        }
        if (warm && m.programs?.length)
          preloadPrograms(m.programs);
        trace("worker.warm");
      } else if (m.type === "images") {
        e.stopImmediatePropagation();
        await openImages();
      } else if (m.type === "run") {
        e.stopImmediatePropagation();
        runAt = performance.now();
        pid = m.pid;
        if (kernel.x.bat_proc_attach(pid) < 0)
          throw new Error(`no such process ${pid}`);
        if (handles.length < kernel.imageNames().length)
          await openImages();
        marks.push(["warm", warm ? 1 : 0]);
        warmUp();
        rt.mark("runtime");
        const info = kernel.procInfo(pid);
        run(info);
      }
    } catch (err2) {
      const text = `${err2?.stack ?? err2}
`;
      if (pid) {
        try {
          kernel.write(2, new TextEncoder().encode(text));
        } catch {}
        try {
          kernel.exit(1);
        } catch {}
      } else
        host.postMessage({ type: "error", error: text });
    }
  });
})();

//# sourceURL=bat:///bat-process.js
