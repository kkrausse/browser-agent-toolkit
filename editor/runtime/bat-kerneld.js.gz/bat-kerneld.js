// runtime/src/kernel/attach.ts
var closedExports = new Proxy({}, {
  get() {
    throw new Error("The runtime is closed");
  }
});
var declaredMaximum = new WeakMap;
var decoder = new TextDecoder;
async function attachKernel(opts) {
  const { module, canBlock } = opts;
  let memory = opts.memory;
  let u8 = new Uint8Array(memory.buffer);
  let i32 = new Int32Array(memory.buffer);
  let dv = new DataView(memory.buffer);
  let memGenIdx = -1;
  let memGen = -1;
  const refresh = () => {
    u8 = new Uint8Array(memory.buffer);
    i32 = new Int32Array(memory.buffer);
    dv = new DataView(memory.buffer);
  };
  const fresh = () => {
    if (memGenIdx >= 0) {
      const g = Atomics.load(i32, memGenIdx);
      if (g !== memGen) {
        memGen = g;
        refresh();
      }
    }
  };
  const host = {
    imageRead: () => -11,
    log: (level, message) => level >= 3 ? console.error(message) : console.log(message),
    ...opts.host
  };
  const text = (ptr, len) => {
    fresh();
    return decoder.decode(u8.slice(ptr, ptr + len));
  };
  const imports = {
    env: { memory },
    bat: {
      host_wait(addr, expect, timeoutMs) {
        fresh();
        const r = Atomics.wait(i32, addr >>> 2, expect | 0, timeoutMs < 0 ? Infinity : timeoutMs);
        return r === "ok" ? 0 : r === "not-equal" ? 1 : 2;
      },
      host_notify(addr, count) {
        fresh();
        return Atomics.notify(i32, addr >>> 2, count >>> 0 === 4294967295 ? Infinity : count);
      },
      host_log(level, ptr, len) {
        host.log(level, text(ptr, len));
      },
      host_now_ms: () => performance.timeOrigin + performance.now(),
      host_image_read(image, offset, ptr, len) {
        fresh();
        return host.imageRead(image, offset, u8.subarray(ptr, ptr + len));
      }
    },
    wasi_snapshot_preview1: {
      environ_get: () => 0,
      environ_sizes_get(countPtr, sizePtr) {
        fresh();
        dv.setUint32(countPtr, 0, true);
        dv.setUint32(sizePtr, 0, true);
        return 0;
      },
      fd_write(_fd, iovs, iovsLen, nwritten) {
        fresh();
        let total = 0;
        let s = "";
        for (let i = 0;i < iovsLen; i++) {
          const p = dv.getUint32(iovs + i * 8, true);
          const l = dv.getUint32(iovs + i * 8 + 4, true);
          s += decoder.decode(u8.slice(p, p + l));
          total += l;
        }
        if (s)
          host.log(3, s.trimEnd());
        dv.setUint32(nwritten, total, true);
        return 0;
      },
      proc_exit(code) {
        throw new Error(`kernel proc_exit(${code})`);
      },
      sched_yield: () => 0,
      clock_time_get(_id, _prec, out) {
        fresh();
        dv.setBigUint64(out, BigInt(Math.round((performance.timeOrigin + performance.now()) * 1e6)), true);
        return 0;
      },
      random_get(ptr, len) {
        fresh();
        const tmp = new Uint8Array(len);
        crypto.getRandomValues(tmp);
        u8.set(tmp, ptr);
        return 0;
      }
    },
    wasi: { "thread-spawn": () => -1 }
  };
  const instance = await WebAssembly.instantiate(module, imports);
  const x = instance.exports;
  memGenIdx = x.BAT_MEM_GEN.value >>> 2;
  if (opts.first) {
    x.bat_mem_configure(declaredMaximum.get(memory) ?? memory.buffer.byteLength / 65536);
    x._initialize?.();
  }
  const lockIdx = x.BAT_BOOT_LOCK.value >>> 2;
  while (Atomics.compareExchange(i32, lockIdx, 0, 1) !== 0) {
    if (canBlock)
      Atomics.wait(i32, lockIdx, 1, 5);
  }
  let thread = 0;
  try {
    thread = x.bat_thread_alloc(opts.stackSize ?? 1 << 20, x.__tls_size.value, x.__tls_align.value) >>> 0;
    if (!thread)
      throw new Error("kernel: out of memory attaching thread");
    fresh();
    x.__stack_pointer.value = dv.getUint32(thread + 28, true);
    x.__wasm_init_tls(dv.getUint32(thread + 32, true));
  } finally {
    Atomics.store(i32, lockIdx, 0);
    Atomics.notify(i32, lockIdx, 1);
  }
  const tid = x.bat_thread_start(thread, canBlock ? 1 : 0);
  if (opts.first)
    x.bat_kernel_init();
  const inst = {
    x,
    memory,
    module,
    thread,
    tid,
    canBlock,
    host,
    u8: () => (fresh(), u8),
    i32: () => (fresh(), i32),
    dv: () => (fresh(), dv),
    release() {
      memGenIdx = -1;
      const none = new ArrayBuffer(8);
      u8 = new Uint8Array(none);
      i32 = new Int32Array(none);
      dv = new DataView(none);
      memory = undefined;
      inst.x = closedExports;
      inst.memory = undefined;
    }
  };
  return inst;
}

// runtime/src/kernel/errno.ts
var ERRNO = {
  1: "EPERM",
  2: "ENOENT",
  3: "ESRCH",
  4: "EINTR",
  5: "EIO",
  9: "EBADF",
  10: "ECHILD",
  11: "EAGAIN",
  12: "ENOMEM",
  13: "EACCES",
  14: "EFAULT",
  17: "EEXIST",
  18: "EXDEV",
  20: "ENOTDIR",
  21: "EISDIR",
  22: "EINVAL",
  24: "EMFILE",
  25: "ENOTTY",
  28: "ENOSPC",
  29: "ESPIPE",
  30: "EROFS",
  32: "EPIPE",
  34: "ERANGE",
  36: "ENAMETOOLONG",
  38: "ENOSYS",
  39: "ENOTEMPTY",
  40: "ELOOP",
  88: "ENOTSOCK",
  98: "EADDRINUSE",
  104: "ECONNRESET",
  107: "ENOTCONN",
  110: "ETIMEDOUT",
  111: "ECONNREFUSED"
};
var ENOENT = 2;
var EAGAIN = 11;
var ENOTDIR = 20;
var ERANGE = 34;
function kernelError(rc, syscall, path) {
  const errno = -rc;
  const code = ERRNO[errno] ?? `E${errno}`;
  const e = new Error(`${code}: ${syscall}${path !== undefined ? ` '${path}'` : ""}`);
  e.code = code;
  e.errno = errno;
  e.syscall = syscall;
  if (path !== undefined)
    e.path = path;
  return e;
}

// runtime/src/kernel/wait.ts
var hostSetTimeout = globalThis.setTimeout.bind(globalThis);
var hostClearTimeout = globalThis.clearTimeout.bind(globalThis);
var pending = new Map;
async function waitWord(i32, index, seen, timeoutMs) {
  let wait = pending.get(index);
  if (!wait || wait.seen !== seen) {
    const r = Atomics.waitAsync(i32, index, seen);
    if (!r.async)
      return;
    const mine = {
      seen,
      woke: r.value.then(() => {
        if (pending.get(index) === mine)
          pending.delete(index);
      })
    };
    pending.set(index, mine);
    wait = mine;
  }
  let timer;
  await Promise.race([wait.woke, new Promise((resolve) => timer = hostSetTimeout(resolve, timeoutMs))]);
  hostClearTimeout(timer);
}

// runtime/src/kernel/kernel.ts
var O_RDONLY = 0;
var STDIO_INHERIT = 0;
var STDIO_PIPE = 1;
var STDIO_NULL = 2;
var STDIO_FD = 3;
var SCRATCH = 256 * 1024;
var PATH_A = 0;
var PATH_B = 8192;
var STAT = 16384;
var OUT = 16512;
var DATA = 20480;
var DATA_CAP = SCRATCH - DATA;
var encoder = new TextEncoder;
var decoder2 = new TextDecoder;
function createKernel(inst) {
  let x = inst.x;
  const scratch = x.bat_alloc(SCRATCH) >>> 0;
  if (!scratch)
    throw new Error("kernel: out of memory");
  let u8 = inst.u8();
  let i32 = inst.i32();
  let f64 = new Float64Array(u8.buffer);
  let u32 = new Uint32Array(u8.buffer);
  const genIdx = x.BAT_MEM_GEN.value >>> 2;
  let gen = Atomics.load(i32, genIdx);
  const sync = () => {
    const g = Atomics.load(i32, genIdx);
    if (g !== gen) {
      gen = g;
      u8 = inst.u8();
      i32 = inst.i32();
      f64 = new Float64Array(u8.buffer);
      u32 = new Uint32Array(u8.buffer);
    }
  };
  const pathA = scratch + PATH_A;
  const pathB = scratch + PATH_B;
  const statP = scratch + STAT;
  const outP = scratch + OUT;
  const dataP = scratch + DATA;
  const put = (s, at, cap = 8192) => {
    const n = s.length;
    if (n <= cap) {
      let i = 0;
      for (;i < n; i++) {
        const c = s.charCodeAt(i);
        if (c > 127)
          break;
        u8[at + i] = c;
      }
      if (i === n)
        return n;
    }
    const bytes = encoder.encode(s);
    if (bytes.length > cap)
      throw kernelError(-36, "path", s);
    u8.set(bytes, at);
    return bytes.length;
  };
  let priv = new Uint8Array(4096);
  const text = (ptr, len) => {
    if (len <= 24) {
      let s = "";
      let i = 0;
      for (;i < len; i++) {
        const c = u8[ptr + i];
        if (c > 127)
          break;
        s += String.fromCharCode(c);
      }
      if (i === len)
        return s;
    }
    if (len > priv.length)
      priv = new Uint8Array(Math.max(len, priv.length * 2));
    priv.set(u8.subarray(ptr, ptr + len));
    return decoder2.decode(priv.subarray(0, len));
  };
  const readStat = () => {
    const w = statP >>> 2;
    const d = statP >>> 3;
    return {
      kind: u32[w],
      mode: u32[w + 1],
      size: f64[d + 1],
      mtimeMs: f64[d + 2],
      ctimeMs: f64[d + 3],
      ino: f64[d + 4],
      nlink: u32[w + 10],
      dev: u32[w + 11],
      facts: u32[w + 12],
      compiledLen: u32[w + 13],
      birthtimeMs: f64[d + 7]
    };
  };
  const check = (rc, syscall, path) => {
    if (rc < 0)
      throw kernelError(rc, syscall, path);
    return rc;
  };
  const withBuf = (size, fn) => {
    if (size <= DATA_CAP)
      return fn(dataP, DATA_CAP);
    const p = x.bat_alloc(size) >>> 0;
    if (!p)
      throw kernelError(-12, "alloc");
    try {
      sync();
      return fn(p, size);
    } finally {
      x.bat_free(p, size);
    }
  };
  function tryStat(path, nofollow = false) {
    sync();
    const rc = x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
    if (rc === 0)
      return readStat();
    if (rc === -ENOENT || rc === -ENOTDIR)
      return;
    throw kernelError(rc, nofollow ? "lstat" : "stat", path);
  }
  function stat(path, nofollow = false) {
    sync();
    check(x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP), nofollow ? "lstat" : "stat", path);
    return readStat();
  }
  function statRaw(path, nofollow = false) {
    sync();
    return x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
  }
  const st = {
    get kind() {
      return u32[statP >>> 2];
    },
    get mode() {
      return u32[(statP >>> 2) + 1];
    },
    get size() {
      return f64[(statP >>> 3) + 1];
    },
    get mtimeMs() {
      return f64[(statP >>> 3) + 2];
    },
    get ctimeMs() {
      return f64[(statP >>> 3) + 3];
    },
    get ino() {
      return f64[(statP >>> 3) + 4];
    },
    get nlink() {
      return u32[(statP >>> 2) + 10];
    },
    get dev() {
      return u32[(statP >>> 2) + 11];
    },
    get facts() {
      return u32[(statP >>> 2) + 12];
    },
    get compiledLen() {
      return u32[(statP >>> 2) + 13];
    },
    get birthtimeMs() {
      return f64[(statP >>> 3) + 7];
    }
  };
  function kindOf(path) {
    sync();
    const rc = x.bat_stat(pathA, put(path, pathA), 0, statP);
    return rc === 0 ? u32[statP >>> 2] : -1;
  }
  function readFileRaw(path, compiled) {
    sync();
    const n = put(path, pathA);
    let rc = x.bat_read_file(pathA, n, compiled ? 1 : 0, dataP, DATA_CAP, statP);
    if (rc >= 0) {
      sync();
      const st2 = readStat();
      return { data: u8.slice(dataP, dataP + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
    }
    if (rc !== -ERANGE)
      return rc;
    for (let attempt = 0;attempt < 4; attempt++) {
      const size = f64[(statP >>> 3) + 1];
      const p = x.bat_alloc(size || 1) >>> 0;
      if (!p)
        return -12;
      try {
        sync();
        rc = x.bat_read_file(pathA, put(path, pathA), compiled ? 1 : 0, p, size, statP);
        if (rc >= 0) {
          sync();
          const st2 = readStat();
          return { data: u8.slice(p, p + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
        }
      } finally {
        x.bat_free(p, size || 1);
      }
      if (rc !== -ERANGE)
        return rc;
    }
    return rc;
  }
  function readFileInto(path, dst, compiled = false) {
    sync();
    const n = put(path, pathA);
    const flags = compiled ? 1 : 0;
    if (dst.length <= DATA_CAP) {
      const rc = x.bat_read_file(pathA, n, flags, dataP, dst.length, statP);
      if (rc >= 0) {
        sync();
        dst.set(u8.subarray(dataP, dataP + rc));
        return rc;
      }
      if (rc === -ERANGE)
        return -f64[(statP >>> 3) + 1] - 1;
      throw kernelError(rc, "open", path);
    }
    const p = x.bat_alloc(dst.length) >>> 0;
    if (!p)
      throw kernelError(-12, "alloc");
    try {
      sync();
      const rc = x.bat_read_file(pathA, put(path, pathA), flags, p, dst.length, statP);
      if (rc >= 0) {
        sync();
        dst.set(u8.subarray(p, p + rc));
        return rc;
      }
      if (rc === -ERANGE)
        return -f64[(statP >>> 3) + 1] - 1;
      throw kernelError(rc, "open", path);
    } finally {
      x.bat_free(p, dst.length);
    }
  }
  function readFile(path) {
    const r = readFileRaw(path, false);
    if (typeof r === "number")
      throw kernelError(r, "open", path);
    return r.data;
  }
  function tryReadFile(path) {
    const r = readFileRaw(path, false);
    if (typeof r !== "number")
      return r.data;
    if (r === -ENOENT || r === -ENOTDIR)
      return;
    throw kernelError(r, "open", path);
  }
  function readModule(path) {
    const r = readFileRaw(path, true);
    if (typeof r !== "number")
      return r;
    if (r === -ENOENT || r === -ENOTDIR)
      return;
    throw kernelError(r, "open", path);
  }
  function readText(path) {
    return decoder2.decode(readFile(path));
  }
  function writeFile(path, data, opts = {}) {
    const bytes = typeof data === "string" ? encoder.encode(data) : data;
    const flags = (opts.append ? 1 : 0) | (opts.excl ? 2 : 0);
    withBuf(bytes.length, (ptr) => {
      u8.set(bytes, ptr);
      check(x.bat_write_file(pathA, put(path, pathA), ptr, bytes.length, opts.mode ?? 420, flags), "open", path);
    });
  }
  function mkdir(path, opts = {}) {
    sync();
    check(x.bat_mkdir(pathA, put(path, pathA), opts.mode ?? 493, opts.recursive ? 1 : 0), "mkdir", path);
  }
  function rmdir(path) {
    sync();
    check(x.bat_rmdir(pathA, put(path, pathA)), "rmdir", path);
  }
  function unlink(path) {
    sync();
    check(x.bat_unlink(pathA, put(path, pathA)), "unlink", path);
  }
  function rename(from, to) {
    sync();
    check(x.bat_rename(pathA, put(from, pathA), pathB, put(to, pathB)), "rename", from);
  }
  function symlink(target, path) {
    sync();
    check(x.bat_symlink(pathB, put(target, pathB), pathA, put(path, pathA)), "symlink", path);
  }
  function link(existing, path) {
    sync();
    check(x.bat_link(pathA, put(existing, pathA), pathB, put(path, pathB)), "link", path);
  }
  function readlink(path) {
    sync();
    const n = check(x.bat_readlink(pathA, put(path, pathA), dataP, DATA_CAP), "readlink", path);
    return text(dataP, n);
  }
  function realpath(path) {
    sync();
    const n = check(x.bat_realpath(pathA, put(path, pathA), dataP, DATA_CAP), "realpath", path);
    return text(dataP, n);
  }
  function chmod(path, mode, nofollow = false) {
    sync();
    check(x.bat_chmod(pathA, put(path, pathA), mode, nofollow ? 1 : 0), "chmod", path);
  }
  function utimes(path, mtimeMs, nofollow = false) {
    sync();
    check(x.bat_utimes(pathA, put(path, pathA), mtimeMs, nofollow ? 1 : 0), "utime", path);
  }
  function truncate(path, size = 0) {
    sync();
    check(x.bat_truncate(pathA, put(path, pathA), size), "truncate", path);
  }
  function readdir(path) {
    sync();
    const n = put(path, pathA);
    const parse = (ptr, len) => {
      const out = [];
      let i = ptr;
      const end = ptr + len;
      while (i < end) {
        const l = u8[i + 1] | u8[i + 2] << 8;
        out.push({ kind: u8[i], name: text(i + 3, l) });
        i += 3 + l;
      }
      return out;
    };
    let rc = x.bat_readdir(pathA, n, dataP, DATA_CAP);
    if (rc >= 0)
      return parse(dataP, rc);
    if (rc !== -ERANGE)
      throw kernelError(rc, "scandir", path);
    const need = u32[dataP >>> 2] + 4096;
    return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
      rc = check(x.bat_readdir(pathA, put(path, pathA), ptr, cap), "scandir", path);
      return parse(ptr, rc);
    });
  }
  function open(path, flags = O_RDONLY, mode = 420) {
    sync();
    return check(x.bat_open(pathA, put(path, pathA), flags, mode), "open", path);
  }
  function close(fd) {
    check(x.bat_close(fd), "close");
  }
  function read(fd, dst, pos) {
    sync();
    return withBuf(dst.length, (ptr) => {
      const rc = pos === undefined ? x.bat_read(fd, ptr, dst.length) : x.bat_pread(fd, ptr, dst.length, pos);
      if (rc < 0)
        throw kernelError(rc, "read");
      sync();
      dst.set(u8.subarray(ptr, ptr + rc));
      return rc;
    });
  }
  function readRaw(fd, dst) {
    sync();
    return withBuf(dst.length, (ptr) => {
      const rc = x.bat_read(fd, ptr, dst.length);
      if (rc > 0) {
        sync();
        dst.set(u8.subarray(ptr, ptr + rc));
      }
      return rc;
    });
  }
  function write(fd, src, pos) {
    sync();
    return withBuf(src.length, (ptr) => {
      u8.set(src, ptr);
      return check(pos === undefined ? x.bat_write(fd, ptr, src.length) : x.bat_pwrite(fd, ptr, src.length, pos), "write");
    });
  }
  function writeRaw(fd, src) {
    sync();
    return withBuf(src.length, (ptr) => {
      u8.set(src, ptr);
      return x.bat_write(fd, ptr, src.length);
    });
  }
  function seek(fd, offset, whence = 0) {
    const r = x.bat_seek(fd, offset, whence);
    if (r < 0)
      throw kernelError(r, "lseek");
    return r;
  }
  function fstat(fd) {
    sync();
    check(x.bat_fstat(fd, statP), "fstat");
    return readStat();
  }
  function ftruncate(fd, size = 0) {
    check(x.bat_ftruncate(fd, size), "ftruncate");
  }
  function fsetmeta(fd, mode, mtimeMs) {
    check(x.bat_fsetmeta(fd, mode ?? -1, mtimeMs ?? -1), "futimes");
  }
  function setNonblock(fd, on) {
    check(x.bat_set_nonblock(fd, on ? 1 : 0), "fcntl");
  }
  function dup(fd) {
    return check(x.bat_dup(fd), "dup");
  }
  function fdPath(fd) {
    sync();
    return text(dataP, check(x.bat_fd_path(fd, dataP, DATA_CAP), "fcntl"));
  }
  function pipe() {
    sync();
    check(x.bat_pipe(outP), "pipe");
    return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
  }
  function listen(port) {
    return check(x.bat_listen(port), "listen");
  }
  function connect(port) {
    return check(x.bat_connect(port), "connect");
  }
  function accept(fd) {
    const rc = x.bat_accept(fd);
    if (rc === -EAGAIN)
      return;
    return check(rc, "accept");
  }
  function shutdown(fd) {
    check(x.bat_shutdown(fd), "shutdown");
  }
  function sockPorts(fd) {
    sync();
    check(x.bat_sock_ports(fd, outP), "getsockname");
    return { local: u32[outP >>> 2], peer: u32[(outP >>> 2) + 1] };
  }
  function socketpair() {
    sync();
    check(x.bat_socketpair(outP), "socketpair");
    return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
  }
  function ttyOpen(cols, rows) {
    sync();
    check(x.bat_tty_open(cols, rows, outP), "openpty");
    return { master: i32[outP >>> 2], slave: i32[(outP >>> 2) + 1] };
  }
  function isatty(fd) {
    return x.bat_isatty(fd) === 1;
  }
  function ttyGetattr(fd) {
    sync();
    check(x.bat_tty_getattr(fd, dataP), "tcgetattr");
    return u8.slice(dataP, dataP + 44);
  }
  function ttySetattr(fd, termios, action = 0) {
    sync();
    u8.set(termios.subarray(0, 44), dataP);
    check(x.bat_tty_setattr(fd, action, dataP), "tcsetattr");
  }
  function ttyWinsize(fd) {
    sync();
    check(x.bat_tty_winsize(fd, dataP), "ioctl");
    const dv = inst.dv();
    return { rows: dv.getUint16(dataP, true), cols: dv.getUint16(dataP + 2, true), xpixel: dv.getUint16(dataP + 4, true), ypixel: dv.getUint16(dataP + 6, true) };
  }
  function ttyResize(fd, cols, rows, xpixel = 0, ypixel = 0) {
    check(x.bat_tty_resize(fd, cols, rows, xpixel, ypixel), "ioctl");
  }
  function subscribe(fd, mask) {
    check(x.bat_fd_subscribe(fd, mask), "poll");
  }
  function pollFd(fd) {
    return check(x.bat_fd_poll(fd), "poll");
  }
  function poll(fds, timeoutMs) {
    sync();
    const base = dataP >>> 2;
    fds.forEach((f, i) => {
      i32[base + i * 3] = f.fd;
      u32[base + i * 3 + 1] = f.events;
      u32[base + i * 3 + 2] = 0;
    });
    check(x.bat_poll(dataP, fds.length, timeoutMs), "poll");
    sync();
    return fds.map((_, i) => u32[base + i * 3 + 2]);
  }
  function takeEvents() {
    sync();
    const n = x.bat_events_take(dataP, 256);
    const out = [];
    const base = dataP >>> 2;
    for (let i = 0;i < n; i++)
      out.push([u32[base + i * 2], u32[base + i * 2 + 1]]);
    return out;
  }
  function runEvents(on) {
    let stopped = false;
    const word = x.bat_event_word() >>> 2;
    const loop = async () => {
      while (!stopped) {
        sync();
        const seen = Atomics.load(i32, word);
        const events = takeEvents();
        for (const [token, mask] of events) {
          try {
            on(token, mask);
          } catch (e) {
            inst.host.log(3, `event handler: ${e?.stack ?? e}`);
          }
        }
        if (events.length === 0) {
          const r = Atomics.waitAsync(i32, word, seen);
          if (r.async)
            await r.value;
        }
      }
    };
    loop();
    return () => {
      stopped = true;
      Atomics.notify(i32, word);
    };
  }
  function watchAdd(path, recursive) {
    sync();
    return check(x.bat_watch_add(pathA, put(path, pathA), recursive ? 1 : 0), "watch", path);
  }
  function watchRemove(id) {
    x.bat_watch_remove(id);
  }
  function watchRead() {
    sync();
    const out = [];
    for (;; ) {
      const n = x.bat_watch_read(dataP, DATA_CAP);
      if (n <= 0)
        break;
      const dv = inst.dv();
      let i = dataP;
      const end = dataP + n;
      while (i < end) {
        const len = dv.getUint16(i + 8, true);
        out.push({ id: dv.getUint32(i, true), kind: dv.getUint32(i + 4, true), path: text(i + 10, len) });
        i += 10 + len;
      }
    }
    return out;
  }
  function getpid() {
    return check(x.bat_getpid(), "getpid");
  }
  function getppid() {
    return check(x.bat_getppid(), "getppid");
  }
  function chdir(path) {
    sync();
    check(x.bat_chdir(pathA, put(path, pathA)), "chdir", path);
  }
  function getcwd() {
    sync();
    return text(dataP, check(x.bat_getcwd(dataP, DATA_CAP), "getcwd"));
  }
  function spawn(req) {
    const env = Object.entries(req.env ?? {}).map(([k, v]) => `${k}=${v}`);
    const strings = [req.exec, req.cwd ?? "", ...req.argv, ...env].map((s) => encoder.encode(s));
    const size = 4 + 24 + 8 + strings.reduce((n, s) => n + 4 + s.length, 0);
    return withBuf(size + 16, (ptr) => {
      const dv = inst.dv();
      let o = ptr;
      const w32 = (v) => {
        dv.setUint32(o, v, true);
        o += 4;
      };
      w32(0);
      for (let i = 0;i < 3; i++) {
        const s = req.stdio?.[i] ?? "inherit";
        if (typeof s === "object") {
          w32(STDIO_FD);
          w32(s.fd);
        } else {
          w32(s === "pipe" ? STDIO_PIPE : s === "null" ? STDIO_NULL : STDIO_INHERIT);
          w32(0);
        }
      }
      w32(req.argv.length);
      w32(env.length);
      for (const s of strings) {
        w32(s.length);
        u8.set(s, o);
        o += s.length;
      }
      const fdsP = o + 3 & ~3;
      const pid = check(x.bat_spawn(ptr, size, fdsP), "spawn", req.exec);
      sync();
      const b = fdsP >>> 2;
      return { pid, stdio: [i32[b], i32[b + 1], i32[b + 2]] };
    });
  }
  function procInfo(pid) {
    sync();
    const parse = (ptr) => {
      const dv = inst.dv();
      let o = ptr;
      const r32 = () => {
        const v = dv.getUint32(o, true);
        o += 4;
        return v;
      };
      const str = () => {
        const n = r32();
        const s = text(o, n);
        o += n;
        return s;
      };
      const argc = r32();
      const envc = r32();
      const exec = str();
      const cwd = str();
      const argv = Array.from({ length: argc }, str);
      const env = {};
      for (let i = 0;i < envc; i++) {
        const kv = str();
        const eq = kv.indexOf("=");
        env[kv.slice(0, eq)] = kv.slice(eq + 1);
      }
      return { exec, cwd, argv, env };
    };
    const rc = x.bat_proc_info(pid, dataP, DATA_CAP);
    if (rc >= 0)
      return parse(dataP);
    if (rc !== -ERANGE)
      throw kernelError(rc, "procinfo");
    const need = u32[dataP >>> 2];
    return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
      check(x.bat_proc_info(pid, ptr, cap), "procinfo");
      return parse(ptr);
    });
  }
  function exit(code) {
    x.bat_proc_exit(code);
  }
  function waitpid(pid, nohang = false) {
    const rc = x.bat_waitpid(pid, nohang || !inst.canBlock ? 1 : 0);
    if (rc === -EAGAIN)
      return;
    return check(rc, "waitpid");
  }
  function kill(pid, signal) {
    check(x.bat_kill(pid, signal), "kill");
  }
  function sigTake() {
    return x.bat_sig_take() >>> 0;
  }
  function procList() {
    sync();
    const n = x.bat_proc_list(dataP, 1024);
    const b = dataP >>> 2;
    return Array.from({ length: n }, (_, i) => ({
      pid: u32[b + i * 4],
      ppid: u32[b + i * 4 + 1],
      state: u32[b + i * 4 + 2],
      status: i32[b + i * 4 + 3]
    }));
  }
  function imageNames() {
    sync();
    const n = x.bat_image_count();
    return Array.from({ length: n }, (_, id) => {
      const rc = x.bat_image_name(id, dataP, DATA_CAP);
      return rc >= 0 ? text(dataP, rc) : undefined;
    });
  }
  function imageStats(id) {
    sync();
    check(x.bat_image_stats(id, outP), "imagestats");
    const d = outP >>> 3;
    return { entries: f64[d], fileLen: f64[d + 1], cachedBytes: f64[d + 2], hostReads: f64[d + 3] };
  }
  function imageCacheStats() {
    sync();
    x.bat_image_cache_stats(outP);
    const d = outP >>> 3;
    return { limit: f64[d], bytes: f64[d + 1], peakBytes: f64[d + 2], loads: f64[d + 3], evictions: f64[d + 4] };
  }
  function memoryStats() {
    sync();
    x.bat_mem_stats(outP);
    const d = outP >>> 3;
    return { size: f64[d], maximum: f64[d + 1], heapStart: f64[d + 2], heapEnd: f64[d + 3], inUse: f64[d + 4], peakInUse: f64[d + 5], refused: f64[d + 6], grows: f64[d + 7] };
  }
  function imageSection(id, section) {
    sync();
    if (x.bat_image_section(id, section, outP) < 0)
      return;
    const ptr = u32[outP >>> 2];
    return u8.slice(ptr, ptr + u32[(outP >>> 2) + 1]);
  }
  async function flush() {
    const target = x.bat_flush_begin();
    if (target < 0)
      return;
    const word = x.BAT_PERSIST_WORD.value >>> 2;
    for (;; ) {
      sync();
      const seen = Atomics.load(i32, word);
      if (x.bat_persist_durable() >= target)
        return;
      await waitWord(i32, word, seen, 1000);
    }
  }
  function flushSync(timeoutMs = -1) {
    const target = x.bat_flush_begin();
    if (target < 0)
      return;
    check(x.bat_flush_wait(target, timeoutMs), "fsync");
  }
  const overlayGenIdx = x.BAT_OVERLAY_GEN.value >>> 2;
  function overlayGeneration() {
    return Atomics.load(i32, overlayGenIdx);
  }
  async function retrying(fn) {
    const word = x.BAT_FAULT_WORD.value >>> 2;
    for (;; ) {
      sync();
      const seen = Atomics.load(i32, word);
      try {
        return fn();
      } catch (e) {
        if (e?.errno !== EAGAIN)
          throw e;
      }
      await waitWord(i32, word, seen, 100);
    }
  }
  function release() {
    inst.release();
    x = self2.x = inst.x;
    u8 = inst.u8();
    i32 = inst.i32();
    f64 = new Float64Array(u8.buffer);
    u32 = new Uint32Array(u8.buffer);
  }
  const self2 = {
    inst,
    x,
    release,
    stat,
    tryStat,
    statRaw,
    st,
    kindOf,
    readFile,
    readFileInto,
    tryReadFile,
    readModule,
    readText,
    writeFile,
    mkdir,
    rmdir,
    unlink,
    rename,
    symlink,
    link,
    readlink,
    realpath,
    chmod,
    utimes,
    truncate,
    readdir,
    open,
    close,
    read,
    readRaw,
    write,
    writeRaw,
    seek,
    fstat,
    ftruncate,
    fsetmeta,
    setNonblock,
    dup,
    fdPath,
    pipe,
    listen,
    connect,
    accept,
    shutdown,
    sockPorts,
    socketpair,
    ttyOpen,
    isatty,
    ttyGetattr,
    ttySetattr,
    ttyWinsize,
    ttyResize,
    subscribe,
    pollFd,
    poll,
    takeEvents,
    runEvents,
    watchAdd,
    watchRemove,
    watchRead,
    getpid,
    getppid,
    chdir,
    getcwd,
    spawn,
    procInfo,
    exit,
    waitpid,
    kill,
    sigTake,
    procList,
    imageNames,
    imageStats,
    imageSection,
    imageCacheStats,
    memoryStats,
    flush,
    flushSync,
    overlayGeneration,
    retrying
  };
  return self2;
}

// runtime/src/trace.ts
var TRACE_CHANNEL = "bat-trace";
var channel;
var source = "";
function traceEnable(src) {
  source = src;
  channel ??= new BroadcastChannel(TRACE_CHANNEL);
}
function trace(name, data, at) {
  if (channel)
    channel.postMessage({ src: source, name, t: performance.timeOrigin + (at ?? performance.now()), data });
}

// runtime/src/kernel/opfs.ts
async function opfsDir(namespace, ...parts) {
  let dir = await navigator.storage.getDirectory();
  for (const part of ["bat", namespace, ...parts]) {
    dir = await dir.getDirectoryHandle(part, { create: true });
  }
  return dir;
}
function renameIn(dir, handle, name) {
  return handle.move(dir, name);
}
async function imageExists(namespace, name) {
  const dir = await opfsDir(namespace, "images");
  try {
    const h = await dir.getFileHandle(name);
    return (await h.getFile()).size;
  } catch {
    return;
  }
}
var sharedHandles;
async function openSyncHandle(file, mode) {
  let read = false;
  const options = {
    get mode() {
      read = true;
      return mode;
    }
  };
  try {
    return await file.createSyncAccessHandle(options);
  } finally {
    sharedHandles = read;
  }
}
async function openImage(namespace, name, keeper) {
  if (!keeper && sharedHandles === false)
    return;
  const dir = await opfsDir(namespace, "images");
  const h = await dir.getFileHandle(name);
  for (let attempt = 0;; attempt++) {
    try {
      const handle = await openSyncHandle(h, "read-only");
      if (sharedHandles || keeper)
        return handle;
      handle.close();
      return;
    } catch (e) {
      if (sharedHandles) {
        if (e?.name !== "NoModificationAllowedError")
          throw e;
        return openSyncHandle(h, "readwrite-unsafe");
      }
      if (!keeper)
        return;
      if (attempt >= 40) {
        const name2 = e?.name;
        if (name2 !== "InvalidStateError" && name2 !== "NoModificationAllowedError")
          throw e;
        throw Object.assign(new Error("This workspace is already open in another tab or window, and this browser lets only one of them read its files. Close it there, then reload.", { cause: e }), { code: "EBUSY" });
      }
      await new Promise((resolve) => setTimeout(resolve, 25));
    }
  }
}
var early = new Map;
function preopenImage(namespace, name, keeper = false) {
  const key = `${namespace}/${name}`;
  if (early.has(key))
    return;
  const opening = openImage(namespace, name, keeper);
  opening.catch(() => {
    if (early.get(key) === opening)
      early.delete(key);
  });
  early.set(key, opening);
}
async function openImageHandle(namespace, name, keeper = false) {
  const key = `${namespace}/${name}`;
  const opening = early.get(key);
  if (opening) {
    early.delete(key);
    try {
      const handle = await opening;
      if (handle || !keeper)
        return handle;
    } catch {}
  }
  return openImage(namespace, name, keeper);
}
async function storeImage(namespace, name, url, onProgress) {
  const t0 = performance.now();
  const dir = await opfsDir(namespace, "images");
  const tmpName = `${name}.partial`;
  const tmp = await dir.getFileHandle(tmpName, { create: true });
  const handle = await tmp.createSyncAccessHandle();
  let bytes = 0;
  try {
    handle.truncate(0);
    const res = await fetch(url);
    if (!res.ok || !res.body)
      throw new Error(`image download failed: ${res.status} ${url}`);
    const reader = res.body.getReader();
    for (;; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      let off = 0;
      while (off < value.length)
        off += handle.write(value.subarray(off), { at: bytes + off });
      bytes += value.length;
      onProgress?.(bytes);
    }
    handle.flush();
  } finally {
    handle.close();
  }
  await renameIn(dir, tmp, name);
  return { bytes, ms: performance.now() - t0 };
}
async function removeImage(namespace, name) {
  const dir = await opfsDir(namespace, "images");
  await dir.removeEntry(name).catch(() => {});
}
function fnv1a32(bytes) {
  let h = 2166136261;
  for (let i = 0;i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// runtime/src/kernel/kerneld.ts
var reports;
function report(...args) {
  console.error(...args);
  try {
    reports ??= new BroadcastChannel("bat-diag");
    reports.postMessage({ src: "kerneld", text: args.map((a) => a instanceof Error ? `${a.name}: ${a.message}
${a.stack ?? ""}` : String(a)).join(" ").slice(0, 2000) });
  } catch {}
}
addEventListener("error", (e) => report("kerneld: uncaught", e.error ?? e.message));
addEventListener("unhandledrejection", (e) => report("kerneld: unhandled rejection", e.reason));
var JOURNAL_MAGIC = 1247035714;
var FRAME_HEADER = 24;
var SNAP_HEADER = 32;
var SNAP_MAGIC = [66, 65, 84, 83, 78, 65, 80, 49];
var SNAPSHOT_AT = 16 << 20;
var SNAPSHOT_IDLE_AT = 1 << 20;
var SNAPSHOT_IDLE_MS = 5000;
var inst;
var k;
var cfg;
var handles = [];
var procs = new Map;
var spares = [];
var journal;
var journalSize = 0;
var journalWrittenAt = 0;
var nextSlot = "snap-a";
var outP = 0;
var stats = { spawns: 0, kills: 0, faults: 0, snapshotReads: 0, journalFrames: 0, journalBytes: 0, snapshots: 0 };
var ownWorkerUrls = false;
var workerSeq = 0;
function processWorkerUrl() {
  if (!ownWorkerUrls)
    return cfg.processWorkerUrl;
  const at = cfg.processWorkerUrl.indexOf("#");
  const [url, hash] = at < 0 ? [cfg.processWorkerUrl, ""] : [cfg.processWorkerUrl.slice(0, at), cfg.processWorkerUrl.slice(at)];
  return `${url}${url.includes("?") ? "&" : "?"}worker=${++workerSeq}${hash}`;
}
function createProcessWorker(programs = [], attempt = 0) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(processWorkerUrl(), { type: cfg.processWorkerType ?? "module", name: "bat-process" });
    const proc = { worker, thread: 0, pid: 0 };
    worker.onmessage = (e) => {
      const m = e.data;
      if (m.type === "ready") {
        proc.thread = m.thread;
        trace("worker.ready", { thread: m.thread });
        resolve(proc);
      } else if (m.type === "uncontrolled") {
        worker.terminate();
        ownWorkerUrls = true;
        trace("worker.uncontrolled", { attempt });
        if (attempt < 3)
          resolve(createProcessWorker(programs, attempt + 1));
        else
          reject(new Error("process worker: not controlled by the page's service worker"));
      } else if (m.type === "exited") {
        retire(proc, 0);
      } else if (m.type === "error") {
        report("process worker:", m.error);
        if (proc.pid)
          k.x.bat_proc_mark_exited(proc.pid, 1);
        else
          reject(new Error(m.error));
      }
    };
    worker.onerror = (e) => {
      report("process worker crashed:", e.message || "(no message)", e.filename ? `${e.filename}:${e.lineno}` : "");
      if (proc.pid) {
        k.x.bat_proc_mark_exited(proc.pid, 1);
        retire(proc, 0);
      } else
        reject(new Error(e.message));
    };
    worker.postMessage({ type: "attach", module: cfg.module, memory: cfg.memory, namespace: cfg.namespace, images: cfg.images, programs, controlled: !!navigator.serviceWorker?.controller });
  });
}
function addSpare(programs = []) {
  const spare = { hint: programs.join(","), ready: createProcessWorker(programs) };
  spare.ready.catch(() => {
    const i = spares.indexOf(spare);
    if (i >= 0)
      spares.splice(i, 1);
  });
  spares.push(spare);
}
function ensureSpare(count = 1) {
  if (!cfg.warmSpare)
    return;
  for (let have = spares.filter((s) => s.hint === "").length;have < count; have++)
    addSpare();
}
function takeSpare(pid) {
  let want = "";
  try {
    want = k.procInfo(pid).env.BAT_PROGRAMS ?? "";
  } catch {}
  let i = want ? spares.findIndex((s) => s.hint === want) : -1;
  if (i >= 0)
    refillAt = performance.now() + 1500;
  else
    i = spares.findIndex((s) => s.hint === "");
  return i < 0 ? undefined : spares.splice(i, 1)[0].ready;
}
var refillAt = 0;
function refillSpare() {
  const wait = refillAt - performance.now();
  if (wait > 0)
    setTimeout(refillSpare, wait);
  else
    ensureSpare();
}
async function spawn(pid) {
  stats.spawns++;
  trace("spawn.request", { pid, spares: spares.length });
  const taken = takeSpare(pid) ?? createProcessWorker();
  let proc;
  try {
    proc = await taken;
  } catch (e) {
    report("spawn failed:", e);
    k.x.bat_proc_mark_exited(pid, 127);
    return;
  }
  proc.pid = pid;
  procs.set(pid, proc);
  trace("spawn.run", { pid });
  proc.worker.postMessage({ type: "run", pid, runnerUrl: cfg.runnerUrl });
  refillSpare();
}
var retired = new WeakSet;
function retire(proc, graceMs) {
  if (retired.has(proc))
    return;
  retired.add(proc);
  if (procs.get(proc.pid) === proc)
    procs.delete(proc.pid);
  const x = k.x;
  const finish = () => {
    if (proc.thread) {
      x.bat_thread_mark_dying(proc.thread);
      const until = performance.now() + 2000;
      while (x.bat_thread_lock_depth(proc.thread) !== 0 && performance.now() < until) {}
    }
    proc.worker.terminate();
    if (proc.thread)
      setTimeout(() => x.bat_thread_free(proc.thread), 5000);
  };
  if (graceMs > 0)
    setTimeout(finish, graceMs);
  else
    finish();
}
function kill(pid, sig) {
  stats.kills++;
  const proc = procs.get(pid);
  if (proc)
    retire(proc, 0);
  k.x.bat_proc_mark_exited(pid, 128 + sig);
}
var arrivingImages = [];
var IMAGE_CHUNK = 1 << 17;
var SNAPSHOT_CHUNKS = 8;
var snapshotReader;
async function readSnapshot(file, at, length) {
  snapshotReader ??= new globalThis.FileReaderSync;
  for (let attempt = 0;; attempt++) {
    const snapshot = await file.getFile();
    if (snapshot.size <= at)
      return new Uint8Array(0);
    try {
      return new Uint8Array(snapshotReader.readAsArrayBuffer(snapshot.slice(at, Math.min(snapshot.size, at + length))));
    } catch (e) {
      if (attempt >= 8)
        throw e;
    }
  }
}
function readStash(image, offset, dst) {
  for (const s of image.stash) {
    if (offset >= s.at && offset + dst.length <= s.at + s.bytes.length) {
      dst.set(s.bytes.subarray(offset - s.at, offset - s.at + dst.length));
      return dst.length;
    }
  }
  return 0;
}
async function faultArriving(id, chunk) {
  const image = arrivingImages[id];
  if (!image || image.pending.has(chunk))
    return;
  image.pending.add(chunk);
  try {
    const at = chunk * IMAGE_CHUNK;
    const bytes = await readSnapshot(image.file, at, SNAPSHOT_CHUNKS * IMAGE_CHUNK);
    if (arrivingImages[id] !== image) {
      if (handles[id])
        k.x.bat_image_fault(id, chunk);
      return;
    }
    if (!bytes.length)
      return;
    const stashed = { at, bytes };
    image.stash.push(stashed);
    stats.snapshotReads++;
    try {
      for (let ci = chunk;ci * IMAGE_CHUNK < at + bytes.length; ci++)
        k.x.bat_image_fault(id, ci);
    } finally {
      image.stash.splice(image.stash.indexOf(stashed), 1);
    }
  } catch (e) {
    report("kerneld: reading an arriving image:", e);
  } finally {
    image.pending.delete(chunk);
  }
}
async function imageArrived(id) {
  const image = arrivingImages[id];
  if (!image)
    return;
  handles[id] = await openImageHandle(cfg.namespace, image.name, true);
  arrivingImages[id] = undefined;
}
async function mount(name, path, arriving = false, snapshot) {
  const t0 = performance.now();
  const id = k.x.bat_image_reserve();
  if (arriving)
    k.x.bat_image_arriving(id, 1);
  let head;
  if (arriving && snapshot) {
    const file = await (await opfsDir(cfg.namespace, "images")).getFileHandle(name);
    head = { at: 0, bytes: await readSnapshot(file, 0, snapshot.headBytes) };
    arrivingImages[id] = { name, file, stash: [head], pending: new Set };
  } else {
    handles[id] = await openImageHandle(cfg.namespace, name, true);
  }
  const tOpen = performance.now();
  const u8 = inst.u8();
  const enc = new TextEncoder;
  const nb = enc.encode(name);
  const pb = enc.encode(path);
  const p = k.x.bat_alloc(nb.length + pb.length + 8) >>> 0;
  inst.u8().set(nb, p);
  inst.u8().set(pb, p + nb.length);
  const rc = k.x.bat_image_mount(id, p, nb.length, p + nb.length, pb.length);
  k.x.bat_free(p, nb.length + pb.length + 8);
  if (rc < 0)
    throw new Error(`mount ${name} at ${path} failed: errno ${-rc}`);
  const still = arrivingImages[id];
  if (head && still)
    still.stash.splice(still.stash.indexOf(head), 1);
  const t1 = performance.now();
  for (const spare of spares)
    spare.ready.then((s) => s.worker.postMessage({ type: "images" })).catch(() => {});
  for (const proc of procs.values())
    proc.worker.postMessage({ type: "images" });
  return { id, entries: rc, ms: t1 - t0, openHandleMs: tOpen - t0, indexMs: t1 - tOpen };
}
function readInto(h, ptr, len, at) {
  let done = 0;
  while (done < len) {
    const n = h.read(inst.u8().subarray(ptr + done, ptr + len), { at: at + done });
    if (n <= 0)
      throw new Error("short read from OPFS");
    done += n;
  }
}
function writeFrom(h, ptr, len, at) {
  let done = 0;
  while (done < len)
    done += h.write(inst.u8().subarray(ptr + done, ptr + len), { at: at + done });
}
function replay(ptr, len) {
  return k.x.bat_persist_replay(ptr, len);
}
async function restore() {
  const t0 = performance.now();
  const dir = await opfsDir(cfg.namespace, "overlay");
  const open = async (name) => await (await dir.getFileHandle(name, { create: true })).createSyncAccessHandle();
  let snapSeq = 0;
  let best;
  for (const name of ["snap-a", "snap-b"]) {
    const h = await open(name);
    try {
      const size2 = h.getSize();
      if (size2 < SNAP_HEADER)
        continue;
      const hdr = new Uint8Array(SNAP_HEADER);
      h.read(hdr, { at: 0 });
      const dv = new DataView(hdr.buffer);
      const ok = SNAP_MAGIC.every((b, i) => hdr[i] === b) && dv.getUint32(24, true) === 1;
      const seq2 = dv.getFloat64(8, true);
      const len = dv.getFloat64(16, true);
      if (ok && size2 === SNAP_HEADER + len && (!best || seq2 > snapSeq)) {
        best = { name, len };
        snapSeq = seq2;
      }
    } finally {
      h.close();
    }
  }
  if (best) {
    const h = await open(best.name);
    const p = k.x.bat_alloc(best.len || 1) >>> 0;
    try {
      readInto(h, p, best.len, SNAP_HEADER);
      replay(p, best.len);
    } finally {
      k.x.bat_free(p, best.len || 1);
      h.close();
    }
    nextSlot = best.name === "snap-a" ? "snap-b" : "snap-a";
  }
  journal = await open("journal");
  const size = journal.getSize();
  let seq = snapSeq;
  let off = 0;
  let frames = 0;
  if (size > 0) {
    const file = new Uint8Array(size);
    journal.read(file, { at: 0 });
    const dv = new DataView(file.buffer);
    while (off + FRAME_HEADER <= size) {
      if (dv.getUint32(off, true) !== JOURNAL_MAGIC)
        break;
      const len = dv.getUint32(off + 4, true);
      const sum = dv.getUint32(off + 8, true);
      const end = dv.getFloat64(off + 16, true);
      if (off + FRAME_HEADER + len > size)
        break;
      const payload = file.subarray(off + FRAME_HEADER, off + FRAME_HEADER + len);
      if (fnv1a32(payload) !== sum)
        break;
      if (end > snapSeq) {
        const p = k.x.bat_alloc(len || 1) >>> 0;
        inst.u8().set(payload, p);
        replay(p, len);
        k.x.bat_free(p, len || 1);
        seq = end;
        frames++;
      }
      off += FRAME_HEADER + len;
    }
    if (off < size) {
      journal.truncate(off);
      journal.flush();
    }
  }
  journalSize = off;
  journalWrittenAt = performance.now();
  k.x.bat_persist_enable(seq);
  for (const path of cfg.noPersist)
    excludePath(path);
  return { snapshotSeq: snapSeq, seq, snapshotBytes: best?.len ?? 0, journalFrames: frames, journalBytes: off, ms: performance.now() - t0 };
}
function excludePath(path) {
  const b = new TextEncoder().encode(path);
  const p = k.x.bat_alloc(b.length + 1) >>> 0;
  inst.u8().set(b, p);
  k.x.bat_persist_exclude(p, b.length);
  k.x.bat_free(p, b.length + 1);
}
function drainJournal() {
  if (!journal)
    return;
  const x = k.x;
  x.bat_journal_take(outP);
  const dv = inst.dv();
  const ptr = dv.getUint32(outP, true);
  const len = dv.getUint32(outP + 4, true);
  const seq = dv.getFloat64(outP + 8, true);
  if (len > 0) {
    const hdr = new Uint8Array(FRAME_HEADER);
    const h = new DataView(hdr.buffer);
    h.setUint32(0, JOURNAL_MAGIC, true);
    h.setUint32(4, len, true);
    h.setUint32(8, fnv1a32(inst.u8().subarray(ptr, ptr + len)), true);
    h.setFloat64(16, seq, true);
    journal.write(hdr, { at: journalSize });
    writeFrom(journal, ptr, len, journalSize + FRAME_HEADER);
    journal.flush();
    journalSize += FRAME_HEADER + len;
    journalWrittenAt = performance.now();
    x.bat_blob_free(ptr, len);
    stats.journalFrames++;
    stats.journalBytes += len;
  }
  x.bat_persist_set_durable(seq);
  if (journalSize > SNAPSHOT_AT)
    snapshot();
}
var snapshotting;
function snapshot() {
  return snapshotting ??= (async () => {
    if (!journal)
      return { seq: 0, bytes: 0, ms: 0 };
    const t0 = performance.now();
    const dir = await opfsDir(cfg.namespace, "overlay");
    const fh = await dir.getFileHandle(nextSlot, { create: true });
    const h = await fh.createSyncAccessHandle();
    const x = k.x;
    let len = 0;
    let seq = 0;
    try {
      x.bat_persist_snapshot(outP);
      const dv = inst.dv();
      const ptr = dv.getUint32(outP, true);
      len = dv.getUint32(outP + 4, true);
      seq = dv.getFloat64(outP + 8, true);
      h.truncate(0);
      writeFrom(h, ptr, len, SNAP_HEADER);
      h.flush();
      const hdr = new Uint8Array(SNAP_HEADER);
      hdr.set(SNAP_MAGIC, 0);
      const hd = new DataView(hdr.buffer);
      hd.setFloat64(8, seq, true);
      hd.setFloat64(16, len, true);
      hd.setUint32(24, 1, true);
      h.write(hdr, { at: 0 });
      h.flush();
      x.bat_blob_free(ptr, len);
    } finally {
      h.close();
    }
    journal.truncate(0);
    journal.flush();
    journalSize = 0;
    nextSlot = nextSlot === "snap-a" ? "snap-b" : "snap-a";
    x.bat_persist_set_durable(seq);
    stats.snapshots++;
    return { seq, bytes: len, ms: performance.now() - t0 };
  })().finally(() => {
    snapshotting = undefined;
  });
}
async function supervise() {
  const x = k.x;
  const word = x.BAT_KERNELD_WORD.value >>> 2;
  for (;; ) {
    const i32 = inst.i32();
    const seen = Atomics.load(i32, word);
    for (;; ) {
      const kind = x.bat_kerneld_next(outP);
      if (kind === 0)
        break;
      const dv = inst.dv();
      const a = dv.getUint32(outP, true);
      const b = dv.getUint32(outP + 4, true);
      try {
        if (kind === 1)
          spawn(a);
        else if (kind === 2)
          kill(a, b);
        else if (kind === 3) {
          const proc = procs.get(a);
          if (proc)
            retire(proc, 50);
        } else if (kind === 4) {
          stats.faults++;
          if (arrivingImages[a])
            faultArriving(a, b);
          else
            x.bat_image_fault(a, b);
        } else if (kind === 5)
          drainJournal();
      } catch (e) {
        report("kerneld:", e);
      }
    }
    await waitWord(i32, word, seen, 250);
    if (journal && x.bat_persist_pending() > 0) {
      try {
        drainJournal();
      } catch (e) {
        report("kerneld journal:", e);
      }
    } else if (journal && journalSize > SNAPSHOT_IDLE_AT && performance.now() - journalWrittenAt > SNAPSHOT_IDLE_MS) {
      snapshot().catch((e) => report("kerneld snapshot:", e));
    }
  }
}
async function init(args) {
  cfg = args;
  if (args.trace)
    traceEnable("kerneld");
  trace("kerneld.init");
  if (args.warmSpare)
    for (const programs of args.spareHints ?? [])
      addSpare(programs);
  ensureSpare((args.spares ?? 1) - (args.spareHints?.length ?? 0));
  for (const name of args.images ?? [])
    preopenImage(args.namespace, name, true);
  if (args.persist) {
    const tryLock = () => new Promise((resolve) => {
      navigator.locks.request(`bat-kernel:${args.namespace}`, { ifAvailable: true }, (lock) => {
        resolve(!!lock);
        return lock ? new Promise(() => {}) : undefined;
      });
    });
    let got = await tryLock();
    for (let i = 0;!got && i < 20; i++) {
      await new Promise((r) => setTimeout(r, 100));
      got = await tryLock();
    }
    if (!got) {
      const e = new Error("This workspace is already open in another tab.");
      e.code = "EBUSY";
      throw e;
    }
    trace("kerneld.locked");
  }
  inst = await attachKernel({
    module: args.module,
    memory: args.memory,
    canBlock: true,
    host: {
      imageRead(image, offset, dst) {
        const h = handles[image];
        if (h)
          return h.read(dst, { at: offset });
        const arriving = arrivingImages[image];
        return arriving ? readStash(arriving, offset, dst) : -11;
      }
    }
  });
  k = createKernel(inst);
  trace("kerneld.attached");
  const pid = k.x.bat_host_proc_new();
  outP = k.x.bat_alloc(64) >>> 0;
  const restored = args.persist ? await restore() : undefined;
  trace("kerneld.restored", restored);
  if (!args.persist)
    for (const path of args.noPersist)
      excludePath(path);
  supervise();
  return { pid, restored };
}
var ops = {
  init,
  mount: (a) => mount(a.name, a.path, a.arriving, a.snapshot),
  imageArrived: (a) => imageArrived(a.id),
  hasImage: (a) => imageExists(cfg.namespace, a.name),
  storeImage: async (a) => {
    const have = await imageExists(cfg.namespace, a.name);
    if (have !== undefined && !a.url.includes("#force"))
      return { bytes: have, ms: 0, cached: true };
    return { ...await storeImage(cfg.namespace, a.name, a.url), cached: false };
  },
  removeImage: (a) => removeImage(cfg.namespace, a.name),
  snapshot: () => snapshot(),
  compact: () => {
    drainJournal();
    return journal && journalSize > SNAPSHOT_IDLE_AT ? snapshot() : undefined;
  },
  flush: () => drainJournal(),
  spareReady: async () => {
    ensureSpare();
    await Promise.all(spares.map((s) => s.ready));
    return true;
  },
  stats: () => ({ ...stats, journalSize, procs: [...procs.keys()] })
};
self.onmessage = async (e) => {
  const { id, op, args } = e.data;
  try {
    const value = await ops[op](args);
    postMessage({ id, ok: true, value });
  } catch (err) {
    postMessage({ id, ok: false, error: String(err?.message ?? err), code: err?.code });
  }
};

//# sourceURL=bat:///bat-kerneld.js
