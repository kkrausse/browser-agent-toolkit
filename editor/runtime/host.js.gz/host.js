// runtime/src/kernel/attach.ts
var closedExports = new Proxy({}, {
  get() {
    throw new Error("The runtime is closed");
  }
});
var KERNEL_PAGES_DEFAULT = 4096;
var declaredMaximum = new WeakMap;
function createKernelMemory(options = {}) {
  const whole = (value, fallback) => Number.isFinite(value) ? Math.floor(value) : fallback;
  const initial = Math.min(65536, Math.max(64, whole(options.pages, KERNEL_PAGES_DEFAULT)));
  const maximum = Math.min(65536, Math.max(initial, whole(options.maximumPages, initial)));
  try {
    const memory = new WebAssembly.Memory({ initial, maximum, shared: true });
    declaredMaximum.set(memory, maximum);
    return memory;
  } catch (cause) {
    const mib = (pages) => `${pages / 16} MiB`;
    throw new Error(`kernel: this browser refused a shared memory of ${mib(initial)}${maximum > initial ? ` (maximum ${mib(maximum)})` : ""}: ${cause?.message ?? cause}. A smaller one can be asked for with the boot option kernelMemory.pages.`, { cause });
  }
}
var decoder = new TextDecoder;
async function attachKernel(opts) {
  const { module, canBlock } = opts;
  let memory = opts.memory;
  let u8 = new Uint8Array(memory.buffer);
  let i32 = new Int32Array(memory.buffer);
  let dv = new DataView(memory.buffer);
  let memGenIdx = -1;
  let memGen = -1;
  const refresh = () => {
    u8 = new Uint8Array(memory.buffer);
    i32 = new Int32Array(memory.buffer);
    dv = new DataView(memory.buffer);
  };
  const fresh = () => {
    if (memGenIdx >= 0) {
      const g = Atomics.load(i32, memGenIdx);
      if (g !== memGen) {
        memGen = g;
        refresh();
      }
    }
  };
  const host = {
    imageRead: () => -11,
    log: (level, message) => level >= 3 ? console.error(message) : console.log(message),
    ...opts.host
  };
  const text = (ptr, len) => {
    fresh();
    return decoder.decode(u8.slice(ptr, ptr + len));
  };
  const imports = {
    env: { memory },
    bat: {
      host_wait(addr, expect, timeoutMs) {
        fresh();
        const r = Atomics.wait(i32, addr >>> 2, expect | 0, timeoutMs < 0 ? Infinity : timeoutMs);
        return r === "ok" ? 0 : r === "not-equal" ? 1 : 2;
      },
      host_notify(addr, count) {
        fresh();
        return Atomics.notify(i32, addr >>> 2, count >>> 0 === 4294967295 ? Infinity : count);
      },
      host_log(level, ptr, len) {
        host.log(level, text(ptr, len));
      },
      host_now_ms: () => performance.timeOrigin + performance.now(),
      host_image_read(image, offset, ptr, len) {
        fresh();
        return host.imageRead(image, offset, u8.subarray(ptr, ptr + len));
      }
    },
    wasi_snapshot_preview1: {
      environ_get: () => 0,
      environ_sizes_get(countPtr, sizePtr) {
        fresh();
        dv.setUint32(countPtr, 0, true);
        dv.setUint32(sizePtr, 0, true);
        return 0;
      },
      fd_write(_fd, iovs, iovsLen, nwritten) {
        fresh();
        let total = 0;
        let s = "";
        for (let i = 0;i < iovsLen; i++) {
          const p = dv.getUint32(iovs + i * 8, true);
          const l = dv.getUint32(iovs + i * 8 + 4, true);
          s += decoder.decode(u8.slice(p, p + l));
          total += l;
        }
        if (s)
          host.log(3, s.trimEnd());
        dv.setUint32(nwritten, total, true);
        return 0;
      },
      proc_exit(code) {
        throw new Error(`kernel proc_exit(${code})`);
      },
      sched_yield: () => 0,
      clock_time_get(_id, _prec, out) {
        fresh();
        dv.setBigUint64(out, BigInt(Math.round((performance.timeOrigin + performance.now()) * 1e6)), true);
        return 0;
      },
      random_get(ptr, len) {
        fresh();
        const tmp = new Uint8Array(len);
        crypto.getRandomValues(tmp);
        u8.set(tmp, ptr);
        return 0;
      }
    },
    wasi: { "thread-spawn": () => -1 }
  };
  const instance = await WebAssembly.instantiate(module, imports);
  const x = instance.exports;
  memGenIdx = x.BAT_MEM_GEN.value >>> 2;
  if (opts.first) {
    x.bat_mem_configure(declaredMaximum.get(memory) ?? memory.buffer.byteLength / 65536);
    x._initialize?.();
  }
  const lockIdx = x.BAT_BOOT_LOCK.value >>> 2;
  while (Atomics.compareExchange(i32, lockIdx, 0, 1) !== 0) {
    if (canBlock)
      Atomics.wait(i32, lockIdx, 1, 5);
  }
  let thread = 0;
  try {
    thread = x.bat_thread_alloc(opts.stackSize ?? 1 << 20, x.__tls_size.value, x.__tls_align.value) >>> 0;
    if (!thread)
      throw new Error("kernel: out of memory attaching thread");
    fresh();
    x.__stack_pointer.value = dv.getUint32(thread + 28, true);
    x.__wasm_init_tls(dv.getUint32(thread + 32, true));
  } finally {
    Atomics.store(i32, lockIdx, 0);
    Atomics.notify(i32, lockIdx, 1);
  }
  const tid = x.bat_thread_start(thread, canBlock ? 1 : 0);
  if (opts.first)
    x.bat_kernel_init();
  const inst = {
    x,
    memory,
    module,
    thread,
    tid,
    canBlock,
    host,
    u8: () => (fresh(), u8),
    i32: () => (fresh(), i32),
    dv: () => (fresh(), dv),
    release() {
      memGenIdx = -1;
      const none = new ArrayBuffer(8);
      u8 = new Uint8Array(none);
      i32 = new Int32Array(none);
      dv = new DataView(none);
      memory = undefined;
      inst.x = closedExports;
      inst.memory = undefined;
    }
  };
  return inst;
}

// runtime/src/kernel/errno.ts
var ERRNO = {
  1: "EPERM",
  2: "ENOENT",
  3: "ESRCH",
  4: "EINTR",
  5: "EIO",
  9: "EBADF",
  10: "ECHILD",
  11: "EAGAIN",
  12: "ENOMEM",
  13: "EACCES",
  14: "EFAULT",
  17: "EEXIST",
  18: "EXDEV",
  20: "ENOTDIR",
  21: "EISDIR",
  22: "EINVAL",
  24: "EMFILE",
  25: "ENOTTY",
  28: "ENOSPC",
  29: "ESPIPE",
  30: "EROFS",
  32: "EPIPE",
  34: "ERANGE",
  36: "ENAMETOOLONG",
  38: "ENOSYS",
  39: "ENOTEMPTY",
  40: "ELOOP",
  88: "ENOTSOCK",
  98: "EADDRINUSE",
  104: "ECONNRESET",
  107: "ENOTCONN",
  110: "ETIMEDOUT",
  111: "ECONNREFUSED"
};
var ENOENT = 2;
var EAGAIN = 11;
var ENOTDIR = 20;
var ERANGE = 34;
function kernelError(rc, syscall, path) {
  const errno = -rc;
  const code = ERRNO[errno] ?? `E${errno}`;
  const e = new Error(`${code}: ${syscall}${path !== undefined ? ` '${path}'` : ""}`);
  e.code = code;
  e.errno = errno;
  e.syscall = syscall;
  if (path !== undefined)
    e.path = path;
  return e;
}

// runtime/src/kernel/wait.ts
var hostSetTimeout = globalThis.setTimeout.bind(globalThis);
var hostClearTimeout = globalThis.clearTimeout.bind(globalThis);
var pending = new Map;
async function waitWord(i32, index, seen, timeoutMs) {
  let wait = pending.get(index);
  if (!wait || wait.seen !== seen) {
    const r = Atomics.waitAsync(i32, index, seen);
    if (!r.async)
      return;
    const mine = {
      seen,
      woke: r.value.then(() => {
        if (pending.get(index) === mine)
          pending.delete(index);
      })
    };
    pending.set(index, mine);
    wait = mine;
  }
  let timer;
  await Promise.race([wait.woke, new Promise((resolve) => timer = hostSetTimeout(resolve, timeoutMs))]);
  hostClearTimeout(timer);
}

// runtime/src/kernel/kernel.ts
var K_FILE = 0;
var K_DIR = 1;
var O_RDONLY = 0;
var TOKEN_CHILD = 2147483648;
var TOKEN_WATCH = 1073741824;
var TOKEN_SIGNAL = 1073741825;
var STDIO_INHERIT = 0;
var STDIO_PIPE = 1;
var STDIO_NULL = 2;
var STDIO_FD = 3;
var SCRATCH = 256 * 1024;
var PATH_A = 0;
var PATH_B = 8192;
var STAT = 16384;
var OUT = 16512;
var DATA = 20480;
var DATA_CAP = SCRATCH - DATA;
var encoder = new TextEncoder;
var decoder2 = new TextDecoder;
function createKernel(inst) {
  let x = inst.x;
  const scratch = x.bat_alloc(SCRATCH) >>> 0;
  if (!scratch)
    throw new Error("kernel: out of memory");
  let u8 = inst.u8();
  let i32 = inst.i32();
  let f64 = new Float64Array(u8.buffer);
  let u32 = new Uint32Array(u8.buffer);
  const genIdx = x.BAT_MEM_GEN.value >>> 2;
  let gen = Atomics.load(i32, genIdx);
  const sync = () => {
    const g = Atomics.load(i32, genIdx);
    if (g !== gen) {
      gen = g;
      u8 = inst.u8();
      i32 = inst.i32();
      f64 = new Float64Array(u8.buffer);
      u32 = new Uint32Array(u8.buffer);
    }
  };
  const pathA = scratch + PATH_A;
  const pathB = scratch + PATH_B;
  const statP = scratch + STAT;
  const outP = scratch + OUT;
  const dataP = scratch + DATA;
  const put = (s, at, cap = 8192) => {
    const n = s.length;
    if (n <= cap) {
      let i = 0;
      for (;i < n; i++) {
        const c = s.charCodeAt(i);
        if (c > 127)
          break;
        u8[at + i] = c;
      }
      if (i === n)
        return n;
    }
    const bytes = encoder.encode(s);
    if (bytes.length > cap)
      throw kernelError(-36, "path", s);
    u8.set(bytes, at);
    return bytes.length;
  };
  let priv = new Uint8Array(4096);
  const text = (ptr, len) => {
    if (len <= 24) {
      let s = "";
      let i = 0;
      for (;i < len; i++) {
        const c = u8[ptr + i];
        if (c > 127)
          break;
        s += String.fromCharCode(c);
      }
      if (i === len)
        return s;
    }
    if (len > priv.length)
      priv = new Uint8Array(Math.max(len, priv.length * 2));
    priv.set(u8.subarray(ptr, ptr + len));
    return decoder2.decode(priv.subarray(0, len));
  };
  const readStat = () => {
    const w = statP >>> 2;
    const d = statP >>> 3;
    return {
      kind: u32[w],
      mode: u32[w + 1],
      size: f64[d + 1],
      mtimeMs: f64[d + 2],
      ctimeMs: f64[d + 3],
      ino: f64[d + 4],
      nlink: u32[w + 10],
      dev: u32[w + 11],
      facts: u32[w + 12],
      compiledLen: u32[w + 13],
      birthtimeMs: f64[d + 7]
    };
  };
  const check = (rc, syscall, path) => {
    if (rc < 0)
      throw kernelError(rc, syscall, path);
    return rc;
  };
  const withBuf = (size, fn) => {
    if (size <= DATA_CAP)
      return fn(dataP, DATA_CAP);
    const p = x.bat_alloc(size) >>> 0;
    if (!p)
      throw kernelError(-12, "alloc");
    try {
      sync();
      return fn(p, size);
    } finally {
      x.bat_free(p, size);
    }
  };
  function tryStat(path, nofollow = false) {
    sync();
    const rc = x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
    if (rc === 0)
      return readStat();
    if (rc === -ENOENT || rc === -ENOTDIR)
      return;
    throw kernelError(rc, nofollow ? "lstat" : "stat", path);
  }
  function stat(path, nofollow = false) {
    sync();
    check(x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP), nofollow ? "lstat" : "stat", path);
    return readStat();
  }
  function statRaw(path, nofollow = false) {
    sync();
    return x.bat_stat(pathA, put(path, pathA), nofollow ? 1 : 0, statP);
  }
  const st = {
    get kind() {
      return u32[statP >>> 2];
    },
    get mode() {
      return u32[(statP >>> 2) + 1];
    },
    get size() {
      return f64[(statP >>> 3) + 1];
    },
    get mtimeMs() {
      return f64[(statP >>> 3) + 2];
    },
    get ctimeMs() {
      return f64[(statP >>> 3) + 3];
    },
    get ino() {
      return f64[(statP >>> 3) + 4];
    },
    get nlink() {
      return u32[(statP >>> 2) + 10];
    },
    get dev() {
      return u32[(statP >>> 2) + 11];
    },
    get facts() {
      return u32[(statP >>> 2) + 12];
    },
    get compiledLen() {
      return u32[(statP >>> 2) + 13];
    },
    get birthtimeMs() {
      return f64[(statP >>> 3) + 7];
    }
  };
  function kindOf(path) {
    sync();
    const rc = x.bat_stat(pathA, put(path, pathA), 0, statP);
    return rc === 0 ? u32[statP >>> 2] : -1;
  }
  function readFileRaw(path, compiled) {
    sync();
    const n = put(path, pathA);
    let rc = x.bat_read_file(pathA, n, compiled ? 1 : 0, dataP, DATA_CAP, statP);
    if (rc >= 0) {
      sync();
      const st2 = readStat();
      return { data: u8.slice(dataP, dataP + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
    }
    if (rc !== -ERANGE)
      return rc;
    for (let attempt = 0;attempt < 4; attempt++) {
      const size = f64[(statP >>> 3) + 1];
      const p = x.bat_alloc(size || 1) >>> 0;
      if (!p)
        return -12;
      try {
        sync();
        rc = x.bat_read_file(pathA, put(path, pathA), compiled ? 1 : 0, p, size, statP);
        if (rc >= 0) {
          sync();
          const st2 = readStat();
          return { data: u8.slice(p, p + rc), stat: st2, compiled: compiled && st2.compiledLen !== 0 };
        }
      } finally {
        x.bat_free(p, size || 1);
      }
      if (rc !== -ERANGE)
        return rc;
    }
    return rc;
  }
  function readFileInto(path, dst, compiled = false) {
    sync();
    const n = put(path, pathA);
    const flags = compiled ? 1 : 0;
    if (dst.length <= DATA_CAP) {
      const rc = x.bat_read_file(pathA, n, flags, dataP, dst.length, statP);
      if (rc >= 0) {
        sync();
        dst.set(u8.subarray(dataP, dataP + rc));
        return rc;
      }
      if (rc === -ERANGE)
        return -f64[(statP >>> 3) + 1] - 1;
      throw kernelError(rc, "open", path);
    }
    const p = x.bat_alloc(dst.length) >>> 0;
    if (!p)
      throw kernelError(-12, "alloc");
    try {
      sync();
      const rc = x.bat_read_file(pathA, put(path, pathA), flags, p, dst.length, statP);
      if (rc >= 0) {
        sync();
        dst.set(u8.subarray(p, p + rc));
        return rc;
      }
      if (rc === -ERANGE)
        return -f64[(statP >>> 3) + 1] - 1;
      throw kernelError(rc, "open", path);
    } finally {
      x.bat_free(p, dst.length);
    }
  }
  function readFile(path) {
    const r = readFileRaw(path, false);
    if (typeof r === "number")
      throw kernelError(r, "open", path);
    return r.data;
  }
  function tryReadFile(path) {
    const r = readFileRaw(path, false);
    if (typeof r !== "number")
      return r.data;
    if (r === -ENOENT || r === -ENOTDIR)
      return;
    throw kernelError(r, "open", path);
  }
  function readModule(path) {
    const r = readFileRaw(path, true);
    if (typeof r !== "number")
      return r;
    if (r === -ENOENT || r === -ENOTDIR)
      return;
    throw kernelError(r, "open", path);
  }
  function readText(path) {
    return decoder2.decode(readFile(path));
  }
  function writeFile(path, data, opts = {}) {
    const bytes = typeof data === "string" ? encoder.encode(data) : data;
    const flags = (opts.append ? 1 : 0) | (opts.excl ? 2 : 0);
    withBuf(bytes.length, (ptr) => {
      u8.set(bytes, ptr);
      check(x.bat_write_file(pathA, put(path, pathA), ptr, bytes.length, opts.mode ?? 420, flags), "open", path);
    });
  }
  function mkdir(path, opts = {}) {
    sync();
    check(x.bat_mkdir(pathA, put(path, pathA), opts.mode ?? 493, opts.recursive ? 1 : 0), "mkdir", path);
  }
  function rmdir(path) {
    sync();
    check(x.bat_rmdir(pathA, put(path, pathA)), "rmdir", path);
  }
  function unlink(path) {
    sync();
    check(x.bat_unlink(pathA, put(path, pathA)), "unlink", path);
  }
  function rename(from, to) {
    sync();
    check(x.bat_rename(pathA, put(from, pathA), pathB, put(to, pathB)), "rename", from);
  }
  function symlink(target, path) {
    sync();
    check(x.bat_symlink(pathB, put(target, pathB), pathA, put(path, pathA)), "symlink", path);
  }
  function link(existing, path) {
    sync();
    check(x.bat_link(pathA, put(existing, pathA), pathB, put(path, pathB)), "link", path);
  }
  function readlink(path) {
    sync();
    const n = check(x.bat_readlink(pathA, put(path, pathA), dataP, DATA_CAP), "readlink", path);
    return text(dataP, n);
  }
  function realpath(path) {
    sync();
    const n = check(x.bat_realpath(pathA, put(path, pathA), dataP, DATA_CAP), "realpath", path);
    return text(dataP, n);
  }
  function chmod(path, mode, nofollow = false) {
    sync();
    check(x.bat_chmod(pathA, put(path, pathA), mode, nofollow ? 1 : 0), "chmod", path);
  }
  function utimes(path, mtimeMs, nofollow = false) {
    sync();
    check(x.bat_utimes(pathA, put(path, pathA), mtimeMs, nofollow ? 1 : 0), "utime", path);
  }
  function truncate(path, size = 0) {
    sync();
    check(x.bat_truncate(pathA, put(path, pathA), size), "truncate", path);
  }
  function readdir(path) {
    sync();
    const n = put(path, pathA);
    const parse = (ptr, len) => {
      const out = [];
      let i = ptr;
      const end = ptr + len;
      while (i < end) {
        const l = u8[i + 1] | u8[i + 2] << 8;
        out.push({ kind: u8[i], name: text(i + 3, l) });
        i += 3 + l;
      }
      return out;
    };
    let rc = x.bat_readdir(pathA, n, dataP, DATA_CAP);
    if (rc >= 0)
      return parse(dataP, rc);
    if (rc !== -ERANGE)
      throw kernelError(rc, "scandir", path);
    const need = u32[dataP >>> 2] + 4096;
    return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
      rc = check(x.bat_readdir(pathA, put(path, pathA), ptr, cap), "scandir", path);
      return parse(ptr, rc);
    });
  }
  function open(path, flags = O_RDONLY, mode = 420) {
    sync();
    return check(x.bat_open(pathA, put(path, pathA), flags, mode), "open", path);
  }
  function close(fd) {
    check(x.bat_close(fd), "close");
  }
  function read(fd, dst, pos) {
    sync();
    return withBuf(dst.length, (ptr) => {
      const rc = pos === undefined ? x.bat_read(fd, ptr, dst.length) : x.bat_pread(fd, ptr, dst.length, pos);
      if (rc < 0)
        throw kernelError(rc, "read");
      sync();
      dst.set(u8.subarray(ptr, ptr + rc));
      return rc;
    });
  }
  function readRaw(fd, dst) {
    sync();
    return withBuf(dst.length, (ptr) => {
      const rc = x.bat_read(fd, ptr, dst.length);
      if (rc > 0) {
        sync();
        dst.set(u8.subarray(ptr, ptr + rc));
      }
      return rc;
    });
  }
  function write(fd, src, pos) {
    sync();
    return withBuf(src.length, (ptr) => {
      u8.set(src, ptr);
      return check(pos === undefined ? x.bat_write(fd, ptr, src.length) : x.bat_pwrite(fd, ptr, src.length, pos), "write");
    });
  }
  function writeRaw(fd, src) {
    sync();
    return withBuf(src.length, (ptr) => {
      u8.set(src, ptr);
      return x.bat_write(fd, ptr, src.length);
    });
  }
  function seek(fd, offset, whence = 0) {
    const r = x.bat_seek(fd, offset, whence);
    if (r < 0)
      throw kernelError(r, "lseek");
    return r;
  }
  function fstat(fd) {
    sync();
    check(x.bat_fstat(fd, statP), "fstat");
    return readStat();
  }
  function ftruncate(fd, size = 0) {
    check(x.bat_ftruncate(fd, size), "ftruncate");
  }
  function fsetmeta(fd, mode, mtimeMs) {
    check(x.bat_fsetmeta(fd, mode ?? -1, mtimeMs ?? -1), "futimes");
  }
  function setNonblock(fd, on) {
    check(x.bat_set_nonblock(fd, on ? 1 : 0), "fcntl");
  }
  function dup(fd) {
    return check(x.bat_dup(fd), "dup");
  }
  function fdPath(fd) {
    sync();
    return text(dataP, check(x.bat_fd_path(fd, dataP, DATA_CAP), "fcntl"));
  }
  function pipe() {
    sync();
    check(x.bat_pipe(outP), "pipe");
    return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
  }
  function listen(port) {
    return check(x.bat_listen(port), "listen");
  }
  function connect(port) {
    return check(x.bat_connect(port), "connect");
  }
  function accept(fd) {
    const rc = x.bat_accept(fd);
    if (rc === -EAGAIN)
      return;
    return check(rc, "accept");
  }
  function shutdown(fd) {
    check(x.bat_shutdown(fd), "shutdown");
  }
  function sockPorts(fd) {
    sync();
    check(x.bat_sock_ports(fd, outP), "getsockname");
    return { local: u32[outP >>> 2], peer: u32[(outP >>> 2) + 1] };
  }
  function socketpair() {
    sync();
    check(x.bat_socketpair(outP), "socketpair");
    return [i32[outP >>> 2], i32[(outP >>> 2) + 1]];
  }
  function ttyOpen(cols, rows) {
    sync();
    check(x.bat_tty_open(cols, rows, outP), "openpty");
    return { master: i32[outP >>> 2], slave: i32[(outP >>> 2) + 1] };
  }
  function isatty(fd) {
    return x.bat_isatty(fd) === 1;
  }
  function ttyGetattr(fd) {
    sync();
    check(x.bat_tty_getattr(fd, dataP), "tcgetattr");
    return u8.slice(dataP, dataP + 44);
  }
  function ttySetattr(fd, termios, action = 0) {
    sync();
    u8.set(termios.subarray(0, 44), dataP);
    check(x.bat_tty_setattr(fd, action, dataP), "tcsetattr");
  }
  function ttyWinsize(fd) {
    sync();
    check(x.bat_tty_winsize(fd, dataP), "ioctl");
    const dv = inst.dv();
    return { rows: dv.getUint16(dataP, true), cols: dv.getUint16(dataP + 2, true), xpixel: dv.getUint16(dataP + 4, true), ypixel: dv.getUint16(dataP + 6, true) };
  }
  function ttyResize(fd, cols, rows, xpixel = 0, ypixel = 0) {
    check(x.bat_tty_resize(fd, cols, rows, xpixel, ypixel), "ioctl");
  }
  function subscribe(fd, mask) {
    check(x.bat_fd_subscribe(fd, mask), "poll");
  }
  function pollFd(fd) {
    return check(x.bat_fd_poll(fd), "poll");
  }
  function poll(fds, timeoutMs) {
    sync();
    const base = dataP >>> 2;
    fds.forEach((f, i) => {
      i32[base + i * 3] = f.fd;
      u32[base + i * 3 + 1] = f.events;
      u32[base + i * 3 + 2] = 0;
    });
    check(x.bat_poll(dataP, fds.length, timeoutMs), "poll");
    sync();
    return fds.map((_, i) => u32[base + i * 3 + 2]);
  }
  function takeEvents() {
    sync();
    const n = x.bat_events_take(dataP, 256);
    const out = [];
    const base = dataP >>> 2;
    for (let i = 0;i < n; i++)
      out.push([u32[base + i * 2], u32[base + i * 2 + 1]]);
    return out;
  }
  function runEvents(on) {
    let stopped = false;
    const word = x.bat_event_word() >>> 2;
    const loop = async () => {
      while (!stopped) {
        sync();
        const seen = Atomics.load(i32, word);
        const events = takeEvents();
        for (const [token, mask] of events) {
          try {
            on(token, mask);
          } catch (e) {
            inst.host.log(3, `event handler: ${e?.stack ?? e}`);
          }
        }
        if (events.length === 0) {
          const r = Atomics.waitAsync(i32, word, seen);
          if (r.async)
            await r.value;
        }
      }
    };
    loop();
    return () => {
      stopped = true;
      Atomics.notify(i32, word);
    };
  }
  function watchAdd(path, recursive) {
    sync();
    return check(x.bat_watch_add(pathA, put(path, pathA), recursive ? 1 : 0), "watch", path);
  }
  function watchRemove(id) {
    x.bat_watch_remove(id);
  }
  function watchRead() {
    sync();
    const out = [];
    for (;; ) {
      const n = x.bat_watch_read(dataP, DATA_CAP);
      if (n <= 0)
        break;
      const dv = inst.dv();
      let i = dataP;
      const end = dataP + n;
      while (i < end) {
        const len = dv.getUint16(i + 8, true);
        out.push({ id: dv.getUint32(i, true), kind: dv.getUint32(i + 4, true), path: text(i + 10, len) });
        i += 10 + len;
      }
    }
    return out;
  }
  function getpid() {
    return check(x.bat_getpid(), "getpid");
  }
  function getppid() {
    return check(x.bat_getppid(), "getppid");
  }
  function chdir(path) {
    sync();
    check(x.bat_chdir(pathA, put(path, pathA)), "chdir", path);
  }
  function getcwd() {
    sync();
    return text(dataP, check(x.bat_getcwd(dataP, DATA_CAP), "getcwd"));
  }
  function spawn(req) {
    const env = Object.entries(req.env ?? {}).map(([k, v]) => `${k}=${v}`);
    const strings = [req.exec, req.cwd ?? "", ...req.argv, ...env].map((s) => encoder.encode(s));
    const size = 4 + 24 + 8 + strings.reduce((n, s) => n + 4 + s.length, 0);
    return withBuf(size + 16, (ptr) => {
      const dv = inst.dv();
      let o = ptr;
      const w32 = (v) => {
        dv.setUint32(o, v, true);
        o += 4;
      };
      w32(0);
      for (let i = 0;i < 3; i++) {
        const s = req.stdio?.[i] ?? "inherit";
        if (typeof s === "object") {
          w32(STDIO_FD);
          w32(s.fd);
        } else {
          w32(s === "pipe" ? STDIO_PIPE : s === "null" ? STDIO_NULL : STDIO_INHERIT);
          w32(0);
        }
      }
      w32(req.argv.length);
      w32(env.length);
      for (const s of strings) {
        w32(s.length);
        u8.set(s, o);
        o += s.length;
      }
      const fdsP = o + 3 & ~3;
      const pid = check(x.bat_spawn(ptr, size, fdsP), "spawn", req.exec);
      sync();
      const b = fdsP >>> 2;
      return { pid, stdio: [i32[b], i32[b + 1], i32[b + 2]] };
    });
  }
  function procInfo(pid) {
    sync();
    const parse = (ptr) => {
      const dv = inst.dv();
      let o = ptr;
      const r32 = () => {
        const v = dv.getUint32(o, true);
        o += 4;
        return v;
      };
      const str = () => {
        const n = r32();
        const s = text(o, n);
        o += n;
        return s;
      };
      const argc = r32();
      const envc = r32();
      const exec = str();
      const cwd = str();
      const argv = Array.from({ length: argc }, str);
      const env = {};
      for (let i = 0;i < envc; i++) {
        const kv = str();
        const eq = kv.indexOf("=");
        env[kv.slice(0, eq)] = kv.slice(eq + 1);
      }
      return { exec, cwd, argv, env };
    };
    const rc = x.bat_proc_info(pid, dataP, DATA_CAP);
    if (rc >= 0)
      return parse(dataP);
    if (rc !== -ERANGE)
      throw kernelError(rc, "procinfo");
    const need = u32[dataP >>> 2];
    return withBuf(Math.max(need, DATA_CAP + 1), (ptr, cap) => {
      check(x.bat_proc_info(pid, ptr, cap), "procinfo");
      return parse(ptr);
    });
  }
  function exit(code) {
    x.bat_proc_exit(code);
  }
  function waitpid(pid, nohang = false) {
    const rc = x.bat_waitpid(pid, nohang || !inst.canBlock ? 1 : 0);
    if (rc === -EAGAIN)
      return;
    return check(rc, "waitpid");
  }
  function kill(pid, signal) {
    check(x.bat_kill(pid, signal), "kill");
  }
  function sigTake() {
    return x.bat_sig_take() >>> 0;
  }
  function procList() {
    sync();
    const n = x.bat_proc_list(dataP, 1024);
    const b = dataP >>> 2;
    return Array.from({ length: n }, (_, i) => ({
      pid: u32[b + i * 4],
      ppid: u32[b + i * 4 + 1],
      state: u32[b + i * 4 + 2],
      status: i32[b + i * 4 + 3]
    }));
  }
  function imageNames() {
    sync();
    const n = x.bat_image_count();
    return Array.from({ length: n }, (_, id) => {
      const rc = x.bat_image_name(id, dataP, DATA_CAP);
      return rc >= 0 ? text(dataP, rc) : undefined;
    });
  }
  function imageStats(id) {
    sync();
    check(x.bat_image_stats(id, outP), "imagestats");
    const d = outP >>> 3;
    return { entries: f64[d], fileLen: f64[d + 1], cachedBytes: f64[d + 2], hostReads: f64[d + 3] };
  }
  function imageCacheStats() {
    sync();
    x.bat_image_cache_stats(outP);
    const d = outP >>> 3;
    return { limit: f64[d], bytes: f64[d + 1], peakBytes: f64[d + 2], loads: f64[d + 3], evictions: f64[d + 4] };
  }
  function memoryStats() {
    sync();
    x.bat_mem_stats(outP);
    const d = outP >>> 3;
    return { size: f64[d], maximum: f64[d + 1], heapStart: f64[d + 2], heapEnd: f64[d + 3], inUse: f64[d + 4], peakInUse: f64[d + 5], refused: f64[d + 6], grows: f64[d + 7] };
  }
  function imageSection(id, section) {
    sync();
    if (x.bat_image_section(id, section, outP) < 0)
      return;
    const ptr = u32[outP >>> 2];
    return u8.slice(ptr, ptr + u32[(outP >>> 2) + 1]);
  }
  async function flush() {
    const target = x.bat_flush_begin();
    if (target < 0)
      return;
    const word = x.BAT_PERSIST_WORD.value >>> 2;
    for (;; ) {
      sync();
      const seen = Atomics.load(i32, word);
      if (x.bat_persist_durable() >= target)
        return;
      await waitWord(i32, word, seen, 1000);
    }
  }
  function flushSync(timeoutMs = -1) {
    const target = x.bat_flush_begin();
    if (target < 0)
      return;
    check(x.bat_flush_wait(target, timeoutMs), "fsync");
  }
  const overlayGenIdx = x.BAT_OVERLAY_GEN.value >>> 2;
  function overlayGeneration() {
    return Atomics.load(i32, overlayGenIdx);
  }
  async function retrying(fn) {
    const word = x.BAT_FAULT_WORD.value >>> 2;
    for (;; ) {
      sync();
      const seen = Atomics.load(i32, word);
      try {
        return fn();
      } catch (e) {
        if (e?.errno !== EAGAIN)
          throw e;
      }
      await waitWord(i32, word, seen, 100);
    }
  }
  function release() {
    inst.release();
    x = self.x = inst.x;
    u8 = inst.u8();
    i32 = inst.i32();
    f64 = new Float64Array(u8.buffer);
    u32 = new Uint32Array(u8.buffer);
  }
  const self = {
    inst,
    x,
    release,
    stat,
    tryStat,
    statRaw,
    st,
    kindOf,
    readFile,
    readFileInto,
    tryReadFile,
    readModule,
    readText,
    writeFile,
    mkdir,
    rmdir,
    unlink,
    rename,
    symlink,
    link,
    readlink,
    realpath,
    chmod,
    utimes,
    truncate,
    readdir,
    open,
    close,
    read,
    readRaw,
    write,
    writeRaw,
    seek,
    fstat,
    ftruncate,
    fsetmeta,
    setNonblock,
    dup,
    fdPath,
    pipe,
    listen,
    connect,
    accept,
    shutdown,
    sockPorts,
    socketpair,
    ttyOpen,
    isatty,
    ttyGetattr,
    ttySetattr,
    ttyWinsize,
    ttyResize,
    subscribe,
    pollFd,
    poll,
    takeEvents,
    runEvents,
    watchAdd,
    watchRemove,
    watchRead,
    getpid,
    getppid,
    chdir,
    getcwd,
    spawn,
    procInfo,
    exit,
    waitpid,
    kill,
    sigTake,
    procList,
    imageNames,
    imageStats,
    imageSection,
    imageCacheStats,
    memoryStats,
    flush,
    flushSync,
    overlayGeneration,
    retrying
  };
  return self;
}

// runtime/src/kernel/boot.ts
async function bootKernel(opts) {
  if (!crossOriginIsolated)
    throw new Error("kernel: the page is not cross-origin isolated (COOP/COEP headers missing)");
  const t0 = performance.now();
  const module = await (opts.module ?? WebAssembly.compileStreaming(fetch(opts.wasmUrl)));
  const t1 = performance.now();
  let memory = createKernelMemory(opts.kernelMemory);
  const inst = await attachKernel({ module, memory, canBlock: false, first: true });
  const kernel = createKernel(inst);
  if (opts.imageCacheBytes !== undefined)
    inst.x.bat_image_cache_limit(opts.imageCacheBytes);
  const t2 = performance.now();
  const worker = new Worker(opts.kerneldUrl, { type: "module", name: "kerneld" });
  let nextId = 1;
  const pending2 = new Map;
  worker.onmessage = (e) => {
    const { id, ok, value, error, code } = e.data;
    const p = pending2.get(id);
    if (!p)
      return;
    pending2.delete(id);
    if (ok)
      p.resolve(value);
    else
      p.reject(Object.assign(new Error(error), { code }));
  };
  worker.onerror = (e) => {
    for (const p of pending2.values())
      p.reject(new Error(`kerneld crashed: ${e.message}`));
    pending2.clear();
  };
  const kerneld = (op, args) => new Promise((resolve, reject) => {
    const id = nextId++;
    pending2.set(id, { resolve, reject });
    worker.postMessage({ id, op, args });
  });
  const init = await kerneld("init", {
    module,
    memory,
    namespace: opts.namespace ?? "default",
    persist: opts.persist ?? false,
    noPersist: opts.noPersist ?? [],
    processWorkerUrl: new URL(opts.processWorkerUrl, location.href).href,
    processWorkerType: opts.processWorkerType ?? "module",
    runnerUrl: opts.runnerUrl ? new URL(opts.runnerUrl, location.href).href : "",
    warmSpare: opts.warmSpare ?? true,
    spares: opts.spares ?? 1,
    spareHints: opts.spareHints ?? [],
    images: opts.images ?? [],
    trace: opts.trace ?? false
  });
  const t3 = performance.now();
  const onPageHide = () => worker.terminate();
  addEventListener("pagehide", onPageHide);
  const booted = {
    kernel,
    module,
    memory,
    kerneld,
    storeImage: (name, url) => kerneld("storeImage", { name, url: new URL(url, location.href).href }),
    mountImage: (name, path, arriving, snapshot) => kerneld("mount", { name, path, arriving, snapshot }),
    imageArrived: (id) => kerneld("imageArrived", { id }),
    restored: init.restored,
    timings: { compileMs: t1 - t0, attachMs: t2 - t1, kerneldMs: t3 - t2 },
    close() {
      worker.terminate();
      removeEventListener("pagehide", onPageHide);
      for (const p of pending2.values())
        p.reject(new Error("The runtime is closed"));
      pending2.clear();
      kernel.release();
      memory = booted.memory = undefined;
    }
  };
  return booted;
}

// runtime/src/net/codec.ts
var EV_HEAD = 1;
var EV_BODY = 2;
var EV_END = 3;
var EV_EOF = 4;
var EV_WS_FRAME = 6;
var EV_WS_DATA = 7;
var EV_WS_END = 8;
var F_KEEPALIVE = 1;
var F_UPGRADE = 4;
var WS_FIN = 256;
var WS_MASK = 512;
var EAGAIN2 = 11;
var EPIPE = 32;
var EV_WORDS = 2048;
var latin1 = new TextDecoder("latin1");
function getCodec(kernel) {
  const k = kernel;
  return k.__codec ??= createCodec(kernel);
}
function createCodec(kernel) {
  const inst = kernel.inst;
  const evP = kernel.x.bat_alloc(EV_WORDS * 4 + 64) >>> 0;
  if (!evP)
    throw new Error("kernel: out of memory");
  const outP = evP + EV_WORDS * 4;
  const ev = new Uint32Array(EV_WORDS);
  const take = (n) => {
    const u32 = new Uint32Array(inst.u8().buffer, evP, n);
    ev.set(u32);
  };
  const copy = (ptr, len, alloc) => {
    const out = alloc ? alloc(len) : new Uint8Array(len);
    out.set(inst.u8().subarray(ptr, ptr + len));
    return out;
  };
  function httpParser(kind, alloc) {
    let h = kernel.x.bat_http_parser_new(kind === "response" ? 1 : 0) >>> 0;
    let busy = false;
    return {
      recv(fd, sink, more) {
        if (!h || busy)
          return false;
        busy = true;
        try {
          for (;; ) {
            const n = kernel.x.bat_http_recv(h, fd, evP, EV_WORDS);
            if (n <= 0) {
              if (n < 0)
                sink.error(-n);
              return false;
            }
            take(n);
            const chunks = [];
            for (let i = 0;i < n; ) {
              const kindWord = ev[i];
              if (kindWord === EV_BODY) {
                chunks.push(copy(ev[i + 1], ev[i + 2], alloc));
                i += 3;
              } else if (kindWord === EV_HEAD) {
                chunks.push(copy(ev[i + 4], ev[i + 5]));
                i += ev[i + 1];
              } else
                i += 2;
            }
            let c = 0;
            for (let i = 0;i < n; ) {
              switch (ev[i]) {
                case EV_HEAD: {
                  const text = latin1.decode(chunks[c++]);
                  const count = ev[i + 12];
                  const raw = new Array(count * 2);
                  for (let j = 0, w = i + 13;j < count; j++, w += 4) {
                    raw[j * 2] = text.substring(ev[w], ev[w] + ev[w + 1]);
                    raw[j * 2 + 1] = text.substring(ev[w + 2], ev[w + 2] + ev[w + 3]);
                  }
                  const status = ev[i + 3];
                  const a = text.substring(ev[i + 6], ev[i + 6] + ev[i + 7]);
                  const head = {
                    flags: ev[i + 2],
                    status,
                    method: kind === "request" ? a : "",
                    target: kind === "request" ? text.substring(ev[i + 8], ev[i + 8] + ev[i + 9]) : "",
                    reason: kind === "response" ? a : "",
                    raw,
                    contentLength: ev[i + 10] + ev[i + 11] * 4294967296
                  };
                  i += ev[i + 1];
                  sink.head(head);
                  break;
                }
                case EV_BODY:
                  i += 3;
                  sink.body(chunks[c++]);
                  break;
                case EV_END:
                  i += 2;
                  sink.end();
                  break;
                case EV_EOF:
                  sink.eof(ev[i + 1] === 1);
                  i += 2;
                  break;
                default:
                  sink.error(ev[i + 1]);
                  i += 2;
              }
            }
            if (!h)
              return false;
            if (more && !more())
              return true;
          }
        } finally {
          busy = false;
        }
      },
      expectNoBody() {
        if (h)
          kernel.x.bat_http_expect_no_body(h);
      },
      resume(fd, raw) {
        if (h)
          kernel.x.bat_http_resume(h, fd, raw ? 1 : 0);
      },
      free() {
        if (h)
          kernel.x.bat_http_parser_free(h);
        h = 0;
      }
    };
  }
  function wsParser() {
    let h = kernel.x.bat_ws_new() >>> 0;
    let busy = false;
    return {
      recv(fd, sink, more) {
        if (!h || busy)
          return false;
        busy = true;
        try {
          for (;; ) {
            const n = kernel.x.bat_ws_recv(h, fd, evP, EV_WORDS);
            if (n <= 0) {
              if (n < 0)
                sink.error(-n);
              return false;
            }
            take(n);
            const chunks = [];
            for (let i = 0;i < n; ) {
              const w = ev[i];
              if (w === EV_WS_DATA) {
                chunks.push(copy(ev[i + 1], ev[i + 2]));
                i += 3;
              } else
                i += w === EV_WS_FRAME ? 4 : w === EV_WS_END ? 1 : 2;
            }
            let c = 0;
            for (let i = 0;i < n; ) {
              switch (ev[i]) {
                case EV_WS_FRAME:
                  sink.frame(ev[i + 1] & 15, (ev[i + 1] & WS_FIN) !== 0, ev[i + 2] + ev[i + 3] * 4294967296);
                  i += 4;
                  break;
                case EV_WS_DATA:
                  i += 3;
                  sink.data(chunks[c++]);
                  break;
                case EV_WS_END:
                  i += 1;
                  sink.frameEnd();
                  break;
                case EV_EOF:
                  sink.eof(ev[i + 1] === 1);
                  i += 2;
                  break;
                default:
                  sink.error(ev[i + 1]);
                  i += 2;
              }
            }
            if (!h)
              return false;
            if (more && !more())
              return true;
          }
        } finally {
          busy = false;
        }
      },
      free() {
        if (h)
          kernel.x.bat_ws_free(h);
        h = 0;
      }
    };
  }
  function send(fd, bytes, from = 0, chunked = false) {
    const flags = chunked ? 1 : 0;
    let done = from;
    const end = bytes.length;
    while (done < end) {
      const cap = kernel.x.bat_http_reserve(fd, flags, outP);
      if (cap <= 0) {
        if (cap === -EAGAIN2 || cap === 0)
          break;
        return cap;
      }
      const u8 = inst.u8();
      const u32 = new Uint32Array(u8.buffer, outP, 5);
      const n = Math.min(cap, end - done);
      const l1 = Math.min(n, u32[2]);
      u8.set(bytes.subarray(done, done + l1), u32[1]);
      if (n > l1)
        u8.set(bytes.subarray(done + l1, done + n), u32[3]);
      const rc = kernel.x.bat_http_commit(fd, flags, n);
      if (rc < 0)
        return rc;
      done += n;
    }
    return done - from;
  }
  function sendText(fd, text, from = 0) {
    let done = from;
    const end = text.length;
    while (done < end) {
      const cap = kernel.x.bat_http_reserve(fd, 0, outP);
      if (cap <= 0) {
        if (cap === -EAGAIN2 || cap === 0)
          break;
        return cap;
      }
      const u8 = inst.u8();
      const u32 = new Uint32Array(u8.buffer, outP, 5);
      const n = Math.min(cap, end - done);
      const l1 = Math.min(n, u32[2]);
      let p = u32[1];
      for (let i = 0;i < l1; i++)
        u8[p++] = text.charCodeAt(done + i);
      p = u32[3];
      for (let i = l1;i < n; i++)
        u8[p++] = text.charCodeAt(done + i);
      const rc = kernel.x.bat_http_commit(fd, 0, n);
      if (rc < 0)
        return rc;
      done += n;
    }
    return done - from;
  }
  function wsSend(fd, opcode, payload, from, first, mask) {
    const left = payload.length - from;
    const flags = (first ? opcode : 0) | WS_FIN | (mask ? WS_MASK : 0);
    const n = kernel.x.bat_ws_reserve(fd, flags, left, outP);
    if (n < 0)
      return n;
    const u8 = inst.u8();
    const u32 = new Uint32Array(u8.buffer, outP, 6);
    const l1 = Math.min(n, u32[3]);
    if (l1)
      u8.set(payload.subarray(from, from + l1), u32[2]);
    if (n > l1)
      u8.set(payload.subarray(from + l1, from + n), u32[4]);
    const rc = kernel.x.bat_ws_commit(fd, u32[0] + n);
    return rc < 0 ? rc : n;
  }
  function wsAcceptKey(key) {
    const u8 = inst.u8();
    for (let i = 0;i < key.length; i++)
      u8[evP + i] = key.charCodeAt(i);
    kernel.x.bat_ws_accept_key(evP, key.length, evP + 256);
    let out = "";
    for (let i = 0;i < 28; i++)
      out += String.fromCharCode(u8[evP + 256 + i]);
    return out;
  }
  const READ_CAP = 64 * 1024;
  let readP = 0;
  function read(fd, alloc) {
    if (!readP)
      readP = kernel.x.bat_alloc(READ_CAP) >>> 0;
    const n = kernel.x.bat_read(fd, readP, READ_CAP);
    if (n <= 0)
      return n;
    return copy(readP, n, alloc);
  }
  const portListener = (port) => kernel.x.bat_port_listener(port) >>> 0;
  async function waitForListener(port, signal) {
    const word = kernel.x.BAT_PORTS_WORD.value >>> 2;
    for (;; ) {
      signal?.throwIfAborted();
      const i32 = inst.i32();
      const seen = Atomics.load(i32, word);
      const id = portListener(port);
      if (id)
        return id;
      const woke = waitWord(i32, word, seen, 1000);
      if (signal) {
        let onAbort;
        const aborted = new Promise((resolve) => {
          onAbort = resolve;
          signal.addEventListener("abort", onAbort, { once: true });
        });
        await Promise.race([woke, aborted]);
        signal.removeEventListener("abort", onAbort);
      } else
        await woke;
    }
  }
  return { httpParser, wsParser, send, sendText, read, wsSend, wsAcceptKey, portListener, waitForListener };
}

// runtime/src/net/client.ts
var POLLIN = 1;
var POLLOUT = 4;
var POLLERR = 8;
var POLLHUP = 16;
function netError(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}
var MAX_PER_PORT = 48;
var IDLE_MAX = 8;
var HIGH_WATER = 1 << 20;
var encoder2 = new TextEncoder;
function createOutbox(codec, fd, wantWrite) {
  const queue = [];
  let failed;
  let queued = 0;
  let blocked = false;
  const drains = [];
  function flush() {
    while (queue.length) {
      const item = queue[0];
      const len = item.data.length;
      const n = typeof item.data === "string" ? codec.sendText(fd, item.data, item.at) : codec.send(fd, item.data, item.at, item.chunked);
      if (n < 0) {
        fail(netError(n === -EPIPE ? "EPIPE" : "ECONNRESET", "socket closed by the peer"));
        return;
      }
      item.at += n;
      queued -= n;
      if (item.at < len) {
        if (!blocked) {
          blocked = true;
          wantWrite(true);
        }
        return;
      }
      queue.shift();
      item.done?.();
    }
    if (blocked) {
      blocked = false;
      wantWrite(false);
    }
    while (drains.length)
      drains.shift()();
  }
  function fail(err) {
    if (failed)
      return;
    failed = err;
    for (const item of queue.splice(0))
      item.done?.(err);
    queued = 0;
    while (drains.length)
      drains.shift()();
  }
  return {
    write(data, chunked = false, done) {
      if (failed) {
        done?.(failed);
        return false;
      }
      if (data.length === 0) {
        if (queue.length)
          queue.push({ data, at: 0, chunked, done });
        else
          done?.();
        return queue.length === 0;
      }
      queue.push({ data, at: 0, chunked, done });
      queued += data.length;
      if (queue.length === 1)
        flush();
      return queue.length === 0;
    },
    flush,
    fail,
    get failed() {
      return failed;
    },
    get queued() {
      return queued;
    },
    drained() {
      if (queue.length === 0 || failed)
        return Promise.resolve();
      return new Promise((resolve) => drains.push(resolve));
    }
  };
}
function createHttpClient(ctx) {
  const { kernel, io } = ctx;
  const codec = getCodec(kernel);
  const pools = new Map;
  let closed = false;
  const live = new Set;
  const poolOf = (port) => {
    let p = pools.get(port);
    if (!p)
      pools.set(port, p = { idle: [], active: 0, waiters: [] });
    return p;
  };
  function destroy(conn) {
    if (conn.dead)
      return;
    conn.dead = true;
    live.delete(conn);
    io.off(conn.fd);
    conn.parser.free();
    try {
      kernel.close(conn.fd);
    } catch {}
  }
  function connect(port) {
    const fd = kernel.x.bat_connect(port);
    if (fd < 0)
      throw netError(fd === -111 ? "ECONNREFUSED" : `E${-fd}`, `connect ECONNREFUSED 127.0.0.1:${port}`);
    kernel.setNonblock(fd, true);
    const conn = { fd, parser: codec.httpParser("response"), port, reused: false, dead: false };
    live.add(conn);
    return conn;
  }
  async function acquire(port, signal) {
    const pool = poolOf(port);
    while (pool.active >= MAX_PER_PORT) {
      await new Promise((resolve, reject) => {
        const wake = () => {
          signal?.removeEventListener("abort", onAbort);
          resolve();
        };
        const onAbort = () => {
          const i = pool.waiters.indexOf(wake);
          if (i >= 0)
            pool.waiters.splice(i, 1);
          reject(signal.reason);
        };
        signal?.addEventListener("abort", onAbort, { once: true });
        pool.waiters.push(wake);
      });
      if (closed)
        throw netError("ECONNRESET", "runtime closed");
    }
    let conn;
    while (conn = pool.idle.pop()) {
      if (!conn.dead) {
        io.off(conn.fd);
        conn.reused = true;
        break;
      }
    }
    conn ??= connect(port);
    pool.active++;
    return conn;
  }
  function release(conn, reusable) {
    const pool = poolOf(conn.port);
    pool.active--;
    if (reusable && !conn.dead && !closed && pool.idle.length < IDLE_MAX) {
      pool.idle.push(conn);
      io.on(conn.fd, POLLIN | POLLHUP | POLLERR, () => {
        const i = pool.idle.indexOf(conn);
        if (i >= 0)
          pool.idle.splice(i, 1);
        destroy(conn);
      });
    } else
      destroy(conn);
    pool.waiters.shift()?.();
  }
  function exchange(conn, req) {
    return new Promise((resolve, reject) => {
      const { fd, parser } = conn;
      const method = req.method.toUpperCase();
      let settled = false;
      let finished = false;
      let controller;
      let keepAlive = false;
      let requestSent = false;
      let responseDone = false;
      let interim = false;
      let wantOut = false;
      let paused = false;
      const arm = () => io.on(fd, POLLIN | POLLHUP | POLLERR | (wantOut ? POLLOUT : 0), onReady);
      const outbox = createOutbox(codec, fd, (on) => {
        wantOut = on;
        if (!finished)
          arm();
      });
      const finish = (reusable) => {
        if (finished)
          return;
        finished = true;
        req.signal?.removeEventListener("abort", onAbort);
        release(conn, reusable);
      };
      const fail = (err) => {
        if (finished)
          return;
        outbox.fail(err instanceof Error ? err : new Error(String(err)));
        finish(false);
        if (!settled) {
          settled = true;
          reject(err);
        } else {
          try {
            controller?.error(err);
          } catch {}
        }
      };
      const onAbort = () => fail(req.signal.reason ?? new DOMException("The operation was aborted.", "AbortError"));
      const maybeDone = () => {
        if (responseDone && requestSent)
          finish(keepAlive);
      };
      const sink = {
        head(head2) {
          if (head2.status >= 100 && head2.status < 200 && !(head2.flags & F_UPGRADE)) {
            interim = true;
            return;
          }
          interim = false;
          keepAlive = (head2.flags & F_KEEPALIVE) !== 0 && !(head2.flags & F_UPGRADE);
          const headers = [];
          for (let i = 0;i < head2.raw.length; i += 2)
            headers.push([head2.raw[i], head2.raw[i + 1]]);
          const noBody = method === "HEAD" || head2.status === 204 || head2.status === 205 || head2.status === 304;
          const body2 = new ReadableStream({
            start(c) {
              controller = c;
            },
            pull() {
              if (paused) {
                paused = false;
                pump();
              }
            },
            cancel() {
              fail(netError("ECONNRESET", "response body cancelled"));
            }
          }, new ByteLengthQueuingStrategy({ highWaterMark: HIGH_WATER }));
          settled = true;
          resolve({ status: head2.status, statusText: head2.reason, headers, body: noBody ? null : body2 });
        },
        body(chunk) {
          if (finished)
            return;
          try {
            controller?.enqueue(chunk);
          } catch {}
        },
        end() {
          if (interim) {
            interim = false;
            return;
          }
          responseDone = true;
          try {
            controller?.close();
          } catch {}
          maybeDone();
          if (!finished && !requestSent)
            finish(false);
        },
        eof(clean) {
          if (finished)
            return;
          if (responseDone)
            return finish(false);
          if (!settled) {
            const e = netError("ECONNRESET", "socket hang up");
            e.beforeResponse = clean;
            return fail(e);
          }
          fail(new TypeError("terminated"));
        },
        error(errno) {
          fail(netError("HPE_INVALID", `invalid HTTP response from the guest (errno ${errno})`));
        }
      };
      const more = () => !finished && (!controller || (controller.desiredSize ?? 1) > 0);
      const pump = () => {
        if (finished)
          return;
        if (parser.recv(fd, sink, more))
          paused = true;
      };
      const onReady = (mask) => {
        if (finished)
          return;
        if (mask & POLLOUT)
          outbox.flush();
        if (mask & (POLLIN | POLLHUP) && !paused)
          pump();
        if (mask & POLLERR && !requestSent && !finished)
          outbox.flush();
      };
      if (req.signal?.aborted)
        return onAbort();
      req.signal?.addEventListener("abort", onAbort, { once: true });
      if (method === "HEAD")
        parser.expectNoBody();
      let head = `${method} ${req.path} HTTP/1.1\r
`;
      let hasHost = false;
      for (const [name, value] of req.headers) {
        const lower = name.toLowerCase();
        if (lower === "content-length" || lower === "transfer-encoding" || lower === "connection" || lower === "keep-alive")
          continue;
        if (lower === "host")
          hasHost = true;
        head += `${name}: ${value}\r
`;
      }
      if (!hasHost)
        head += `host: localhost:${conn.port}\r
`;
      const body = req.body;
      if (body instanceof Uint8Array) {
        head += `content-length: ${body.length}\r
\r
`;
        outbox.write(head);
        outbox.write(body, false, (err) => {
          if (err)
            return;
          requestSent = true;
          maybeDone();
        });
      } else if (body) {
        head += `transfer-encoding: chunked\r
\r
`;
        outbox.write(head);
        const reader = body.getReader();
        (async () => {
          try {
            for (;; ) {
              const { done, value } = await reader.read();
              if (finished)
                return void reader.cancel().catch(() => {});
              if (done)
                break;
              if (value?.length) {
                outbox.write(value, true);
                await outbox.drained();
                if (outbox.failed)
                  throw outbox.failed;
              }
            }
            outbox.write(`0\r
\r
`, false, (err) => {
              if (err)
                return;
              requestSent = true;
              maybeDone();
            });
          } catch (e) {
            fail(e);
          }
        })();
      } else {
        if (method !== "GET" && method !== "HEAD")
          head += `content-length: 0\r
`;
        head += `\r
`;
        outbox.write(head, false, (err) => {
          if (err)
            return;
          requestSent = true;
          maybeDone();
        });
      }
      if (!finished) {
        arm();
        pump();
      }
    });
  }
  async function request(port, req) {
    if (closed)
      throw netError("ECONNRESET", "runtime closed");
    req.signal?.throwIfAborted();
    for (;; ) {
      const conn = await acquire(port, req.signal);
      const reused = conn.reused;
      try {
        return await exchange(conn, req);
      } catch (e) {
        const stale = reused && e?.beforeResponse === true && !(req.body instanceof ReadableStream);
        if (!stale || req.signal?.aborted)
          throw e;
      }
    }
  }
  function close() {
    closed = true;
    for (const conn of [...live])
      destroy(conn);
    for (const pool of pools.values())
      for (const wake of pool.waiters.splice(0))
        wake();
  }
  return { request, close, codec };
}
function headerPairs(init) {
  if (!init)
    return [];
  const out = [];
  new Headers(init).forEach((value, name) => out.push([name, value]));
  return out;
}
async function wireBody(body) {
  if (body == null)
    return { body: null };
  if (typeof body === "string")
    return { body: encoder2.encode(body), type: "text/plain;charset=UTF-8" };
  if (body instanceof Uint8Array)
    return { body };
  if (body instanceof ArrayBuffer)
    return { body: new Uint8Array(body) };
  if (ArrayBuffer.isView(body))
    return { body: new Uint8Array(body.buffer, body.byteOffset, body.byteLength) };
  if (body instanceof ReadableStream)
    return { body };
  const r = new Response(body);
  return { body: new Uint8Array(await r.arrayBuffer()), type: r.headers.get("content-type") ?? undefined };
}
function toResponse(res) {
  const headers = new Headers;
  for (const [name, value] of res.headers) {
    try {
      headers.append(name, value);
    } catch {}
  }
  const status = res.status >= 200 && res.status <= 599 ? res.status : 502;
  const nullBody = status === 204 || status === 205 || status === 304;
  return new Response(nullBody ? null : res.body, { status, statusText: /^[\t\x20-\x7e\x80-\xff]*$/.test(res.statusText) ? res.statusText : "", headers });
}

// runtime/src/process/runtime.ts
var DEFAULT_CONFIG = {
  nodelibUrl: "bat-nodelib.js",
  wasm: {},
  programs: {},
  cacheDir: "/.bat/cache",
  execPath: "/usr/local/bin/node",
  version: "v24.11.0",
  prewarm: ["events", "path", "buffer", "util", "fs", "stream", "url", "module", "os"]
};

// runtime/src/process/config.ts
function processWorkerUrl(scriptUrl, config = {}) {
  return `${scriptUrl}#${encodeURIComponent(JSON.stringify(config))}`;
}

// runtime/src/host/endpoint.ts
function createEndpoints(ctx, previewUrl, closed) {
  const client = createHttpClient(ctx);
  const codec = getCodec(ctx.kernel);
  closed.addEventListener("abort", () => client.close(), { once: true });
  async function fetchPort(port, path, init = {}) {
    if (closed.aborted)
      throw new Error("The runtime is closed");
    const headers = headerPairs(init.headers);
    const { body, type } = await wireBody(init.body);
    if (type && !headers.some(([name]) => name.toLowerCase() === "content-type"))
      headers.push(["content-type", type]);
    try {
      const res = await client.request(port, {
        method: init.method ?? "GET",
        path: path.startsWith("/") ? path : `/${path}`,
        headers,
        body,
        signal: init.signal ? AbortSignal.any([init.signal, closed]) : closed
      });
      return toResponse(res);
    } catch (e) {
      if (e?.name === "AbortError" || e?.name === "TimeoutError" || !e?.code)
        throw e;
      throw new TypeError(`Failed to fetch guest port ${port}: ${e.message}`, { cause: e });
    }
  }
  function endpoint(port) {
    return {
      url: `${previewUrl}${port}/`,
      fetch: (path, init) => fetchPort(port, path, init),
      async ready(signal) {
        await codec.waitForListener(port, signal ? AbortSignal.any([signal, closed]) : closed);
      }
    };
  }
  return { endpoint, client };
}

// runtime/src/host/reactor.ts
function createReactor(kernel) {
  const fds = new Map;
  const children = new Map;
  const exited = new Map;
  const watches = new Map;
  const stop = kernel.runEvents((token, mask) => {
    if (token === TOKEN_WATCH) {
      for (const e of kernel.watchRead())
        watches.get(e.id)?.(e.kind, e.path);
    } else if (token === TOKEN_SIGNAL) {
      kernel.sigTake();
    } else if (token >= TOKEN_CHILD) {
      const pid = token - TOKEN_CHILD;
      const cb = children.get(pid);
      if (cb) {
        children.delete(pid);
        cb(mask);
      } else
        exited.set(pid, mask);
    } else
      fds.get(token)?.(mask);
  });
  return {
    on(fd, mask, cb) {
      fds.set(fd, cb);
      kernel.subscribe(fd, mask);
    },
    off(fd) {
      if (fds.delete(fd)) {
        try {
          kernel.subscribe(fd, 0);
        } catch {}
      }
    },
    onChild(pid, cb) {
      const status = exited.get(pid);
      if (status !== undefined) {
        exited.delete(pid);
        queueMicrotask(() => cb(status));
      } else
        children.set(pid, cb);
    },
    onWatch: (id, cb) => void watches.set(id, cb),
    offWatch: (id) => void watches.delete(id),
    stop
  };
}

// runtime/src/trace.ts
var TRACE_CHANNEL = "bat-trace";
var channel;
var source = "";
function traceEnable(src) {
  source = src;
  channel ??= new BroadcastChannel(TRACE_CHANNEL);
}
function trace(name, data, at) {
  if (channel)
    channel.postMessage({ src: source, name, t: performance.timeOrigin + (at ?? performance.now()), data });
}
function traceCollect(src) {
  traceEnable(src);
  const store = globalThis.__batTrace ??= [];
  const listener = new BroadcastChannel(TRACE_CHANNEL);
  listener.onmessage = (e) => {
    if (e.data?.name)
      store.push(e.data);
  };
  return () => listener.close();
}

// runtime/src/host/host.ts
var HOST_ALIAS = "host.internal";
var OUTPUT_KEEP = 1 << 20;
var encoder3 = new TextEncoder;
function busy(cause) {
  return Object.assign(new Error("This workspace is already open in another tab.", { cause }), { code: "STORAGE_BUSY" });
}
function rpc(worker) {
  let next = 1;
  const pending2 = new Map;
  worker.onmessage = (e) => {
    const m = e.data;
    const p = pending2.get(m.id);
    if (!p)
      return;
    if (m.progress)
      return void p.progress?.(m.progress);
    pending2.delete(m.id);
    if (m.ok)
      p.resolve(m.value);
    else
      p.reject(Object.assign(new Error(m.error), { code: m.code, name: m.name ?? "Error" }));
  };
  worker.onerror = (e) => {
    for (const p of pending2.values())
      p.reject(new Error(`runtime worker crashed: ${e.message}`));
    pending2.clear();
  };
  return {
    call(op, args, transfer = [], progress) {
      const id = next++;
      const promise = new Promise((resolve, reject) => pending2.set(id, { resolve, reject, progress }));
      promise.id = id;
      worker.postMessage({ id, op, args }, transfer);
      return promise;
    }
  };
}
var namespaceOf = (manifestUrl) => new URL(manifestUrl).pathname.replace(/\/[^/]*$/, "").replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "") || "default";
async function resetWorkspace(options) {
  const namespace = options.namespace ?? namespaceOf(options.manifestUrl);
  const attempt = () => navigator.locks.request(`bat-kernel:${namespace}`, { ifAvailable: true }, async (lock) => {
    if (!lock)
      return false;
    let dir = await navigator.storage.getDirectory();
    try {
      for (const part of ["bat", namespace])
        dir = await dir.getDirectoryHandle(part);
      await dir.removeEntry("overlay", { recursive: true });
    } catch (e) {
      if (e?.name !== "NotFoundError")
        throw e;
    }
    return true;
  });
  let done = await attempt();
  for (let i = 0;!done && i < 20; i++) {
    await new Promise((r) => setTimeout(r, 100));
    done = await attempt();
  }
  if (!done)
    throw busy();
}
var kernelModule;
var compileKernel = (url) => {
  if (kernelModule?.url !== url) {
    const module = WebAssembly.compileStreaming(fetch(url));
    kernelModule = { url, module };
    module.catch(() => {
      if (kernelModule?.module === module)
        kernelModule = undefined;
    });
  }
  return kernelModule.module;
};
function preloadRuntime() {
  compileKernel(new URL("kernel.wasm", import.meta.url).href).catch(() => {});
}
async function bootRuntime(options) {
  const t0 = performance.now();
  const manifest = options.manifest;
  if (!manifest?.image?.file)
    throw new Error("The prepared manifest has no runtime image");
  options.signal?.throwIfAborted();
  const asset = (name) => new URL(name, import.meta.url).href;
  const prepared = (name) => new URL(name, options.manifestUrl).href;
  const progress = (p) => {
    try {
      options.onProgress?.(p);
    } catch {}
  };
  const namespace = options.namespace ?? namespaceOf(options.manifestUrl);
  const image = manifest.image;
  const timings = {};
  let tracing = options.trace;
  try {
    tracing ??= localStorage.getItem("bat-trace") === "1";
  } catch {}
  if (tracing) {
    traceCollect("page");
    trace("boot.start", undefined, t0);
  }
  const timed = (name) => {
    try {
      performance.mark(`bat:boot.${name}`, { detail: { ...timings } });
    } catch {}
  };
  const netdWorker = new Worker(asset("bat-netd.js"), { type: "module", name: "bat-netd" });
  const netd = rpc(netdWorker);
  progress({ phase: "image" });
  const images = [image, ...manifest.layers ?? []];
  const kernelReady = {};
  const stores = images.map((img, index) => {
    let usable;
    const ready = new Promise((resolve) => usable = resolve);
    const state = { id: -1 };
    const done = netd.call("storeImage", {
      namespace,
      name: img.file,
      url: prepared(img.file),
      bytes: img.bytes,
      sha256: img.sha256,
      headBytes: img.headBytes,
      firstBytes: img.firstBytes,
      sums: img.sums && { url: prepared(img.sums.file), blockBytes: img.sums.blockBytes, sha256: img.sums.sha256 },
      nativeWasmUrl: asset("bat_node_native.wasm")
    }, [], (p) => {
      if (p.usable)
        usable(p.usable);
      if (p.loaded === undefined)
        return;
      if (state.id >= 0)
        kernelReady.kernel?.x.bat_image_progress(state.id);
      if (index === 0)
        progress({ phase: "image", loaded: p.loaded, total: p.total, cached: false });
    });
    done.catch(() => {});
    return { img, ready: Promise.race([ready, done.then((r) => ({ file: r.file, arriving: false }))]), done, state };
  });
  const resumeImages = () => void netd.call("resumeImages").catch(() => {});
  setTimeout(resumeImages, 20000);
  const cancelDownloads = () => {
    for (const s of stores)
      netd.call("cancel", { id: s.done.id });
  };
  const programs = {};
  for (const p of manifest.programs ?? [])
    programs[p.name] = prepared(p.file);
  const spareHints = Object.values(manifest.launch ?? {}).map((launch) => (launch?.programs ?? []).filter((name) => programs[name]));
  const stored = (key) => {
    try {
      const value = localStorage.getItem(key);
      return value === null || !Number.isFinite(Number(value)) ? undefined : Number(value);
    } catch {
      return;
    }
  };
  const kernelPages = stored("bat-kernel-memory-pages");
  const kernelMaximum = stored("bat-kernel-memory-maximum-pages");
  let booted;
  try {
    booted = await bootKernel({
      wasmUrl: asset("kernel.wasm"),
      module: compileKernel(asset("kernel.wasm")),
      kerneldUrl: asset("bat-kerneld.js"),
      processWorkerUrl: processWorkerUrl(asset("bat-process.js"), {
        nodelibUrl: "bat-nodelib.js",
        wasm: { modules: "bat_modules.wasm", native: "bat_node_native.wasm", sqlite: "sqlite3.wasm", sh: "bat_sh.wasm", tls: "bat_tls.wasm" },
        programs,
        prewarm: [...DEFAULT_CONFIG.prewarm, "bat:net-globals"],
        trace: tracing
      }),
      processWorkerType: "classic",
      namespace,
      persist: options.persist ?? true,
      noPersist: ["/.bat", "/tmp"],
      warmSpare: true,
      spares: Math.max(2, spareHints.length),
      spareHints,
      images: images.map((i) => i.file),
      trace: tracing,
      kernelMemory: options.kernelMemory ?? (kernelPages === undefined && kernelMaximum === undefined ? undefined : { pages: kernelPages, maximumPages: kernelMaximum }),
      imageCacheBytes: options.imageCacheBytes ?? stored("bat-image-cache-bytes")
    });
  } catch (e) {
    cancelDownloads();
    netdWorker.terminate();
    if (e?.code === "EBUSY")
      throw busy(e);
    throw new Error(`kernel boot failed: ${e.message}`, { cause: e });
  }
  timings.kernel = performance.now() - t0;
  timings.kernelMemoryBytes = booted.memory.buffer.byteLength;
  Object.assign(timings, { kernelCompile: booted.timings.compileMs, kernelAttach: booted.timings.attachMs, kerneldInit: booted.timings.kerneldMs, restore: booted.restored?.ms ?? 0, journalBytes: booted.restored?.journalBytes ?? 0, snapshotBytes: booted.restored?.snapshotBytes ?? 0 });
  trace("boot.kernel");
  timed("kernel");
  progress({ phase: "kernel" });
  const lifetime = new AbortController;
  let closing;
  const outside = new AbortController;
  const teardown = () => {
    lifetime.abort(new Error("The runtime is closed"));
    outside.abort();
    for (const name of ["__batKernel", "__batImageTrace", "__batMemory"])
      delete globalThis[name];
    booted.close();
    netdWorker.terminate();
  };
  let kernel;
  try {
    const aborted = new Promise((_, reject) => options.signal?.addEventListener("abort", () => reject(options.signal.reason), { once: true }));
    let imageTrace = false;
    try {
      imageTrace = localStorage.getItem("bat-image-trace") === "1";
    } catch {}
    if (imageTrace)
      booted.kernel.x.bat_image_trace(1);
    try {
      if (localStorage.getItem("bat-memory-stats") === "1")
        globalThis.__batMemory = () => ({ kernel: booted.kernel.memoryStats(), imageCache: booted.kernel.imageCacheStats() });
    } catch {}
    timings.mount = 0;
    for (const [index, store] of stores.entries()) {
      const usable = await Promise.race([store.ready, aborted]);
      if (index === 0) {
        timings.image = performance.now() - t0;
        timings.imageCached = !usable.arriving && (await Promise.race([store.done, aborted])).cached;
        timings.imageArriving = usable.arriving;
        trace("boot.image");
        timed("image");
        if (!usable.arriving)
          progress({ phase: "image", loaded: image.bytes, total: image.bytes, cached: timings.imageCached });
      }
      const mounted = await booted.mountImage(usable.file, store.img.mount ?? "/", usable.arriving, usable.snapshot).catch((e) => {
        throw new Error(`mounting ${store.img.file} failed: ${e.message}`, { cause: e });
      });
      timings.mount += mounted.ms;
      store.state.id = mounted.id;
      if (usable.arriving) {
        const settle = (state) => {
          if (!lifetime.signal.aborted)
            booted.kernel.x.bat_image_arriving(mounted.id, state);
        };
        const arrived = usable.snapshot ? store.done.then(() => booted.imageArrived(mounted.id)) : store.done;
        arrived.then(() => {
          settle(0);
          if (index === 0) {
            timings.imageComplete = performance.now() - t0;
            timings.imageArriving = false;
            timed("image-complete");
            progress({ phase: "image", loaded: image.bytes, total: image.bytes, cached: false });
          }
        }, (e) => {
          settle(2);
          if (!lifetime.signal.aborted)
            console.error(`The download of ${store.img.file} failed while it was in use:`, e);
        });
      }
    }
    kernel = booted.kernel;
    kernelReady.kernel = kernel;
    if (imageTrace) {
      globalThis.__batImageTrace = (id = 0) => {
        const cap = 1 << 17;
        const ptr = kernel.x.bat_alloc(cap * 8) >>> 0;
        const out = [];
        for (;; ) {
          const n = kernel.x.bat_image_trace_read(id, out.length, ptr, cap);
          const view = new Float64Array(booted.memory.buffer, ptr, n * 2);
          for (let i = 0;i < n; i++)
            out.push([view[i * 2], view[i * 2 + 1]]);
          if (n < cap / 2)
            break;
        }
        kernel.x.bat_free(ptr, cap * 8);
        return out;
      };
    }
    for (const dir of ["/tmp", "/workspace", "/bin", "/usr/bin", "/usr/local/bin", "/home/user", "/.bat"])
      kernel.mkdir(dir, { recursive: true });
    for (const path of ["/bin/sh", "/bin/bash", "/usr/bin/env"])
      if (kernel.kindOf(path) < 0)
        kernel.writeFile(path, `#!/bin/sh
# built into the runtime
`, { mode: 493 });
    progress({ phase: "mount" });
    await netd.call("attach", { module: booted.module, memory: booted.memory });
    Promise.all(stores.map((s) => s.done)).then(() => netd.call("collectImages", { namespace, keep: images.map((i) => i.file) })).then((removed) => {
      if (removed.length)
        trace("boot.images-collected", { removed });
    }).catch(() => {});
  } catch (e) {
    cancelDownloads();
    teardown();
    throw e;
  }
  if (tracing)
    globalThis.__batKernel = kernel;
  timings.mounted = performance.now() - t0;
  trace("boot.mounted");
  timed("mounted");
  const reactor = createReactor(kernel);
  const codec = getCodec(kernel);
  const worker = typeof options.serviceWorker === "object" ? options.serviceWorker : undefined;
  const scope = worker ? new URL(worker.scope, location.href).pathname.replace(/\/?$/, "/") : "/preview/";
  const previewUrl = location.origin + (scope.endsWith("/preview/") ? scope : `${scope}preview/`);
  const { endpoint } = createEndpoints({ kernel, io: reactor }, previewUrl, lifetime.signal);
  const live = () => {
    if (lifetime.signal.aborted)
      throw new Error("The runtime is closed");
  };
  const hostPaths = {};
  const guestPaths = {};
  let serviceWorker;
  const toWorker = (m, transfer = []) => serviceWorker?.postMessage(m, transfer);
  const sendPort = (target) => {
    const channel2 = new MessageChannel;
    let portedBodies = false;
    try {
      portedBodies = localStorage.getItem("bat-ported-bodies") === "1";
    } catch {}
    netd.call("port", { port: channel2.port1, portedBodies }, [channel2.port1]);
    target.postMessage({ t: "bat-port", port: channel2.port2, hostPaths, guestPaths }, [channel2.port2]);
  };
  const onWorkerMessage = (e) => {
    if (e.data?.t === "bat-need-port" && !lifetime.signal.aborted && e.source)
      sendPort(e.source);
  };
  if (options.serviceWorker !== false && "serviceWorker" in navigator) {
    try {
      const registration = await navigator.serviceWorker.register(worker ? new URL(worker.url, location.href).href : asset("sw.js"), { scope, updateViaCache: "none" });
      const activated = (worker2) => new Promise((resolve, reject) => {
        if (worker2.state === "activated")
          return resolve(worker2);
        worker2.addEventListener("statechange", () => {
          if (worker2.state === "activated")
            resolve(worker2);
          else if (worker2.state === "redundant")
            reject(new Error("The preview service worker failed to install"));
        });
      });
      serviceWorker = await activated(registration.installing ?? registration.waiting ?? registration.active);
      navigator.serviceWorker.addEventListener("message", onWorkerMessage, { signal: outside.signal });
      navigator.serviceWorker.startMessages();
      sendPort(serviceWorker);
      registration.addEventListener("updatefound", () => {
        const next = registration.installing;
        if (next) {
          activated(next).then((worker2) => {
            if (lifetime.signal.aborted)
              return;
            serviceWorker = worker2;
            sendPort(worker2);
          }, () => {});
        }
      }, { signal: outside.signal });
    } catch (e) {
      teardown();
      throw new Error(`The preview service worker could not be registered: ${e.message}`, { cause: e });
    }
    timings.serviceWorker = performance.now() - t0;
    trace("boot.service-worker");
    progress({ phase: "service-worker" });
  }
  const io = (fn) => {
    try {
      live();
    } catch (e) {
      return Promise.reject(e);
    }
    return kernel.retrying(fn);
  };
  const removeTree = (path) => {
    const st = kernel.tryStat(path, true);
    if (!st)
      return;
    if (st.kind === K_DIR) {
      for (const entry of kernel.readdir(path))
        removeTree(`${path === "/" ? "" : path}/${entry.name}`);
      kernel.rmdir(path);
    } else
      kernel.unlink(path);
  };
  const fs = {
    readFile: (path) => io(() => kernel.readFile(path)),
    writeFile: (path, data) => io(() => kernel.writeFile(path, data)),
    stat: (path) => io(() => {
      const st = kernel.stat(path);
      return { isFile: st.kind === K_FILE, isDirectory: st.kind === K_DIR, size: st.size, mtimeMs: st.mtimeMs };
    }),
    readdir: (path) => io(() => kernel.readdir(path).map((e) => e.name)),
    mkdir: (path) => io(() => kernel.mkdir(path, { recursive: true })),
    remove: (path) => io(() => removeTree(path)),
    rename: (from, to) => io(() => kernel.rename(from, to)),
    watch(path, listener) {
      live();
      const root = kernel.realpath(path);
      const id = kernel.watchAdd(root, true);
      let batch = new Set;
      let timer;
      reactor.onWatch(id, (_kind, rel) => {
        batch.add(rel ? `${root === "/" ? "" : root}/${rel}` : root);
        timer ??= setTimeout(() => {
          timer = undefined;
          const paths = [...batch];
          batch = new Set;
          try {
            listener({ paths });
          } catch (e) {
            console.error(e);
          }
        }, 20);
      });
      let active = true;
      const stop = () => {
        if (!active)
          return;
        active = false;
        if (timer)
          clearTimeout(timer);
        reactor.offWatch(id);
        kernel.watchRemove(id);
      };
      lifetime.signal.addEventListener("abort", stop, { once: true });
      return stop;
    }
  };
  const processes = new Map;
  function output(fd) {
    kernel.setNonblock(fd, true);
    let queue = [];
    let queued = 0;
    let ended = false;
    let wake;
    const end = () => {
      if (ended)
        return;
      ended = true;
      reactor.off(fd);
      try {
        kernel.close(fd);
      } catch {}
      wake?.();
    };
    const pump = () => {
      while (!ended) {
        const r = codec.read(fd);
        if (typeof r === "number") {
          if (r !== -EAGAIN2)
            end();
          break;
        }
        queue.push(r);
        queued += r.length;
        while (queued > OUTPUT_KEEP && queue.length > 1)
          queued -= queue.shift().length;
      }
      wake?.();
    };
    reactor.on(fd, 1 | 16, pump);
    lifetime.signal.addEventListener("abort", end, { once: true });
    return new ReadableStream({
      async pull(controller) {
        while (queue.length === 0 && !ended)
          await new Promise((resolve) => wake = resolve);
        wake = undefined;
        if (queue.length) {
          const chunks = queue;
          queue = [];
          queued = 0;
          for (const c of chunks)
            controller.enqueue(c);
        } else
          controller.close();
      },
      cancel: end
    });
  }
  const exitOf = (status) => {
    const signal = { [128 + 9]: "SIGKILL", [128 + 15]: "SIGTERM", [128 + 2]: "SIGINT", [128 + 1]: "SIGHUP" }[status];
    return signal ? { code: null, signal } : { code: status, signal: null };
  };
  const launchEnv = (launch) => launch.programs?.length ? { ...launch.env, BAT_PROGRAMS: launch.programs.join(",") } : launch.env ?? {};
  async function spawnTerminal(launch, terminal) {
    live();
    if (!launch.argv?.length)
      throw new Error("spawnTerminal: empty argv");
    const { master, slave } = kernel.ttyOpen(terminal.cols, terminal.rows);
    let child;
    try {
      kernel.ttyResize(master, terminal.cols, terminal.rows, terminal.xpixel, terminal.ypixel);
      child = kernel.spawn({ exec: launch.argv[0], argv: launch.argv, env: launchEnv(launch), cwd: launch.cwd ?? "/", stdio: [{ fd: slave }, { fd: slave }, { fd: slave }] });
    } catch (e) {
      kernel.close(master);
      kernel.close(slave);
      throw e;
    }
    kernel.close(slave);
    kernel.setNonblock(master, true);
    let open = true;
    let drained;
    const eof = new Promise((resolve) => drained = resolve);
    const close = () => {
      if (!open)
        return;
      open = false;
      reactor.off(master);
      try {
        kernel.close(master);
      } catch {}
      drained();
    };
    const buf = new Uint8Array(65536);
    const pump = () => {
      while (open) {
        const n = kernel.readRaw(master, buf);
        if (n > 0) {
          try {
            terminal.onOutput(buf.slice(0, n));
          } catch (e) {
            console.error(e);
          }
        } else {
          if (n !== -EAGAIN2)
            close();
          break;
        }
      }
    };
    reactor.on(master, 1 | 16, pump);
    lifetime.signal.addEventListener("abort", close, { once: true });
    let gone = false;
    const exited = new Promise((resolve) => {
      reactor.onChild(child.pid, (status) => {
        gone = true;
        terminals.delete(child.pid);
        try {
          kernel.waitpid(child.pid, true);
        } catch {}
        Promise.race([eof, new Promise((r) => setTimeout(r, 200))]).then(() => {
          close();
          resolve(exitOf(status));
        });
      });
    });
    const handle = {
      pid: child.pid,
      exited,
      write(data) {
        if (!open)
          return;
        const bytes = typeof data === "string" ? encoder3.encode(data) : data;
        for (let off = 0;off < bytes.length; off += 32768)
          kernel.write(master, bytes.subarray(off, off + 32768));
      },
      resize(size) {
        if (open)
          kernel.ttyResize(master, size.cols, size.rows, size.xpixel, size.ypixel);
      },
      kill(signal = "SIGTERM") {
        if (gone)
          return;
        try {
          kernel.kill(child.pid, signal === "SIGKILL" ? 9 : 15);
        } catch {}
      }
    };
    terminals.set(child.pid, handle);
    return handle;
  }
  const terminals = new Map;
  async function spawn(launch) {
    live();
    if (!launch.argv?.length)
      throw new Error("spawn: empty argv");
    const env = launchEnv(launch);
    const child = kernel.spawn({ exec: launch.argv[0], argv: launch.argv, env, cwd: launch.cwd ?? "/", stdio: ["pipe", "pipe", "pipe"] });
    const [stdinFd, stdoutFd, stderrFd] = child.stdio;
    kernel.setNonblock(stdinFd, true);
    let stdinOpen = true;
    let wantOut = false;
    const closeIn = () => {
      if (!stdinOpen)
        return;
      stdinOpen = false;
      reactor.off(stdinFd);
      try {
        kernel.close(stdinFd);
      } catch {}
    };
    const stdin = createOutbox(codec, stdinFd, (on) => {
      wantOut = on;
      if (stdinOpen) {
        if (on)
          reactor.on(stdinFd, 4 | 8, () => stdin.flush());
        else
          reactor.off(stdinFd);
      }
    });
    let gone = false;
    const exited = new Promise((resolve) => {
      reactor.onChild(child.pid, (status) => {
        gone = true;
        processes.delete(child.pid);
        closeIn();
        try {
          kernel.waitpid(child.pid, true);
        } catch {}
        resolve(exitOf(status));
      });
    });
    const proc = {
      pid: child.pid,
      stdout: output(stdoutFd),
      stderr: output(stderrFd),
      exited,
      write(data) {
        if (stdinOpen && !gone)
          stdin.write(typeof data === "string" ? encoder3.encode(data) : data);
      },
      closeStdin() {
        if (stdinOpen)
          stdin.write("", false, closeIn);
      },
      kill(signal = "SIGTERM") {
        if (gone)
          return;
        try {
          kernel.kill(child.pid, signal === "SIGKILL" ? 9 : 15);
        } catch {}
      }
    };
    processes.set(child.pid, proc);
    return proc;
  }
  const host = {
    fs,
    hostOrigin: `${location.protocol}//${HOST_ALIAS}${location.port ? `:${location.port}` : ""}`,
    spawn,
    spawnTerminal,
    endpoint,
    setHostPaths(port, prefixes) {
      hostPaths[port] = [...prefixes];
      toWorker({ t: "bat-host-paths", hostPaths });
    },
    setGuestPaths(port, routes) {
      guestPaths[port] = { ...routes };
      toWorker({ t: "bat-guest-paths", guestPaths });
    },
    started: resumeImages,
    flush: () => {
      try {
        live();
      } catch (e) {
        return Promise.reject(e);
      }
      return kernel.flush();
    },
    close() {
      return closing ??= (async () => {
        const running = [...processes.values(), ...terminals.values()];
        for (const p of running)
          p.kill("SIGKILL");
        await Promise.race([Promise.all(running.map((p) => p.exited)), new Promise((r) => setTimeout(r, 2000))]);
        await kernel.flush().catch(() => {});
        await Promise.race([booted.kerneld("compact").catch(() => {}), new Promise((r) => setTimeout(r, 2000))]);
        toWorker({ t: "bat-closed" });
        navigator.serviceWorker?.removeEventListener("message", onWorkerMessage);
        reactor.stop();
        teardown();
      })();
    },
    timings,
    kernel
  };
  options.signal?.addEventListener("abort", () => void host.close(), { once: true, signal: outside.signal });
  if (options.signal?.aborted) {
    await host.close();
    throw options.signal.reason;
  }
  addEventListener("pagehide", () => toWorker({ t: "bat-closed" }), { signal: outside.signal });
  timings.total = performance.now() - t0;
  trace("boot.done");
  timed("done");
  progress({ phase: "ready" });
  return host;
}
export {
  HOST_ALIAS,
  bootRuntime,
  preloadRuntime,
  resetWorkspace
};
